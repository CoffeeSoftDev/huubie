<?php
require_once __DIR__ . '/../../conf/_Session.php';
if (empty($_POST['opc'])) exit(0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

require_once '../mdl/mdl-tenant.php';

// Colores del acento del tema para badge(): van como variables CSS y no como
// hex para que sigan al tema elegido (ver src/js/tailwind-theme.js).
const ACCENT_TEXT = 'var(--accent-soft-fg, rgb(var(--brand-700, 168 74 51)))';
const ACCENT_BG   = 'var(--accent-soft-bg, rgb(var(--brand-100, 247 227 220)))';

// Controlador del Administrador del Tenant: super-admin global.
class ctrl extends mdl {

    /* Valores de enum válidos por entidad (whitelist). */
    private $companyStatuses = ['pending', 'active', 'suspendend', 'cancelled'];
    private $subStatuses      = ['trial', 'active', 'past_due', 'cancelled', 'expired'];
    private $billingCycles    = ['monthly', 'yearly', 'lifetime'];
    private $paymentStatuses  = ['paid', 'pending', 'failed', 'refunded'];
    private $discountTypes    = ['percent', 'fixed'];

    // Los permisos se resuelven por roles.code: un rol de empresa con el código
    // superadmin le daría acceso total a toda la plataforma a quien lo tenga.
    private $reservedRoleCodes = ['superadmin', 'dueno'];

    public function __construct() {
        parent::__construct();
    }

    function init() {
        return [
            'status'                 => 200,
            // Filtro genérico activo/inactivo (planes).
            'statusFilter'           => [
                ['id' => '1', 'valor' => 'Activos'],
                ['id' => '0', 'valor' => 'Inactivos']
            ],
            // users.status es enum de texto; el filtro manda 1/0 y el ctrl lo traduce.
            'userStatusFilter'       => [
                ['id' => '1', 'valor' => 'Activos'],
                ['id' => '0', 'valor' => 'Inactivos']
            ],
            'companyStatusFilter'    => [
                ['id' => 'active',     'valor' => 'Activas'],
                ['id' => 'pending',    'valor' => 'Pendientes'],
                ['id' => 'suspendend', 'valor' => 'Suspendidas'],
                ['id' => 'cancelled',  'valor' => 'Canceladas']
            ],
            'subscriptionStatusFilter' => [
                ['id' => 'active',   'valor' => 'Activas'],
                ['id' => 'trial',    'valor' => 'Prueba'],
                ['id' => 'past_due', 'valor' => 'Vencidas'],
                ['id' => 'cancelled','valor' => 'Canceladas'],
                ['id' => 'expired',  'valor' => 'Expiradas']
            ],
            'billingCycles'          => [
                ['id' => 'monthly',  'valor' => 'Mensual'],
                ['id' => 'yearly',   'valor' => 'Anual'],
                ['id' => 'lifetime', 'valor' => 'De por vida']
            ],
            'companyStatusOptions'   => [
                ['id' => 'pending',    'valor' => 'Pendiente'],
                ['id' => 'active',     'valor' => 'Activa'],
                ['id' => 'suspendend', 'valor' => 'Suspendida'],
                ['id' => 'cancelled',  'valor' => 'Cancelada']
            ],
            'subscriptionStatusOptions' => [
                ['id' => 'trial',    'valor' => 'Prueba'],
                ['id' => 'active',   'valor' => 'Activa'],
                ['id' => 'past_due', 'valor' => 'Vencida'],
                ['id' => 'cancelled','valor' => 'Cancelada'],
                ['id' => 'expired',  'valor' => 'Expirada']
            ],
            'paymentStatusFilter'    => [
                ['id' => 'paid',     'valor' => 'Pagados'],
                ['id' => 'pending',  'valor' => 'Pendientes'],
                ['id' => 'failed',   'valor' => 'Fallidos'],
                ['id' => 'refunded', 'valor' => 'Reembolsados']
            ],
            'paymentStatusOptions'   => [
                ['id' => 'pending',  'valor' => 'Pendiente'],
                ['id' => 'paid',     'valor' => 'Pagado'],
                ['id' => 'failed',   'valor' => 'Fallido'],
                ['id' => 'refunded', 'valor' => 'Reembolsado']
            ],
            'discountTypeOptions'    => [
                ['id' => 'percent', 'valor' => 'Porcentaje (%)'],
                ['id' => 'fixed',   'valor' => 'Monto fijo']
            ],
            'companies'              => $this->qCompaniesForSelect(),
            'plans'                  => $this->qPlansForSelect(),
            'subscriptions'          => $this->qSubscriptionsForSelect(),
            'modules'                => $this->qModulesForSelect(),
            'submodules'             => $this->qSubmodulesForSelect(),
            'sections'               => $this->qSectionsForSelect(),
            'roles'                  => $this->qRolesForSelect(),
            'typePermissions'        => $this->qTypePermissionsForSelect(),
            'branches'               => $this->qBranchesForSelect([$this->companyId()]),
            // Rutas navegables reales detectadas en disco (carpetas con index.php),
            // para que Módulos/Submódulos/Secciones elijan una ruta que sí existe.
            'routes'                 => $this->scanRoutes()
        ];
    }

    // Empresa del super-admin en sesión (fallback a la empresa base mientras no haya login).
    private function companyId() {
        return (int) ($_SESSION['company_id'] ?? 1);
    }

    // Escanea inventory/ (hasta 2 niveles) y devuelve las rutas navegables: las carpetas
    // que tienen index.php y, dentro de cada una, los archivos .php sueltos (ej.
    // operacion/almacen/salidas.php). Formato {id: ruta, valor: etiqueta}.
    private function scanRoutes() {
        // El controlador vive en inventory/tenant/ctrl/ -> la raíz del módulo es ../../
        $base = realpath(__DIR__ . '/../../');
        if ($base === false) return [];

        $skip   = ['conf', 'src', 'uploads', 'vendor', 'node_modules', '.git'];
        $routes = [];

        $top = @scandir($base);
        if ($top === false) return [];

        foreach ($top as $dir) {
            if ($dir === '.' || $dir === '..' || in_array($dir, $skip, true)) continue;
            $path = $base . DIRECTORY_SEPARATOR . $dir;
            if (!is_dir($path)) continue;

            // Nivel 1: carpeta con index.php + sus archivos .php directos.
            if (is_file($path . DIRECTORY_SEPARATOR . 'index.php')) {
                $routes[] = ['id' => $dir, 'valor' => $dir];
                $this->collectPhpFiles($path, $dir, $routes);
            }

            // Nivel 2: subcarpetas con index.php (ej. operacion/almacen, admin/usuarios).
            $sub = @scandir($path);
            if ($sub === false) continue;
            foreach ($sub as $child) {
                if ($child === '.' || $child === '..') continue;
                $childPath = $path . DIRECTORY_SEPARATOR . $child;
                if (is_dir($childPath) && is_file($childPath . DIRECTORY_SEPARATOR . 'index.php')) {
                    $route = $dir . '/' . $child;
                    $routes[] = ['id' => $route, 'valor' => $route];
                    // Archivos .php directos de la subcarpeta (ej. operacion/almacen/salidas.php).
                    $this->collectPhpFiles($childPath, $route, $routes);
                }
            }
        }

        // Orden alfabético por ruta para una lista predecible.
        usort($routes, function ($a, $b) { return strcmp($a['id'], $b['id']); });
        return $routes;
    }

    // Agrega a $routes los archivos .php que viven directamente en $dirPath (sin entrar a
    // subcarpetas), omitiendo index.php porque la carpeta ya lo representa como ruta.
    private function collectPhpFiles($dirPath, $prefix, &$routes) {
        $files = @scandir($dirPath);
        if ($files === false) return;
        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || $file === 'index.php') continue;
            if (strtolower(substr($file, -4)) !== '.php') continue;
            if (!is_file($dirPath . DIRECTORY_SEPARATOR . $file)) continue;
            $route = $prefix . '/' . $file;
            $routes[] = ['id' => $route, 'valor' => $route];
        }
    }

    /* ===== Empresas (companies) ===== */

    function lsCompanies() {
        $status = $this->companyStatusIn($_POST['status'] ?? 'active');
        $ls = $this->qCompanies([$status]);

        $row = [];
        foreach ($ls as $c) {
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'companies.editCompany(' . $c['id'] . ')'
            ];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-palette"></i>',
                'title'   => 'Temas',
                'onclick' => 'companies.editCompanyThemes(' . $c['id'] . ')'
            ];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral', true),
                'html'    => '<i class="icon-cog"></i>',
                'onclick' => "companies.changeStatus(" . $c['id'] . ", '" . $c['status'] . "')"
            ];

            $row[] = [
                'id'        => $c['id'],
                'Empresa'   => renderAvatar($c['name'] ?? ''),
                'RFC'       => $c['rfc'] ?: '-',
                'Base de datos' => $c['database_name'] ?: '-',
                'Ubicación' => $c['ubication'] ?: '-',
                'Estado'    => renderCompanyStatus($c['status']),
                'Creación'  => $c['created'] ?: '-',
                'a'         => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getCompany() {
        $data = $this->qCompany([(int) $_POST['id']]);
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'OK' : 'Empresa no encontrada',
            'data'    => $data
        ];
    }

    function addCompany() {
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre de la empresa es obligatorio'];
        }
        $status = $this->companyStatusIn($_POST['status'] ?? 'pending');

        $ok = $this->qInsertCompany([
            $name,
            trim($_POST['database_name'] ?? '') ?: null,
            trim($_POST['ubication'] ?? '') ?: null,
            trim($_POST['rfc'] ?? '') ?: null,
            $status
        ]);

        // Nace con sus orígenes, motivos, estados de traspaso y colores de los estados de la
        // requisición: Entradas, Salidas, Traspasos y Requisiciones los buscan por code
        // dentro de la empresa.
        if ($ok) $this->qSeedInventoryCatalogs([$name]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Empresa creada correctamente' : 'No se pudo crear la empresa'
        ];
    }

    function editCompany() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre de la empresa es obligatorio'];
        }
        if (!$this->qCompany([$id])) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }

        $ok = $this->qUpdateCompany([
            $name,
            trim($_POST['database_name'] ?? '') ?: null,
            trim($_POST['ubication'] ?? '') ?: null,
            trim($_POST['rfc'] ?? '') ?: null,
            $id
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Empresa actualizada correctamente' : 'No se pudo actualizar la empresa'
        ];
    }

    function changeCompanyStatus() {
        $id     = (int) $_POST['id'];
        $status = $this->companyStatusIn($_POST['status'] ?? '');
        if (!in_array($_POST['status'] ?? '', $this->companyStatuses, true)) {
            return ['status' => 400, 'message' => 'Estado de empresa no válido'];
        }
        if (!$this->qCompany([$id])) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }

        $ok = $this->qSetCompanyStatus([$status, $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Estado de la empresa actualizado' : 'No se pudo actualizar el estado'
        ];
    }

    /* ===== Temas por empresa (company_themes) ===== */

    // Temas asignables y los que ya tiene la empresa, para el modal "Temas".
    function getCompanyThemes() {
        $companyId = (int) $_POST['company_id'];
        $company   = $this->qCompany([$companyId]);

        if (!$company) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }

        return [
            'status'   => 200,
            'company'  => $company['name'],
            'themes'   => $this->lsAssignableThemes(),
            'selected' => array_map('intval', array_column($this->listCompanyThemes([$companyId]), 'theme_id'))
        ];
    }

    // Reemplaza los temas de la empresa por los marcados. El modal manda un checkbox por
    // tema (theme_9=true) y solo viajan los marcados. Solo entran temas asignables:
    // el de por defecto lo ven todas las empresas siempre.
    function editCompanyThemes() {
        $companyId = (int) $_POST['company_id'];

        if (!$this->qCompany([$companyId])) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }

        $checked = [];
        foreach ($_POST as $key => $value) {
            if (preg_match('/^theme_(\d+)$/', $key, $m) && $value === 'true') $checked[] = (int) $m[1];
        }

        $assignable = array_map('intval', array_column($this->lsAssignableThemes(), 'id'));
        $selected   = array_intersect($assignable, $checked);

        $this->deleteCompanyThemesById([
            'where' => 'company_id',
            'data'  => [$companyId]
        ]);

        $now    = date('Y-m-d H:i:s');
        $failed = 0;

        foreach ($selected as $themeId) {
            $ok = $this->createCompanyTheme($this->util->sql([
                'company_id' => $companyId,
                'theme_id'   => $themeId,
                'created_at' => $now
            ]));

            if (!$ok) $failed++;
        }

        return [
            'status'  => $failed === 0 ? 200 : 500,
            'message' => $failed === 0 ? 'Temas de la empresa actualizados' : 'No se pudieron guardar todos los temas'
        ];
    }

    /* ===== Planes (plans) ===== */

    function lsPlans() {
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $ls = $this->qPlans([$active]);

        $row = [];
        foreach ($ls as $p) {
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'plans.editPlan(' . $p['id'] . ')'
            ];
            if ($p['is_active'] == 1) {
                $a[] = [
                    'class'   => $this->actionBtnClass('danger', true),
                    'html'    => '<i class="icon-toggle-on"></i>',
                    'onclick' => 'plans.togglePlan(' . $p['id'] . ', 0)'
                ];
            } else {
                $a[] = [
                    'class'   => $this->actionBtnClass('neutral', true),
                    'html'    => '<i class="icon-toggle-off"></i>',
                    'onclick' => 'plans.togglePlan(' . $p['id'] . ', 1)'
                ];
            }

            $price = number_format((float) $p['price'], 2) . ' ' . ($p['currency'] ?: '');
            $row[] = [
                'id'         => $p['id'],
                'Código'     => $p['code'] ?: '-',
                'Plan'       => htmlspecialchars($p['name'] ?? ''),
                'Precio'     => trim($price),
                'Ciclo'      => renderBillingCycle($p['billing_cycle']),
                'Usuarios'   => $p['max_users'] ?? '∞',
                'Sucursales' => $p['max_branches'] ?? '∞',
                'Prueba'     => ($p['trial_days'] ?? 0) . ' días',
                'Estado'     => renderActive($p['is_active']),
                'a'          => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getPlan() {
        $data = $this->qPlan([(int) $_POST['id']]);
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'OK' : 'Plan no encontrado',
            'data'    => $data
        ];
    }

    function addPlan() {
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre del plan es obligatorio'];
        }
        $cycle = in_array($_POST['billing_cycle'] ?? '', $this->billingCycles, true)
            ? $_POST['billing_cycle'] : 'monthly';

        $ok = $this->qInsertPlan([
            trim($_POST['code'] ?? '') ?: null,
            $name,
            (float) ($_POST['price'] ?? 0),
            trim($_POST['currency'] ?? '') ?: 'MXN',
            $cycle,
            $this->intOrNull($_POST['max_users'] ?? ''),
            $this->intOrNull($_POST['max_branches'] ?? ''),
            $this->intOrNull($_POST['trial_days'] ?? '')
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Plan creado correctamente' : 'No se pudo crear el plan'
        ];
    }

    function editPlan() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre del plan es obligatorio'];
        }
        if (!$this->qPlan([$id])) {
            return ['status' => 404, 'message' => 'Plan no encontrado'];
        }
        $cycle = in_array($_POST['billing_cycle'] ?? '', $this->billingCycles, true)
            ? $_POST['billing_cycle'] : 'monthly';

        $ok = $this->qUpdatePlan([
            trim($_POST['code'] ?? '') ?: null,
            $name,
            (float) ($_POST['price'] ?? 0),
            trim($_POST['currency'] ?? '') ?: 'MXN',
            $cycle,
            $this->intOrNull($_POST['max_users'] ?? ''),
            $this->intOrNull($_POST['max_branches'] ?? ''),
            $this->intOrNull($_POST['trial_days'] ?? ''),
            $id
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Plan actualizado correctamente' : 'No se pudo actualizar el plan'
        ];
    }

    function togglePlan() {
        $id     = (int) $_POST['id'];
        $active = (int) $_POST['active'];
        if (!$this->qPlan([$id])) {
            return ['status' => 404, 'message' => 'Plan no encontrado'];
        }

        $ok = $this->qSetPlanActive([$active, $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? ($active ? 'Plan activado' : 'Plan desactivado') : 'No se pudo actualizar el estado'
        ];
    }

    /* ===== Suscripciones (subscriptions) ===== */

    function lsSubscriptions() {
        $status = $this->subStatusIn($_POST['status'] ?? 'active');
        $ls = $this->qSubscriptions([$status]);

        $row = [];
        foreach ($ls as $s) {
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'subscriptions.editSubscription(' . $s['id'] . ')'
            ];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral', true),
                'html'    => '<i class="icon-cog"></i>',
                'onclick' => "subscriptions.changeStatus(" . $s['id'] . ", '" . $s['status'] . "')"
            ];

            $row[] = [
                'id'        => $s['id'],
                'Empresa'   => htmlspecialchars($s['company_name'] ?? '—'),
                'Plan'      => htmlspecialchars($s['plan_name'] ?? '—'),
                'Inicio'    => $s['starts'] ?: '-',
                'Fin'       => $s['ends'] ?: '-',
                'Próx. cobro' => $s['next_billing'] ?: '-',
                'Estado'    => renderSubStatus($s['status']),
                'a'         => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getSubscription() {
        $data = $this->qSubscription([(int) $_POST['id']]);
        if ($data) {
            // El front espera strings para autorrellenar selects.
            $data['company_id'] = (string) $data['company_id'];
            $data['plan_id']    = (string) $data['plan_id'];
            // Los inputs type=date esperan 'YYYY-MM-DD' (recortar la parte de hora).
            $data['starts_at']         = $data['starts_at']         ? substr($data['starts_at'], 0, 10)         : '';
            $data['ends_at']           = $data['ends_at']           ? substr($data['ends_at'], 0, 10)           : '';
            $data['next_billing_date'] = $data['next_billing_date'] ? substr($data['next_billing_date'], 0, 10) : '';
        }
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'OK' : 'Suscripción no encontrada',
            'data'    => $data
        ];
    }

    function addSubscription() {
        $companyId = (int) ($_POST['company_id'] ?? 0);
        $planId    = (int) ($_POST['plan_id'] ?? 0);
        $status    = $this->subStatusIn($_POST['status'] ?? 'trial');

        if ($companyId <= 0 || $planId <= 0) {
            return ['status' => 400, 'message' => 'Empresa y plan son obligatorios'];
        }
        if (!$this->qCompanyHasSubscription([$companyId])) {
            return ['status' => 400, 'message' => 'La empresa seleccionada no es válida'];
        }
        if (!$this->qPlanExists([$planId])) {
            return ['status' => 400, 'message' => 'El plan seleccionado no es válido'];
        }

        $ok = $this->qInsertSubscription([
            $companyId,
            $planId,
            $status,
            $this->dateOrNull($_POST['starts_at'] ?? ''),
            $this->dateOrNull($_POST['ends_at'] ?? ''),
            $this->dateOrNull($_POST['next_billing_date'] ?? ''),
            trim($_POST['external_reference'] ?? '') ?: null
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Suscripción creada correctamente' : 'No se pudo crear la suscripción'
        ];
    }

    function editSubscription() {
        $id        = (int) $_POST['id'];
        $companyId = (int) ($_POST['company_id'] ?? 0);
        $planId    = (int) ($_POST['plan_id'] ?? 0);
        $status    = $this->subStatusIn($_POST['status'] ?? 'trial');

        if ($companyId <= 0 || $planId <= 0) {
            return ['status' => 400, 'message' => 'Empresa y plan son obligatorios'];
        }
        if (!$this->qSubscription([$id])) {
            return ['status' => 404, 'message' => 'Suscripción no encontrada'];
        }

        $ok = $this->qUpdateSubscription([
            $companyId,
            $planId,
            $status,
            $this->dateOrNull($_POST['starts_at'] ?? ''),
            $this->dateOrNull($_POST['ends_at'] ?? ''),
            $this->dateOrNull($_POST['next_billing_date'] ?? ''),
            trim($_POST['external_reference'] ?? '') ?: null,
            $id
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Suscripción actualizada correctamente' : 'No se pudo actualizar la suscripción'
        ];
    }

    function changeSubscriptionStatus() {
        $id = (int) $_POST['id'];
        if (!in_array($_POST['status'] ?? '', $this->subStatuses, true)) {
            return ['status' => 400, 'message' => 'Estado de suscripción no válido'];
        }
        if (!$this->qSubscription([$id])) {
            return ['status' => 404, 'message' => 'Suscripción no encontrada'];
        }

        $ok = $this->qSetSubscriptionStatus([$_POST['status'], $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Estado de la suscripción actualizado' : 'No se pudo actualizar el estado'
        ];
    }

    /* ===== Pagos (payment_history) ===== */

    function lsPayments() {
        $status = $this->paymentStatusIn($_POST['status'] ?? 'paid');
        $ls = $this->qPayments([$status]);

        $row = [];
        foreach ($ls as $p) {
            // El me-1 de "cambiar estado" depende de si el boton de factura la
            // sigue en la fila: si no hay factura, "cambiar estado" es el ultimo.
            $hasInvoice = !empty($p['invoice_url']);
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'payments.editPayment(' . $p['id'] . ')'
            ];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral', !$hasInvoice),
                'html'    => '<i class="icon-cog"></i>',
                'onclick' => "payments.changeStatus(" . $p['id'] . ", '" . $p['status'] . "')"
            ];
            if ($hasInvoice) {
                $a[] = [
                    'class'   => $this->actionBtnClass('neutral', true),
                    'html'    => '<i class="icon-link-ext"></i>',
                    'onclick' => "window.open('" . htmlspecialchars($p['invoice_url'], ENT_QUOTES) . "', '_blank')"
                ];
            }

            $amount = number_format((float) $p['amount'], 2) . ' ' . ($p['currency'] ?: '');
            $row[] = [
                'id'        => $p['id'],
                'Empresa'   => htmlspecialchars($p['company_name'] ?? '—'),
                'Monto'     => trim($amount),
                'Pasarela'  => $p['gateway'] ?: '-',
                'Transacción' => $p['transaction_id'] ?: '-',
                'Pagado'    => $p['paid'] ?: '-',
                'Estado'    => renderPaymentStatus($p['status']),
                'a'         => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getPayment() {
        $data = $this->qPayment([(int) $_POST['id']]);
        if ($data) {
            $data['company_id']      = (string) $data['company_id'];
            $data['subscription_id'] = $data['subscription_id'] !== null ? (string) $data['subscription_id'] : '';
            $data['paid_at']         = $data['paid_at'] ? substr($data['paid_at'], 0, 10) : '';
        }
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'OK' : 'Pago no encontrado',
            'data'    => $data
        ];
    }

    function addPayment() {
        $companyId = (int) ($_POST['company_id'] ?? 0);
        $amount    = (float) ($_POST['amount'] ?? 0);
        if ($companyId <= 0) {
            return ['status' => 400, 'message' => 'La empresa es obligatoria'];
        }
        if ($amount <= 0) {
            return ['status' => 400, 'message' => 'El monto debe ser mayor a 0'];
        }
        if (!$this->qCompanyHasSubscription([$companyId])) {
            return ['status' => 400, 'message' => 'La empresa seleccionada no es válida'];
        }
        $status = $this->paymentStatusIn($_POST['status'] ?? 'pending');

        $ok = $this->qInsertPayment([
            $companyId,
            $this->selectOrNull($_POST['subscription_id'] ?? ''),
            $amount,
            trim($_POST['currency'] ?? '') ?: 'MXN',
            $status,
            trim($_POST['gateway'] ?? '') ?: null,
            $this->intOrNull($_POST['transaction_id'] ?? ''),
            $this->dateOrNull($_POST['paid_at'] ?? ''),
            trim($_POST['invoice_url'] ?? '') ?: null
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Pago registrado correctamente' : 'No se pudo registrar el pago'
        ];
    }

    function editPayment() {
        $id        = (int) $_POST['id'];
        $companyId = (int) ($_POST['company_id'] ?? 0);
        $amount    = (float) ($_POST['amount'] ?? 0);
        if ($companyId <= 0) {
            return ['status' => 400, 'message' => 'La empresa es obligatoria'];
        }
        if ($amount <= 0) {
            return ['status' => 400, 'message' => 'El monto debe ser mayor a 0'];
        }
        if (!$this->qPayment([$id])) {
            return ['status' => 404, 'message' => 'Pago no encontrado'];
        }
        $status = $this->paymentStatusIn($_POST['status'] ?? 'pending');

        $ok = $this->qUpdatePayment([
            $companyId,
            $this->selectOrNull($_POST['subscription_id'] ?? ''),
            $amount,
            trim($_POST['currency'] ?? '') ?: 'MXN',
            $status,
            trim($_POST['gateway'] ?? '') ?: null,
            $this->intOrNull($_POST['transaction_id'] ?? ''),
            $this->dateOrNull($_POST['paid_at'] ?? ''),
            trim($_POST['invoice_url'] ?? '') ?: null,
            $id
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Pago actualizado correctamente' : 'No se pudo actualizar el pago'
        ];
    }

    function changePaymentStatus() {
        $id = (int) $_POST['id'];
        if (!in_array($_POST['status'] ?? '', $this->paymentStatuses, true)) {
            return ['status' => 400, 'message' => 'Estado de pago no válido'];
        }
        if (!$this->qPayment([$id])) {
            return ['status' => 404, 'message' => 'Pago no encontrado'];
        }

        $ok = $this->qSetPaymentStatus([$_POST['status'], $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Estado del pago actualizado' : 'No se pudo actualizar el estado'
        ];
    }

    /* ===== Cupones (coupons) ===== */

    function lsCoupons() {
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $ls = $this->qCoupons([$active]);

        $row = [];
        foreach ($ls as $c) {
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral'),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'coupons.editCoupon(' . $c['id'] . ')'
            ];
            if ($c['is_active'] == 1) {
                $a[] = [
                    'class'   => $this->actionBtnClass('danger', true),
                    'html'    => '<i class="icon-toggle-on"></i>',
                    'onclick' => 'coupons.toggleCoupon(' . $c['id'] . ', 0)'
                ];
            } else {
                $a[] = [
                    'class'   => $this->actionBtnClass('neutral', true),
                    'html'    => '<i class="icon-toggle-off"></i>',
                    'onclick' => 'coupons.toggleCoupon(' . $c['id'] . ', 1)'
                ];
            }

            $row[] = [
                'id'         => $c['id'],
                'Código'     => htmlspecialchars($c['code'] ?? ''),
                'Descripción'=> $c['description'] ? htmlspecialchars($c['description']) : '-',
                'Descuento'  => renderDiscount($c['discount_type'], $c['discount_value']),
                'Usos'       => ($c['times_redeemed'] ?? 0) . ' / ' . ($c['max_redemptions'] ?? '∞'),
                'Vigencia'   => ($c['valid_from'] ?: '—') . ' → ' . ($c['valid_to'] ?: '—'),
                'Estado'     => renderActive($c['is_active']),
                'a'          => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getCoupon() {
        $data = $this->qCoupon([(int) $_POST['id']]);
        if ($data) {
            $data['valid_from'] = $data['valid_from'] ? substr($data['valid_from'], 0, 10) : '';
            $data['valid_to']   = $data['valid_to']   ? substr($data['valid_to'], 0, 10)   : '';
        }
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'OK' : 'Cupón no encontrado',
            'data'    => $data
        ];
    }

    function addCoupon() {
        $code = trim($_POST['code'] ?? '');
        if ($code === '') {
            return ['status' => 400, 'message' => 'El código del cupón es obligatorio'];
        }
        if ($this->qCodeExists([$code])) {
            return ['status' => 409, 'message' => 'Ya existe un cupón con ese código'];
        }
        $type = in_array($_POST['discount_type'] ?? '', $this->discountTypes, true)
            ? $_POST['discount_type'] : 'percent';

        $ok = $this->qInsertCoupon([
            $code,
            trim($_POST['description'] ?? '') ?: null,
            $type,
            (int) ($_POST['discount_value'] ?? 0),
            $this->intOrNull($_POST['max_redemptions'] ?? '') ?? 1,
            $this->dateOrNull($_POST['valid_from'] ?? ''),
            $this->dateOrNull($_POST['valid_to'] ?? '')
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Cupón creado correctamente' : 'No se pudo crear el cupón'
        ];
    }

    function editCoupon() {
        $id   = (int) $_POST['id'];
        $code = trim($_POST['code'] ?? '');
        if ($code === '') {
            return ['status' => 400, 'message' => 'El código del cupón es obligatorio'];
        }
        if (!$this->qCoupon([$id])) {
            return ['status' => 404, 'message' => 'Cupón no encontrado'];
        }
        if ($this->qCodeExistsExcept([$code, $id])) {
            return ['status' => 409, 'message' => 'Ya existe otro cupón con ese código'];
        }
        $type = in_array($_POST['discount_type'] ?? '', $this->discountTypes, true)
            ? $_POST['discount_type'] : 'percent';

        $ok = $this->qUpdateCoupon([
            $code,
            trim($_POST['description'] ?? '') ?: null,
            $type,
            (int) ($_POST['discount_value'] ?? 0),
            $this->intOrNull($_POST['max_redemptions'] ?? '') ?? 1,
            $this->dateOrNull($_POST['valid_from'] ?? ''),
            $this->dateOrNull($_POST['valid_to'] ?? ''),
            $id
        ]);

        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Cupón actualizado correctamente' : 'No se pudo actualizar el cupón'
        ];
    }

    function toggleCoupon() {
        $id     = (int) $_POST['id'];
        $active = (int) $_POST['active'];
        if (!$this->qCoupon([$id])) {
            return ['status' => 404, 'message' => 'Cupón no encontrado'];
        }

        $ok = $this->qSetCouponActive([$active, $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? ($active ? 'Cupón activado' : 'Cupón desactivado') : 'No se pudo actualizar el estado'
        ];
    }

    /* ===== Canjes de cupón (coupon_redemptions) ===== */

    function lsRedemptions() {
        $ls = $this->qRedemptions([]);

        $row = [];
        foreach ($ls as $r) {
            $row[] = [
                'id'          => $r['id'],
                'Cupón'       => $r['coupon_code'] ? htmlspecialchars($r['coupon_code']) : '—',
                'Empresa'     => htmlspecialchars($r['company_name'] ?? '—'),
                'Suscripción' => $r['subscription_id'] ? '#' . $r['subscription_id'] : '-',
                'Canjeado'    => $r['redeemed'] ?: '-'
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    /* ===== Módulos (modules) ===== */

    function lsModules() {
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $ls = $this->qModules([$active]);

        $row = [];
        foreach ($ls as $m) {
            $row[] = [
                'id'      => $m['id'],
                'Nombre'  => htmlspecialchars($m['name'] ?? ''),
                'Código'  => $m['code'] ?: '-',
                'Ruta'    => $m['route'] ?: '-',
                'Orden'   => $m['orden'] ?? 0,
                'Estado'  => renderActive($m['is_active']),
                'a'       => $this->toggleActions('modules', 'editModule', 'toggleModule', $m['id'], $m['is_active'])
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getModule() {
        $data = $this->qModule([(int) $_POST['id']]);
        return ['status' => $data ? 200 : 404, 'message' => $data ? 'OK' : 'Módulo no encontrado', 'data' => $data];
    }

    function addModule() {
        $name = trim($_POST['name'] ?? '');
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del módulo es obligatorio'];

        $ok = $this->qInsertModule([
            $name,
            trim($_POST['code'] ?? '') ?: null,
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['description'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            $this->qModulesMaxOrden() + 1
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Módulo creado correctamente' : 'No se pudo crear el módulo'];
    }

    function editModule() {
        $id     = (int) $_POST['id'];
        $name   = trim($_POST['name'] ?? '');
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del módulo es obligatorio'];
        $module = $this->qModule([$id]);
        if (!$module) return ['status' => 404, 'message' => 'Módulo no encontrado'];

        $ok = $this->qUpdateModule([
            $name,
            trim($_POST['code'] ?? '') ?: null,
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['description'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            (int) $module['orden'],
            $id
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Módulo actualizado correctamente' : 'No se pudo actualizar el módulo'];
    }

    function toggleModule() {
        $id = (int) $_POST['id'];
        if (!$this->qModule([$id])) return ['status' => 404, 'message' => 'Módulo no encontrado'];
        $ok = $this->qSetModuleActive([(int) $_POST['active'], $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? ((int) $_POST['active'] ? 'Módulo activado' : 'Módulo desactivado') : 'No se pudo actualizar el estado'];
    }

    /* ===== Submódulos (submodules) ===== */

    function lsSubmodules() {
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $ls = $this->qSubmodules([$active]);

        $row = [];
        foreach ($ls as $sm) {
            $row[] = [
                'id'      => $sm['id'],
                'Nombre'  => htmlspecialchars($sm['name'] ?? ''),
                'Módulo'  => $sm['module_name'] ? htmlspecialchars($sm['module_name']) : '<span class="italic text-gray-400">Sin módulo</span>',
                'Código'  => $sm['code'] ?: '-',
                'Ruta'    => $sm['route'] ?: '-',
                'Orden'   => $sm['orden'] ?? 0,
                'Estado'  => renderActive($sm['is_active']),
                'a'       => $this->toggleActions('submodules', 'editSubmodule', 'toggleSubmodule', $sm['id'], $sm['is_active'])
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getSubmodule() {
        $data = $this->qSubmodule([(int) $_POST['id']]);
        if ($data && $data['module_id'] !== null) $data['module_id'] = (string) $data['module_id'];
        return ['status' => $data ? 200 : 404, 'message' => $data ? 'OK' : 'Submódulo no encontrado', 'data' => $data];
    }

    function addSubmodule() {
        $name     = trim($_POST['name'] ?? '');
        $moduleId = (int) ($_POST['module_id'] ?? 0);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del submódulo es obligatorio'];
        if ($moduleId <= 0) return ['status' => 400, 'message' => 'Debes seleccionar un módulo'];

        $ok = $this->qInsertSubmodule([
            $name,
            trim($_POST['code'] ?? '') ?: null,
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['description'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            $this->intOrNull($_POST['orden'] ?? '') ?? 0,
            $moduleId
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Submódulo creado correctamente' : 'No se pudo crear el submódulo'];
    }

    function editSubmodule() {
        $id       = (int) $_POST['id'];
        $name     = trim($_POST['name'] ?? '');
        $moduleId = (int) ($_POST['module_id'] ?? 0);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del submódulo es obligatorio'];
        if ($moduleId <= 0) return ['status' => 400, 'message' => 'Debes seleccionar un módulo'];
        if (!$this->qSubmodule([$id])) return ['status' => 404, 'message' => 'Submódulo no encontrado'];

        $ok = $this->qUpdateSubmodule([
            $name,
            trim($_POST['code'] ?? '') ?: null,
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['description'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            $this->intOrNull($_POST['orden'] ?? '') ?? 0,
            $moduleId,
            $id
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Submódulo actualizado correctamente' : 'No se pudo actualizar el submódulo'];
    }

    // Renombrado en línea desde el acordeón de la pestaña Secciones: solo cambia el nombre.
    function renameSubmodule() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name']);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del submódulo es obligatorio'];
        if (!$this->qSubmodule([$id])) return ['status' => 404, 'message' => 'Submódulo no encontrado'];

        $ok = $this->qRenameSubmodule([$name, $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Submódulo actualizado correctamente' : 'No se pudo actualizar el submódulo'];
    }

    function toggleSubmodule() {
        $id = (int) $_POST['id'];
        if (!$this->qSubmodule([$id])) return ['status' => 404, 'message' => 'Submódulo no encontrado'];
        $ok = $this->qSetSubmoduleActive([(int) $_POST['active'], $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? ((int) $_POST['active'] ? 'Submódulo activado' : 'Submódulo desactivado') : 'No se pudo actualizar el estado'];
    }

    /* ===== Secciones (sections) ===== */

    function lsSections() {
        // 'all' = Estado Todos: activas e inactivas.
        $active = isset($_POST['active']) ? $_POST['active'] : '1';
        $ls = $active === 'all' ? $this->qSections([]) : $this->qSections([(int) $active]);

        $row = [];
        foreach ($ls as $s) {
            $row[] = [
                'id'         => $s['id'],
                'Nombre'     => htmlspecialchars($s['name'] ?? ''),
                'Módulo'     => $s['module_name'] ? htmlspecialchars($s['module_name']) : '-',
                'Submódulo'  => $s['submodule_name'] ? htmlspecialchars($s['submodule_name']) : '-',
                'Ruta'       => $s['route'] ?: '-',
                'Orden'      => $s['orden'] ?? 0,
                'Estado'     => renderActive($s['is_active']),
                'a'          => $this->toggleActions('sections', 'editSection', 'toggleSection', $s['id'], $s['is_active'])
            ];
        }

        return [
            'status'     => 200,
            'row'        => $row,
            'ls'         => $ls,
            'modules'    => $this->qModulesCatalog(),
            'submodules' => $this->qSubmodulesCatalog()
        ];
    }

    function getSection() {
        $data = $this->qSection([(int) $_POST['id']]);
        if ($data) {
            $data['module_id']    = $data['module_id'] !== null ? (string) $data['module_id'] : '';
            $data['submodule_id'] = $data['submodule_id'] !== null ? (string) $data['submodule_id'] : '';
        }
        return ['status' => $data ? 200 : 404, 'message' => $data ? 'OK' : 'Sección no encontrada', 'data' => $data];
    }

    function addSection() {
        $name     = trim($_POST['name'] ?? '');
        $moduleId = (int) ($_POST['module_id'] ?? 0);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre de la sección es obligatorio'];
        if ($moduleId <= 0) return ['status' => 400, 'message' => 'Debes seleccionar un módulo'];

        $ok = $this->qInsertSection([
            $name,
            trim($_POST['code'] ?? '') ?: null,
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            $this->intOrNull($_POST['orden'] ?? '') ?? 0,
            $moduleId,
            $this->selectOrNull($_POST['submodule_id'] ?? '')
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Sección creada correctamente' : 'No se pudo crear la sección'];
    }

    function editSection() {
        $id       = (int) $_POST['id'];
        $name     = trim($_POST['name'] ?? '');
        $moduleId = (int) ($_POST['module_id'] ?? 0);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre de la sección es obligatorio'];
        if ($moduleId <= 0) return ['status' => 400, 'message' => 'Debes seleccionar un módulo'];
        $section = $this->qSection([$id]);
        if (!$section) return ['status' => 404, 'message' => 'Sección no encontrada'];

        // El código es la llave de los permisos (Permissions::page/can): renombrar no lo cambia.
        $ok = $this->qUpdateSection([
            $name,
            $section['code'],
            trim($_POST['icon'] ?? '') ?: null,
            trim($_POST['route'] ?? '') ?: null,
            $this->intOrNull($_POST['orden'] ?? '') ?? 0,
            $moduleId,
            $this->selectOrNull($_POST['submodule_id'] ?? ''),
            $id
        ]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Sección actualizada correctamente' : 'No se pudo actualizar la sección'];
    }

    function toggleSection() {
        $id = (int) $_POST['id'];
        if (!$this->qSection([$id])) return ['status' => 404, 'message' => 'Sección no encontrada'];
        $ok = $this->qSetSectionActive([(int) $_POST['active'], $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? ((int) $_POST['active'] ? 'Sección activada' : 'Sección desactivada') : 'No se pudo actualizar el estado'];
    }

    // Solo se elimina una sección desactivada. Borra el acceso (sección + permisos);
    // la carpeta y los archivos de la ruta en disco no se tocan.
    function deleteSection() {
        $id = (int) $_POST['id'];
        $found = $this->qSection([$id]);
        if (!$found) return ['status' => 404, 'message' => 'Sección no encontrada'];
        if ((int) $found['is_active'] === 1) return ['status' => 400, 'message' => 'Solo se puede eliminar una sección desactivada'];

        $ok = $this->qDeleteSection([$id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Sección eliminada' : 'No se pudo eliminar la sección'];
    }

    // Renombrado en línea (doble clic en el nombre): solo cambia el nombre.
    function renameSection() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name']);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre de la sección es obligatorio'];
        if (!$this->qSection([$id])) return ['status' => 404, 'message' => 'Sección no encontrada'];

        $ok = $this->qRenameSection([$name, $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Sección actualizada correctamente' : 'No se pudo actualizar la sección'];
    }

    // Reorden por arrastre: llegan solo las secciones cuyo orden cambió, [{id, orden}, ...].
    function sortSections() {
        $items = json_decode($_POST['items'], true);

        $pairs = [];
        foreach ((is_array($items) ? $items : []) as $item) {
            $id    = (int) ($item['id'] ?? 0);
            $orden = (int) ($item['orden'] ?? 0);
            if ($id > 0 && $orden >= 0) $pairs[] = [$id, $orden];
        }
        if (!$pairs) return ['status' => 400, 'message' => 'No hay secciones que reordenar'];

        $ok = $this->qSortSections($pairs);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Orden actualizado' : 'No se pudo actualizar el orden'];
    }

    /* ===== Tipos de permiso (type_permissions) ===== */

    function lsTypePermissions() {
        $active = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $ls = $this->qTypePermissions([$active]);

        $row = [];
        foreach ($ls as $t) {
            $isActive = (int) $t['is_active'];
            // El toggle deja de ser el ultimo boton cuando Eliminar lo sigue.
            $a = $this->toggleActions('typePermissions', 'editTypePermission', 'toggleTypePermission', $t['id'], $isActive, $isActive === 1);
            if ($isActive === 0) {
                $a[] = [
                    'class'   => $this->actionBtnClass('danger', true),
                    'html'    => '<i class="icon-trash"></i>',
                    'onclick' => 'typePermissions.deleteTypePermission(' . $t['id'] . ')'
                ];
            }
            $row[] = [
                'id'     => $t['id'],
                'Nombre' => htmlspecialchars($t['name'] ?? ''),
                'Código' => $t['code'] ?: '-',
                'Estado' => renderActive($t['is_active']),
                'a'      => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getTypePermission() {
        $data = $this->qTypePermission([(int) $_POST['id']]);
        return ['status' => $data ? 200 : 404, 'message' => $data ? 'OK' : 'Tipo de permiso no encontrado', 'data' => $data];
    }

    // El código sale del nombre y ya no cambia: los módulos revisan las acciones
    // por código (conf/_Permissions.php), así renombrar el tipo no quita permisos.
    function addTypePermission() {
        $name = trim($_POST['name'] ?? '');
        $code = $this->slug($name);
        if ($name === '' || $code === '') return ['status' => 400, 'message' => 'El nombre es obligatorio'];
        if ($this->qTypeCodeExists([$code])) return ['status' => 409, 'message' => "Ya existe un tipo de permiso con el código «{$code}»"];

        $ok = $this->qInsertTypePermission([$name, $code]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Tipo de permiso creado' : 'No se pudo crear el tipo de permiso'];
    }

    // 'Subir comprobante' -> 'subir-comprobante'.
    private function slug($text) {
        $text = strtr(mb_strtolower(trim((string) $text), 'UTF-8'), ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n']);
        return trim(preg_replace('/[^a-z0-9]+/', '-', $text), '-');
    }

    function editTypePermission() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name'] ?? '');
        if ($name === '') return ['status' => 400, 'message' => 'El nombre es obligatorio'];
        if (!$this->qTypePermission([$id])) return ['status' => 404, 'message' => 'Tipo de permiso no encontrado'];
        $ok = $this->qUpdateTypePermission([$name, $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Tipo de permiso actualizado' : 'No se pudo actualizar'];
    }

    function toggleTypePermission() {
        $id = (int) $_POST['id'];
        if (!$this->qTypePermission([$id])) return ['status' => 404, 'message' => 'Tipo de permiso no encontrado'];
        $ok = $this->qSetTypePermissionActive([(int) $_POST['active'], $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? ((int) $_POST['active'] ? 'Activado' : 'Desactivado') : 'No se pudo actualizar el estado'];
    }

    function deleteTypePermission() {
        $id = (int) $_POST['id'];
        $found = $this->qTypePermission([$id]);
        if (!$found) return ['status' => 404, 'message' => 'Tipo de permiso no encontrado'];
        if ((int) $found['is_active'] === 1) return ['status' => 400, 'message' => 'Solo se puede eliminar un tipo de permiso desactivado'];

        $enUso = $this->qCountPermissionsByType([$id]);
        if ($enUso > 0) return ['status' => 400, 'message' => 'No se puede eliminar: hay permisos que usan este tipo'];

        $ok = $this->qDeleteTypePermission([$id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Tipo de permiso eliminado' : 'No se pudo eliminar el tipo de permiso'];
    }

    /* ===== Roles (roles) ===== */

    function lsRoles() {
        // Empresa: all = todos, system = solo los del sistema, un id = los de esa empresa.
        $active  = isset($_POST['active']) ? (int) $_POST['active'] : 1;
        $company = (string) ($_POST['company_id'] ?? 'all');

        $ls = ctype_digit($company)
            ? $this->qRoles([$active, (int) $company], 'company')
            : $this->qRoles([$active], $company === 'system' ? 'system' : 'all');

        $row = [];
        foreach ($ls as $r) {
            // Los roles del sistema no se desactivan: si editar queda solo en la
            // fila, pasa a ser el ultimo boton (sin me-1).
            $isSystem = (int) $r['is_system'] === 1;
            $a = [];
            $a[] = [
                'class'   => $this->actionBtnClass('neutral', $isSystem),
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'roles.editRole(' . $r['id'] . ')'
            ];
            if (!$isSystem) {
                if ($r['is_active'] == 1) {
                    $a[] = [
                        'class'   => $this->actionBtnClass('danger', true),
                        'html'    => '<i class="icon-toggle-on"></i>',
                        'onclick' => 'roles.toggleRole(' . $r['id'] . ', 0)'
                    ];
                } else {
                    $a[] = [
                        'class'   => $this->actionBtnClass('neutral', true),
                        'html'    => '<i class="icon-toggle-off"></i>',
                        'onclick' => 'roles.toggleRole(' . $r['id'] . ', 1)'
                    ];
                }
            }

            $system = (int) $r['is_system'] === 1
                ? '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-sky-50 text-sky-700 ">Sistema</span>'
                : '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-600 ">De empresa</span>';

            $row[] = [
                'id'       => $r['id'],
                'Código'   => $r['code'] ?: '-',
                'Rol'      => htmlspecialchars($r['name'] ?? ''),
                'Empresa'  => $this->roleCompanyLabel($r),
                'Tipo'     => $system,
                'Permisos' => $this->roleAccessLabel($r),
                'Estado'   => renderActive($r['is_active']),
                'a'        => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getRole() {
        $data = $this->qRole([(int) $_POST['id']]);
        if ($data && (int) $data['is_system'] === 1) $data['company_name'] = 'Todas las empresas (rol del sistema)';
        return ['status' => $data ? 200 : 404, 'message' => $data ? 'OK' : 'Rol no encontrado', 'data' => $data];
    }

    // Acciones por sección para el modal del rol. id = 0 es un rol nuevo: llegan
    // todas sin marcar. El Super Admin no se edita porque su acceso es total.
    function getRolePermissions() {
        $id   = (int) ($_POST['id'] ?? 0);
        $role = $id > 0 ? $this->qRole([$id]) : null;
        if ($id > 0 && !$role) return ['status' => 404, 'message' => 'Rol no encontrado'];

        if ($role && $role['code'] === 'superadmin') {
            return ['status' => 200, 'fullAccess' => true, 'modules' => []];
        }

        return [
            'status'     => 200,
            'fullAccess' => false,
            'modules'    => $this->permissionTree($this->qRolePermissions([$id]))
        ];
    }

    function addRole() {
        $name      = trim($_POST['name'] ?? '');
        $code      = trim($_POST['code'] ?? '') ?: null;
        $companyId = (int) ($_POST['company_id'] ?? 0);
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del rol es obligatorio'];
        if ($companyId <= 0 || !$this->qCompany([$companyId])) return ['status' => 400, 'message' => 'Elige la empresa del rol'];

        $error = $this->roleError($code, $name, $companyId, 0);
        if ($error) return ['status' => 400, 'message' => $error];

        return $this->transaction(function () use ($code, $name, $companyId) {
            $this->qInsertRole([$code, $name, $companyId]);

            $newId = $this->qLastInsertId();
            if (!$newId) {
                throw new \Exception('No se pudo obtener el id del rol creado');
            }

            $this->syncRolePermissions($newId);

            return ['status' => 200, 'message' => 'Rol creado correctamente'];
        });
    }

    function editRole() {
        $id   = (int) $_POST['id'];
        $name = trim($_POST['name'] ?? '');
        $code = trim($_POST['code'] ?? '') ?: null;
        if ($name === '') return ['status' => 400, 'message' => 'El nombre del rol es obligatorio'];

        $role = $this->qRole([$id]);
        if (!$role) return ['status' => 404, 'message' => 'Rol no encontrado'];

        // El código del Super Admin es el que le da el acceso total: no se cambia.
        if ((int) $role['is_system'] === 1) {
            $code = $role['code'];
        } else {
            $error = $this->roleError($code, $name, (int) $role['company_id'], $id);
            if ($error) return ['status' => 400, 'message' => $error];
        }

        return $this->transaction(function () use ($id, $code, $name, $role) {
            $this->qUpdateRole([$code, $name, $id]);

            if ($role['code'] !== 'superadmin') $this->syncRolePermissions($id);

            return ['status' => 200, 'message' => 'Rol actualizado correctamente'];
        });
    }

    function toggleRole() {
        $id   = (int) $_POST['id'];
        $role = $this->qRole([$id]);
        if (!$role) return ['status' => 404, 'message' => 'Rol no encontrado'];
        if ((int) $role['is_system'] === 1) {
            return ['status' => 400, 'message' => 'Los roles del sistema no se pueden desactivar'];
        }
        $ok = $this->qSetRoleActive([(int) $_POST['active'], $id]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? ((int) $_POST['active'] ? 'Rol activado' : 'Rol desactivado') : 'No se pudo actualizar el estado'];
    }

    // Rol de una empresa (no del sistema): el código no puede ser uno reservado y
    // el nombre no se repite dentro de la misma empresa.
    private function roleError($code, $name, $companyId, $id) {
        if ($code !== null && in_array(strtolower($code), $this->reservedRoleCodes, true)) {
            return 'Ese código está reservado para un rol del sistema';
        }
        if ($this->qRoleNameExists([$name, $companyId, $id])) return 'Esa empresa ya tiene un rol con ese nombre';
        return null;
    }

    private function roleCompanyLabel($role) {
        if ((int) $role['is_system'] === 1) return '<span class="text-gray-400">Todas</span>';
        return $role['company_name'] ? htmlspecialchars($role['company_name']) : '-';
    }

    // Columna Permisos de la tabla de roles. El Super Admin tiene acceso total
    // por código y no lleva filas en permissions_roles.
    private function roleAccessLabel($role) {
        if ($role['code'] === 'superadmin') {
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold bg-gray-900 text-white">Acceso total</span>';
        }

        $actions  = (int) $role['actions'];
        $sections = (int) $role['sections'];
        if ($actions === 0) return '<span class="italic text-gray-400">Sin permisos</span>';

        return $actions . ($actions === 1 ? ' acción' : ' acciones')
            . ' · ' . $sections . ($sections === 1 ? ' sección' : ' secciones');
    }

    // Filas de qRolePermissions -> módulo > sección > acciones, en el orden en que llegan.
    private function permissionTree($rows) {
        $modules = [];
        foreach ($rows as $r) {
            $mid = (int) $r['module_id'];
            $sid = (int) $r['section_id'];

            if (!isset($modules[$mid])) {
                $modules[$mid] = [
                    'id'       => $mid,
                    'name'     => $r['module_name'],
                    'icon'     => $r['module_icon'] ?: 'layout-grid',
                    'sections' => []
                ];
            }

            if (!isset($modules[$mid]['sections'][$sid])) {
                $modules[$mid]['sections'][$sid] = [
                    'id'      => $sid,
                    'name'    => $r['section_name'],
                    'icon'    => $r['section_icon'] ?: 'square',
                    'actions' => []
                ];
            }

            $modules[$mid]['sections'][$sid]['actions'][] = [
                'id'      => (int) $r['permission_id'],
                'name'    => $r['type_name'],
                'granted' => (int) $r['granted'] === 1
            ];
        }

        // Listas y no objetos en el JSON: el front las recorre en orden.
        foreach ($modules as &$m) $m['sections'] = array_values($m['sections']);
        unset($m);

        return array_values($modules);
    }

    /*  Deja en permissions_roles exactamente las acciones que llegan en
        `permissions` (JSON con ids), pero solo entre las vigentes: lo que esté
        apagado en el catálogo no sale en el modal y se conserva tal cual, para
        que el rol lo recupere si se vuelve a encender. Sin `permissions` en el
        POST no se toca nada: una pantalla vieja que solo edita el nombre no le
        borra los permisos al rol. */
    private function syncRolePermissions($roleId) {
        if (!isset($_POST['permissions'])) return;

        $rows    = $this->qRolePermissions([$roleId]);
        $visible = array_map('intval', array_column($rows, 'permission_id'));
        $granted = [];
        foreach ($rows as $r) {
            if ((int) $r['granted'] === 1) $granted[] = (int) $r['permission_id'];
        }

        $wanted = array_values(array_intersect($this->postedPermissionIds(), $visible));

        foreach (array_diff($granted, $wanted) as $permissionId) {
            $this->qDeleteRolePermission([$roleId, $permissionId]);
        }
        foreach (array_diff($wanted, $granted) as $permissionId) {
            $this->qInsertRolePermission([$roleId, $permissionId]);
        }
    }

    private function postedPermissionIds() {
        $decoded = json_decode((string) $_POST['permissions'], true);
        if (!is_array($decoded)) return [];

        $ids = [];
        foreach ($decoded as $v) {
            $id = (int) $v;
            if ($id > 0) $ids[] = $id;
        }
        return array_values(array_unique($ids));
    }

    /* ===== Permisos: acciones de cada sección (permissions) ===== */

    // Datos de la pestaña Permisos: las secciones encendidas (filas), los tipos
    // de permiso activos (columnas) y las acciones que ya tiene cada sección.
    function lsPermissions() {
        $sections = $this->qCatalogSections();

        $modules = [];
        foreach ($sections as $s) {
            $mid = (int) $s['module_id'];
            if (isset($modules[$mid])) continue;
            $modules[$mid] = [
                'id'   => $mid,
                'name' => $s['module_name'],
                'icon' => $s['module_icon'] ?: 'layout-grid'
            ];
        }

        return [
            'status'   => 200,
            'modules'  => array_values($modules),
            'sections' => array_map(function ($s) {
                return [
                    'id'        => (int) $s['id'],
                    'name'      => $s['name'],
                    'icon'      => $s['icon'] ?: 'square',
                    'route'     => $s['route'] ?: '',
                    'module_id' => (int) $s['module_id']
                ];
            }, $sections),
            'types' => array_map(function ($t) {
                return ['id' => (int) $t['id'], 'name' => $t['name']];
            }, $this->qTypePermissions([1])),
            'permissions' => array_map(function ($p) {
                return $this->permissionRow($p);
            }, $this->qPermissionsCatalog())
        ];
    }

    // Enciende o apaga una acción en una sección. Apagarla no le quita nada a los
    // roles: deja de verse y de contar, y al encenderla cada rol la recupera.
    function togglePermission() {
        $secId  = (int) ($_POST['section_id'] ?? 0);
        $typeId = (int) ($_POST['type_permission_id'] ?? 0);
        $active = (int) ($_POST['active'] ?? 0) === 1 ? 1 : 0;

        if (!$this->qSection([$secId]))         return ['status' => 404, 'message' => 'Sección no encontrada'];
        if (!$this->qTypePermission([$typeId])) return ['status' => 404, 'message' => 'Tipo de permiso no encontrado'];

        $found = $this->qFindPermission([$secId, $typeId]);
        if ($found) {
            $ok = $this->qSetPermissionActive([$active, (int) $found['id']]);
        } elseif ($active === 1) {
            $ok = $this->qInsertPermission([$secId, $typeId]);
        } else {
            $ok = true; // No existe y se pide quitar: nada que hacer.
        }

        $current = $this->qFindPermission([$secId, $typeId]);

        return [
            'status'     => $ok ? 200 : 500,
            'message'    => $ok ? ($active ? 'Acción agregada a la sección' : 'Acción quitada de la sección') : 'No se pudo actualizar la acción',
            'permission' => $current ? $this->permissionRow($current) : null
        ];
    }

    private function permissionRow($p) {
        return [
            'id'                 => (int) $p['id'],
            'section_id'         => (int) $p['section_id'],
            'type_permission_id' => (int) $p['type_permission_id'],
            'is_active'          => (int) $p['is_active'],
            'roles'              => (int) $p['roles']
        ];
    }

    /* ===== Usuarios (mismo CRUD que admin/accesos, mas el rol) ===== */

    function lsUsers() {
        $status = (isset($_POST['active']) && (int) $_POST['active'] === 0) ? 'inactive' : 'active';
        $ls = $this->qUsersFull([$this->companyId(), $status]);

        $row = [];
        foreach ($ls as $u) {
            $a = [];
            $a[] = [
                'class'   => 'inline-flex items-center px-2 py-1 text-sm rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition me-1',
                'html'    => '<i class="icon-pencil"></i>',
                'onclick' => 'users.editUser(' . $u['id'] . ')'
            ];
            if ($u['status'] === 'active') {
                $a[] = [
                    'class'   => 'inline-flex items-center px-2 py-1 text-sm rounded-md border border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 transition',
                    'html'    => '<i class="icon-toggle-on"></i>',
                    'onclick' => 'users.toggleUser(' . $u['id'] . ', 0)'
                ];
            } else {
                $a[] = [
                    'class'   => 'inline-flex items-center px-2 py-1 text-sm rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition',
                    'html'    => '<i class="icon-toggle-off"></i>',
                    'onclick' => 'users.toggleUser(' . $u['id'] . ', 1)'
                ];
            }

            // renderAvatar() ya devuelve un flex con iniciales + nombre; el badge
            // de dueño se envuelve aparte para que quede a un lado y no debajo.
            $fullName = trim(($u['name'] ?? '') . ' ' . ($u['last_name'] ?? ''));
            $cell     = renderAvatar($fullName);
            if ((int) $u['is_owner'] === 1) {
                $cell = '<div class="flex items-center gap-2">'
                      . $cell . badge('Dueño', ACCENT_TEXT, 100, ACCENT_BG)
                      . '</div>';
            }

            $branches = $u['branch_names']
                ? implode(' ', array_map(function ($n) {
                    return badge(trim($n), ACCENT_TEXT, 100, ACCENT_BG);
                  }, explode(',', $u['branch_names'])))
                : '<span class="italic text-gray-400 text-sm">Sin asignar</span>';

            $roles = $u['role_names']
                ? implode(' ', array_map(function ($n) {
                    return badge(trim($n), '#1D4ED8', 100, '#DBEAFE');
                  }, explode(',', $u['role_names'])))
                : badge('Sin rol', '#92400E', 100, '#FEF3C7');

            $row[] = [
                'id'          => $u['id'],
                'Usuario'     => $cell,
                'Correo'      => htmlspecialchars($u['email'] ?? '—'),
                'Sucursales'  => $branches,
                'Rol'         => $roles,
                'Estado'      => renderUserStatus($u['status']),
                'a'           => $a
            ];
        }

        return ['status' => 200, 'row' => $row, 'ls' => $ls];
    }

    function getUser() {
        $id   = (int) ($_POST['id'] ?? 0);
        $data = $this->qUserFull([$id, $this->companyId()]);
        if (!$data) {
            return ['status' => 404, 'message' => 'Usuario no encontrado'];
        }

        $data['branch_ids'] = $this->qUserBranchIds([$id]);
        $data['role_id']    = $this->qUserMainRole([$id]);
        $data['photo_url']  = $this->photoUrl($data['photo'] ?? '');

        return ['status' => 200, 'message' => 'OK', 'data' => $data];
    }

    /* ===== Foto del colaborador =====
       Convención compartida con el login (acceso/ctrl/ctrl-access.php) y con
       admin/accesos: `users.photo` guarda SOLO el nombre del archivo dentro de
       inventory/uploads/users/. */

    private function photoDir() {
        return __DIR__ . '/../../uploads/users/';
    }

    // ¿El formulario trae algo que hacer con la foto? Sin esto, guardar el
    // usuario sin tocar su foto la borraría.
    private function photoTouched() {
        return ($_POST['photo_b64'] ?? '') !== '' || ($_POST['photo_clear'] ?? '') === '1';
    }

    /*  La foto viaja como dataURL en un campo de TEXTO, no como archivo:
        createModalForm manda el formulario por useFetch, que arma un
        URLSearchParams, y ahí un File se convierte en "[object File]".

        Devuelve el nombre de archivo a guardar, o null para dejarla vacía. Si
        el dataURL viene roto se conserva la que ya había: vale más quedarse con
        la foto vieja que borrarla por un envío mal formado. */
    private function savePhoto($userId, $currentPhoto) {
        $b64   = (string) ($_POST['photo_b64'] ?? '');
        $clear = ($_POST['photo_clear'] ?? '') === '1';
        $dir   = $this->photoDir();

        if (!$clear) {
            if (!preg_match('#^data:image/([a-zA-Z0-9.+-]+);base64,#', $b64, $m)) return $currentPhoto;

            $ext = strtolower($m[1]) === 'jpeg' ? 'jpg' : strtolower($m[1]);
            if (!in_array($ext, ['jpg', 'png', 'webp', 'gif'], true))            return $currentPhoto;

            $data = base64_decode(substr($b64, strpos($b64, ',') + 1), true);
            if ($data === false)                                                 return $currentPhoto;

            if (!is_dir($dir)) @mkdir($dir, 0777, true);

            $fileName = 'user_' . (int) $userId . '_' . time() . '.' . $ext;
            if (@file_put_contents($dir . $fileName, $data) === false)           return $currentPhoto;

            $this->dropPhoto($currentPhoto);
            return $fileName;
        }

        $this->dropPhoto($currentPhoto);
        return null;
    }

    // Borra del disco la foto anterior. basename() para que un valor manipulado
    // no pueda salirse de la carpeta.
    private function dropPhoto($photo) {
        $photo = basename(trim((string) $photo));
        if ($photo === '') return;

        $file = $this->photoDir() . $photo;
        if (is_file($file)) @unlink($file);
    }

    // La foto lista para un <img src>. La base sale de la ruta real de este
    // controlador (.../inventory/tenant/ctrl/) y no escrita a mano.
    private function photoUrl($photo) {
        $photo = trim((string) $photo);
        if ($photo === '') return '';
        if ($photo[0] === '/' || preg_match('#^https?://#', $photo)) return $photo;

        $base = dirname(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '')));
        $base = rtrim(str_replace('\\', '/', $base), '/');

        return $base . '/uploads/users/' . rawurlencode($photo);
    }

    function addUser() {
        $name      = trim($_POST['name'] ?? '');
        $lastName  = trim($_POST['last_name'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $password  = (string) ($_POST['password'] ?? '');
        $roleId    = (int) ($_POST['role_id'] ?? 0);
        $branchIds = $this->normalizeBranchIds($_POST['branch_ids'] ?? '');
        $color     = $this->normalizeColor($_POST['color'] ?? '');

        if ($password !== (string) ($_POST['password_confirmation'] ?? '')) {
            return ['status' => 422, 'message' => 'Las contraseñas no coinciden'];
        }
        if ($name === '' || $email === '') {
            return ['status' => 400, 'message' => 'Nombre y correo son obligatorios'];
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['status' => 400, 'message' => 'El correo no es válido'];
        }
        if ($roleId <= 0 || !$this->qRole([$roleId])) {
            return ['status' => 400, 'message' => 'Debes elegir un rol válido'];
        }
        if (empty($branchIds)) {
            return ['status' => 400, 'message' => 'Debes asignar al menos una sucursal'];
        }
        if (strlen($password) < 4) {
            return ['status' => 400, 'message' => 'La contraseña debe tener al menos 4 caracteres'];
        }
        if ($this->qUserEmailExists([$email, $this->companyId()])) {
            return ['status' => 409, 'message' => 'Ya existe un usuario con ese correo'];
        }
        foreach ($branchIds as $bid) {
            if (!$this->qBranchInCompany([$bid, $this->companyId()])) {
                return ['status' => 400, 'message' => 'Una de las sucursales seleccionadas no es válida'];
            }
        }

        return $this->transaction(function () use ($name, $lastName, $email, $password, $branchIds, $color, $roleId) {
            $this->qInsertUser([
                $name,
                $lastName ?: null,
                $email,
                password_hash($password, PASSWORD_BCRYPT),
                $branchIds[0],
                $this->companyId(),
                $color
            ]);

            $newId = $this->qLastInsertId();
            if (!$newId) {
                throw new \Exception('No se pudo obtener el id del usuario creado');
            }

            // El rol elegido se aplica a todas sus sucursales: el modal captura
            // un rol por usuario, no uno por sucursal.
            foreach ($branchIds as $bid) {
                $this->qInsertUserBranchRole([$newId, $bid, $roleId]);
            }

            // La foto se guarda al final porque su nombre lleva el id del usuario,
            // que hasta aquí no existía.
            if ($this->photoTouched()) {
                $this->qUpdateUserPhoto([$this->savePhoto($newId, ''), $newId, $this->companyId()]);
            }

            return ['status' => 200, 'message' => 'Usuario creado correctamente'];
        });
    }

    function editUser() {
        $id                   = (int) ($_POST['id'] ?? 0);
        $name                 = trim($_POST['name'] ?? '');
        $lastName             = trim($_POST['last_name'] ?? '');
        $email                = trim($_POST['email'] ?? '');
        $roleId               = (int) ($_POST['role_id'] ?? 0);
        $branchIds            = $this->normalizeBranchIds($_POST['branch_ids'] ?? '');
        $color                = $this->normalizeColor($_POST['color'] ?? '');
        // Opcionales en la edicion: si no llegan, la contrasena no se toca.
        $password             = (string) ($_POST['password'] ?? '');
        $passwordConfirmation = (string) ($_POST['password_confirmation'] ?? '');

        if ($password !== '' && $password !== $passwordConfirmation) {
            return ['status' => 422, 'message' => 'Las contraseñas no coinciden'];
        }
        if ($name === '' || $email === '') {
            return ['status' => 400, 'message' => 'Nombre y correo son obligatorios'];
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['status' => 400, 'message' => 'El correo no es válido'];
        }
        if ($roleId <= 0 || !$this->qRole([$roleId])) {
            return ['status' => 400, 'message' => 'Debes elegir un rol válido'];
        }
        if (empty($branchIds)) {
            return ['status' => 400, 'message' => 'Debes asignar al menos una sucursal'];
        }
        if ($password !== '' && strlen($password) < 4) {
            return ['status' => 400, 'message' => 'La contraseña debe tener al menos 4 caracteres'];
        }
        $current = $this->qUserFull([$id, $this->companyId()]);
        if (!$current) {
            return ['status' => 404, 'message' => 'Usuario no encontrado'];
        }
        if ($this->qUserEmailExistsExcept([$email, $this->companyId(), $id])) {
            return ['status' => 409, 'message' => 'Ya existe otro usuario con ese correo'];
        }
        foreach ($branchIds as $bid) {
            if (!$this->qBranchInCompany([$bid, $this->companyId()])) {
                return ['status' => 400, 'message' => 'Una de las sucursales seleccionadas no es válida'];
            }
        }

        $photoActual = $current['photo'] ?? '';

        return $this->transaction(function () use ($id, $name, $lastName, $email, $branchIds, $color, $password, $roleId, $photoActual) {
            $this->qUpdateUser([
                $name,
                $lastName ?: null,
                $email,
                $branchIds[0],
                $color,
                $id,
                $this->companyId()
            ]);

            $this->qDeleteUserBranches([$id]);

            foreach ($branchIds as $bid) {
                $this->qInsertUserBranchRole([$id, $bid, $roleId]);
            }

            if ($password !== '') {
                $this->qUpdateUserPassword([
                    password_hash($password, PASSWORD_BCRYPT),
                    $id,
                    $this->companyId()
                ]);
            }

            if ($this->photoTouched()) {
                $this->qUpdateUserPhoto([$this->savePhoto($id, $photoActual), $id, $this->companyId()]);
            }

            return ['status' => 200, 'message' => 'Usuario actualizado correctamente'];
        });
    }

    function toggleUser() {
        $id     = (int) ($_POST['id'] ?? 0);
        $active = (int) ($_POST['active'] ?? 0);

        if (!$this->qUserFull([$id, $this->companyId()])) {
            return ['status' => 404, 'message' => 'Usuario no encontrado'];
        }

        $ok = $this->qSetUserStatus([$active === 1 ? 'active' : 'inactive', $id, $this->companyId()]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? ($active ? 'Usuario activado' : 'Usuario desactivado') : 'No se pudo actualizar el estado'
        ];
    }

    // branch_ids viaja como CSV desde los chips ('1,3'), pero se acepta tambien
    // un array JSON por si la peticion llega de otro cliente.
    private function normalizeBranchIds($raw) {
        if (is_array($raw)) {
            $ids = $raw;
        } elseif (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            $ids = is_array($decoded) ? $decoded : explode(',', $raw);
        } else {
            return [];
        }

        $result = [];
        foreach ($ids as $v) {
            $n = (int) trim((string) $v);
            if ($n > 0 && !in_array($n, $result, true)) $result[] = $n;
        }
        return $result;
    }

    private function normalizeColor($raw) {
        $color = trim((string) $raw);
        return preg_match('/^#[0-9A-Fa-f]{6}$/', $color) ? $color : null;
    }

    /* ===== Sucursales (el admin elige empresa y reparte su gente) ===== */

    // Una sola consulta por empresa: la lista, el detalle de cada sucursal y los
    // KPIs salen de esta respuesta, así que cambiar de sucursal no vuelve al servidor.
    function lsBranches() {
        $companyId = (int) ($_POST['company_id'] ?? 0) ?: $this->companyId();
        if (!$this->qCompanyHasSubscription([$companyId])) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }

        $byBranch = [];
        foreach ($this->qBranchAssignments([$companyId]) as $a) {
            $byBranch[$a['branch_id']][] = $a;
        }

        $branches = [];
        foreach ($this->qBranches([$companyId]) as $b) {
            $members = [];
            $row     = [];
            foreach ($byBranch[$b['id']] ?? [] as $a) {
                $fullName  = trim($a['name'] . ' ' . ($a['last_name'] ?? ''));
                $members[] = [
                    'assignment_id' => (int) $a['assignment_id'],
                    'user_id'       => (int) $a['user_id'],
                    'role_id'       => (int) $a['role_id'],
                    'name'          => $fullName
                ];
                $row[] = [
                    'id'      => $a['assignment_id'],
                    'Usuario' => renderUserCell($fullName, $a['email']),
                    'Rol'     => $a['role_name']
                        ? badge(htmlspecialchars($a['role_name']), '#1D4ED8', 100, '#DBEAFE')
                        : badge('Sin rol', '#92400E', 100, '#FEF3C7'),
                    'a'       => [
                        [
                            'class'   => $this->actionBtnClass('neutral'),
                            'html'    => '<i class="icon-pencil"></i>',
                            'onclick' => 'branches.editUserRole(' . (int) $a['assignment_id'] . ')'
                        ],
                        [
                            'class'   => $this->actionBtnClass('danger', true),
                            'html'    => '<i class="icon-trash"></i>',
                            'onclick' => 'branches.removeUserRole(' . (int) $a['assignment_id'] . ')'
                        ]
                    ]
                ];
            }

            $branches[] = [
                'id'        => (int) $b['id'],
                'name'      => (string) $b['name'],
                'ubication' => (string) $b['ubication'],
                'is_active' => (int) $b['is_active'],
                'created'   => $b['created'],
                'users'     => (int) $b['users'],
                'members'   => $members,
                'row'       => $row
            ];
        }

        return [
            'status'         => 200,
            'company_id'     => $companyId,
            'companies'      => $this->qCompaniesBranchSummary(),
            'branches'       => $branches,
            'candidates'     => $this->qUsersForBranchAssign([$companyId]),
            'plan'           => $this->qPlanActiveByCompany([$companyId]),
            // Las sucursales que ofrece el modal de Usuarios (empresa en sesión), frescas tras cada cambio.
            'selectBranches' => $this->qBranchesForSelect([$this->companyId()])
        ];
    }

    function addBranch() {
        $companyId = (int) ($_POST['company_id'] ?? 0);
        $name      = trim($_POST['name'] ?? '');

        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre de la sucursal es obligatorio'];
        }
        if (!$this->qCompanyHasSubscription([$companyId])) {
            return ['status' => 404, 'message' => 'Empresa no encontrada'];
        }
        if ($this->qBranchNameExists([$name, $companyId])) {
            return ['status' => 400, 'message' => 'Ya existe una sucursal con ese nombre'];
        }

        $plan = $this->qPlanActiveByCompany([$companyId]);
        if ($plan && $plan['max_branches'] !== null
            && $this->qCountActiveBranches([$companyId]) >= (int) $plan['max_branches']) {
            return ['status' => 400, 'message' => 'El plan ' . $plan['name'] . ' permite ' . (int) $plan['max_branches'] . ' sucursales activas'];
        }

        $ok = $this->qInsertBranch([$name, trim($_POST['ubication'] ?? '') ?: null, $companyId]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Sucursal «' . $name . '» creada correctamente' : 'No se pudo crear la sucursal'
        ];
    }

    function editBranch() {
        $id   = (int) ($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');

        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre de la sucursal es obligatorio'];
        }
        $branch = $this->qBranch([$id]);
        if (!$branch) {
            return ['status' => 404, 'message' => 'Sucursal no encontrada'];
        }
        if ($this->qBranchNameExistsExcept([$name, (int) $branch['company_id'], $id])) {
            return ['status' => 400, 'message' => 'Ya existe una sucursal con ese nombre'];
        }

        $ok = $this->qUpdateBranch([$name, trim($_POST['ubication'] ?? '') ?: null, $id]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Sucursal actualizada' : 'No se pudo actualizar la sucursal'
        ];
    }

    // Desactivar no borra la gente: las asignaciones quedan guardadas para cuando se reactive.
    function toggleBranch() {
        $id     = (int) ($_POST['id'] ?? 0);
        $active = (int) ($_POST['active'] ?? 0) === 1 ? 1 : 0;

        $branch = $this->qBranch([$id]);
        if (!$branch) {
            return ['status' => 404, 'message' => 'Sucursal no encontrada'];
        }

        $ok = $this->qSetBranchActive([$active, $id]);
        if (!$ok) {
            return ['status' => 500, 'message' => 'No se pudo actualizar el estado'];
        }
        if ($active) {
            return ['status' => 200, 'message' => 'Sucursal «' . $branch['name'] . '» activada'];
        }

        $kept = $this->qCountBranchAssignments([$id]);
        return [
            'status'  => 200,
            'message' => $kept > 0
                ? 'Sucursal desactivada. ' . $kept . ' asignaciones quedan guardadas.'
                : 'Sucursal desactivada'
        ];
    }

    // La empresa se toma de la sucursal y no de la sesión: el admin SaaS reparte
    // gente en la empresa que eligió arriba, no solo en la suya.
    function assignUserRole() {
        $userId   = (int) ($_POST['user_id'] ?? 0);
        $branchId = (int) ($_POST['branch_id'] ?? 0);
        $roleId   = (int) ($_POST['role_id'] ?? 0);

        if ($userId <= 0 || $branchId <= 0 || $roleId <= 0) {
            return ['status' => 400, 'message' => 'Usuario, sucursal y rol son obligatorios'];
        }
        $branch = $this->qBranch([$branchId]);
        if (!$branch) {
            return ['status' => 404, 'message' => 'Sucursal no encontrada'];
        }
        if ((int) $branch['is_active'] !== 1) {
            return ['status' => 400, 'message' => 'La sucursal está desactivada: reactívala para asignar gente'];
        }
        $user = $this->qUserFull([$userId, (int) $branch['company_id']]);
        if (!$user) {
            return ['status' => 400, 'message' => 'El usuario no pertenece a la empresa de la sucursal'];
        }
        $role = $this->qRole([$roleId]);
        if (!$role) {
            return ['status' => 400, 'message' => 'El rol seleccionado no es válido'];
        }

        // Si ya existe la fila usuario+sucursal, se actualiza el rol en vez de duplicar.
        $existing = $this->qUserBranchAssignment([$userId, $branchId]);
        $ok = $existing
            ? $this->qSetUserBranchRole([$roleId, (int) $existing['id']])
            : $this->qInsertUserBranchRole([$userId, $branchId, $roleId]);

        $fullName = trim($user['name'] . ' ' . ($user['last_name'] ?? ''));
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? $fullName . ' asignado como ' . $role['name'] : 'No se pudo asignar el rol'
        ];
    }

    function updateUserRole() {
        $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
        $roleId       = (int) ($_POST['role_id'] ?? 0);

        if ($assignmentId <= 0 || $roleId <= 0) {
            return ['status' => 400, 'message' => 'Asignación y rol son obligatorios'];
        }
        if (!$this->qAssignment([$assignmentId])) {
            return ['status' => 404, 'message' => 'Asignación no encontrada'];
        }
        $role = $this->qRole([$roleId]);
        if (!$role) {
            return ['status' => 400, 'message' => 'El rol seleccionado no es válido'];
        }

        $ok = $this->qSetUserBranchRole([$roleId, $assignmentId]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Rol actualizado a ' . $role['name'] : 'No se pudo actualizar el rol'
        ];
    }

    function removeUserRole() {
        $assignmentId = (int) ($_POST['assignment_id'] ?? 0);
        if (!$this->qAssignment([$assignmentId])) {
            return ['status' => 404, 'message' => 'Asignación no encontrada'];
        }

        $ok = $this->qDeleteUserBranchRole([$assignmentId]);
        return [
            'status'  => $ok ? 200 : 500,
            'message' => $ok ? 'Asignación quitada' : 'No se pudo quitar la asignación'
        ];
    }

    /* ===== Helpers internos ===== */

    // Clase de los botones de accion en el estilo minimalista que ya usaba la
    // pestana Usuarios (borde + texto, sin relleno solido). Centraliza la cadena
    // que estaba repetida en ~19 sitios del archivo con dos lenguajes distintos
    // (btn-primary de Bootstrap y bg-slate-100 de Tailwind): variant 'neutral'
    // para editar/cambiar estado/activar/abrir factura, 'danger' para
    // desactivar/eliminar. $last quita el me-1 cuando es el ultimo boton de la fila.
    private function actionBtnClass($variant, $last = false) {
        $base = $variant === 'danger'
            ? 'inline-flex items-center px-2 py-1 text-sm rounded-md border border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 transition'
            : 'inline-flex items-center px-2 py-1 text-sm rounded-md border border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition';
        return $last ? $base : $base . ' me-1';
    }

    // Acciones estándar editar + activar/desactivar para entidades del catálogo.
    // $toggleIsLast en false cuando la fila agrega otro boton despues del toggle
    // (ej. Tipos de permiso agrega Eliminar cuando el registro esta inactivo).
    private function toggleActions($jsObj, $editFn, $toggleFn, $id, $isActive, $toggleIsLast = true) {
        $a = [];
        $a[] = [
            'class'   => $this->actionBtnClass('neutral', false),
            'html'    => '<i class="icon-pencil"></i>',
            'onclick' => "{$jsObj}.{$editFn}({$id})"
        ];
        if ((int) $isActive === 1) {
            $a[] = [
                'class'   => $this->actionBtnClass('danger', $toggleIsLast),
                'html'    => '<i class="icon-toggle-on"></i>',
                'onclick' => "{$jsObj}.{$toggleFn}({$id}, 0)"
            ];
        } else {
            $a[] = [
                'class'   => $this->actionBtnClass('neutral', $toggleIsLast),
                'html'    => '<i class="icon-toggle-off"></i>',
                'onclick' => "{$jsObj}.{$toggleFn}({$id}, 1)"
            ];
        }
        return $a;
    }

    private function paymentStatusIn($v) {
        return in_array($v, $this->paymentStatuses, true) ? $v : 'paid';
    }

    private function companyStatusIn($v) {
        return in_array($v, $this->companyStatuses, true) ? $v : 'active';
    }

    private function subStatusIn($v) {
        return in_array($v, $this->subStatuses, true) ? $v : 'active';
    }

    private function intOrNull($v) {
        $v = trim((string) $v);
        return $v === '' ? null : (int) $v;
    }

    // Para selects OPCIONALES con placeholder "-- Selecciona --" (value="0"):
    // tanto '' como '0' significan "sin valor" -> NULL (no rompe la FK).
    private function selectOrNull($v) {
        $v = trim((string) $v);
        return ($v === '' || $v === '0') ? null : (int) $v;
    }

    private function dateOrNull($v) {
        $v = trim((string) $v);
        return $v === '' ? null : $v;
    }
}

/* ===== Helpers de render (badges) ===== */

function renderActive($status) {
    switch ((int) $status) {
        case 1:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-emerald-50 text-emerald-700 ">Activo</span>';
        case 0:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-red-50 text-red-700 ">Inactivo</span>';
        default:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-500 ">Desconocido</span>';
    }
}

function renderCompanyStatus($status) {
    switch ($status) {
        case 'active':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-emerald-50 text-emerald-700 ">Activa</span>';
        case 'pending':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-amber-50 text-amber-700 ">Pendiente</span>';
        case 'suspendend':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-red-50 text-red-700 ">Suspendida</span>';
        case 'cancelled':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-red-50 text-red-700 ">Cancelada</span>';
        default:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-500 ">—</span>';
    }
}

function renderSubStatus($status) {
    switch ($status) {
        case 'active':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-emerald-50 text-emerald-700 ">Activa</span>';
        case 'trial':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-sky-50 text-sky-700 ">Prueba</span>';
        case 'past_due':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-amber-50 text-amber-700 ">Vencida</span>';
        case 'cancelled':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-red-50 text-red-700 ">Cancelada</span>';
        case 'expired':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-600 ">Expirada</span>';
        default:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-500 ">—</span>';
    }
}

function renderBillingCycle($cycle) {
    switch ($cycle) {
        case 'monthly':  return 'Mensual';
        case 'yearly':   return 'Anual';
        case 'lifetime': return 'De por vida';
        default:         return $cycle ?: '-';
    }
}

function renderPaymentStatus($status) {
    switch ($status) {
        case 'paid':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-emerald-50 text-emerald-700 ">Pagado</span>';
        case 'pending':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-amber-50 text-amber-700 ">Pendiente</span>';
        case 'failed':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-red-50 text-red-700 ">Fallido</span>';
        case 'refunded':
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-600 ">Reembolsado</span>';
        default:
            return '<span class="px-2 py-1 rounded-md text-sm font-semibold  bg-slate-50 text-slate-500 ">—</span>';
    }
}

function avatarInitials($name) {
    $name = trim((string) $name);
    if ($name === '') return '?';

    $parts    = preg_split('/\s+/', $name);
    $initials = mb_strtoupper(mb_substr($parts[0], 0, 1));
    if (count($parts) > 1) {
        $initials .= mb_strtoupper(mb_substr($parts[count($parts) - 1], 0, 1));
    } elseif (mb_strlen($parts[0]) > 1) {
        $initials .= mb_strtoupper(mb_substr($parts[0], 1, 1));
    }
    return $initials;
}

function renderAvatar($name) {
    $name = trim((string) $name);
    return '<div class="flex items-center gap-2">'
        . '<span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-50 text-blue-600 text-xs font-semibold shrink-0">' . htmlspecialchars(avatarInitials($name)) . '</span>'
        . '<span>' . htmlspecialchars($name) . '</span>'
        . '</div>';
}

// Celda de la tabla de Sucursales: avatar con iniciales, nombre y el correo debajo.
function renderUserCell($name, $email) {
    return '<div class="flex items-center gap-2.5">'
        . '<span class="inline-flex items-center justify-center w-7 h-7 rounded-full bg-blue-50 text-blue-600 text-[10.5px] font-semibold shrink-0">' . htmlspecialchars(avatarInitials($name)) . '</span>'
        . '<div class="min-w-0">'
        . '<p class="font-semibold text-gray-900 truncate mb-0">' . htmlspecialchars($name) . '</p>'
        . '<p class="text-[11px] text-gray-500 truncate mb-0">' . htmlspecialchars($email ?: '—') . '</p>'
        . '</div>'
        . '</div>';
}

// users.status es un enum de texto ('active'/'inactive'), no el 1/0 que usa
// renderActive() para el resto de los catalogos de este modulo.
function renderUserStatus($status) {
    return $status === 'active'
        ? badge('Activo', '#16A34A', 100, '#DCFCE7')
        : badge('Inactivo', '#9D3434', 100, '#F6E4E4');
}

function renderDiscount($type, $value) {
    $value = (float) $value;
    if ($type === 'percent') {
        return rtrim(rtrim(number_format($value, 2), '0'), '.') . '%';
    }
    return '$' . number_format($value, 2);
}

$obj = new ctrl();
$opc = $_POST['opc'];
if (!method_exists($obj, $opc)) {
    echo json_encode(['status' => 405, 'message' => "opc '{$opc}' no implementado"]);
    exit(0);
}
// El tenant administra roles y permisos: solo quien entra a la sección "Permisos"
// (hoy, el Super Admin). Sin esto, cualquiera con sesión podría darse acciones.
require_once __DIR__ . '/../../conf/_Permissions.php';
echo json_encode(Permissions::guard('permisos-editor', $opc, []) ?: $obj->{$opc}());
