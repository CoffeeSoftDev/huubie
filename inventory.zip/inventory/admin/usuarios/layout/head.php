<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../src/img/logos/favicon.svg" type="image/svg+xml">
    <title>Coffee Inventory</title>
    <!--FONTELLO-->
    <link rel="stylesheet" href="../../src/plugin/fontello/css/fontello.css">
    <link rel="stylesheet" href="../../src/plugin/fontello/css/animation.css">
    <!--BOOTSTRAP-->
    <link rel="stylesheet" href="../../src/plugin/bootstrap-5/css/bootstrap.min.css">
    <!--SWEETALERT-->
    <link rel="stylesheet" href="../../src/plugin/sweetalert2/sweetalert2.min.css">
    <!--DATATABLES-->
    <link rel="stylesheet" href="../../src/plugin/datatables/dataTables.responsive.min.css">
    <link rel="stylesheet" href="../../src/plugin/datatables/1.13.6/css/dataTables.bootstrap5.min.css">

    
    <link rel="stylesheet" href="../../src/plugin/daterangepicker/daterangepicker.css">
    <!--SELECT2-->
    <link rel="stylesheet" href="../../src/plugin/select2/bootstrap/select2.min.css">
    <link rel="stylesheet" href="../../src/plugin/select2/bootstrap/select2-bootstrap-5-theme.min.css">

    <!--PERSONALIZADO-->
    <link rel="stylesheet" href="../../src/css/general.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/general.css'); ?>">
    <!-- Las hojas y el script del tema van versionados con filemtime(): al
         cambiar el tema el navegador no puede servir una copia vieja. -->
    <link rel="stylesheet" href="../../src/css/colors.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/colors.css'); ?>">
    <link rel="stylesheet" href="../../src/css/table.css">
    <link rel="stylesheet" href="../../src/css/buttons.css">
    <link rel="stylesheet" href="../../src/css/background.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/background.css'); ?>">
    <link rel="stylesheet" href="../../src/css/text.css">
    <link rel="stylesheet" href="../../src/css/style.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/style.css'); ?>">
    <link rel="stylesheet" href="../../src/css/sidebar.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/sidebar.css'); ?>">

    <!-- CDN TAILWIND -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Tema Arcilla Invernal (blue → terracota) -->
    <script src="../../src/js/tailwind-theme.js?v=<?php echo filemtime(__DIR__ . '/../../../src/js/tailwind-theme.js'); ?>"></script>

        <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
   
  <!-- Compact Styles -->
    <link rel="stylesheet" href="../../src/css/compact.css">

    <!-- Tokens del tema activo. Va al final: redefine lo que las hojas de arriba
         dejaron con el color clavado. -->
    <link rel="stylesheet" href="../../src/css/themes.css?v=<?php echo filemtime(__DIR__ . '/../../../src/css/themes.css'); ?>">