<?php
require_once '../../conf/_CRUD.php';
require_once '../../conf/_Utileria.php';

class MAccess extends CRUD {
    protected $util;
    public $bd;
    public $bdInv;

    public function __construct() {
        $this->util  = new Utileria;
        $this->bd    = "fayxzvov_erp.";
        $this->bdInv = "fayxzvov_inventory.";
    }

    function getUserByData($array) {
        $query = "
            SELECT 
                u.id,
                u.user,
                u.key,
                u.fullname,
                u.photo,
                u.rol,
                u.rol_id,
                u.sucursal,
                u.active,
                c.company,
                c.DB,
                c.ubication,
                c.logo,
                c.id as company_id
            FROM users u
            LEFT JOIN companies c ON u.company_id = c.id
            WHERE u.user = ?
            AND u.active = 1
        ";
        
        $result = $this->_Read($query, $array);
        return !empty($result) ? $result[0] : null;
    }

    function getUserById($array) {
        $query = "
            SELECT
                id,
                user,
                fullname,
                photo,
                rol,
                rol_id
            FROM users
            WHERE id = ?
        ";

        $result = $this->_Read($query, $array);
        return !empty($result) ? $result[0] : null;
    }

    function getSessionUser($array) {
        // [company_id activa, branch_id activa, id usuario]
        // La empresa y la sucursal son las de la sesión, no users.company_id: el
        // Super Admin entra a otras empresas. El rol sale de users_braches para la
        // SUCURSAL ACTIVA: un usuario puede tener un rol distinto por sucursal, asi
        // que se empareja ub por branch_id (no por LIMIT 1, que tomaba una fila arbitraria).
        $query = "
            SELECT
                u.id        AS id,
                TRIM(CONCAT(COALESCE(u.name, ''), ' ', COALESCE(u.last_name, ''))) AS user,
                u.email     AS email,
                u.photo     AS photo,
                u.color     AS color,
                u.is_owner  AS level,
                c.id        AS company_id,
                c.name      AS company,
                s.id        AS branch_id,
                s.name      AS branch,
                r.name      AS rol
            FROM {$this->bd}users u
            LEFT JOIN {$this->bd}companies c ON c.id = ?
            LEFT JOIN {$this->bd}branches s ON s.id = ?
            LEFT JOIN {$this->bd}users_braches ub ON ub.user_id = u.id AND ub.branch_id = s.id
            LEFT JOIN {$this->bd}roles r ON r.id = ub.role_id
            WHERE u.id = ?
            LIMIT 1
        ";

        $result = $this->_Read($query, $array);
        return !empty($result) ? $result[0] : null;
    }

    function getUserByCredentials($array) {
        // [email]
        $query = "
            SELECT
                u.id         AS IDU,
                u.name       AS name,
                u.last_name  AS last_name,
                u.email      AS email,
                u.password   AS password,
                u.photo      AS photo,
                u.color      AS color,
                u.is_owner   AS is_owner,
                u.company_id AS company_id,
                c.name       AS company,
                u.branch_id  AS branch_id,
                b.name       AS branch,
                b.company_id AS branch_company_id
            FROM {$this->bd}users u
            LEFT JOIN {$this->bd}companies c ON c.id = u.company_id
            LEFT JOIN {$this->bd}branches b ON b.id = u.branch_id
            WHERE LOWER(u.email) = LOWER(?)
                AND u.status = 'active'
            LIMIT 1
        ";

        $result = $this->_Read($query, $array);
        return !empty($result) ? $result[0] : null;
    }

    /* ===== Recuperación de contraseña (código de 6 dígitos) ===== */

    // La cuenta que pide el código. reset_vigente lo resuelve MySQL con su propio
    // NOW() para que el reloj que pone la caducidad y el que la revisa sean uno solo.
    function getUserForReset($array) {
        // [email]
        $query = "
            SELECT
                u.id          AS IDU,
                u.name        AS name,
                u.last_name   AS last_name,
                u.email       AS email,
                u.reset_code  AS reset_code,
                u.reset_tries AS reset_tries,
                (u.reset_expires IS NOT NULL AND u.reset_expires > NOW()) AS reset_vigente
            FROM {$this->bd}users u
            WHERE LOWER(u.email) = LOWER(?)
                AND u.status = 'active'
            LIMIT 1
        ";

        $result = $this->_Read($query, $array);
        return !empty($result) ? $result[0] : null;
    }

    function setResetCode($array) {
        // [hash del codigo, minutos de vigencia, id usuario]
        $query = "
            UPDATE {$this->bd}users
               SET reset_code    = ?,
                   reset_expires = DATE_ADD(NOW(), INTERVAL ? MINUTE),
                   reset_tries   = 0
             WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function addResetTry($array) {
        // [id usuario]
        $query = "UPDATE {$this->bd}users SET reset_tries = reset_tries + 1 WHERE id = ?";
        return $this->_CUD($query, $array);
    }

    function clearResetCode($array) {
        // [id usuario]
        $query = "
            UPDATE {$this->bd}users
               SET reset_code    = NULL,
                   reset_expires = NULL,
                   reset_tries   = 0
             WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // login() solo valida contra `password` (bcrypt), así que es la única llave que se escribe.
    // El código se tira en el mismo UPDATE: ya se gastó.
    function setNewPassword($array) {
        // [password bcrypt, id usuario]
        $query = "
            UPDATE {$this->bd}users
               SET password      = ?,
                   reset_code    = NULL,
                   reset_expires = NULL,
                   reset_tries   = 0
             WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // ¿Manda en alguna sucursal? Super Admin en cualquiera, o Dueño en una de SU
    // empresa: al iniciar sesión todavía no hay sucursal activa que consultar. Un
    // rol Dueño que se quedó en otra empresa (usuario que se cambió de empresa)
    // no cuenta: lo haría administrador de una empresa donde no lo es.
    function userIsAdmin($array) {
        // [user_id]
        $query = "
            SELECT 1
            FROM {$this->bd}users_braches ub
            JOIN {$this->bd}users u    ON u.id = ub.user_id
            JOIN {$this->bd}roles r    ON r.id = ub.role_id AND r.is_active = 1
            JOIN {$this->bd}branches b ON b.id = ub.branch_id
            WHERE ub.user_id = ?
                AND (r.code = 'superadmin' OR (r.code = 'dueno' AND b.company_id = u.company_id))
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return !empty($r);
    }

    // El orden de las sucursales en la navbar (y la primera, con la que arranca
    // la sesión si la suya no sirve) es branches.order; sin orden, al final y
    // por nombre.
    function getBranchesByCompany($array) {
        $query = "
            SELECT
                id,
                name,
                ubication,
                is_active,
                logo
            FROM {$this->bd}branches
            WHERE company_id = ?
                AND is_active = 1
            ORDER BY `order` IS NULL, `order` ASC, name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Sucursales asignadas al usuario en UNA empresa (la suya o la de la sesión).
    // Las que tenga en otra no salen en el selector de la navbar ni sirven para
    // arrancar la sesión: tampoco puede cambiarse a ellas (switchBranch).
    function getBranchesByUser($array) {
        // [user_id, company_id]
        $query = "
            SELECT
                b.id,
                b.name,
                b.ubication,
                b.is_active,
                b.logo
            FROM {$this->bd}users_braches ub
            INNER JOIN {$this->bd}branches b ON b.id = ub.branch_id
            WHERE ub.user_id = ?
                AND b.company_id = ?
                AND b.is_active = 1
            ORDER BY b.`order` IS NULL, b.`order` ASC, b.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function getBranchById($array) {
        $query = "
            SELECT
                id,
                name,
                company_id,
                ubication,
                is_active
            FROM {$this->bd}branches
            WHERE id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return !empty($r) ? $r[0] : null;
    }

    function userHasAccessToBranch($array) {
        $query = "
            SELECT 1
            FROM {$this->bd}users_braches
            WHERE user_id = ?
                AND branch_id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return !empty($r);
    }

    // Secciones que el usuario ve en una sucursal: las encendidas, de módulo
    // encendido, en las que su rol tiene al menos una acción concedida
    // (users_braches -> permissions_roles -> permissions -> sections). Base del
    // menú dinámico. module_id = 0 trae las de todos los módulos.
    function getAccessibleSections($array) {
        // [user_id, branch_id, module_id, module_id]
        $query = "
            SELECT
                s.id, s.name, s.code, s.icon, s.route, s.orden,
                m.name AS module_name
            FROM {$this->bd}sections s
            JOIN {$this->bd}modules m ON m.id = s.module_id AND m.is_active = 1
            WHERE s.is_active = 1
                AND EXISTS (
                    SELECT 1
                    FROM {$this->bd}users_braches ub
                    JOIN {$this->bd}roles r              ON r.id = ub.role_id AND r.is_active = 1
                    JOIN {$this->bd}permissions_roles pr ON pr.role_id = r.id
                    JOIN {$this->bd}permissions p        ON p.id = pr.permission_id AND p.is_active = 1
                    JOIN {$this->bd}type_permissions tp  ON tp.id = p.type_permission_id AND tp.is_active = 1
                    WHERE ub.user_id = ? AND ub.branch_id = ?
                        AND p.section_id = s.id
                )
                AND (? = 0 OR s.module_id = ?)
            ORDER BY m.orden ASC, s.orden ASC, s.id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // ¿Es Super Admin? Basta con tenerlo en CUALQUIER sucursal: es un rol del
    // sistema que entra a todas las empresas, también a las que no tienen filas
    // suyas en users_braches. No lleva filas en permissions_roles: su acceso es
    // total y el tenant no deja editarlo.
    function userIsSuperAdmin($array) {
        // [user_id]
        $query = "
            SELECT 1
            FROM {$this->bd}users_braches ub
            JOIN {$this->bd}roles r ON r.id = ub.role_id AND r.is_active = 1
            WHERE ub.user_id = ?
                AND r.code = 'superadmin'
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return !empty($r);
    }

    // Todas las secciones encendidas de módulos encendidos (menú del Super Admin).
    // module_id = 0 trae todos los módulos.
    function getAllActiveSections($array) {
        // [module_id, module_id]
        $query = "
            SELECT
                s.id, s.name, s.code, s.icon, s.route, s.orden,
                m.name AS module_name
            FROM {$this->bd}sections s
            JOIN {$this->bd}modules m ON m.id = s.module_id AND m.is_active = 1
            WHERE s.is_active = 1
                AND (? = 0 OR s.module_id = ?)
            ORDER BY m.orden ASC, s.orden ASC, s.id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Modulos activos (id + route) ordenados por ruta mas larga primero, para
    // resolver a que modulo pertenece la pagina actual por prefijo de ruta.
    function getModulesForMatch() {
        $query = "
            SELECT id, route
            FROM {$this->bd}modules
            WHERE is_active = 1 AND route IS NOT NULL AND route <> ''
            ORDER BY CHAR_LENGTH(route) DESC
        ";
        $r = $this->_Read($query, null);
        return is_array($r) ? $r : [];
    }

    /* ===== Temas del navbar (themes) ===== */

    // Catalogo de temas activos para el selector de la barra.
    function getThemes() {
        $query = "
            SELECT code, name, tipo, color, image, accent, primary_color, secondary_color, sidebar_color, scheme, mode, badge, is_default, orden
            FROM {$this->bd}themes
            WHERE is_active = 1
            ORDER BY orden ASC, id ASC
        ";
        $r = $this->_Read($query, null);
        return is_array($r) ? $r : [];
    }

    // Temas que puede ver una empresa: los asignados en company_themes más el de
    // por defecto, que siempre está. Sin asignaciones queda solo el de por defecto.
    function getThemesByCompany($array) {
        // [company_id]
        $query = "
            SELECT t.code, t.name, t.tipo, t.color, t.image, t.accent, t.primary_color, t.secondary_color, t.sidebar_color, t.scheme, t.mode, t.badge, t.is_default, t.orden
            FROM {$this->bd}themes t
            LEFT JOIN {$this->bd}company_themes ct ON ct.theme_id = t.id AND ct.company_id = ?
            WHERE t.is_active = 1
                AND (t.is_default = 1 OR ct.id IS NOT NULL)
            ORDER BY t.orden ASC, t.id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Avisos de la campana: pedidos que le piden a la sucursal y siguen Solicitada (nadie los
    // ha revisado), también los que hizo el mismo usuario. Hace cuánto se mide con el reloj de
    // MySQL, el mismo que llena created_at (PHP corre en UTC). Las compras (CP-) no cuentan.
    function getPedidosPorSurtir($array) {
        // [companies_id, destination_branch_id]
        $query = "
            SELECT
                po.id,
                po.folio,
                po.total_products,
                s.name AS branch_name,
                TIMESTAMPDIFF(MINUTE, po.created_at, NOW()) AS minutos,
                DATEDIFF(CURDATE(), DATE(po.created_at))    AS dias
            FROM {$this->bdInv}purchase_order po
            LEFT JOIN {$this->bd}branches s ON s.id = po.branch_id
            WHERE po.active = 1
                AND po.companies_id = ?
                AND po.destination_branch_id = ?
                AND po.status = 'Solicitada'
                AND po.folio NOT LIKE 'CP-%'
            ORDER BY po.created_at DESC, po.id DESC
            LIMIT 20
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Tema guardado del usuario. NULL cuando nunca ha elegido uno.
    function getUserTheme($array) {
        // [user_id]
        $query = "SELECT theme_code FROM {$this->bd}users WHERE id = ? LIMIT 1";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0]['theme_code'] : null;
    }

    function setUserTheme($array) {
        // [theme_code, user_id]
        $query = "UPDATE {$this->bd}users SET theme_code = ? WHERE id = ?";
        return $this->_CUD($query, $array);
    }

    // Valida que el code exista y este activo antes de guardarlo.
    function themeExists($array) {
        // [code]
        $query = "SELECT id FROM {$this->bd}themes WHERE code = ? AND is_active = 1 LIMIT 1";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r);
    }
}
