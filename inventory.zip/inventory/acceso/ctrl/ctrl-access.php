<?php
// Sesion de 8 horas, propia de inventory: ver conf/_Session.php.
require_once __DIR__ . '/../../conf/_Session.php';
if (empty($_POST['opc'])) exit(0);
$opc = $_POST['opc'];

require_once('../mdl/mdl-access.php');
require_once('../../conf/_Message.php');
require_once __DIR__ . '/../../conf/_Auditoria.php';
require_once __DIR__ . '/../../conf/_Permissions.php';

class Access extends MAccess {

    // Recuperación de contraseña: cuánto vive el código y cuántos tiros hay.
    // Seis dígitos son un millón de combinaciones; con 15 minutos y 5 intentos
    // la ventana de quien prueba a ciegas son 5 tiros entre un millón.
    const RESET_MINUTES     = 15;
    const RESET_MAX_TRIES   = 5;
    const RESET_CODE_LENGTH = 6;
    const PASSWORD_MIN      = 4;

    function login() {
            $user = trim(str_replace("'", "", $_POST['usuario'] ?? ''));
            $pass = str_replace("'", "", $_POST['clave'] ?? '');

            $usr = $this->getUserByCredentials([$user]);

            // Solo users.password (bcrypt): no se lee `key` ni `password2` porque
            // cada BD local tiene una u otra y la que falta tumba el SELECT.
            $valid = $usr
                && !empty($usr['password'])
                && password_verify($pass, $usr['password']);

            if (!$valid) {
                return false;
            }

            // Id nuevo en cada login: nadie puede entrar con un id que ya conociera
            // de antes. La cookie sale con 30 dias si marco "Recordar mi usuario en
            // este equipo" y con 8 horas si no (conf/_Session.php).
            session_regenerate_id(true);
            invSessionRecordar(!empty($_POST['recordar']));

            $expira = time() + (365 * 24 * 60 * 60);
            setcookie("IDU",        $usr['IDU'],        $expira, "/");
            setcookie("company_id", $usr['company_id'], $expira, "/");
            setcookie("company",    $usr['company'],    $expira, "/");

            $isSuperAdmin = $this->userIsSuperAdmin([$usr['IDU']]);
            $branch       = $this->homeBranch($usr, $isSuperAdmin);

            $_SESSION['IDU']        = $usr['IDU'];             // id usuario (clave que validan las páginas: sucursales, almacén, etc.)
            $_SESSION['user_id']    = $usr['IDU'];             // alias id usuario
            $_SESSION['company_id'] = $usr['company_id'];      // id compania
            $_SESSION['branch_id']  = $branch['id'];           // id sucursal
            $_SESSION['company']    = $usr['company'];         // nombre de la compania
            $_SESSION['branch']     = $branch['name'];         // nombre de la sucursal

            $_SESSION['user']       = trim(($usr['name'] ?? '') . ' ' . ($usr['last_name'] ?? ''));
            $_SESSION['email']      = $usr['email'] ?? '';
            // is_owner en sesión decide si se ven TODAS las sucursales de la empresa
            // (navbar, filtros de sucursal de inventario). El Super Admin entra a
            // empresas donde no tiene filas en users_braches: las ve como un dueño.
            $_SESSION['is_owner']      = $isSuperAdmin ? 1 : $usr['is_owner'];
            $_SESSION['is_superadmin'] = $isSuperAdmin ? 1 : 0;
            $_SESSION['last_activity'] = time();

            // Administrador de CoffeeIA (borrar entradas, salidas y pedidos): el
            // dueño (is_owner) y cualquiera con rol Super Admin o Dueño.
            $isAdmin = (int) ($usr['is_owner'] ?? 0) === 1 || $this->userIsAdmin([$usr['IDU']]);
            $_SESSION['is_admin'] = $isAdmin ? 1 : 0;

            Auditoria::registrar('iniciar-sesion', 'sesion', (int) $usr['IDU'], $_SESSION['user'], [
                'sucursal' => $branch['name']
            ]);

            return [
                "IDU"        => $usr['IDU'],
                "company_id" => $usr['company_id'],
                "company"    => $usr['company'],
                "user"       => $_SESSION['user'],
                // El correo lo usa el login para recordar al usuario en este navegador.
                "email"      => $_SESSION['email'],
                "photo"      => $this->photoUrl($usr['photo'] ?? ''),
                // Color elegido para el usuario: pinta su avatar en el login recordado
                // y en la navbar.
                "color"      => $usr['color'] ?? '',
                "is_owner"   => $usr['is_owner'],
                "is_admin"   => $_SESSION['is_admin'],
                // El Super Admin aterriza en la pantalla de empresas; los demás, en módulos.
                "is_superadmin" => $_SESSION['is_superadmin'],
            ];
    }

    /*  Sucursal con la que arranca la sesión: la suya (users.branch_id) si está
        activa y la puede usar; si no, la primera que sí. Sin el selector de
        sucursal de por medio, una sucursal en la que no tiene rol dejaría la
        pantalla de módulos vacía. El dueño y el Super Admin pueden usar
        cualquiera de la empresa. */
    private function homeBranch($usr, $isSuperAdmin) {
        $isOwner = $isSuperAdmin || (int) ($usr['is_owner'] ?? 0) === 1;
        $list    = $isOwner
            ? $this->getBranchesByCompany([$usr['company_id']])
            : $this->getBranchesByUser([$usr['IDU'], $usr['company_id']]);

        foreach ($list as $b) {
            if ((int) $b['id'] === (int) $usr['branch_id']) return ['id' => (int) $b['id'], 'name' => $b['name']];
        }

        if (!empty($list)) return ['id' => (int) $list[0]['id'], 'name' => $list[0]['name']];

        // Sin sucursales en su empresa: la suya solo si es de esa misma empresa.
        // Una de otra empresa armaría una sesión cruzada (empresa A, sucursal de B).
        if ((int) ($usr['branch_company_id'] ?? 0) === (int) $usr['company_id']) {
            return ['id' => $usr['branch_id'], 'name' => $usr['branch']];
        }
        return ['id' => 0, 'name' => ''];
    }

    /* ===== Recuperación de contraseña =====
       Tres pasos, los tres los llama inventory/recuperar.php:
         1. forgotPassword() manda el código al correo
         2. verifyCode()     solo abre el paso 3
         3. resetPassword()  escribe la contraseña nueva
       Portado de erp-pro/pro/auth/ctrl/ctrl-auth.php. */

    /*  PASO 1 :: EL CÓDIGO SE GUARDA DESPUÉS DE ENTREGARLO. Si el correo no
        sale no se escribe nada, porque un código que nadie llegó a leer solo
        sirve para gastarle los intentos al siguiente.

        La respuesta distingue "no existe esa cuenta" de "no se pudo entregar":
        le dice a cualquiera si un correo está dado de alta, pero sin eso quien
        escribe un correo viejo se queda esperando un mensaje que no va a llegar. */
    function forgotPassword() {
        $correo = trim($_POST['correo'] ?? '');

        if ($correo === '') {
            return ['status' => 400, 'message' => 'Escribe tu correo.', 'data' => null];
        }

        $usuario = $this->getUserForReset([$correo]);

        if (empty($usuario)) {
            return [
                'status'  => 404,
                'message' => 'No encontramos una cuenta activa con ese correo.',
                'data'    => null
            ];
        }

        $codigo  = $this->resetCode();
        $nombre  = trim($usuario['name'] ?? '');
        $saludo  = $nombre === '' ? 'Hola.' : "Hola, {$nombre}.";
        $mensaje = new Message;

        $entregado = $mensaje->correo(
            $usuario['email'],
            'Código para recuperar tu contraseña — Coffee Inventory',
            $saludo . "\n\n" . $this->recoveryMessage($codigo)
        );

        if ($entregado !== true) {
            return [
                'status'  => 502,
                'message' => 'No pudimos entregarte el código. Inténtalo más tarde; tu contraseña actual sigue funcionando.',
                'data'    => null
            ];
        }

        if ($this->setResetCode([password_hash($codigo, PASSWORD_BCRYPT), self::RESET_MINUTES, $usuario['IDU']]) !== true) {
            // Salió el correo pero no se guardó el código: el que acaba de leer
            // no le va a servir, y hay que decírselo.
            return [
                'status'  => 500,
                'message' => 'Enviamos el correo pero no pudimos registrar el código. Inténtalo de nuevo.',
                'data'    => null
            ];
        }

        return [
            'status'  => 200,
            'message' => 'Te enviamos un código a tu correo.',
            'data'    => ['minutos' => self::RESET_MINUTES]
        ];
    }

    /*  PASO 2 :: no entrega nada ni firma ninguna sesión, solo abre la pantalla
        de la contraseña nueva. Por eso resetPassword() vuelve a pedir el código:
        si este paso fuera el único guardián, bastaría con saltárselo. */
    function verifyCode() {
        $correo = trim($_POST['correo'] ?? '');
        $codigo = trim($_POST['codigo'] ?? '');

        $usuario = $correo === '' ? null : $this->getUserForReset([$correo]);

        if (empty($usuario)) {
            return ['status' => 404, 'message' => 'No encontramos esa cuenta. Vuelve a empezar.', 'data' => null];
        }

        $revision = $this->checkCode($usuario, $codigo);

        return [
            'status'  => $revision['status'],
            'message' => $revision['message'],
            'data'    => $revision['status'] === 200 ? ['minimo' => self::PASSWORD_MIN] : null
        ];
    }

    // PASO 3 :: el código es lo único que demuestra que quien escribe la
    // contraseña es quien recibió el correo, así que se comprueba otra vez.
    function resetPassword() {
        $correo   = trim($_POST['correo'] ?? '');
        $codigo   = trim($_POST['codigo'] ?? '');
        $nueva    = (string) ($_POST['nueva'] ?? '');
        $confirma = (string) ($_POST['confirmar'] ?? '');

        $usuario = $correo === '' ? null : $this->getUserForReset([$correo]);

        if (empty($usuario)) {
            return ['status' => 404, 'message' => 'No encontramos esa cuenta. Vuelve a empezar.', 'data' => null];
        }

        // El código va ANTES que la contraseña: si está vencido da igual lo que
        // haya escrito, y así no se le va un intento en corregir algo inútil.
        $revision = $this->checkCode($usuario, $codigo);

        if ($revision['status'] !== 200) {
            return ['status' => $revision['status'], 'message' => $revision['message'], 'data' => null];
        }

        if ($nueva === '' || $confirma === '') {
            return ['status' => 400, 'message' => 'Escribe la contraseña nueva dos veces.', 'data' => null];
        }

        if (mb_strlen($nueva) < self::PASSWORD_MIN) {
            return ['status' => 400, 'message' => 'La contraseña debe tener al menos ' . self::PASSWORD_MIN . ' caracteres.', 'data' => null];
        }

        if ($nueva !== $confirma) {
            return ['status' => 400, 'message' => 'Las dos contraseñas no coinciden.', 'data' => null];
        }

        $guardada = $this->setNewPassword([
            password_hash($nueva, PASSWORD_BCRYPT),
            $usuario['IDU']
        ]);

        return $guardada === true
             ? ['status' => 200, 'message' => 'Tu contraseña quedó lista. Ya puedes iniciar sesión.', 'data' => null]
             : ['status' => 500, 'message' => 'No pudimos guardar la contraseña. Inténtalo de nuevo.', 'data' => null];
    }

    /*  ¿VALE ESTE CÓDIGO? El único sitio donde se decide.

        El orden de las preguntas importa: primero si hay código, luego si sigue
        vivo, luego si quedan tiros y solo al final si acierta. Así un código
        vencido no gasta intentos y el mensaje dice lo que de verdad pasa.

        AL QUINTO FALLO EL CÓDIGO SE TIRA: si alguien está probando a ciegas, lo
        que no puede es seguir teniendo blanco. */
    private function checkCode($usuario, $codigo) {
        $guardado = (string) ($usuario['reset_code'] ?? '');
        $fallos   = (int) ($usuario['reset_tries'] ?? 0);

        if ($guardado === '') {
            return ['status' => 409, 'message' => 'No tienes ningún código pendiente. Pide uno nuevo.'];
        }

        if (empty($usuario['reset_vigente'])) {
            return ['status' => 410, 'message' => 'El código ya venció. Pide uno nuevo.'];
        }

        if ($fallos >= self::RESET_MAX_TRIES) {
            return ['status' => 429, 'message' => 'Se agotaron los intentos. Pide un código nuevo.'];
        }

        // Seis dígitos o no es un código. No gasta intento: al que se le coló un
        // espacio no hay por qué cobrárselo.
        if (!preg_match('/^[0-9]{' . self::RESET_CODE_LENGTH . '}$/', $codigo)) {
            return ['status' => 400, 'message' => 'El código son ' . self::RESET_CODE_LENGTH . ' dígitos.'];
        }

        if (password_verify($codigo, $guardado)) {
            return ['status' => 200, 'message' => 'Código correcto.'];
        }

        $fallos++;

        if ($fallos >= self::RESET_MAX_TRIES) {
            $this->clearResetCode([$usuario['IDU']]);

            return ['status' => 429, 'message' => 'Se agotaron los intentos. Pide un código nuevo.'];
        }

        $this->addResetTry([$usuario['IDU']]);

        $quedan = self::RESET_MAX_TRIES - $fallos;

        return [
            'status'  => 401,
            'message' => 'El código no es correcto. Te ' . ($quedan === 1 ? 'queda 1 intento' : "quedan {$quedan} intentos") . '.'
        ];
    }

    // random_int() y no random_bytes() con módulo: aquel repartía 256 valores
    // entre 10 dígitos, así que del 0 al 5 salían más seguido que del 6 al 9.
    private function resetCode() {
        $codigo = '';

        for ($i = 0; $i < self::RESET_CODE_LENGTH; $i++) $codigo .= random_int(0, 9);

        return $codigo;
    }

    /*  El correo dice DOS cosas que no son adorno: cuánto dura el código, para
        que no lo teclee media hora después y crea que el sistema está roto; y
        que su contraseña de siempre sigue sirviendo, que es lo que permite a
        quien no pidió nada ignorar el mensaje sin hacer nada más. */
    private function recoveryMessage($codigo) {
        $texto  = "Tu código para recuperar el acceso a Coffee Inventory es:\n\n";
        $texto .= "{$codigo}\n\n";
        $texto .= "Vence en " . self::RESET_MINUTES . " minutos. Escríbelo aquí y ahí mismo eliges tu nueva contraseña:\n";
        $texto .= $this->baseUrl() . "recuperar.php\n\n";
        $texto .= "Si no has sido tú, ignora este mensaje: tu contraseña actual sigue funcionando.";

        return $texto;
    }

    /*  La foto del usuario, lista para meter en un <img src>.

        `users.photo` guarda el NOMBRE del archivo dentro de
        inventory/uploads/users/ y aquí se le arma la URL con baseUrl(), que sale
        de la ruta real del controlador: así no hay un '/inventory/' escrito a
        mano que se rompa cuando el proyecto cuelga de una subcarpeta.

        Si el valor ya viene como URL (http...) o como ruta absoluta (/...) se
        deja igual: el día que la carga de imágenes guarde una ruta completa
        --o una foto de Google-- esto sigue sirviendo sin tocarse. */
    private function photoUrl($photo) {
        $photo = trim((string) $photo);

        if ($photo === '')                                  return '';
        if (preg_match('#^(https?:)?//#', $photo))          return $photo;
        if ($photo[0] === '/')                              return $photo;

        return $this->baseUrl() . 'uploads/users/' . rawurlencode($photo);
    }

    // La URL del login. Sale de la ruta de este controlador
    // (/inventory/acceso/ctrl/) y no escrita a mano, así una prueba desde local
    // manda a local.
    private function baseUrl() {
        $esquema = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host    = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $ruta    = dirname(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '')));

        return $esquema . '://' . $host . rtrim(str_replace('\\', '/', $ruta), '/') . '/';
    }

    function company() {
        // La empresa y la sucursal son las de la sesión (el Super Admin cambia de
        // empresa sin cambiar de usuario). El rol depende de la sucursal accedida:
        // users_braches -> roles de esa sucursal (no de una cualquiera).
        $userId    = (int) ($_SESSION['IDU'] ?? 0);
        $companyId = (int) ($_SESSION['company_id'] ?? 0);
        $branchId  = (int) ($_SESSION['branch_id'] ?? 0);
        $sql = $userId > 0 ? $this->getSessionUser([$companyId, $branchId, $userId]) : null;

        // En una empresa donde no tiene filas en users_braches, el Super Admin no
        // trae rol de la sucursal: se nombra igual.
        $isSuperAdmin = $userId > 0 && $this->userIsSuperAdmin([$userId]);

        // Se prioriza el valor vivo de la BD sobre el cacheado en sesion (login viejo),
        // asi un rename de compania/sucursal se refleja sin cerrar sesion.
        $company = $sql['company'] ?? ($_SESSION['company'] ?? '');
        // Sucursal asignada: se resuelve desde branches por branch_id (igual que inventario).
        $branch  = $sql['branch'] ?? ($_SESSION['branch'] ?? '');

        return [
            "photo"      => $this->photoUrl($sql['photo'] ?? ''),
            "color"      => $sql['color'] ?? '',
            "user"       => $sql['user'] ?? ($_SESSION['user'] ?? 'Usuario'),
            "email"      => $sql['email'] ?? ($_SESSION['email'] ?? ''),
            "rol"        => ($sql['rol'] ?? '') ?: ($isSuperAdmin ? 'Super Admin' : ''),
            "is_superadmin" => $isSuperAdmin ? 1 : 0,
            "level"      => isset($sql['level']) ? (int)$sql['level'] : 0,
            "company"    => $company,
            "company_id" => $sql['company_id'] ?? ($_SESSION['company_id'] ?? null),
            "sucursal"   => $branch,
            "branch"     => $branch,
            "branch_id"  => $sql['branch_id'] ?? ($_SESSION['branch_id'] ?? null),
            // Compatibilidad con el navbar (lee udn/negocio).
            "udn"        => $company,
            "negocio"    => $company,
        ];
    }

    function sidebar() {
        $sidebar = [
            [
                "text"    => "Ventas",
                "submenu" => [
                    // ["text" => "Eventos", "url" => "/dev/eventos/"],
                    ["text" => "Pedidos", "url" => "/dev/pedidos/"],
                    ["text" => "Reservaciones", "url" => "/dev/reservaciones/"],
                    ["text" => "Dashboard", "url" => "/dev/dashboard/"],
                    ["text" => "Administración", "url" => "/dev/admin-pedidos/"]
                ]
            ]
        ];

        if((int)($_SESSION['is_owner'] ?? 0) === 1 ){
          $sidebar[] = [
            "text"    => "Configuracion",
            "submenu" => [
                ["text" => "Empresas", "url" => "/dev/empresas/"],
                ["text" => "Usuarios", "url" => "/dev/usuarios/"],
            ]
          ];
        }


      $rrhh = [
        "text"=> "Recursos Humanos", "submenu"=> [
          [ "text"=> "Personal", "url"=> "#" ],
          [ "text"=> "Incidencia", "url"=> "#" ],
          [ "text"=> "Nómina", "url"=> "#" ],
          [ "text"=> "Permisos", "url"=> "#" ],
          [ "text"=> "Desempeño", "url"=> "#" ],
          [ "text"=> "Reclutamiento", "url"=> "#" ],
          [ "text"=> "Actas", "url"=> "#" ],
          [ "text"=> "Reconocimientos", "url"=> "#" ],
          [ "text"=> "Configuración", "url"=> "#" ],
        ]
      ];

      $finanzas = [
            "text"=> "Finanzas", "submenu"=> [
                [ "text"=> "Ingresos", "url"=> "#" ],
                [ "text"=> "Egresos", "url"=> "#" ],
                [ "text"=> "Cuentas por pagar", "url"=> "#" ],
                [ "text"=> "Cuentas por cobrar", "url"=> "#" ],
                [ "text"=> "Ordenes de compra", "url"=> "#" ],
                [ "text"=> "Proveedores", "url"=> "#" ],
                [ "text"=> "Recepción y entrega", "url"=> "#" ],
                [ "text"=> "Auditoría", "url"=> "#" ],
                [ "text"=> "Reportes", "url"=> "#" ],
                [ "text"=> "Presupuesto", "url"=> "#" ],
            ]
        ];

        return $sidebar;
    }

    // Menú lateral dinámico: secciones a las que el usuario logueado tiene acceso
    // en su sucursal activa. Fail-closed: si no hay sesión o no hay permisos, regresa vacío.
    function menu () {
        $userId   = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0);
        $branchId = (int) ($_SESSION['branch_id'] ?? 0);

        if ($userId <= 0 || $branchId <= 0) {
            return ['status' => 200, 'items' => []];
        }

        // Modulo actual: se resuelve por la ruta de la pagina (relativa a /inventory/)
        // que envia el sidebar. Asi el menu muestra solo las secciones de ese modulo.
        $moduleId = $this->resolveModuleId($_POST['module'] ?? '');

        // Con modulo resuelto se acota a sus secciones; si no (pagina fuera de un
        // modulo) quedan todas las accesibles. Una seccion se ve cuando el rol tiene
        // al menos una de sus acciones (permissions_roles). El Super Admin ve todas
        // las secciones encendidas: su acceso es total y no lleva filas.
        $ls = $this->userIsSuperAdmin([$userId])
            ? $this->getAllActiveSections([$moduleId, $moduleId])
            : $this->getAccessibleSections([$userId, $branchId, $moduleId, $moduleId]);

        $items = [];
        foreach ($ls as $s) {
            // Sin ruta no hay a donde ir: el rail armaria base + '' = raiz de
            // inventory, que es el login, y el usuario lo vive como "me saco la sesion".
            $route = trim((string) ($s['route'] ?? ''));
            if ($route === '') continue;

            $items[] = [
                'code'  => $s['code'],
                'title' => $s['name'],
                'icon'  => $s['icon'] ?: 'square',     // ícono por defecto si falta
                'route' => $route                      // ruta relativa a inventory/
            ];
        }

        return ['status' => 200, 'items' => $items, 'module_id' => $moduleId];
    }

    // Empareja la ruta de la pagina (relativa a /inventory/) contra modules.route,
    // tomando el prefijo de ruta mas largo (segmento a segmento). 0 si no hay match.
    private function resolveModuleId($path) {
        $path = trim((string) $path, "/ \t\n\r\0\x0B");
        if ($path === '') return 0;

        foreach ($this->getModulesForMatch() as $m) {
            $route = trim((string) $m['route'], '/');
            if ($route === '') continue;
            // Match exacto o por segmento: "operacion/almacen" cubre
            // "operacion/almacen/stock.php" pero "admin" no cubre "administracion".
            if ($path === $route || strpos($path . '/', $route . '/') === 0) {
                return (int) $m['id'];
            }
        }
        return 0;
    }

    function branches() {
        $userId   = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0);
        $isOwner  = (int) ($_SESSION['is_owner'] ?? 0);

        // Solo las de la empresa de la sesión: un usuario con sucursales de otra
        // empresa (se cambió de empresa) las veía aquí aunque no pudiera usarlas.
        if ($isOwner === 1) {
            $list = $this->getBranchesByCompany([$_SESSION['company_id']]);
        } else {
            $list = $this->getBranchesByUser([$userId, (int) ($_SESSION['company_id'] ?? 0)]);
        }

        $branches = [];
        foreach ($list as $branch) {
            $parts    = preg_split('/\s+/', trim($branch['name']));
            $initials = strtoupper(substr($parts[0], 0, 1));
            if (count($parts) > 1) {
                $initials .= strtoupper(substr(end($parts), 0, 1));
            }

            $branches[] = [
                'id'        => (int) $branch['id'],
                'name'      => $branch['name'],
                'ubication' => $branch['ubication'] ?? '',
                'active'    => (int) $branch['is_active'],
                'initials'  => $initials,
                'selected'  => ((int) $branch['id'] === (int) ($_SESSION['branch_id'] ?? 0)) ? 1 : 0,
            ];
        }

        return [
            'status'   => 200,
            'company'  => $_SESSION['company'] ?? '',
            'current'  => [
                'id'   => (int) ($_SESSION['branch_id'] ?? 0),
                'name' => $_SESSION['branch'] ?? '',
            ],
            'branches' => $branches,
        ];
    }

    function switchBranch() {
        $id = $_POST['id'];

        $branch = $this->getBranchById([$id]);

        if (!$branch) {
            return [
                'status'  => 404,
                'message' => 'Sucursal no encontrada',
            ];
        }

        if ((int) $branch['company_id'] !== (int) ($_SESSION['company_id'] ?? 0)) {
            return [
                'status'  => 403,
                'message' => 'No tienes acceso a esta sucursal',
            ];
        }

        $isOwner = (int) ($_SESSION['is_owner'] ?? 0);
        if ($isOwner !== 1) {
            $userId = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0);
            if (!$this->userHasAccessToBranch([$userId, (int) $id])) {
                return [
                    'status'  => 403,
                    'message' => 'Esta sucursal no está asignada a tu usuario',
                ];
            }
        }

        $_SESSION['branch_id'] = (int) $branch['id'];
        $_SESSION['branch']    = $branch['name'];

        return [
            'status'  => 200,
            'message' => 'Sucursal cambiada correctamente',
            'branch'  => [
                'id'   => (int) $branch['id'],
                'name' => $branch['name'],
            ],
        ];
    }

    /* ===== Temas del navbar ===== */

    // Catalogo + el tema elegido por el usuario. Sin sesion se responde igual,
    // con el tema por defecto, para que la barra del login tambien se pinte.
    // Un tema pinta la barra (como en erp-pro) y trae el acento y el primario
    // de la pagina (hex). El fondo de la pagina no cambia.
    function themes() {
        $userId = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0);
        $ls     = $this->allowedThemes($userId);

        $themes  = [];
        $codes   = [];
        $default = '';
        foreach ($ls as $t) {
            if ((int) $t['is_default'] === 1) $default = $t['code'];
            $codes[]  = $t['code'];
            $themes[] = [
                'code'      => $t['code'],
                'name'      => $t['name'],
                'tipo'      => $t['tipo'],
                'color'     => $t['color'],
                'image'     => $t['tipo'] === 'imagen' ? $this->themeImageUrl($t['image']) : '',
                'accent'    => $t['accent'],
                'primary'   => $t['primary_color'],
                'secondary' => $t['secondary_color'],
                'sidebar'   => $t['sidebar_color'] ?: '',
                'scheme'    => $t['scheme'],
                'mode'      => $t['mode'],
                'badge'     => $t['badge'] ?: '',
            ];
        }

        if ($default === '' && !empty($codes)) $default = $codes[0];

        // Un tema elegido que despues se apago ya no esta en el catalogo: esa
        // persona ve el de por defecto, igual que quien nunca eligio.
        $current = $userId > 0 ? $this->getUserTheme([$userId]) : null;
        if (!in_array($current, $codes, true)) $current = $default;

        return [
            'status'  => 200,
            'themes'  => $themes,
            'current' => $current,
        ];
    }

    // La imagen del tema lista para un url(). La base sale de la ruta real de
    // este controlador (.../inventory/acceso/ctrl/). El ?v= cambia al resubirla,
    // porque el archivo conserva su nombre y el navegador serviria la vieja.
    private function themeImageUrl($image) {
        $image = trim((string) $image);
        if ($image === '') return '';

        $file = __DIR__ . '/../../' . $image;
        if (!is_file($file)) return '';

        $base = dirname(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '')));
        $base = rtrim(str_replace('\\', '/', $base), '/');

        return $base . '/' . $image . '?v=' . filemtime($file);
    }

    function saveTheme() {
        $userId = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0);
        $code   = trim($_POST['code'] ?? '');

        if ($userId <= 0)                 return ['status' => 401, 'message' => 'Sin sesión'];
        if ($code === '')                 return ['status' => 400, 'message' => 'Tema no válido'];
        if (!$this->themeExists([$code])) return ['status' => 404, 'message' => 'Ese tema no existe'];

        $allowed = array_column($this->allowedThemes($userId), 'code');
        if (!in_array($code, $allowed, true)) {
            return ['status' => 403, 'message' => 'Ese tema no está habilitado para tu empresa'];
        }

        $ok = $this->setUserTheme([$code, $userId]);
        return ['status' => $ok ? 200 : 500, 'message' => $ok ? 'Tema guardado' : 'No se pudo guardar el tema'];
    }

    // Temas que puede elegir el usuario: el Super Admin todos; los demás, los de su
    // empresa más el de por defecto. Sin sesión, solo el de por defecto (la barra
    // del login).
    private function allowedThemes($userId) {
        if ($userId > 0 && $this->userIsSuperAdmin([$userId])) {
            return $this->getThemes();
        }

        return $this->getThemesByCompany([(int) ($_SESSION['company_id'] ?? 0)]);
    }

    // -- Avisos de la campana --

    // Requisiciones que le llegaron a la sucursal de la sesión y siguen sin revisar
    // (Solicitada, el punto verde de Despacho). Solo para quien puede entrar a Despacho;
    // sin sesión o sin sucursal, ninguna. `url` abre la requisición en Despacho.
    function lsAvisos() {
        $companyId = (int) ($_SESSION['company_id'] ?? 0);
        $branchId  = (int) ($_SESSION['branch_id'] ?? 0);

        if ($companyId <= 0 || $branchId <= 0 || empty(Permissions::actions('despacho'))) {
            return ['status' => 200, 'items' => []];
        }

        $items = array_map(function ($pedido) {
            $materiales = (int) $pedido['total_products'];

            return [
                'id'      => (int) $pedido['id'],
                'folio'   => $pedido['folio'],
                'titulo'  => 'Nueva requisición',
                'detalle' => ($pedido['branch_name'] ?: 'Una sucursal') . " pide {$materiales} " . ($materiales === 1 ? 'material' : 'materiales'),
                'minutos' => (int) $pedido['minutos'],
                'dias'    => (int) $pedido['dias'],
                'url'     => 'operacion/almacen/despacho.php?pedido=' . (int) $pedido['id'] . '&folio=' . rawurlencode($pedido['folio'])
            ];
        }, $this->getPedidosPorSurtir([$companyId, $branchId]));

        return ['status' => 200, 'items' => $items];
    }

    // SESSION
    function checkSession() {
        define('SESSION_TIMEOUT', 28800);  // 8 horas
        define('WARNING_TIME', 300);       // 5 minutos antes de expirar

          // Verificar si la sesión existe
        if (!isset($_SESSION['last_activity'])) {
            $_SESSION['last_activity'] = time();  // Inicializar si no está definida
        }

        $inactive_time = time() - $_SESSION['last_activity'];
        $result        = [
            "status"  => 200,
            "message" => "active",
        ];

          // Verifica si la sesión está activa
        if ($inactive_time >= SESSION_TIMEOUT) {
            $this->logout();
            $result = ["status" => "expired"];  // Notificar al frontend que la sesión expiró
            exit   (json_encode($result));      // Salir inmediatamente
        } elseif ($inactive_time >= (SESSION_TIMEOUT - WARNING_TIME)) {
            $time_left = SESSION_TIMEOUT - $inactive_time;
            $result    = [
                "status"        => "warning",
                "time_left"     => $time_left,
                "inactive_time" => $inactive_time
            ];
        }

        return $result;
    }

    function updateSession() {
        $_SESSION['last_activity'] = time();  // Actualizar la actividad de la sesión
        return [ "status" => 200, "message" => "Sesión actualizada"];
    }

    function logout() {
        sleep(2);
        session_unset();
        session_destroy();
        return "/dev/";
    }
}

// Las consultas de la barra y el menú lateral solo leen la sesión: la sueltan desde ya.
// PHP la deja bloqueada mientras corre la petición y las demás que la página lanza al
// mismo tiempo (el init del módulo, los avisos) esperaban formadas detrás.
if (in_array($opc, ['company', 'themes', 'branches', 'menu', 'lsAvisos'], true)) session_write_close();

$obj    = new Access();
$result = $obj->$opc();
echo json_encode($result);
