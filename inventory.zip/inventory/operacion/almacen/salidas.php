<?php
require_once __DIR__ . '/../../conf/_Session.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Validar sesión de usuario
if (empty($_SESSION["IDU"])) {
    require_once('../../acceso/ctrl/ctrl-logout.php');
    exit();
}

// El rol necesita al menos una acción en Salidas; si no, de regreso a Inicio.
require_once __DIR__ . '/../../conf/_Permissions.php';
$permissions = Permissions::page('salidas');

require_once('layout/head.php');
require_once('layout/core-libraries.php');
?>

<!-- CoffeeSoft Framework -->
<script src="../../src/js/coffeeSoft.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/plugins.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/complementos.js?t=<?php echo time(); ?>"></script>
<link rel="stylesheet" href="../../src/css/dark-mode.css?v=<?php echo filemtime(__DIR__ . '/../../src/css/dark-mode.css'); ?>">

<body>
    <div id="menu-sidebar" class="bg-white flex flex-col items-center py-4 gap-2"></div>
    <main>
        <div id="menu-navbar"></div>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <!-- <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">Operación</li>
                    <li class="breadcrumb-item fw-bold active">Salidas</li>
                </ol>
            </nav> -->

            <!-- Contenedor principal -->
            <div class="" id="root"></div>
        </div>
    </main>

    <!-- Importación navbar y sidebar -->
    <script src="../../acceso/src/js/navbar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/navbar.js'); ?>"></script>
    <script src="../../acceso/src/js/sidebar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/sidebar.js'); ?>"></script>

    <!-- Componentes -->
    <script src="../../src/js/components/salida-form.js?v=<?php echo filemtime(__DIR__ . '/../../src/js/components/salida-form.js'); ?>"></script>
    <!-- Chat de CoffeeIA (el mismo de Catálogo) para revisar y capturar la salida; forja-blob dibuja su muñeco -->
    <script src="../../src/js/components/forja-blob.js?v=<?php echo filemtime(__DIR__ . '/../../src/js/components/forja-blob.js'); ?>"></script>
    <script src="../../src/js/components/ia-chat.js?v=<?php echo filemtime(__DIR__ . '/../../src/js/components/ia-chat.js'); ?>"></script>

    <!-- Módulo de Salidas -->
    <!-- Acciones del rol en Salidas: el módulo solo pinta los botones que puede usar -->
    <?php echo Permissions::script($permissions); ?>
    <script src="js/salidas.js?t=<?php echo time(); ?>"></script>
</body>
</html>
