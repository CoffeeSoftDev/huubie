<?php

if (empty($_POST['opc'])) exit(0);

require_once __DIR__ . '/../../../conf/_Session.php';
require_once '../mdl/mdl-almacen.php';
require_once '../../../conf/_IaLector.php';
require_once '../../../conf/_IaOllama.php';
require_once '../../../conf/_Permissions.php';

class ctrl extends mdl {

    // Tope de la foto del producto, ya decodificada (4 MB, igual que el comprobante de Entradas).
    const IMAGE_MAX = 4194304;

    // Acción del rol que pide cada opc (conf/_Permissions.php); los demás solo
    // piden poder entrar al Catálogo. deleteMaterial y statusMaterial solo cambian
    // active (dar de baja / reactivar); deleteProducto es el que borra de verdad.
    // Entradas y Programadas dan de alta productos al vuelo, y el chat de Entradas
    // y Salidas lee sus adjuntos aquí: readArchivo pide la casilla IA (Accesos ›
    // Roles) en cualquiera de las tres secciones.
    const PERMISSIONS = [
        'addMaterial'        => 'agregar',
        'addProductoRapido'  => ['administrador' => 'agregar', 'entradas' => 'agregar', 'programadas' => '*'],
        'editMaterial'       => 'editar',
        'editProductoRapido' => ['administrador' => 'editar', 'entradas' => ['agregar', 'editar']],
        'statusMaterial'     => 'cancelar',
        'deleteMaterial'     => 'cancelar',
        'deleteProducto'     => 'eliminar',
        'editPresentacion'   => 'editar',
        'statusPresentacion' => 'cancelar',
        'applyAsistente'     => ['agregar', 'editar', 'cancelar'],
        'readArchivo'        => ['administrador' => 'ia', 'entradas' => 'ia', 'salidas' => 'ia']
    ];

    // Cada cambio del asistente pide su propia acción al aplicarse.
    const IA_PERMISSIONS = [
        'add'        => 'agregar',
        'edit'       => 'editar',
        'deactivate' => 'cancelar',
        'activate'   => 'cancelar',
        'present'    => 'editar'
    ];

    function init() {
        // Categorías y áreas de la sucursal de la sesión, también para el administrador: su
        // selector de sucursal arranca en ella (lsCatalogoSucursal trae las de otra).
        $sucursal = (int) ($_SESSION['branch_id'] ?? 0);

        return [
            'categorias'  => $this->categoriasDeSucursal($sucursal),
            'unidades'    => $this->lsUnits(),
            'areas'       => $this->areasConColor($this->areasDeSucursal($sucursal)),
            'proveedores' => $this->lsProveedores(),
            'almacenes'   => $this->lsWarehouses(),
            'productos'   => $this->lsProductos(),
            'superadmin'  => $this->esSuperAdminIA(),
            // Encendido en Administrador › CoffeeIA y con la casilla IA del rol en el Catálogo.
            'coffeeia'    => IaOllama::activo($this) && Permissions::can('administrador', 'ia'),
            // El stock de Productos es el de la sucursal de la navbar. El administrador ve el
            // selector (una sucursal o todas) y el campo Sucursal del producto; quien tiene
            // más de una sucursal, el selector con las suyas.
            'branch_id'     => (int) ($_SESSION['branch_id'] ?? 0),
            'sucursales'    => $this->sucursalesDelSelector(),
            'administrador' => $this->esAdministrador()
        ];
    }

    // Las del selector de sucursal: todas para el administrador; las suyas si son 2 o más.
    private function sucursalesDelSelector() {
        if ($this->esAdministrador()) return $this->lsSucursales([$_SESSION['company_id']]) ?: [];

        return count($this->misSucursales()) > 1 ? $this->misSucursales() : [];
    }

    // La sucursal que eligió en el selector quien tiene varias (`sucursal`). null si es la
    // de la sesión o si es administrador (él tiene su propio camino).
    private function sucursalVista() {
        if ($this->esAdministrador() || !isset($_POST['sucursal'])) return null;

        $elegida = $this->sucursalPropiaElegida('sucursal');
        return $elegida === (int) ($_SESSION['branch_id'] ?? 0) ? null : $elegida;
    }

    // En Catálogo se editan los productos de cualquiera de sus sucursales.
    private function puedeEditarEnCatalogo($itemBranchId) {
        return $this->puedeEditarProducto($itemBranchId) || $this->esDeMisSucursales($itemBranchId);
    }

    // Cada área lleva los colores de su badge para que el select la pinte igual que la
    // tabla, y su descripción para el badge. Una descripción sin letras ni números
    // ("*", "-") es relleno de captura y no se manda.
    private function areasConColor($lista) {
        return array_map(function ($area) {
            $tone = areaColors($area['id'], $area['color_hex']);
            $note = trim((string) $area['description']);

            return [
                'id'          => $area['id'],
                'valor'       => $area['valor'],
                'color'       => $tone['fg'],
                'bg'          => $tone['bg'],
                'description' => preg_match('/[\p{L}\p{N}]/u', $note) ? $note : ''
            ];
        }, $lista ?: []);
    }

    // Categorías y áreas de una sucursal para los filtros de Productos y el formulario de
    // un producto. El administrador pide la que quiera ('' = las de todas); los demás,
    // una de sus sucursales (la de la sesión si no es suya).
    function lsCatalogoSucursal() {
        $sucursal = $this->esAdministrador() ? (string) ($_POST['sucursal'] ?? '') : (string) $this->sucursalPropiaElegida('sucursal');

        if ($sucursal === '') {
            return ['status' => 200, 'categorias' => $this->lsCategories() ?: [], 'areas' => $this->areasConColor($this->lsAreas())];
        }

        return [
            'status'     => 200,
            'categorias' => $this->categoriasDeSucursal((int) $sucursal),
            'areas'      => $this->areasConColor($this->areasDeSucursal((int) $sucursal))
        ];
    }

    function lsMateriales() {

        $filters = [
            'categoria'   => $_POST['categoria'] ?? '',
            'area'        => $_POST['area'] ?? '',
            'estado'      => $_POST['estado'] ?? '',
            'branch_id'   => $this->sucursalDeStock(),
            // Con el selector del administrador en una sucursal: solo los productos de esa sucursal.
            'propietario' => $this->esAdministrador() && ($_POST['sucursal'] ?? '') !== '' ? (int) $_POST['sucursal'] : '',
            'vista'       => $this->sucursalVista()
        ];

        $data = $this->listMateriales($filters);
        $rows = [];
        $totalValue = 0;

        // Con "Activos" o "Inactivos" el estado ya lo dice el filtro: la columna solo sale con "Todos".
        $showStatus = $filters['estado'] === '';

        // «De {sucursal}» bajo el nombre: solo el administrador con «Todas las sucursales».
        $verDueno = $this->esAdministrador() && ($_POST['sucursal'] ?? '') === '';

        foreach ($data as $item) {
            // El inventario se valúa al último costo de compra, no al precio de venta.
            $value = floatval($item['quantity']) * floatval($item['cost_unit']);
            $totalValue += $value;

            // Un producto de otra sucursal (los de Matriz, para las sucursales) se ve con
            // su candado: se usa, no se edita (VisibilidadProductos).
            $a = $this->puedeEditarEnCatalogo($item['branch_id'] ?? null) ? [
                [
                    'class'   => 'inline-flex items-center justify-center w-9 h-9 p-2 text-[#9CA3AF] hover:text-blue-600 transition-colors cursor-pointer bg-transparent border-0',
                    'html'    => '<i data-lucide="pencil" class="w-4 h-4"></i>',
                    'onclick' => 'products.editMaterial(' . $item['id'] . ')'
                ],
                statusSwitch('products.statusMaterial', $item['id'], $item['active'])
            ] : [$this->candadoProducto($item['sucursal'] ?? '')];

            $row = [
                'id'         => $item['id'],
                'Insumo'     => [
                    'class' => 'justify-center px-2 py-2',
                    'html'  => renderProductImage($item['image'] ?? '', $item['name'], $verDueno && !empty($item['sucursal']) ? 'De ' . $item['sucursal'] : '', 'building-2')
                ],
                'Unidad'     => !empty($item['unidad_nombre']) ? $item['unidad_nombre'] : '-',
                'Categoría'  => $item['categoria'] ?? '-',
                'Área'       => renderArea($item['area_id'] ?? null, $item['area'] ?? null, $item['area_color'] ?? null),

                // Inventario = costo (como Soft Restaurant con sus insumos). El precio de
                // venta solo vive en el formulario, para lo que se revende tal cual.
                'Último costo' => [
                    'html'  => costoCelda($item['cost_unit']),
                    'class' => 'text-end'
                ],
                'Stock'      => renderQuantity($item['quantity']),
                'Mín'        => renderQuantity($item['stock_min']),
                'Máx'        => renderQuantity($item['stock_max']),
                'Vida útil'  => isset($item['shelf_life_days']) && $item['shelf_life_days'] !== null
                    ? $item['shelf_life_days'] . ' días'
                    : '-'
            ];

            if ($showStatus) $row['Estado'] = renderStatus($item['active']);

            $row['a'] = Permissions::rowActions('administrador', $a);
            $rows[]   = ['alta' => (string) $item['created_at'], 'row' => $row];
        }

        // Las presentaciones van como un producto más, con la nota de a cuánto equivalen
        // de su base. Su stock son los empaques completos que da el del base (40 piezas
        // ÷ 24 = 1 caja): no suman al valor del inventario, ya se cuenta en el base.
        foreach ($this->listPresentacionesTabla($filters) ?: [] as $p) {
            $factor = (float) $p['factor'];
            $unidad = $this->pluralIA($p['base_unit']);
            $cajas  = $factor > 0 ? max(0, floor((float) $p['base_stock'] / $factor)) : 0;

            // La presentación se edita con su producto base.
            $a = $this->puedeEditarEnCatalogo($p['base_branch_id'] ?? null) ? [
                [
                    'class'   => 'inline-flex items-center justify-center w-9 h-9 p-2 text-[#9CA3AF] hover:text-blue-600 transition-colors cursor-pointer bg-transparent border-0',
                    'html'    => '<i data-lucide="pencil" class="w-4 h-4"></i>',
                    'onclick' => 'products.editPresentacion(' . $p['id'] . ')'
                ],
                statusSwitch('products.statusPresentacion', $p['id'], $p['active'])
            ] : [$this->candadoProducto('')];

            $row = [
                'id'         => 'p' . $p['id'],
                'Insumo'     => [
                    'class' => 'justify-center px-2 py-2',
                    'html'  => renderProductImage($p['image'] ?? '', $p['name'], 'Equivale a ' . $this->numeroIA($factor) . ' ' . $unidad . ' de ' . $p['base_name'])
                ],
                'Unidad'     => !empty($p['unidad_nombre']) ? $p['unidad_nombre'] : '-',
                'Categoría'  => $p['categoria'] ?? '-',
                'Área'       => renderArea($p['area_id'] ?? null, $p['area'] ?? null, $p['area_color'] ?? null),
                'Último costo' => [
                    'html'  => costoCelda($p['cost_unit']),
                    'class' => 'text-end'
                ],
                'Stock'      => $cajas > 0
                    ? '<span title="' . htmlspecialchars($this->numeroIA($p['base_stock']) . ' ' . $unidad . ' ÷ ' . $this->numeroIA($factor)) . '">' . $this->numeroIA($cajas) . '</span>'
                    : '-',
                'Mín'        => '-',
                'Máx'        => '-',
                'Vida útil'  => '-'
            ];

            if ($showStatus) $row['Estado'] = renderStatus($p['active']);

            $row['a'] = Permissions::rowActions('administrador', $a);
            $rows[]   = ['alta' => (string) $p['created_at'], 'row' => $row];
        }

        // Del último agregado al más viejo, productos y presentaciones juntos. Con la misma
        // hora (cargas masivas) se queda el orden de la consulta: usort es estable.
        usort($rows, function ($x, $y) { return strcmp($y['alta'], $x['alta']); });

        return [
            'row'         => array_column($rows, 'row'),
            'total_value' => '$' . number_format($totalValue, 2)
        ];
    }

    // De qué sucursal es el stock de Productos: la de la navbar (sesión). El administrador
    // puede pedir otra con el selector (`sucursal`) o '' para la suma de todas; con una
    // sucursal elegida, la lista trae solo los productos de esa sucursal (`propietario`).
    // Quien tiene varias sucursales, la que elija de las suyas.
    private function sucursalDeStock() {
        if ($this->esAdministrador() && isset($_POST['sucursal'])) {
            return $_POST['sucursal'] === '' ? '' : (int) $_POST['sucursal'];
        }

        return $this->sucursalVista() ?? (int) ($_SESSION['branch_id'] ?? 0);
    }

    // Sucursal dueña que manda el formulario de Productos (campo `branch_id`): solo la toma
    // del administrador y si es una sucursal activa de la empresa. null = no se cambia.
    private function sucursalDelProducto() {
        if (!$this->esAdministrador() || ($_POST['branch_id'] ?? '') === '') return null;

        $id = (int) $_POST['branch_id'];
        $ok = in_array($id, array_map('intval', array_column($this->lsSucursales([$_SESSION['company_id']]) ?: [], 'id')), true);
        return $ok ? $id : null;
    }

    // El candado de la columna de acciones en lugar del lápiz y el switch. El aviso va en
    // `attr`: la tabla arma <a> con jQuery y este proyecto tiene $.fn.title.
    private function candadoProducto($sucursal) {
        return [
            'class' => 'inline-flex items-center justify-center w-9 h-9 p-2 text-gray-300 cursor-default bg-transparent border-0',
            'html'  => '<i data-lucide="lock" class="w-4 h-4"></i>',
            'attr'  => ['title' => 'Es de ' . ($sucursal ?: 'otra sucursal') . ': lo usas, pero solo su sucursal, Matriz o el administrador lo editan']
        ];
    }

    // Candado de VisibilidadProductos: un producto de otra sucursal (los de Matriz, para
    // las sucursales) se usa pero no se edita. 403 con el aviso; null si se puede.
    private function productoAjeno($material) {
        if (!$material || $this->puedeEditarEnCatalogo($material['branch_id'] ?? null)) return null;

        return [
            'status'  => 403,
            'message' => 'Este producto es de otra sucursal: lo puedes usar, pero solo su sucursal, Matriz o el administrador lo editan'
        ];
    }

    function getMaterial() {
        $id      = $_POST['id'];
        $status  = 404;
        $message = 'Insumo no encontrado';
        $data    = null;

        $material = $this->getMaterialById($id);

        // Stock y movimientos: los enseña el formulario si el producto pasa a presentación.
        if ($material) {
            $status  = 200;
            $message = 'Insumo encontrado';
            $data    = $material + [
                'stock'       => $this->getMaterialStock([$id]),
                'movimientos' => (int) $this->getMaterialCounts([$id])['movimientos']
            ];

            // El formulario ofrece las categorías y áreas de la sucursal del producto, no las
            // de quien lo edita (Matriz o el administrador editan productos de otras).
            if (!empty($material['branch_id'])) {
                $data['categorias'] = $this->categoriasDeSucursal($material['branch_id']);
                $data['areas']      = $this->areasConColor($this->areasDeSucursal($material['branch_id']));
            }
        }

        return [
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        ];
    }

    // El formulario lo consulta mientras se escribe el nombre: avisa antes de guardar.
    function lsSimilarMaterials() {
        $id = (int) ($_POST['id'] ?? 0);

        return ['status' => 200] + $this->nameMatches($_POST['name'] ?? '', $id, $this->sucursalDelNombre($id));
    }

    // En qué sucursal no se repite el nombre: la que eligió el administrador en el
    // formulario, la del producto que se edita o, en un alta, la del selector o la sesión.
    private function sucursalDelNombre($id) {
        $elegida = $this->sucursalDelProducto();
        if ($elegida !== null) return $elegida;

        $material = $id ? $this->getMaterialById($id) : null;
        if (!empty($material['branch_id'])) return (int) $material['branch_id'];

        return $this->sucursalVista() ?? (int) ($_SESSION['branch_id'] ?? 0);
    }

    function addMaterial() {
        $status  = 500;
        $message = 'No se pudo agregar el insumo';

        // Con el selector en Presentación no nace un producto: se liga el empaque a su base.
        if (($_POST['is_presentacion'] ?? '') === '1') return $this->addPresentacion();

        // Solo el nombre es obligatorio. El costo lo van dejando las entradas.
        if (trim($_POST['name'] ?? '') === '') {
            return [
                'status'  => 400,
                'message' => 'El nombre del producto es obligatorio'
            ];
        }

        // De la sesión, salvo que el administrador elija otra sucursal en el formulario o que
        // quien tiene varias esté viendo otra de las suyas en el selector.
        $branch_id = $this->sucursalDelNombre(0);

        // El nombre no se repite en esa sucursal; en otra sí (Coca Cola en Matriz y en Centro).
        $nameCheck = $this->checkMaterialName($_POST['name'], 0, $branch_id);

        if ($nameCheck) return $nameCheck;

        // SKU tecleado por el usuario; vacío = automático (skuFor).
        $sku = mb_substr(trim($_POST['sku'] ?? ''), 0, 40);

        if ($sku !== '' && $this->existsItemBySku([$sku])) {
            return [
                'status'  => 409,
                'message' => 'Ese código ya lo usa otro producto'
            ];
        }

        $photo = $_POST['image_b64'] ?? '';

        if ($photo !== '' && !$this->decodeProductImage($photo)) {
            return [
                'status'  => 400,
                'message' => 'La foto debe ser una imagen JPG, PNG o WEBP de hasta 4 MB'
            ];
        }

        $now          = date('Y-m-d H:i:s');
        $companies_id = $_SESSION['company_id'];

        $item = [
            'name'            => $_POST['name'] ?? '',
            'category_id'     => $_POST['category_id'] ?? null,
            'branch_id'       => $branch_id,
            'companies_id'    => $companies_id,
            'created_at'      => $now,
            'active'          => 1
        ];

        // El precio de venta ya no se captura aquí: entra en 0 (columnas NOT NULL). Se anexa
        // DESPUÉS de util->sql() por el gotcha 0 == '' (PHP 7.4), que volvería el 0 NULL.
        $sql = $this->util->sql($item);
        $sql['values'][] = 'price';
        $sql['values'][] = 'price_without_tax';
        $sql['values'][] = 'tax';
        $sql['data'][]   = 0;
        $sql['data'][]   = 0;
        $sql['data'][]   = 0;

        $create = $this->createMaterial($sql);

        if ($create) {
            $itemId = $this->getMaxItemId();

            // Campos numéricos NOT NULL con DEFAULT 0 (cost_unit, stock_min): se omiten cuando
            // van vacíos para que aplique el DEFAULT de la BD. Si se mandara 0, util->sql() lo
            // convertiría en NULL (gotcha 0 == '' en PHP 7.4) y violaría el NOT NULL.
            $attribute = [
                'sku'               => $sku !== '' ? $sku : $this->skuFor($_POST['category_id'] ?? null),
                'description'       => $_POST['description'] ?? '',
                'shelf_life_days'   => ($_POST['shelf_life_days'] ?? '') === '' ? null : $_POST['shelf_life_days'],
                'stock_max'         => ($_POST['stock_max'] ?? '') === '' ? null : $_POST['stock_max'],
                'warehouse_area_id' => ($_POST['warehouse_area_id'] ?? '') === '' ? null : $_POST['warehouse_area_id'],
                'unit_id'           => $_POST['unit_id'] ?? null,
                'item_id'           => $itemId,
                'companies_id'      => $companies_id,
                'created_at'        => $now,
                'active'            => 1
            ];

            // Solo se incluyen si traen valor real; si no, la BD usa su DEFAULT 0.
            if (($_POST['cost_unit'] ?? '') !== '') $attribute['cost_unit'] = $_POST['cost_unit'];
            if (($_POST['cost_tax'] ?? '') !== '')  $attribute['cost_tax']  = $_POST['cost_tax'];
            if (($_POST['stock_min'] ?? '') !== '') $attribute['stock_min'] = $_POST['stock_min'];

            $attribute['is_inventoriable'] = ($_POST['is_inventoriable'] ?? '1') === '0' ? '0' : '1';

            $this->createItemAttribute($this->util->sql($attribute));

            // La foto lleva el id en el nombre: se guarda ya creado el producto.
            if ($photo !== '') $this->saveProductImage($itemId, $photo);

            $status  = 200;
            $message = 'Insumo agregado correctamente';
        }

        return [
            'status'  => $status,
            'message' => $message
        ];
    }

    // Alta exprés desde el buscador de Solicitudes: el solicitante solo aporta el
    // nombre (obligatorio) y, opcionalmente, categoría y unidad. Los precios entran
    // en 0 porque los fija después quien surte/compra; el SKU se autogenera. Devuelve
    // id y sku para inyectar el producto directo en la solicitud sin recargar todo.
    function addProductoRapido() {
        if (($_POST['name'] ?? '') === '') {
            return ['status' => 400, 'message' => 'El nombre del producto es obligatorio'];
        }

        $now          = date('Y-m-d H:i:s');
        $companies_id = $_SESSION['company_id'];
        $branch_id    = $_SESSION['branch_id'];

        $item = [
            'name'         => $_POST['name'],
            'image'        => '',
            'category_id'  => ($_POST['category_id'] ?? '') === '' ? null : $_POST['category_id'],
            'branch_id'    => $branch_id,
            'companies_id' => $companies_id,
            'created_at'   => $now,
            'active'       => 1
        ];

        // price, price_without_tax y tax se anexan DESPUÉS de util->sql() y en 0 para
        // esquivar el gotcha 0 == '' (PHP 7.4), que los volvería NULL y violaría el NOT NULL.
        $sql = $this->util->sql($item);
        $sql['values'][] = 'price';
        $sql['values'][] = 'price_without_tax';
        $sql['values'][] = 'tax';
        $sql['data'][]   = 0;
        $sql['data'][]   = 0;
        $sql['data'][]   = 0;

        if (!$this->createMaterial($sql)) {
            return ['status' => 500, 'message' => 'No se pudo crear el producto'];
        }

        $itemId = $this->getMaxItemId();
        $sku    = $this->skuFor($item['category_id']);

        $attribute = [
            'sku'          => $sku,
            'unit_id'      => ($_POST['unit_id'] ?? '') === '' ? null : $_POST['unit_id'],
            'item_id'      => $itemId,
            'companies_id' => $companies_id,
            'created_at'   => $now,
            'active'       => 1
        ];
        $attrSql = $this->util->sql($attribute);

        // Costo de compra (lo manda Entradas; Solicitudes no). Se anexa después de
        // util->sql() por el mismo gotcha del 0 que price.
        if (isset($_POST['cost_unit']) && $_POST['cost_unit'] !== '') {
            $attrSql['values'][] = 'cost_unit';
            $attrSql['values'][] = 'cost_tax';
            $attrSql['data'][]   = max(0, (float) $_POST['cost_unit']);
            $attrSql['data'][]   = max(0, (float) ($_POST['cost_tax'] ?? 0));
        }
        $this->createItemAttribute($attrSql);

        return [
            'status'  => 200,
            'message' => 'Producto creado',
            'id'      => $itemId,
            'sku'     => $sku
        ];
    }

    // Edición exprés desde la captura de Entradas: solo nombre, categoría, unidad, último
    // costo y descripción (sobrenombres). El SKU, la foto, el precio de venta y el resto del producto no se tocan.
    function editProductoRapido() {
        $id       = (int) $_POST['id'];
        $material = $this->getMaterialById($id);

        if (!$material || (int) $material['companies_id'] !== (int) $_SESSION['company_id']) {
            return ['status' => 404, 'message' => 'Producto no encontrado'];
        }

        if ($bloqueo = $this->productoAjeno($material)) return $bloqueo;

        $name = trim($_POST['name']);

        if ($name === '') {
            return ['status' => 400, 'message' => 'El nombre del producto es obligatorio'];
        }

        if ($this->normalizarIA($name) !== $this->normalizarIA($material['name'])) {
            $nameCheck = $this->checkMaterialName($name, $id, (int) $material['branch_id']);

            if ($nameCheck) return $nameCheck;
        }

        $category = $_POST['category_id'] === '' ? null : $_POST['category_id'];
        $unit     = $_POST['unit_id'] === '' ? null : $_POST['unit_id'];

        $values = 'unit_id = ?';
        $data   = [$unit];

        // Costo de compra: se omite si no viene (no se pisa el último costo con 0).
        if (isset($_POST['cost_unit']) && $_POST['cost_unit'] !== '') {
            $values .= ', cost_unit = ?, cost_tax = ?';
            $data[]  = max(0, (float) $_POST['cost_unit']);
            $data[]  = max(0, (float) $_POST['cost_tax']);
        }

        // Sobrenombres (item_attribute.description): solo si viene; vacío la limpia.
        if (isset($_POST['description'])) {
            $values .= ', description = ?';
            $data[]  = mb_substr(trim(preg_replace('/\s+/u', ' ', $_POST['description'])), 0, 255);
        }

        $data[] = $id;
        $data[] = $_SESSION['company_id'];

        // Producto y atributos juntos: si uno falla, no queda la mitad guardada.
        // El where va como arreglo: _Update cuenta un solo "?" por cadena.
        try {
            $this->transaction(function () use ($name, $category, $id, $values, $data) {
                $updated = $this->updateMaterial([
                    'values' => 'name = ?, category_id = ?',
                    'where'  => ['id', 'companies_id'],
                    'data'   => [$name, $category, $id, $_SESSION['company_id']]
                ]);
                if (!$updated || is_string($updated)) throw new Exception('producto');

                $updated = $this->updateItemAttribute([
                    'values' => $values,
                    'where'  => ['item_id', 'companies_id'],
                    'data'   => $data
                ]);
                if (!$updated || is_string($updated)) throw new Exception('atributos');
            });
        } catch (\Throwable $e) {
            return ['status' => 500, 'message' => 'No se pudo editar el producto'];
        }

        return ['status' => 200, 'message' => 'Producto actualizado', 'id' => $id];
    }

    function editMaterial() {
        $status  = 500;
        $message = 'Error al editar el insumo';

        $id = $_POST['id'];

        if ($bloqueo = $this->productoAjeno($this->getMaterialById($id))) return $bloqueo;

        // Con el selector en Presentación el producto deja de serlo: pasa a ser el empaque de otro.
        if (($_POST['is_presentacion'] ?? '') === '1') return $this->pasarAPresentacion((int) $id);

        // SKU tecleado; si cambió, no puede repetir el de otro producto.
        $sku      = mb_substr(trim($_POST['sku'] ?? ''), 0, 40);
        $material = $this->getMaterialById($id);

        if ($sku !== '' && $sku !== ($material['sku'] ?? '') && $this->existsItemBySku([$sku])) {
            return [
                'status'  => 409,
                'message' => 'Ese código ya lo usa otro producto'
            ];
        }

        // Solo si cambió el nombre: uno que ya se llamaba igual que otro no se traba al editar.
        if ($this->normalizarIA($_POST['name'] ?? '') !== $this->normalizarIA($material['name'] ?? '')) {
            $nameCheck = $this->checkMaterialName($_POST['name'] ?? '', $id, $this->sucursalDelNombre((int) $id));

            if ($nameCheck) return $nameCheck;
        }

        $photo = $_POST['image_b64'] ?? '';

        if ($photo !== '' && !$this->decodeProductImage($photo)) {
            return [
                'status'  => 400,
                'message' => 'La foto debe ser una imagen JPG, PNG o WEBP de hasta 4 MB'
            ];
        }

        // El administrador lo cambia de sucursal (campo Sucursal del formulario). Su stock no
        // se mueve: sigue en el almacén donde está. La categoría y el área que sean de otra
        // sucursal se le quitan (el área también a sus presentaciones).
        $sucursal  = $this->sucursalDelProducto();
        $mueve     = $sucursal !== null && $sucursal !== (int) ($material['branch_id'] ?? 0);
        $categoria = ($_POST['category_id'] ?? '') === '' ? null : $_POST['category_id'];
        $area      = ($_POST['warehouse_area_id'] ?? '') === '' ? null : $_POST['warehouse_area_id'];

        $quitados = [];
        if ($mueve) {
            if (!$this->categoriaEsDeSucursal($categoria, $sucursal)) { $categoria = null; $quitados[] = 'categoría'; }
            if (!$this->areaEsDeSucursal($area, $sucursal))           { $area      = null; $quitados[] = 'área'; }
        }

        // price / price_without_tax / tax no se tocan: el formulario ya no los trae y
        // se conserva lo que haya en la BD. La foto va aparte (abajo).
        $editItem = $this->updateMaterial([
            'values' => 'name = ?, category_id = ?',
            'where'  => 'id = ?',
            'data'   => [
                $_POST['name'] ?? '',
                $categoria,
                $id
            ]
        ]);

        // Foto nueva: reemplaza la anterior. "Quitar foto": la borra. Sin cambios no se toca.
        if ($photo !== '') {
            $this->saveProductImage($id, $photo);
        } elseif (($_POST['image_remove'] ?? '') === '1') {
            $this->dropProductImage($id);
            $this->updateMaterial([
                'values' => 'image = ?',
                'where'  => 'id = ?',
                'data'   => [null, $id]
            ]);
        }

        if ($mueve) {
            $this->updateMaterial([
                'values' => 'branch_id = ?',
                'where'  => 'id = ?',
                'data'   => [$sucursal, $id]
            ]);
            $this->quitarAreasAjenasPresentaciones([$id, $sucursal]);
        }

        $this->updateItemAttribute([
            'values' => 'description = ?, cost_unit = ?, cost_tax = ?, is_inventoriable = ?, stock_min = ?, stock_max = ?, shelf_life_days = ?, warehouse_area_id = ?, unit_id = ?',
            'where'  => 'item_id = ?',
            'data'   => [
                $_POST['description'] ?? '',
                ($_POST['cost_unit'] ?? '') === '' ? 0 : $_POST['cost_unit'],
                ($_POST['cost_tax'] ?? '') === '' ? null : $_POST['cost_tax'],
                ($_POST['is_inventoriable'] ?? '1') === '0' ? 0 : 1,
                ($_POST['stock_min'] ?? '') === '' ? 0 : $_POST['stock_min'],
                ($_POST['stock_max'] ?? '') === '' ? 0 : $_POST['stock_max'],
                ($_POST['shelf_life_days'] ?? '') === '' ? null : $_POST['shelf_life_days'],
                $area,
                $_POST['unit_id'] ?? null,
                $id
            ]
        ]);

        // Con código tecleado se guarda ese. Vacío: un producto que llegó sin SKU (p. ej.
        // por una carga masiva) lo recibe automático; si ya tiene uno, no se toca.
        if ($sku !== '') {
            $this->updateItemAttribute([
                'values' => 'sku = ?',
                'where'  => 'item_id = ?',
                'data'   => [$sku, $id]
            ]);
        } else {
            $this->updateItemAttributeSku([$this->skuFor($_POST['category_id'] ?? null), $id]);
        }

        if ($editItem) {
            $status  = 200;
            $message = 'Insumo editado correctamente';
            if ($quitados) $message .= '. Quedó sin ' . implode(' ni ', $quitados) . (count($quitados) === 1 ? ': era' : ': eran') . ' de otra sucursal';
        }

        return [
            'status'  => $status,
            'message' => $message
        ];
    }

    /*  SKU con el formato de claves de Soft Restaurant: clave del grupo (2 dígitos)
        + consecutivo dentro del grupo (3 dígitos). Aquí el grupo es la categoría:
        el tercer producto de la categoría 4 es 04003. Sin categoría va al grupo 00.

        El consecutivo sale del SKU más alto con ese prefijo, no de contar los
        productos de la categoría: el que se cambia de categoría conserva su SKU
        (igual que en Soft Restaurant) y contar volvería a repartir su número.
        str_pad rellena pero no recorta: la categoría 123 da 123001. */
    private function skuFor($categoryId) {
        $prefix = str_pad((int) $categoryId, 2, '0', STR_PAD_LEFT);
        $last   = $this->getSkuCounts([
            strlen($prefix) + 1,
            $_SESSION['company_id'],
            '^' . $prefix . '[0-9]{3,}$'
        ]);

        return $prefix . str_pad($last + 1, 3, '0', STR_PAD_LEFT);
    }

    // -- Nombre repetido o parecido --

    // Mismo nombre (sin importar mayúsculas, acentos ni signos): no se guarda.
    // Parecido: se avisa y solo se guarda si lo confirman; el formulario manda
    // similar_ok = 1 cuando ya enseñó los parecidos de ese nombre. Solo cuenta lo de la
    // sucursal `$branchId`: en otra el mismo nombre se vale.
    private function checkMaterialName($name, $exceptId, $branchId) {
        $matches = $this->nameMatches($name, $exceptId, $branchId);

        if ($matches['exact']) {
            return [
                'status'  => 409,
                'message' => 'Ya existe un producto con ese nombre en esta sucursal: ' . $this->nameList([$matches['exact']], 0)
                           . ($matches['exact']['active'] ? '.' : '. Actívalo desde el filtro Estado: Inactivos.'),
                'matches' => $matches
            ];
        }

        if ($matches['similar'] && ($_POST['similar_ok'] ?? '') !== '1') {
            return [
                'status'  => 409,
                'message' => 'Ya existe un producto con un nombre similar en esta sucursal: ' . $this->nameList($matches['similar'], $matches['more'])
                           . '. Si es otro producto, pulsa Aceptar otra vez.',
                'matches' => $matches
            ];
        }

        return null;
    }

    // Contra los productos de la sucursal, activos e inactivos. De los parecidos van
    // los 5 que más se parecen; 'more' dice cuántos quedaron fuera.
    private function nameMatches($name, $exceptId, $branchId) {
        $key     = $this->normalizarIA($name);
        $words   = $this->nameWords($key);
        $exact   = null;
        $similar = [];

        if ($key === '') {
            return [
                'exact'   => null,
                'similar' => [],
                'more'    => 0
            ];
        }

        foreach ($this->listMaterialNames([$_SESSION['company_id'], (int) $exceptId, (int) $branchId]) as $producto) {
            $other = $this->normalizarIA($producto['name']);
            $match = [
                'id'     => (int) $producto['id'],
                'name'   => $producto['name'],
                'active' => (int) $producto['active'] === 1
            ];

            if ($other === $key) {
                if ($exact === null || $match['active']) $exact = $match;
                continue;
            }

            $score = $this->nameScore($key, $words, $other);

            if ($score > 0) $similar[] = $match + ['score' => $score];
        }

        usort($similar, function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });

        return [
            'exact'   => $exact,
            'similar' => array_slice($similar, 0, 5),
            'more'    => max(0, count($similar) - 5)
        ];
    }

    // 0 = no se parece. Se parecen si uno trae todas las palabras del otro ("Pan" y
    // "Pan blanco chico"), si comparten dos palabras o más y son la mitad de todas
    // ("Pan blanco mediano" y "Pan blanco chico"), o si casi se escriben igual
    // ("Twinkis" y "Twinkies", 80% de las letras).
    private function nameScore($key, $words, $other) {
        $otherWords = $this->nameWords($other);

        if ($words && $otherWords) {
            $shared = count(array_filter($words, function ($word) use ($otherWords) {
                return $this->hasWord($otherWords, $word);
            }));
            $back = count(array_filter($otherWords, function ($word) use ($words) {
                return $this->hasWord($words, $word);
            }));

            // Entre más palabras de sobra trae el otro, menos se parece ("Chorizo" va antes que "Chorizo argentino").
            if ($shared === count($words) || $back === count($otherWords)) {
                return 0.85 + 0.1 * min(count($words), count($otherWords)) / max(count($words), count($otherWords));
            }

            $union = count($words) + count($otherWords) - $shared;

            if ($shared >= 2 && $shared / $union >= 0.5) return $shared / $union;
        }

        $a     = substr($key, 0, 255);
        $b     = substr($other, 0, 255);
        $ratio = 1 - levenshtein($a, $b) / max(strlen($a), strlen($b), 1);

        return $ratio >= 0.8 ? $ratio : 0;
    }

    // Las palabras que distinguen un producto: sin medidas ni números (2lt, 600, pz)
    // ni artículos o preposiciones.
    private function nameWords($key) {
        $skip = ['del', 'las', 'los', 'con', 'para', 'por', 'pza', 'pzs', 'pzas', 'grs', 'kgs', 'lts', 'mls'];

        return array_values(array_unique(array_filter(explode(' ', $key), function ($word) use ($skip) {
            return strlen($word) >= 3 && !preg_match('/\d/', $word) && !in_array($word, $skip, true);
        })));
    }

    // Singular y plural cuentan como la misma palabra: tomate/tomates, limon/limones.
    private function hasWord($list, $word) {
        foreach ($list as $palabra) {
            if (in_array($palabra, [$word, $word . 's', $word . 'es'], true) || in_array($word, [$palabra . 's', $palabra . 'es'], true)) return true;
        }

        return false;
    }

    // El mensaje lo pinta alertBox como HTML: los nombres van escapados.
    private function nameList($items, $more) {
        $names = array_map(function ($producto) {
            return '«' . htmlspecialchars($producto['name']) . '»' . ($producto['active'] ? '' : ' (inactivo)');
        }, $items);

        return implode(', ', $names) . ($more > 0 ? ' y ' . $more . ' más' : '');
    }

    // -- Foto del producto --

    // Guarda la foto (dataURL, ya comprimida en el navegador) como
    // uploads/productos/{id}_{único}.{ext} y deja esa ruta, relativa a inventory/, en
    // item.image. El nombre cambia en cada foto para que el navegador no siga mostrando
    // la anterior desde su caché; las versiones anteriores del producto se borran.
    private function saveProductImage($id, $b64) {
        $image = $this->decodeProductImage($b64);
        if (!$image) return false;

        $dir = __DIR__ . '/../../../uploads/productos/';
        if (!is_dir($dir)) @mkdir($dir, 0777, true);

        $name = (int) $id . '_' . substr(md5(uniqid('', true)), 0, 8) . '.' . $image['ext'];

        $this->dropProductImage($id);
        if (@file_put_contents($dir . $name, $image['data']) === false) return false;

        return $this->updateMaterial([
            'values' => 'image = ?',
            'where'  => 'id = ?',
            'data'   => ['uploads/productos/' . $name, $id]
        ]);
    }

    // La extensión sale de lo que trae el archivo por dentro, no de lo que dice el dataURL.
    private function decodeProductImage($b64) {
        if (!preg_match('#^data:image/[a-z0-9.+-]+;base64,#i', (string) $b64)) return null;

        $data = base64_decode(substr($b64, strpos($b64, ',') + 1), true);
        if ($data === false || strlen($data) > self::IMAGE_MAX) return null;

        $info = @getimagesizefromstring($data);
        $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$info['mime'] ?? ''] ?? null;

        return $ext ? ['ext' => $ext, 'data' => $data] : null;
    }

    private function dropProductImage($id) {
        foreach (glob(__DIR__ . '/../../../uploads/productos/' . (int) $id . '_*') ?: [] as $old) @unlink($old);
    }

    function deleteMaterial() {
        $status      = 500;
        $nuevoEstado = $_POST['active'];
        $message     = $nuevoEstado == 1 ? 'No se pudo activar el insumo' : 'No se pudo desactivar el insumo';

        if ($bloqueo = $this->productoAjeno($this->getMaterialById((int) $_POST['id']))) return $bloqueo;

        $update = $this->updateMaterial([
            'values' => 'active = ?',
            'where'  => 'id = ?',
            'data'   => [$_POST['active'], $_POST['id']]
        ]);

        if ($update) {
            $status  = 200;
            $message = $nuevoEstado == 1 ? 'Insumo activado correctamente' : 'Insumo desactivado correctamente';
        }

        return [
            'status'  => $status,
            'message' => $message
        ];
    }

    // Borra el producto de verdad. Solo si nunca se movió: sus entradas, salidas,
    // traspasos y órdenes son historia y la BD no deja borrarlo (FK RESTRICT).
    function deleteProducto() {
        $id       = (int) ($_POST['id'] ?? 0);
        $material = $this->getMaterialById($id);

        if (!$material || (int) $material['companies_id'] !== (int) $_SESSION['company_id']) {
            return [
                'status'  => 404,
                'message' => 'Producto no encontrado'
            ];
        }

        if ($bloqueo = $this->productoAjeno($material)) return $bloqueo;

        $uso = $this->getMaterialCounts([$id]);

        if ((int) $uso['movimientos'] > 0) {
            return [
                'status'  => 409,
                'message' => 'Este producto ya tiene movimientos en el almacén. Solo se puede desactivar.'
            ];
        }

        if ((float) $uso['existencia'] != 0) {
            return [
                'status'  => 409,
                'message' => 'Este producto todavía tiene existencia. Solo se puede desactivar.'
            ];
        }

        try {
            $this->transaction(function () use ($id) {
                $this->deleteMaterialById([$id]);
            });
        } catch (\Throwable $e) {
            return [
                'status'  => 500,
                'message' => 'No se pudo eliminar el producto'
            ];
        }

        $this->dropProductImage($id);

        return [
            'status'  => 200,
            'message' => 'Producto eliminado'
        ];
    }

    function statusMaterial() {
        $status  = 500;
        $message = 'No se pudo actualizar el estado';

        if ($bloqueo = $this->productoAjeno($this->getMaterialById((int) $_POST['id']))) return $bloqueo;

        $update = $this->updateMaterial([
            'values' => 'active = ?',
            'where'  => 'id = ?',
            'data'   => [$_POST['active'], $_POST['id']]
        ]);

        if ($update) {
            $status  = 200;
            $message = 'Estado actualizado correctamente';
        }

        return [
            'status'  => $status,
            'message' => $message
        ];
    }

    // -- Presentaciones --
    /*  El empaque de un producto que ya existe: «Reja 12» es 12 piezas de COCA COLA
        LATA. Se da de alta desde «Nuevo Producto» con el interruptor (addMaterial) y
        la tabla de Productos la pinta como un producto más, con la nota de a cuánto
        equivale (lsMateriales). El stock sigue contándose en el base: aquí no se mueve
        inventario. */

    // Todas las de la empresa, o las de un producto con `item_id`, con los datos de su base.
    // Su área va con los colores del badge, como la columna Área de los productos.
    function lsPresentaciones() {
        $itemId = (int) ($_POST['item_id'] ?? 0);

        $rows = array_map(function ($p) {
            $tone = $p['warehouse_area_id'] ? areaColors($p['warehouse_area_id'], $p['area_color']) : ['fg' => '', 'bg' => ''];

            return $p + ['area_fg' => $tone['fg'], 'area_bg' => $tone['bg']];
        }, $this->listPresentaciones([$_SESSION['company_id'], $itemId, $itemId]) ?: []);

        return [
            'status' => 200,
            'row'    => $rows
        ];
    }

    function editPresentacion() {
        $presentacion = $this->getPresentacionById([(int) ($_POST['id'] ?? 0)]);

        if (!$presentacion || (int) $presentacion['companies_id'] !== (int) $_SESSION['company_id']) {
            return [
                'status'  => 404,
                'message' => 'Presentación no encontrada'
            ];
        }

        $base = $this->getMaterialById($presentacion['item_id']);
        if ($bloqueo = $this->productoAjeno($base)) return $bloqueo;

        $fields = $this->presentacionFields($base, (string) $presentacion['sku']);

        if (isset($fields['status'])) return $fields;

        if ($this->existsPresentacionByName([$presentacion['item_id'], $_SESSION['company_id'], $fields['name'], $presentacion['id']])) {
            return [
                'status'  => 409,
                'message' => 'Ese producto ya tiene una presentación con ese nombre'
            ];
        }

        $update = $this->updatePresentacion([
            'values' => 'name = ?, description = ?, sku = ?, factor = ?, unit_id = ?, warehouse_area_id = ?, cost_unit = ?',
            'where'  => 'id = ?',
            'data'   => [
                $fields['name'],
                $fields['description'],
                $fields['sku'],
                $fields['factor'],
                $fields['unit_id'],
                $fields['warehouse_area_id'],
                $fields['cost_unit'],
                $presentacion['id']
            ]
        ]);

        if ($update) $this->fotoPresentacion($presentacion['id'], $fields);

        return [
            'status'  => $update ? 200 : 500,
            'message' => $update ? 'Presentación editada correctamente' : 'No se pudo editar la presentación'
        ];
    }

    // El switch de la sub-fila. El producto base se sigue dando de baja desde su propia fila.
    function statusPresentacion() {
        $presentacion = $this->getPresentacionById([(int) ($_POST['id'] ?? 0)]);

        if (!$presentacion || (int) $presentacion['companies_id'] !== (int) $_SESSION['company_id']) {
            return [
                'status'  => 404,
                'message' => 'Presentación no encontrada'
            ];
        }

        if ($bloqueo = $this->productoAjeno($this->getMaterialById($presentacion['item_id']))) return $bloqueo;

        $update = $this->updatePresentacion([
            'values' => 'active = ?',
            'where'  => 'id = ?',
            'data'   => [
                ($_POST['active'] ?? '') === '1' ? 1 : 0,
                $presentacion['id']
            ]
        ]);

        return [
            'status'  => $update ? 200 : 500,
            'message' => $update ? 'Estado actualizado correctamente' : 'No se pudo actualizar el estado'
        ];
    }

    // La rama de addMaterial: no crea item ni item_attribute. Si el producto base ya tiene
    // una presentación con ese nombre, se actualiza (y se reactiva) en vez de duplicarse.
    private function addPresentacion() {
        $base = $this->getMaterialById((int) ($_POST['base_item_id'] ?? 0));

        if (!$base || (int) $base['companies_id'] !== (int) $_SESSION['company_id']) {
            return [
                'status'  => 400,
                'message' => 'Elige el producto al que equivale la presentación'
            ];
        }

        // Una presentación nueva cambia el catálogo del producto base: solo quien lo edita.
        if ($bloqueo = $this->productoAjeno($base)) return $bloqueo;

        $fields = $this->presentacionFields($base);

        if (isset($fields['status'])) return $fields;

        $exists = $this->existsPresentacionByName([$base['id'], $_SESSION['company_id'], $fields['name'], 0]);

        if ($exists) {
            $this->updatePresentacion([
                'values' => 'name = ?, description = ?, sku = ?, factor = ?, unit_id = ?, warehouse_area_id = ?, cost_unit = ?, active = ?',
                'where'  => 'id = ?',
                'data'   => [
                    $fields['name'],
                    $fields['description'],
                    $fields['sku'],
                    $fields['factor'],
                    $fields['unit_id'],
                    $fields['warehouse_area_id'],
                    $fields['cost_unit'],
                    1,
                    $exists
                ]
            ]);

            $this->fotoPresentacion($exists, $fields);

            return [
                'status'  => 409,
                'updated' => true,
                'message' => '«' . htmlspecialchars($fields['name']) . '» ya era presentación de «' . htmlspecialchars($base['name']) . '»: se actualizó con estos datos.'
            ];
        }

        // created_at con el reloj de PHP, igual que item.created_at (addMaterial): la tabla
        // de Productos los ordena juntos por fecha de alta.
        $create = $this->createPresentacion([
            'values' => ['item_id', 'name', 'description', 'sku', 'factor', 'unit_id', 'warehouse_area_id', 'cost_unit', 'active', 'companies_id', 'created_at'],
            'data'   => [
                $base['id'],
                $fields['name'],
                $fields['description'],
                $fields['sku'],
                $fields['factor'],
                $fields['unit_id'],
                $fields['warehouse_area_id'],
                $fields['cost_unit'],
                1,
                $_SESSION['company_id'],
                date('Y-m-d H:i:s')
            ]
        ]);

        // La foto lleva el id en el nombre: se guarda ya creada la presentación.
        if ($create) $this->fotoPresentacion($this->existsPresentacionByName([$base['id'], $_SESSION['company_id'], $fields['name'], 0]), $fields);

        return [
            'status'  => $create ? 200 : 500,
            'message' => $create ? 'Presentación agregada' : 'No se pudo agregar la presentación'
        ];
    }

    // Lo que trae el formulario para una presentación, validado contra su base. El factor
    // es de 2 o más; el SKU vacío se deriva del base (47003-12) y el costo vacío se sugiere
    // del factor (12 × $16.20 = $194.40). Área, foto y descripción son suyas, no del base:
    // llegan en los mismos campos del producto (warehouse_area_id, image_b64, image_remove,
    // description), que el formulario mueve a la sección de la presentación. Con error
    // devuelve la respuesta (lleva `status`).
    private function presentacionFields($base, $skuActual = '') {
        $name   = mb_substr(trim($_POST['pres_name'] ?? ''), 0, 160);
        $nota   = mb_substr(trim($_POST['description'] ?? ''), 0, 255);
        $sku    = mb_substr(trim($_POST['pres_sku'] ?? ''), 0, 40);
        $factor = (float) ($_POST['factor'] ?? 0);

        if ($name === '') {
            return [
                'status'  => 400,
                'message' => 'El nombre de la presentación es obligatorio'
            ];
        }

        if ($factor == 1) {
            return [
                'status'  => 400,
                'message' => 'Con 1 sería el producto base, no una presentación'
            ];
        }

        if ($factor < 2) {
            return [
                'status'  => 400,
                'message' => 'El factor es cuántas unidades del producto base trae: tiene que ser 2 o más'
            ];
        }

        if (($_POST['pres_unit_id'] ?? '') === '') {
            return [
                'status'  => 400,
                'message' => 'Elige la unidad del empaque (reja, caja, paquete…)'
            ];
        }

        if ($sku !== '' && $sku !== $skuActual && $this->existsItemBySku([$sku])) {
            return [
                'status'  => 409,
                'message' => 'Ese código ya lo usa otro producto'
            ];
        }

        $photo = $_POST['image_b64'] ?? '';

        if ($photo !== '' && !$this->decodeProductImage($photo)) {
            return [
                'status'  => 400,
                'message' => 'La foto debe ser una imagen JPG, PNG o WEBP de hasta 4 MB'
            ];
        }

        if ($sku === '' && ($base['sku'] ?? '') !== '') $sku = $base['sku'] . '-' . $this->numeroIA($factor);

        return [
            'name'              => $name,
            'description'       => $nota === '' ? null : $nota,
            'sku'               => $sku === '' ? null : $sku,
            'factor'            => $factor,
            'unit_id'           => ($_POST['pres_unit_id'] ?? '') === '' ? null : (int) $_POST['pres_unit_id'],
            'warehouse_area_id' => ($_POST['warehouse_area_id'] ?? '') === '' ? null : (int) $_POST['warehouse_area_id'],
            'image_b64'         => $photo,
            'image_remove'      => ($_POST['image_remove'] ?? '') === '1',
            'cost_unit'         => ($_POST['pres_cost_unit'] ?? '') === ''
                ? round($factor * (float) ($base['cost_unit'] ?? 0), 2)
                : (float) $_POST['pres_cost_unit']
        ];
    }

    // Foto nueva: reemplaza la anterior. «Quitar»: la borra. Sin tocarla, se queda la que
    // tenía; y si es un producto que pasa a presentación (`$copia` = su item.image), se
    // le copia la del producto, así cada uno conserva la suya.
    private function fotoPresentacion($id, $fields, $copia = '') {
        if (!$id) return;

        $nueva = ($fields['image_b64'] ?? '') !== ''
            ? $this->decodeProductImage($fields['image_b64'])
            : (empty($fields['image_remove']) && $copia !== '' ? $this->productImageFile($copia) : null);

        if ($nueva) {
            $this->savePresentacionImage($id, $nueva);
        } elseif (!empty($fields['image_remove'])) {
            $this->dropPresentacionImage($id);
            $this->updatePresentacion([
                'values' => 'image = ?',
                'where'  => 'id = ?',
                'data'   => [null, $id]
            ]);
        }
    }

    // Como saveProductImage: uploads/presentaciones/{id}_{único}.{ext} en item_presentation.image.
    private function savePresentacionImage($id, $image) {
        $dir = __DIR__ . '/../../../uploads/presentaciones/';
        if (!is_dir($dir)) @mkdir($dir, 0777, true);

        $name = (int) $id . '_' . substr(md5(uniqid('', true)), 0, 8) . '.' . $image['ext'];

        $this->dropPresentacionImage($id);
        if (@file_put_contents($dir . $name, $image['data']) === false) return false;

        return $this->updatePresentacion([
            'values' => 'image = ?',
            'where'  => 'id = ?',
            'data'   => ['uploads/presentaciones/' . $name, $id]
        ]);
    }

    // La foto guardada de un producto (item.image), leída del disco para copiarla.
    private function productImageFile($ruta) {
        if (!preg_match('#^uploads/productos/[\w.-]+\.(jpg|png|webp)$#i', (string) $ruta, $m)) return null;

        $data = @file_get_contents(__DIR__ . '/../../../' . $ruta);

        return $data === false ? null : ['ext' => strtolower($m[1]), 'data' => $data];
    }

    private function dropPresentacionImage($id) {
        foreach (glob(__DIR__ . '/../../../uploads/presentaciones/' . (int) $id . '_*') ?: [] as $old) @unlink($old);
    }

    // Editar > Presentación: el producto deja de serlo y pasa a ser el empaque de su
    // base. Todo en una transacción: nace la presentación (con su nombre, SKU, unidad,
    // área, foto y costo), su stock pasa al base × factor con un ajuste AJU- ya aplicado por
    // almacén (5 rejas = +60 piezas, sale en el kárdex) y el producto se desactiva;
    // su historial se queda con él.
    private function pasarAPresentacion($id) {
        $material = $this->getMaterialById($id);
        $base     = $this->getMaterialById((int) ($_POST['base_item_id'] ?? 0));

        if (!$material || (int) $material['companies_id'] !== (int) $_SESSION['company_id']) {
            return [
                'status'  => 404,
                'message' => 'Producto no encontrado'
            ];
        }

        if (!$base || (int) $base['companies_id'] !== (int) $_SESSION['company_id'] || (int) $base['id'] === (int) $id) {
            return [
                'status'  => 400,
                'message' => 'Elige el producto al que equivale la presentación'
            ];
        }

        // El base recibe stock y una presentación nueva: tiene que poder editarlo.
        if ($bloqueo = $this->productoAjeno($base)) return $bloqueo;

        // Sus propias presentaciones se quedarían colgando de un producto inactivo.
        if ($this->listPresentaciones([$_SESSION['company_id'], $id, $id])) {
            return [
                'status'  => 409,
                'message' => 'Este producto tiene presentaciones: no puede ser presentación de otro.'
            ];
        }

        $fields = $this->presentacionFields($base, (string) $material['sku']);

        if (isset($fields['status'])) return $fields;

        if (!$this->getAdjustmentReasonByCode(['PRESENTACION'])) {
            return [
                'status'  => 500,
                'message' => 'Falta el motivo PRESENTACION (docs/sql/2026-10-18_motivo-paso-a-presentacion.sql)'
            ];
        }

        try {
            $folios = $this->transaction(function () use ($material, $base, $fields) {
                return $this->moverAPresentacion($material, $base, $fields);
            });
        } catch (\Throwable $e) {
            return [
                'status'  => 500,
                'message' => 'No se pudo pasar a presentación; nada cambió'
            ];
        }

        return [
            'status'  => 200,
            'message' => '«' . htmlspecialchars($material['name']) . '» ahora es presentación de «' . htmlspecialchars($base['name']) . '»'
                       . ($folios ? '. Su stock pasó al producto base (' . implode(', ', $folios) . ').' : '.')
        ];
    }

    // El paso en sí, sin transacción propia: lo envuelve quien llama (pasarAPresentacion,
    // o applyAsistente con todo lo que marcó la persona). Devuelve los folios AJU-.
    private function moverAPresentacion($material, $base, $fields) {
        $reason = $this->getAdjustmentReasonByCode(['PRESENTACION']);

        if (!$reason) throw new Exception('Falta el motivo PRESENTACION (docs/sql/2026-10-18_motivo-paso-a-presentacion.sql).');

        $id      = (int) $material['id'];
        $factor  = $fields['factor'];
        $userId  = (int) ($_SESSION['user_id'] ?? $_SESSION['IDU'] ?? 0) ?: null;
        $company = (int) $_SESSION['company_id'];
        $nota    = mb_substr('«' . $material['name'] . '» pasó a presentación de «' . $base['name'] . '» (×' . $this->numeroIA($factor) . ')', 0, 255);
        $folios  = [];

        foreach ($this->listStockByItem([$id]) as $stock) {
            $cantidad = (float) $stock['quantity'];
            $suma     = round($cantidad * $factor, 4);
            $baseRow  = $this->getStockByItemWarehouse([$base['id'], $stock['warehouse_id']]);
            $basePrev = $baseRow ? (float) $baseRow['quantity'] : 0;
            $basePost = round($basePrev + $suma, 4);
            $folio    = $this->nextFolio('AJU-', 'inventory_adjustment', $company, (int) $stock['branch_id']);

            $this->createAdjustment([$folio, $nota, $reason['id'], $userId, $userId, $stock['warehouse_id'], $stock['branch_id'], $company]);
            $ajuste = $this->getAdjustmentByFolio([$folio, $company]);

            if (!$ajuste) throw new Exception('Sin id del ajuste');

            $this->createAdjustmentDetail([$ajuste, $id, $cantidad, 0, -$cantidad, (float) $material['cost_unit'], round(-$cantidad * (float) $material['cost_unit'], 4), $cantidad, 0, 'Su stock pasó al producto base']);
            $this->createAdjustmentDetail([$ajuste, $base['id'], $basePrev, $basePost, $suma, (float) $base['cost_unit'], round($suma * (float) $base['cost_unit'], 4), $basePrev, $basePost, 'Recibe el stock de la presentación']);
            $this->updateAdjustmentTotals([$ajuste, $ajuste]);
            $this->createAdjustmentHistory(['Aplicado', $nota, $userId, $ajuste]);

            $this->updateStock([0, $stock['id']]);

            if ($baseRow) $this->updateStock([$basePost, $baseRow['id']]);
            else $this->createStock([$basePost, $stock['warehouse_id'], $base['id'], $company]);

            $folios[] = $folio;
        }

        // Si el base ya tenía una con ese nombre, se actualiza en vez de duplicarla. Sin
        // descripción en $fields (CoffeeIA) se queda la que tenía como producto.
        $existe = $this->existsPresentacionByName([$base['id'], $company, $fields['name'], 0]);
        $area   = $fields['warehouse_area_id'] ?? null;
        $nota   = array_key_exists('description', $fields) ? $fields['description'] : (($material['description'] ?? '') !== '' ? $material['description'] : null);

        if ($existe) {
            $this->updatePresentacion([
                'values' => 'name = ?, description = ?, sku = ?, factor = ?, unit_id = ?, warehouse_area_id = ?, cost_unit = ?, active = ?',
                'where'  => 'id = ?',
                'data'   => [$fields['name'], $nota, $fields['sku'], $factor, $fields['unit_id'], $area, $fields['cost_unit'], 1, $existe]
            ]);
        } else {
            $this->createPresentacion([
                'values' => ['item_id', 'name', 'description', 'sku', 'factor', 'unit_id', 'warehouse_area_id', 'cost_unit', 'active', 'companies_id', 'created_at'],
                'data'   => [$base['id'], $fields['name'], $nota, $fields['sku'], $factor, $fields['unit_id'], $area, $fields['cost_unit'], 1, $company, date('Y-m-d H:i:s')]
            ]);
        }

        // Su foto: la del formulario, o la copia de la que tenía como producto.
        $this->fotoPresentacion($existe ?: $this->existsPresentacionByName([$base['id'], $company, $fields['name'], 0]), $fields, (string) ($material['image'] ?? ''));

        $this->updateMaterial([
            'values' => 'active = ?',
            'where'  => 'id = ?',
            'data'   => [0, $id]
        ]);

        return $folios;
    }

    // -- Asistente IA --
    /*  Chat flotante del catálogo del almacén: altas, cambios, bajas y
        reactivaciones de productos, categorías, unidades, áreas, almacenes,
        proveedores, orígenes de entrada, motivos de salida y estados de traspaso
        (todas las pestañas de Catálogo), a partir de un mensaje, un Excel o una foto.

        El modelo solo PROPONE. Aquí se valida cada cambio contra los datos reales
        y la propuesta se guarda en la sesión; lo que se aplica sale de la sesión,
        nunca de lo que mande el navegador.

        El comportamiento (tono y reglas del negocio) vive en ia/asistente-catalogo.md
        y se edita sin tocar PHP. Lo que no se puede romper desde ese archivo --qué
        entidades y campos existen, las herramientas y los datos vivos-- lo arma promptIA().

        Desde el 18/10/2026 trabaja en un bucle con herramientas (como el de Pedidos):
        consulta, opina y pregunta en texto libre, y solo propone con proponer_cambios o
        proponer_presentaciones. Una petición por vuelta; el hilo vive en la sesión y el
        navegador repite con `turno` mientras haya herramientas que usar. */

    const IA_MAX_CAMBIOS        = 150;
    const IA_MAX_CATALOGO       = 1500;
    const IA_MAX_FILTRO         = 150;   // productos por respuesta de filtrar_productos
    const IA_MAX_RONDAS         = 8;
    const IA_MAX_PRESENTACIONES = 60;

    // Entidades que toca el asistente y los campos que el modelo puede mandar en
    // "set" (clave => etiqueta de la vista previa). El orden importa: los
    // catálogos se validan y se aplican antes que los productos que los usan.
    // 'alta' => false: catálogo de sistema, solo se cambia (sus códigos los usa el flujo).
    const IA_ENTIDADES = [
        'category'  => ['tag' => 'Categoría', 'uno' => 'categoría', 'varios' => 'categorías',  'campos' => ['name' => 'Nombre']],
        'unit'      => ['tag' => 'Unidad',    'uno' => 'unidad',    'varios' => 'unidades',    'campos' => ['code' => 'Código', 'name' => 'Nombre']],
        'area'      => ['tag' => 'Área',      'uno' => 'área',      'varios' => 'áreas',       'campos' => ['name' => 'Nombre', 'description' => 'Descripción', 'warehouse' => 'Almacén']],
        'warehouse' => ['tag' => 'Almacén',   'uno' => 'almacén',   'varios' => 'almacenes',   'campos' => ['name' => 'Nombre', 'branch' => 'Sucursal', 'is_default' => 'Por defecto']],
        'supplier'  => ['tag' => 'Proveedor', 'uno' => 'proveedor', 'varios' => 'proveedores', 'campos' => ['name' => 'Nombre', 'contact_name' => 'Contacto', 'phone' => 'Teléfono', 'email' => 'Email']],
        'inflow'    => ['tag' => 'Origen entrada', 'uno' => 'origen de entrada', 'varios' => 'orígenes de entrada', 'campos' => [
            'name'              => 'Nombre',
            'description'       => 'Descripción',
            'requires_supplier' => 'Pide proveedor',
            'icon'              => 'Ícono',
            'color_hex'         => 'Color de texto',
            'bg_hex'            => 'Color de fondo'
        ]],
        'shrinkage' => ['tag' => 'Motivo salida', 'uno' => 'motivo de salida', 'varios' => 'motivos de salida', 'campos' => [
            'name'      => 'Nombre',
            'icon'      => 'Ícono',
            'color_hex' => 'Color de texto',
            'bg_hex'    => 'Color de fondo'
        ]],
        'transfer_status' => ['tag' => 'Estado traspaso', 'uno' => 'estado de traspaso', 'varios' => 'estados de traspaso', 'alta' => false, 'campos' => [
            'name'      => 'Nombre',
            'name_out'  => 'Lo ve quien envía',
            'name_in'   => 'Lo ve quien recibe',
            'color_hex' => 'Color de texto',
            'bg_hex'    => 'Color de fondo'
        ]],
        'product'   => ['tag' => 'Producto',  'uno' => 'producto',  'varios' => 'productos',   'campos' => [
            'name'            => 'Nombre',
            'category'        => 'Categoría',
            'unit'            => 'Unidad',
            'area'            => 'Área',
            'price'           => 'Precio',
            'base'            => 'Precio sin IVA',
            'tax'             => 'IVA',
            'cost'            => 'Último costo',
            'stock_min'       => 'Mínimo',
            'stock_max'       => 'Máximo',
            'shelf_life_days' => 'Vida útil',
            'description'     => 'Descripción',
            'branch'          => 'Sucursal'
        ]]
    ];

    // Tope de caracteres por columna de texto de cada catálogo (el de la BD).
    const IA_LARGOS = [
        'category'        => ['name' => 120],
        'unit'            => ['code' => 20, 'name' => 80],
        'area'            => ['name' => 120, 'description' => 255],
        'warehouse'       => ['name' => 120],
        'supplier'        => ['name' => 160, 'contact_name' => 120, 'phone' => 20, 'email' => 120],
        'inflow'          => ['name' => 120, 'description' => 255],
        'shrinkage'       => ['name' => 120],
        'transfer_status' => ['name' => 80, 'name_out' => 50, 'name_in' => 50]
    ];

    // En su pestaña el ícono es obligatorio: un alta sin ícono válido lleva el de la pestaña.
    const IA_ICONO = ['inflow' => 'log-in', 'shrinkage' => 'log-out'];

    // Lo que deja de pasar al dar de baja (mismo texto que el aviso de su pestaña).
    const IA_BAJA = [
        'inflow'          => 'Ya no aparecerá al registrar entradas.',
        'shrinkage'       => 'Ya no aparecerá al registrar salidas.',
        'transfer_status' => 'Dejará de mostrarse en Traspasos.'
    ];

    // Bloques que vacía el Super Admin, del más chico al más grande. Cada uno
    // arrastra a los anteriores: no se borran productos que siguen usados por
    // movimientos, ni categorías que siguen usadas por productos. Las tablas van
    // en orden de borrado (hijos antes que padres); las null son detalle y no se
    // cuentan aparte. Unidades, almacenes y sucursales nunca se vacían.
    const IA_VACIADO = [
        'movements' => ['nombre' => 'Movimientos del almacén', 'refresca' => ['product'], 'tablas' => [
            'detail_inventory_inflow'      => null,
            'inventory_inflow'             => ['entrada', 'entradas'],
            'detail_inventory_shrinkage'   => null,
            'inventory_shrinkage'          => ['salida', 'salidas'],
            'detail_inventory_adjustment'  => null,
            'inventory_adjustment_history' => null,
            'inventory_adjustment'         => ['ajuste', 'ajustes'],
            'detail_inventory_transfer'    => null,
            'inventory_transfer_history'   => null,
            'inventory_transfer'           => ['traspaso', 'traspasos'],
            'detail_purchase_order'        => null,
            'purchase_order'               => ['orden de compra', 'órdenes de compra'],
            'stock'                        => ['existencia', 'existencias']
        ]],
        'products' => ['nombre' => 'Productos y sus movimientos', 'refresca' => ['product'], 'tablas' => [
            'inflow_format_item' => null,
            'inflow_format'      => ['formato de entrada', 'formatos de entrada'],
            'item_attribute'     => null,
            'item'               => ['producto', 'productos']
        ]],
        'catalogs' => ['nombre' => 'Catálogos, productos y movimientos', 'refresca' => ['product', 'category', 'area', 'supplier'], 'tablas' => [
            'item_category'  => ['categoría', 'categorías'],
            'warehouse_area' => ['área', 'áreas'],
            'supplier'       => ['proveedor', 'proveedores']
        ]]
    ];

    // Lee lo que se adjunta al chat y lo devuelve como texto. No guarda nada en
    // disco: el archivo vive lo que dura la petición.
    function readArchivo() {
        if (empty($_SESSION['company_id'])) return ['status' => 401, 'message' => 'Tu sesión expiró. Vuelve a entrar.'];

        $f = $_FILES['archivo'] ?? null;

        if (!is_array($f)) return ['status' => 400, 'message' => 'No llegó ningún archivo.'];

        if (in_array((int) $f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
            return ['status' => 413, 'message' => 'El archivo pasa del tope del servidor (' . ini_get('upload_max_filesize') . ').'];
        }

        if ((int) $f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
            return ['status' => 400, 'message' => 'El archivo no llegó completo. Vuelve a subirlo.'];
        }

        if ((int) $f['size'] > 8 * 1048576) return ['status' => 413, 'message' => 'El archivo pesa más de 8 MB.'];

        $nombre = mb_substr((string) $f['name'], 0, 120);
        $ext    = strtolower((string) pathinfo($nombre, PATHINFO_EXTENSION));
        $clase  = IaLector::clase($ext);

        if ($clase === null) {
            return ['status' => 415, 'message' => 'Solo leo Excel (.xlsx, .xlsm, .xlsb o .xls), LibreOffice (.ods), CSV/TSV o imágenes (PNG, JPG o WEBP).'];
        }

        if (!IaLector::firmaOk($f['tmp_name'], $ext)) {
            return ['status' => 415, 'message' => 'Ese archivo dice ser .' . $ext . ' pero por dentro es otra cosa. Vuelve a guardarlo desde el programa que lo hizo.'];
        }

        if ($clase === 'imagen') {
            $ia = IaOllama::desdeCredenciales($this);

            if ($ia === null) return ['status' => 503, 'message' => 'El asistente no está configurado: falta la llave de Ollama.'];

            session_write_close();
            set_time_limit(180);

            $leido = $ia->transcribirImagen($f['tmp_name'], ($_POST['dudas'] ?? '') === '1');
        } else {
            $leido = IaLector::leer($f['tmp_name'], $ext);
        }

        if ($leido['texto'] === '') {
            return ['status' => 422, 'message' => $leido['aviso'] !== '' ? $leido['aviso'] : 'No encontré nada que leer en ese archivo.'];
        }

        $renglones = IaLector::renglones($leido['texto']);
        $partes    = (int) ($leido['partes'] ?? 0);
        $origen    = $clase === 'imagen' ? 'Imagen leída' : ($partes > 1 ? $partes . ' hojas' : 'Archivo leído');

        return [
            'status' => 200,
            'data'   => [
                'nombre'  => $nombre,
                'clase'   => $clase,
                'detalle' => $origen . ' · ' . $renglones . ($renglones === 1 ? ' renglón' : ' renglones'),
                'texto'   => $leido['texto']
            ]
        ];
    }

    function askAsistente() {
        if (empty($_SESSION['company_id'])) return ['status' => 401, 'message' => 'Tu sesión expiró. Vuelve a entrar.'];

        if (!IaOllama::activo($this)) return ['status' => 403, 'message' => 'CoffeeIA está apagado. Se enciende en Administrador > CoffeeIA.'];

        if (!Permissions::can('administrador', 'ia')) return ['status' => 403, 'message' => 'Tu rol no tiene CoffeeIA en el Catálogo. Se activa en Accesos › Roles, columna IA.'];

        $ia = IaOllama::desdeCredenciales($this);

        if ($ia === null) return ['status' => 503, 'message' => 'El asistente no está configurado: falta la llave de Ollama.'];

        $super = $this->esSuperAdminIA();
        $turno = (string) ($_POST['turno'] ?? '');

        if ($turno === '') {
            $mensaje   = mb_substr(trim((string) ($_POST['mensaje'] ?? '')), 0, 4000);
            $adjuntos  = json_decode((string) ($_POST['adjuntos'] ?? '[]'), true);
            $historial = json_decode((string) ($_POST['historial'] ?? '[]'), true);
            $adjuntos  = is_array($adjuntos) ? $adjuntos : [];
            $historial = is_array($historial) ? $historial : [];

            if ($mensaje === '' && empty($adjuntos)) {
                return ['status' => 400, 'message' => 'Escríbeme qué quieres hacer o adjunta un archivo.'];
            }

            // El system no viaja en el hilo: se arma en cada vuelta con los datos de ese momento.
            $hilo = [
                'id'             => bin2hex(random_bytes(6)),
                'mensajes'       => $this->mensajesIA($mensaje, $adjuntos, $historial),
                'rondas'         => 0,
                'cierre'         => false,
                'cambios'        => [],
                'presentaciones' => []
            ];
        } else {
            $hilo = $_SESSION['iaProductosHilo'] ?? null;

            if (!is_array($hilo) || !hash_equals((string) $hilo['id'], $turno)) {
                return ['status' => 409, 'message' => 'Perdí el hilo de esta respuesta. Pregúntame otra vez.'];
            }
        }

        $ctx = $this->contextoIA();

        // Sin esto la sesión queda bloqueada mientras el modelo piensa y las tablas
        // del almacén no pueden recargar en ese rato. Se reabre para guardar el hilo.
        session_write_close();
        set_time_limit(180);

        // En la última vuelta ya no hay herramientas: tiene que contestar con lo que tiene.
        $ultima   = $hilo['rondas'] >= self::IA_MAX_RONDAS - 1;
        $mensajes = array_merge([['role' => 'system', 'content' => $this->promptIA($ctx, $super)]], $hilo['mensajes']);
        $r        = $ia->chatRonda($mensajes, $ultima ? [] : $this->herramientasIA($super));

        if (!$r['ok']) return ['status' => 502, 'message' => $r['error']];

        $hilo['rondas']++;

        if (!empty($r['tool_calls']) && !$ultima) {
            $hilo['mensajes'][] = ['role' => 'assistant', 'content' => $r['content'], 'tool_calls' => $r['tool_calls']];
            $pasos              = [];

            foreach ($r['tool_calls'] as $llamada) {
                $nombre = (string) ($llamada['function']['name'] ?? '');
                $args   = $llamada['function']['arguments'] ?? [];
                $args   = is_array($args) ? $args : (json_decode((string) $args, true) ?: []);
                $hecho  = $this->usarHerramientaIA($nombre, $args, $ctx, $super, $hilo);

                $hilo['mensajes'][] = ['role' => 'tool', 'tool_name' => $nombre, 'content' => json_encode($hecho['resultado'], JSON_UNESCAPED_UNICODE)];
                $pasos[]            = $hecho['paso'];
            }

            session_start();
            $_SESSION['iaProductosHilo'] = $hilo;

            return ['status' => 200, 'turno' => $hilo['id'], 'pasos' => $pasos];
        }

        // Vuelta vacía (todo se le fue en pensar): una sola vuelta más pidiéndole el cierre.
        if (trim((string) $r['content']) === '' && !$hilo['cierre']) {
            $hilo['cierre']     = true;
            $hilo['mensajes'][] = ['role' => 'system', 'content' => 'No escribiste respuesta. Redacta ahora la respuesta final para la persona con lo que ya averiguaste.'];

            session_start();
            $_SESSION['iaProductosHilo'] = $hilo;

            return ['status' => 200, 'turno' => $hilo['id'], 'pasos' => ['Redactando la respuesta']];
        }

        // Respuesta final: la vista previa sale de lo último que propuso, validado otra vez.
        $vista = $this->vistaPropuestaIA($hilo, $ctx, $super);
        $token = empty($vista['validos']) ? '' : bin2hex(random_bytes(8));
        $reply = $this->textoIA($r['content']);

        session_start();
        unset($_SESSION['iaProductosHilo']);
        if ($token !== '') $_SESSION['iaProductos'] = ['token' => $token, 'cambios' => $vista['validos']];

        if ($reply === '') $reply = empty($vista['row']) ? 'No pude redactar una respuesta. Pregúntame otra vez, con otras palabras.' : 'Revisa la vista previa y confirma.';

        return [
            'status'  => 200,
            'reply'   => $reply,
            'token'   => $token,
            'row'     => $vista['row'],
            'resumen' => $vista['resumen']
        ];
    }

    // Todo o nada: si un cambio falla, la transacción deshace los demás.
    function applyAsistente() {
        if (empty($_SESSION['company_id'])) return ['status' => 401, 'message' => 'Tu sesión expiró. Vuelve a entrar.'];

        if (!Permissions::can('administrador', 'ia')) return ['status' => 403, 'message' => 'Tu rol no tiene CoffeeIA en el Catálogo. Se activa en Accesos › Roles, columna IA.'];

        $pendiente = $_SESSION['iaProductos'] ?? null;
        $token     = (string) ($_POST['token'] ?? '');

        if (!is_array($pendiente) || $token === '' || !hash_equals((string) $pendiente['token'], $token)) {
            return ['status' => 409, 'message' => 'Esa vista previa ya no está vigente. Pídeme los cambios otra vez.'];
        }

        $ids         = json_decode((string) ($_POST['ids'] ?? '[]'), true);
        $selecciones = [];

        foreach ((array) $ids as $i) {
            if (is_numeric($i) && isset($pendiente['cambios'][(int) $i])) $selecciones[(int) $i] = $pendiente['cambios'][(int) $i];
        }

        if (empty($selecciones)) return ['status' => 400, 'message' => 'No marcaste ningún cambio.'];

        // El rol se vuelve a revisar al aplicar: pudo cambiar desde la vista previa.
        if (in_array('purge', array_column($selecciones, 'entity'), true) && !$this->esSuperAdminIA()) {
            return ['status' => 403, 'message' => 'Solo el Super Admin puede vaciar la base de datos.'];
        }
        $verbos = ['add' => 'dar de alta', 'edit' => 'editar', 'deactivate' => 'dar de baja', 'activate' => 'reactivar', 'present' => 'pasar productos a presentación'];
        foreach ($selecciones as $c) {
            $accion = self::IA_PERMISSIONS[$c['action']] ?? null;
            if ($accion !== null && !Permissions::can('administrador', $accion)) {
                return ['status' => 403, 'message' => 'Tu rol no tiene permiso para ' . $verbos[$c['action']] . ' en el Catálogo.'];
            }
        }

        // El índice ya viene en orden de aplicación: catálogos primero, productos después.
        ksort($selecciones);

        $companies_id = $_SESSION['company_id'];
        $branch_id    = $_SESSION['branch_id'] ?? null;
        $now          = date('Y-m-d H:i:s');

        try {
            $hechos = $this->transaction(function () use ($selecciones, $companies_id, $branch_id, $now) {
                $n       = [];
                $creados = [];

                foreach ($selecciones as $c) {
                    if ($c['entity'] === 'purge') {
                        $n['purge'] = ['scope' => $c['scope'], 'borrados' => $this->vaciarIA($c['scope'], $companies_id)];
                        continue;
                    }

                    $this->aplicarCambioIA($c, $companies_id, $branch_id, $now, $creados);

                    $n[$c['entity']][$c['action']] = ($n[$c['entity']][$c['action']] ?? 0) + 1;
                }

                return $n;
            });
        } catch (Throwable $e) {
            error_log('[applyAsistente] ' . $e->getMessage());

            $motivo = $e instanceof PDOException ? 'la base de datos rechazó un cambio.' : $e->getMessage();

            return ['status' => 500, 'message' => 'No se aplicó ningún cambio: ' . $motivo];
        }

        unset($_SESSION['iaProductos']);

        $entidades = isset($hechos['purge']) ? self::IA_VACIADO[$hechos['purge']['scope']]['refresca'] : array_keys($hechos);

        return [
            'status'  => 200,
            'message' => $this->resumenIA($hechos),
            'data'    => ['entidades' => $entidades]
        ];
    }

    // -- Asistente IA · contexto y prompt --

    private function contextoIA() {
        $ctx = [
            'product'      => $this->listMateriales([]),
            'branch'       => $this->lsBranches(),
            'presentacion' => $this->listPresentaciones([$_SESSION['company_id'], 0, 0])
        ];

        foreach (array_diff(array_keys(self::IA_ENTIDADES), ['product']) as $entidad) {
            $ctx[$entidad] = $this->listCatalog($entidad);
        }

        foreach ($ctx as $k => $filas) {
            if (!is_array($filas)) $ctx[$k] = [];
        }

        return $ctx;
    }

    private function mensajesIA($mensaje, $adjuntos, $historial) {
        $mensajes = [];

        foreach (array_slice($historial, -8) as $h) {
            $rol   = is_array($h) ? ($h['role'] ?? '') : '';
            $texto = is_array($h) ? $this->textoIA($h['content'] ?? '') : '';

            if (($rol === 'user' || $rol === 'assistant') && $texto !== '') {
                $mensajes[] = ['role' => $rol, 'content' => mb_substr($texto, 0, 3000)];
            }
        }

        $pregunta = 'MENSAJE: ' . ($mensaje !== '' ? $mensaje : '(sin texto: solo adjuntó archivos)');
        $cupo     = 60000;

        foreach (array_slice($adjuntos, 0, 3) as $a) {
            $texto = is_array($a) ? mb_substr($this->textoIA($a['texto'] ?? ''), 0, min(30000, $cupo)) : '';

            if ($texto === '') continue;

            $cupo     -= mb_strlen($texto);
            $pregunta .= "\n\nARCHIVO «" . mb_substr($this->textoIA($a['nombre'] ?? 'archivo'), 0, 120) . "»:\n" . $texto;

            if ($cupo <= 0) break;
        }

        $mensajes[] = ['role' => 'user', 'content' => $pregunta];

        return $mensajes;
    }

    // Tres partes: el contexto editable (ia/asistente-catalogo.md), el contrato
    // (entidades, campos y formato JSON, que valida validarCambiosIA) y los datos vivos.
    private function promptIA($ctx, $super) {
        $ruta     = __DIR__ . '/../ia/asistente-catalogo.md';
        $reglas   = is_readable($ruta) ? trim(preg_replace('/<!--.*?-->/s', '', (string) file_get_contents($ruta))) : '';
        $sucursal = array_column($ctx['branch'], 'valor', 'id');
        $almacen  = array_column($ctx['warehouse'], 'name', 'id');
        $estado   = function ($r) { return (int) $r['active'] === 1 ? 'activo' : 'baja'; };
        $filas    = [];

        foreach ($ctx['category'] as $r)  $filas['category'][]  = [$r['id'], $r['name'], $estado($r)];
        foreach ($ctx['unit'] as $r)      $filas['unit'][]      = [$r['id'], $r['code'], $r['name'], $estado($r)];
        foreach ($ctx['area'] as $r)      $filas['area'][]      = [$r['id'], $r['name'], $almacen[$r['warehouse_id']] ?? '-', $r['description'], $estado($r)];
        foreach ($ctx['branch'] as $r)    $filas['branch'][]    = [$r['id'], $r['valor']];
        foreach ($ctx['supplier'] as $r)  $filas['supplier'][]  = [$r['id'], $r['name'], $r['contact_name'], $r['phone'], $r['email'], $estado($r)];

        foreach ($ctx['warehouse'] as $r) {
            $filas['warehouse'][] = [$r['id'], $r['name'], $sucursal[$r['branch_id']] ?? '-', (int) $r['is_default'] === 1 ? 'sí' : 'no', $estado($r)];
        }

        // description de inflow_origin la agrega docs/sql/2026-10-06_origen-entrada-descripcion.sql.
        foreach ($ctx['inflow'] as $r) {
            $filas['inflow'][] = [$r['id'], $r['name'], $r['description'] ?? '', (int) $r['requires_supplier'] === 1 ? 'sí' : 'no', $r['icon'], $r['color_hex'], $r['bg_hex'], $estado($r)];
        }

        foreach ($ctx['shrinkage'] as $r) {
            $filas['shrinkage'][] = [$r['id'], $r['name'], $r['icon'], $r['color_hex'], $r['bg_hex'], $estado($r)];
        }

        foreach ($ctx['transfer_status'] as $r) {
            $filas['transfer_status'][] = [$r['id'], $r['name'], $r['name_out'], $r['name_in'], $r['color_hex'], $r['bg_hex'], $estado($r)];
        }

        foreach (array_slice($ctx['product'], 0, self::IA_MAX_CATALOGO) as $p) {
            $filas['product'][] = [
                $p['id'],
                $p['sku'],
                $p['name'],
                $p['categoria'],
                $p['unidad'],
                $p['area'],
                number_format((float) $p['price'], 2, '.', ''),
                (float) $p['tax'],
                number_format((float) $p['cost_unit'], 2, '.', ''),
                $this->numeroIA($p['stock_min']),
                $this->numeroIA($p['stock_max']),
                $this->numeroIA($p['shelf_life_days']),
                $p['sucursal'] ?? '',
                $estado($p)
            ];
        }

        $recorte = count($ctx['product']) > self::IA_MAX_CATALOGO ? ' (recortado a los ' . self::IA_MAX_CATALOGO . ' más recientes)' : '';

        return implode("\n", [
            $reglas !== '' ? $reglas : 'Eres CoffeeIA, el asistente del catálogo del almacén. Hablas español, en frases cortas.',
            '',
            '== CONTRATO DE proponer_cambios (lo que el sistema acepta) ==',
            'Entidades ("entity") y los campos que puedes mandar en "set":',
            '- product: name, category, unit, area, price (venta con IVA), base (venta sin IVA), tax (0, 8 o 16), cost (último costo sin IVA), stock_min, stock_max, shelf_life_days (días), description, branch (nombre de una SUCURSAL: de quién es el producto)',
            '- category: name',
            '- unit: code, name',
            '- area: name, description, warehouse (nombre de un ALMACÉN de su lista; si hay dos con el mismo nombre, su id). Un alta sin warehouse va al almacén por defecto.',
            '- warehouse: name, branch (nombre de una SUCURSAL), is_default (true o false)',
            '- supplier: name, contact_name, phone, email',
            '- inflow (origen de entrada): name, description, requires_supplier (true o false), icon, color_hex, bg_hex',
            '- shrinkage (motivo de salida): name, icon, color_hex, bg_hex',
            '- transfer_status (estado de traspaso): name, name_out (texto que ve la sucursal que envía), name_in (texto que ve la que recibe), color_hex, bg_hex. Son fijos del sistema: solo "edit", "deactivate" y "activate", nunca "add".',
            '- icon: nombre canónico de un ícono de Lucide en kebab-case (truck, shopping-cart, gift, triangle-alert). color_hex es el color del texto y bg_hex el del fondo, los dos en #RRGGBB.',
            'Acciones ("action"): "add" (alta), "edit" (cambio), "deactivate" (baja), "activate" (reactivar).',
            '- En edit, deactivate y activate el "id" es OBLIGATORIO y sale de la lista de esa entidad. En "ref" pon cómo lo nombró la persona.',
            '- En edit manda en "set" SOLO los campos que cambian.',
            '- En un producto, "category", "unit" y "area" van con el NOMBRE tal como está en su lista. Si la das de alta en esta misma respuesta, usa el mismo nombre.',
            '- Números sin signo de pesos ni separador de miles: 1250.5',
            $this->esAdministrador()
                ? '- MOVER DE SUCURSAL (esta persona es administrador): si dice que un producto es de otra sucursal ("el domo C15 no es de Guadalupe, es de Kafeto"), manda un edit con "branch" y el nombre de la sucursal tal como está en SUCURSALES. Solo cambia de quién es el producto: su existencia se queda en el almacén donde está; dilo en "reply".'
                : '- Cambiar un producto de sucursal es solo para el administrador. Si esta persona lo pide, dile que no tiene permiso y no mandes "branch".',
            '- Como mucho ' . self::IA_MAX_CAMBIOS . ' cambios por respuesta; si hay más, propone los primeros y avísalo en "reply".',
            $super
                ? '- VACIAR (esta persona es Super Admin): si pide vaciar, limpiar o borrar TODO un bloque, manda un solo cambio {"entity": "purge", "action": "purge", "scope": "..."} y ningún otro. scope: "movements" (entradas, salidas, ajustes, traspasos, órdenes de compra y existencias), "products" (todos los productos, con sus movimientos) o "catalogs" (categorías, áreas y proveedores, con productos y movimientos). Unidades, almacenes y sucursales no se vacían. Para quitar registros sueltos usa "deactivate", nunca "purge".'
                : '- VACIAR la base de datos es solo para el Super Admin. Si esta persona lo pide, dile que no tiene permiso y no mandes cambios.',
            '',
            'Ejemplo de "changes" para proponer_cambios:',
            '[',
            '  {"entity": "category", "action": "add", "set": {"name": "Bebidas"}},',
            '  {"entity": "product", "action": "add", "set": {"name": "Agua natural 1 L", "category": "Bebidas", "unit": "Pieza", "price": 18, "tax": 16}},',
            '  {"entity": "product", "action": "edit", "id": 45, "ref": "refresco de cola", "set": {"price": 24.5, "stock_min": 6}},',
            '  {"entity": "supplier", "action": "deactivate", "id": 9, "ref": "Distribuidora Norte"},',
            '  {"entity": "inflow", "action": "edit", "id": 3, "ref": "compra", "set": {"requires_supplier": true, "color_hex": "#166534", "bg_hex": "#DCFCE7"}}',
            ']',
            '',
            '== CÓMO TRABAJAS ==',
            '- Tienes herramientas: úsalas con libertad y las veces que haga falta antes de contestar. ver_producto (existencia por almacén, presentaciones y últimos movimientos de un producto), resumen_catalogo (cómo está el catálogo: conteos, productos sin costo, sin unidad o sin área, valor del inventario), filtrar_productos (la lista exacta de los que cumplen algo: sin área, sin categoría, sin costo, de una sucursal, de una categoría...) y buscar_posibles_presentaciones (productos que parecen el empaque de otro).',
            '- Para CONTAR o LISTAR productos que cumplen algo usa filtrar_productos y da su total tal cual. Nunca los cuentes ni los escojas leyendo la tabla PRODUCTOS: es larga y te equivocas. La tabla es para ubicar ids y nombres.',
            '- Contesta cualquier pregunta sobre el catálogo y su inventario, da tu opinión y sugiere mejoras con lo que veas: duplicados, nombres parecidos, productos sin costo o sin unidad, presentaciones. Si algo no está claro, pregunta.',
            '- Los datos salen de las listas de abajo o de una herramienta. Nunca inventes ids, precios ni existencias.',
            '- Proponer: cuando la persona pide un cambio usa proponer_cambios (con el contrato de arriba) o proponer_presentaciones. Tú no aplicas nada: al terminar tu respuesta ella ve la vista previa, marca y confirma. Si lo que sugieres no lo pidió, pregúntale antes de proponerlo.',
            '- Cada llamada a proponer_cambios o a proponer_presentaciones reemplaza la propuesta anterior de esa misma herramienta: manda todo junto. La herramienta te dice qué entró y qué no, y por qué: corrige y vuelve a llamarla si hace falta.',
            '',
            '== PRESENTACIONES ==',
            '- Una presentación es el empaque de un producto que ya existe: una reja de 12 latas, un six pack, una caja de 24. No tiene stock propio: se cuenta en el producto base. Tiene su propia área y su propia foto; la categoría es la del base.',
            '- Para revisar el catálogo usa buscar_posibles_presentaciones y juzga cada caso: que de verdad sea el mismo producto en otro empaque y cuántas unidades del base trae.',
            '- Una caja para pastel, una caja de cupcake o una bolsa de empaque son productos que se usan (el empaque vacío), no presentaciones.',
            '- Pasar un producto a presentación (proponer_presentaciones) mueve inventario: su stock pasa al base multiplicado por el factor (5 rejas × 12 = +60 latas) con un ajuste registrado, y el producto se desactiva; su historial se queda. La presentación se queda con el área y la foto que tenía el producto. Si no sabes el factor, pregúntalo, no lo adivines. Avisa cuando el producto tenga stock.',
            '',
            '== CÓMO RESPONDES ==',
            '- Texto plano: sin #, sin tablas y sin emojis. Listas con guiones. Frases cortas.',
            '- Remarca con **negritas** los datos clave: cifras, nombres de productos, áreas, almacenes y sucursales, y lo que la persona tiene que hacer. Solo eso: si todo va en negritas, nada resalta.',
            '- Si propusiste algo, di cuántos cambios son y que revise la vista previa.',
            '',
            '== DATOS DE LA EMPRESA ==',
            $this->tablaIA('CATEGORÍAS', ['id', 'nombre', 'estado'], $filas['category'] ?? []),
            '',
            $this->tablaIA('UNIDADES', ['id', 'código', 'nombre', 'estado'], $filas['unit'] ?? []),
            '',
            $this->tablaIA('ÁREAS', ['id', 'nombre', 'almacén', 'descripción', 'estado'], $filas['area'] ?? []),
            '',
            $this->tablaIA('SUCURSALES', ['id', 'nombre'], $filas['branch'] ?? []),
            '',
            $this->tablaIA('ALMACENES', ['id', 'nombre', 'sucursal', 'por defecto', 'estado'], $filas['warehouse'] ?? []),
            '',
            $this->tablaIA('PROVEEDORES', ['id', 'nombre', 'contacto', 'teléfono', 'email', 'estado'], $filas['supplier'] ?? []),
            '',
            $this->tablaIA('ORÍGENES DE ENTRADA', ['id', 'nombre', 'descripción', 'pide proveedor', 'ícono', 'color texto', 'color fondo', 'estado'], $filas['inflow'] ?? []),
            '',
            $this->tablaIA('MOTIVOS DE SALIDA', ['id', 'nombre', 'ícono', 'color texto', 'color fondo', 'estado'], $filas['shrinkage'] ?? []),
            '',
            $this->tablaIA('ESTADOS DE TRASPASO', ['id', 'nombre', 'lo ve quien envía', 'lo ve quien recibe', 'color texto', 'color fondo', 'estado'], $filas['transfer_status'] ?? []),
            '',
            $this->tablaIA('PRODUCTOS' . $recorte, ['id', 'sku', 'nombre', 'categoría', 'unidad', 'área', 'precio con IVA', 'IVA %', 'último costo', 'mín', 'máx', 'vida útil días', 'sucursal', 'estado'], $filas['product'] ?? []),
            '',
            $this->tablaIA('PRESENTACIONES', ['id', 'producto base (id)', 'nombre', 'trae', 'estado'], array_map(function ($p) use ($estado) {
                return [$p['id'], $p['base_name'] . ' (' . $p['item_id'] . ')', $p['name'], $this->numeroIA($p['factor']) . ' ' . ($p['base_unit'] ?: 'unidades'), $estado($p)];
            }, $ctx['presentacion']))
        ]);
    }

    private function tablaIA($titulo, $columnas, $filas) {
        $lineas = array_map(function ($f) {
            return implode(' | ', array_map(function ($v) {
                $v = trim(str_replace(["\r", "\n", '|'], [' ', ' ', '/'], (string) $v));
                return $v === '' ? '-' : $v;
            }, $f));
        }, $filas);

        return $titulo . ' (' . implode(' | ', $columnas) . "):\n" . (empty($lineas) ? '(vacío)' : implode("\n", $lineas));
    }

    // -- Asistente IA · validación --

    // -- Asistente IA · herramientas --

    // Las herramientas que ve el modelo (formato tools de Ollama). Las de consulta solo
    // leen; proponer_cambios y proponer_presentaciones solo dejan en el hilo lo que irá a
    // la vista previa: nada se aplica hasta que la persona marca y confirma.
    private function herramientasIA($super) {
        $fn = function ($nombre, $descripcion, $propiedades = [], $requeridos = []) {
            return [
                'type'     => 'function',
                'function' => [
                    'name'        => $nombre,
                    'description' => $descripcion,
                    'parameters'  => ['type' => 'object', 'properties' => (object) $propiedades, 'required' => $requeridos]
                ]
            ];
        };

        return [
            $fn('ver_producto', 'Abre un producto: sus datos, existencia por almacén, sus presentaciones, cuántos movimientos tiene y los últimos 10 (entradas, salidas, ajustes y traspasos).', [
                'id' => ['type' => 'integer', 'description' => 'id del producto (de la lista PRODUCTOS)']
            ], ['id']),
            $fn('resumen_catalogo', 'Cuenta cómo está el catálogo: productos activos y de baja, sin costo, sin unidad, sin área o sin categoría, con existencia o en negativo, cuántos hay por categoría, valor del inventario a último costo y presentaciones.'),
            $fn('filtrar_productos', 'Lista EXACTA de los productos que cumplen todo lo que pidas (se combinan): sin área, sin categoría, sin costo o sin unidad; de una sucursal, una categoría o un área; o con un texto en el nombre. Devuelve cuántos son y cada uno con id, nombre, categoría, área y sucursal. Úsala siempre para contar o listar productos: no los cuentes en la tabla PRODUCTOS.', [
                'sin_area'      => ['type' => 'boolean', 'description' => 'Solo los que no tienen área'],
                'sin_categoria' => ['type' => 'boolean', 'description' => 'Solo los que no tienen categoría'],
                'sin_costo'     => ['type' => 'boolean', 'description' => 'Solo los de último costo en 0'],
                'sin_unidad'    => ['type' => 'boolean', 'description' => 'Solo los que no tienen unidad'],
                'sucursal'      => ['type' => 'string', 'description' => 'Nombre de la sucursal dueña tal como está en SUCURSALES'],
                'categoria'     => ['type' => 'string', 'description' => 'Nombre de la categoría'],
                'area'          => ['type' => 'string', 'description' => 'Nombre del área'],
                'texto'         => ['type' => 'string', 'description' => 'Parte del nombre o SKU'],
                'incluir_baja'  => ['type' => 'boolean', 'description' => 'También los dados de baja (por omisión solo activos)']
            ]),
            $fn('buscar_posibles_presentaciones', 'Revisa los productos activos y devuelve los que parecen el empaque de otro (reja, caja, six pack, paquete, "x12", "6 pzs"...), con hasta 3 productos base parecidos, el factor que se lee en el nombre y su stock. Son pistas: tú decides cuáles sí lo son.'),
            $fn('proponer_cambios', 'Deja en la vista previa altas, cambios, bajas o reactivaciones' . ($super ? ' (o un vaciado)' : '') . ' del catálogo, con el contrato del system. No aplica nada. Llamarla otra vez reemplaza su propuesta anterior: manda todos los cambios juntos. Devuelve cuáles entraron y por qué no los demás.', [
                'changes' => ['type' => 'array', 'items' => ['type' => 'object'], 'description' => 'Lista de cambios: {entity, action, id, ref, set}']
            ], ['changes']),
            $fn('proponer_presentaciones', 'Deja en la vista previa productos que pasan a ser presentación de otro: su stock pasa al base multiplicado por el factor y el producto se desactiva. No aplica nada. Llamarla otra vez reemplaza su propuesta anterior. Devuelve cuáles entraron y por qué no los demás.', [
                'items' => [
                    'type'  => 'array',
                    'items' => [
                        'type'       => 'object',
                        'properties' => [
                            'product_id' => ['type' => 'integer', 'description' => 'id del producto que pasa a ser presentación'],
                            'base_id'    => ['type' => 'integer', 'description' => 'id del producto base'],
                            'factor'     => ['type' => 'number', 'description' => 'Cuántas unidades del base trae (2 o más)']
                        ],
                        'required'   => ['product_id', 'base_id', 'factor']
                    ]
                ]
            ], ['items'])
        ];
    }

    // Ejecuta lo que pidió el modelo, siempre dentro de la empresa de la sesión. Devuelve
    // el resultado que vuelve al modelo y el paso que ve la persona mientras espera.
    private function usarHerramientaIA($nombre, $args, $ctx, $super, &$hilo) {
        switch ($nombre) {
            case 'ver_producto':
                $producto = $this->verProductoIA((int) ($args['id'] ?? 0), $ctx);

                return [
                    'resultado' => $producto ?? ['error' => 'No encontré ese producto.'],
                    'paso'      => $producto ? 'Revisando «' . $producto['nombre'] . '»' : 'Buscando un producto'
                ];

            case 'resumen_catalogo':
                return [
                    'resultado' => $this->resumenCatalogoIA($ctx),
                    'paso'      => 'Contando el catálogo'
                ];

            case 'filtrar_productos':
                $lista = $this->filtrarProductosIA(is_array($args) ? $args : [], $ctx);

                return [
                    'resultado' => $lista,
                    'paso'      => 'Filtrando productos · ' . ($lista['total'] === 1 ? '1 encontrado' : "{$lista['total']} encontrados")
                ];

            case 'buscar_posibles_presentaciones':
                $candidatos = $this->posiblesPresentacionesIA($ctx);
                $n          = count($candidatos);

                return [
                    'resultado' => ['total' => $n, 'candidatos' => $candidatos],
                    'paso'      => 'Buscando posibles presentaciones · ' . ($n === 1 ? '1 encontrada' : "{$n} encontradas")
                ];

            case 'proponer_cambios':
                $hilo['cambios'] = isset($args['changes']) && is_array($args['changes']) ? $args['changes'] : [];
                $vista           = $this->vaciadoIA($hilo['cambios'], $super) ?? $this->validarCambiosIA($hilo['cambios'], $ctx);
                $n               = count($vista['validos']);

                return [
                    'resultado' => $this->devolucionVistaIA($vista),
                    'paso'      => 'Armando la vista previa · ' . ($n === 1 ? '1 cambio' : "{$n} cambios")
                ];

            case 'proponer_presentaciones':
                $hilo['presentaciones'] = isset($args['items']) && is_array($args['items']) ? array_slice($args['items'], 0, self::IA_MAX_PRESENTACIONES) : [];
                $vista                  = $this->validarPresentacionesIA($hilo['presentaciones'], $ctx);
                $n                      = count($vista['validos']);

                return [
                    'resultado' => $this->devolucionVistaIA($vista),
                    'paso'      => 'Armando la vista previa · ' . ($n === 1 ? '1 presentación' : "{$n} presentaciones")
                ];
        }

        return [
            'resultado' => ['error' => 'No conozco la herramienta «' . $nombre . '».'],
            'paso'      => 'Pensando'
        ];
    }

    // Lo que vuelve al modelo de una propuesta: qué entró y qué no, con el motivo.
    private function devolucionVistaIA($vista) {
        return [
            'entran' => count($vista['validos']),
            'filas'  => array_map(function ($r) {
                $fila = [
                    'nombre' => $r['name'],
                    'accion' => $r['action'] ?? '',
                    'entra'  => !empty($r['valid'])
                ];

                if (($r['note'] ?? '') !== '') $fila['motivo'] = $r['note'];
                if (($r['warn'] ?? '') !== '') $fila['aviso']  = $r['warn'];

                return $fila;
            }, $vista['row'])
        ];
    }

    // La vista previa final: lo último de proponer_cambios y, detrás, lo último de
    // proponer_presentaciones, validado otra vez con los datos de este momento. Un
    // vaciado va solo.
    private function vistaPropuestaIA($hilo, $ctx, $super) {
        $vaciado = $this->vaciadoIA($hilo['cambios'], $super);

        if ($vaciado !== null) return $vaciado;

        $vista = $this->validarCambiosIA($hilo['cambios'], $ctx);
        $pres  = $this->validarPresentacionesIA($hilo['presentaciones'], $ctx);

        foreach ($pres['row'] as $j => $fila) {
            $i = count($vista['row']);

            $fila['idx']     = $i;
            $vista['row'][]  = $fila;

            if (isset($pres['validos'][$j])) $vista['validos'][$i] = $pres['validos'][$j];
        }

        $vista['resumen']['present']  = count($pres['validos']);
        $vista['resumen']['invalid'] += $pres['resumen']['invalid'];

        return $vista;
    }

    // Cada producto propuesto como presentación de otro, revisado contra el catálogo:
    // activo, con base activa y distinta, sin presentaciones propias y factor de 2 o más.
    private function validarPresentacionesIA($items, $ctx) {
        $productos = [];
        $conPres   = [];
        $row       = [];
        $validos   = [];
        $vistos    = [];
        $invalidos = 0;

        foreach ($ctx['product'] as $p) $productos[(int) $p['id']] = $p;
        foreach ($ctx['presentacion'] as $x) $conPres[(int) $x['item_id']] = true;

        foreach ($items as $it) {
            $it     = is_array($it) ? $it : [];
            $id     = (int) ($it['product_id'] ?? 0);
            $baseId = (int) ($it['base_id'] ?? 0);
            $factor = (float) ($it['factor'] ?? 0);
            $p      = $productos[$id] ?? null;
            $b      = $productos[$baseId] ?? null;
            $motivo = '';

            if (!$p)                                $motivo = 'No encontré ese producto.';
            elseif ((int) $p['active'] !== 1)       $motivo = 'Está dado de baja.';
            elseif (!$b)                            $motivo = 'No encontré el producto base.';
            elseif ($id === $baseId)                $motivo = 'No puede ser presentación de sí mismo.';
            elseif ((int) $b['active'] !== 1)       $motivo = 'El producto base está dado de baja.';
            elseif (isset($conPres[$id]))           $motivo = 'Tiene presentaciones propias: no puede ser presentación de otro.';
            elseif ($factor == 1)                   $motivo = 'Con 1 sería el mismo producto.';
            elseif ($factor < 2)                    $motivo = 'Falta cuántas unidades del base trae (2 o más).';
            elseif (isset($vistos[$id]))            $motivo = 'Ya viene en esta propuesta.';

            $fila = ['name' => $p ? $p['name'] : 'Producto ' . $id, 'sku' => $p['sku'] ?? ''];

            if ($motivo !== '') {
                $f = $this->filaIA($fila + ['note' => $motivo]);
            } else {
                $stock  = (float) $p['quantity'];
                $unidad = $this->pluralIA($b['unidad_nombre'] ?? '');
                $f      = $this->filaIA($fila + [
                    'changes' => [
                        ['label' => 'Presentación de', 'before' => '', 'after' => $b['name']],
                        ['label' => 'Trae',            'before' => '', 'after' => $this->numeroIA($factor) . ' ' . $unidad]
                    ],
                    'warn'    => $stock != 0
                        ? 'Su stock (' . $this->numeroIA($stock) . ') pasa al base como ' . $this->numeroIA($stock * $factor) . ' ' . $unidad . ' y se desactiva.'
                        : 'No tiene stock. Se desactiva.'
                ], ['id' => $id, 'base_id' => $baseId, 'factor' => $factor]);

                $vistos[$id] = true;
            }

            $i = count($row);

            $f['row']['idx']    = $i;
            $f['row']['action'] = 'present';
            $f['row']['tag']    = self::IA_ENTIDADES['product']['tag'];
            $f['row']['valid']  = $f['cambio'] !== null;

            if ($f['cambio'] !== null) $validos[$i] = $f['cambio'] + ['entity' => 'product', 'action' => 'present', 'nombre' => $fila['name']];
            else                       $invalidos++;

            $row[] = $f['row'];
        }

        return [
            'row'     => $row,
            'validos' => $validos,
            'resumen' => ['present' => count($validos), 'invalid' => $invalidos]
        ];
    }

    private function verProductoIA($id, $ctx) {
        $p = null;

        foreach ($ctx['product'] as $r) {
            if ((int) $r['id'] === $id) {
                $p = $r;
                break;
            }
        }

        if (!$p) return null;

        $presentaciones = array_values(array_filter($ctx['presentacion'], function ($x) use ($id) {
            return (int) $x['item_id'] === $id;
        }));

        return [
            'id'                  => $id,
            'nombre'              => $p['name'],
            'sku'                 => $p['sku'],
            'categoria'           => $p['categoria'],
            'unidad'              => $p['unidad_nombre'] ?: $p['unidad'],
            'area'                => $p['area'],
            'precio_venta'        => (float) $p['price'],
            'ultimo_costo'        => (float) $p['cost_unit'],
            'minimo'              => (float) $p['stock_min'],
            'maximo'              => (float) $p['stock_max'],
            'vida_util_dias'      => $p['shelf_life_days'],
            'descripcion'         => $p['description'],
            'estado'              => (int) $p['active'] === 1 ? 'activo' : 'baja',
            'existencia_total'    => (float) $p['quantity'],
            'por_almacen'         => array_map(function ($s) use ($ctx) {
                return ['almacen' => $this->nombreAlmacenIA($s['warehouse_id'], $ctx), 'cantidad' => (float) $s['quantity']];
            }, $this->listStockByItem([$id])),
            'movimientos'         => (int) $this->getMaterialCounts([$id])['movimientos'],
            'ultimos_movimientos' => array_map(function ($m) {
                return ['fecha' => $m['occurred_at'], 'tipo' => $m['movement_type'], 'folio' => $m['folio'], 'cantidad' => (float) $m['quantity'], 'quedo' => (float) $m['stock_post']];
            }, $this->listMovimientosItem([$id, $_SESSION['company_id']])),
            'presentaciones'      => array_map(function ($x) {
                return ['nombre' => $x['name'], 'trae' => (float) $x['factor'], 'costo' => (float) $x['cost_unit'], 'activa' => (int) $x['active'] === 1];
            }, $presentaciones)
        ];
    }

    // filtrar_productos: el modelo contaba a ojo la tabla PRODUCTOS del prompt (cientos de
    // renglones) y se equivocaba: con «sin área» metía productos cuya área se llama igual
    // que su categoría. Aquí se filtra con los mismos datos y el conteo es exacto. Los
    // nombres de sucursal, categoría y área valen completos o como parte del nombre.
    private function filtrarProductosIA($args, $ctx) {
        $si    = function ($clave) use ($args) { return filter_var($args[$clave] ?? false, FILTER_VALIDATE_BOOLEAN); };
        $texto = function ($clave) use ($args) { return $this->normalizarIA($this->textoIA($args[$clave] ?? '')); };
        $tiene = function ($valor, $buscado) {
            $valor = $this->normalizarIA((string) $valor);
            return $buscado === '' || ($valor !== '' && strpos($valor, $buscado) !== false);
        };

        $sucursal  = $texto('sucursal');
        $categoria = $texto('categoria');
        $area      = $texto('area');
        $nombre    = $texto('texto');

        $filas = array_values(array_filter($ctx['product'], function ($p) use ($si, $tiene, $sucursal, $categoria, $area, $nombre) {
            if (!$si('incluir_baja') && (int) $p['active'] !== 1) return false;
            if ($si('sin_area')      && !empty($p['area_id']))                 return false;
            if ($si('sin_categoria') && !empty($p['categoria']))               return false;
            if ($si('sin_costo')     && (float) $p['cost_unit'] > 0)           return false;
            if ($si('sin_unidad')    && !empty($p['unidad_nombre']))           return false;

            return $tiene($p['sucursal'] ?? '', $sucursal)
                && $tiene($p['categoria'] ?? '', $categoria)
                && $tiene($p['area'] ?? '', $area)
                && ($nombre === '' || $tiene($p['name'], $nombre) || $tiene($p['sku'] ?? '', $nombre));
        }));

        return [
            'total'     => count($filas),
            'recortado' => count($filas) > self::IA_MAX_FILTRO,
            'productos' => array_map(function ($p) {
                return [
                    'id'        => (int) $p['id'],
                    'nombre'    => $p['name'],
                    'categoria' => $p['categoria'] ?: 'sin categoría',
                    'area'      => $p['area'] ?: 'sin área',
                    'sucursal'  => $p['sucursal'] ?: '-',
                    'estado'    => (int) $p['active'] === 1 ? 'activo' : 'baja'
                ];
            }, array_slice($filas, 0, self::IA_MAX_FILTRO))
        ];
    }

    private function resumenCatalogoIA($ctx) {
        $activos = array_values(array_filter($ctx['product'], function ($p) {
            return (int) $p['active'] === 1;
        }));
        $cuenta  = function ($filtro) use ($activos) {
            return count(array_filter($activos, $filtro));
        };
        $porCategoria = [];
        $valor        = 0;

        foreach ($activos as $p) {
            $categoria                = $p['categoria'] ?: 'Sin categoría';
            $porCategoria[$categoria] = ($porCategoria[$categoria] ?? 0) + 1;
            $valor                   += max(0, (float) $p['quantity']) * (float) $p['cost_unit'];
        }

        arsort($porCategoria);

        $activosDe = function ($entidad) use ($ctx) {
            return count(array_filter($ctx[$entidad], function ($r) {
                return (int) $r['active'] === 1;
            }));
        };

        return [
            'productos'             => count($ctx['product']),
            'activos'               => count($activos),
            'de_baja'               => count($ctx['product']) - count($activos),
            'sin_costo'             => $cuenta(function ($p) { return (float) $p['cost_unit'] <= 0; }),
            'sin_unidad'            => $cuenta(function ($p) { return empty($p['unidad_nombre']); }),
            'sin_area'              => $cuenta(function ($p) { return empty($p['area_id']); }),
            'sin_categoria'         => $cuenta(function ($p) { return empty($p['categoria']); }),
            'con_existencia'        => $cuenta(function ($p) { return (float) $p['quantity'] > 0; }),
            'en_negativo'           => $cuenta(function ($p) { return (float) $p['quantity'] < 0; }),
            'valor_inventario'      => $this->pesosIA($valor),
            'por_categoria'         => array_slice($porCategoria, 0, 20, true),
            'presentaciones'        => count($ctx['presentacion']),
            'categorias_activas'    => $activosDe('category'),
            'unidades_activas'      => $activosDe('unit'),
            'areas_activas'         => $activosDe('area'),
            'almacenes_activos'     => $activosDe('warehouse'),
            'proveedores_activos'   => $activosDe('supplier')
        ];
    }

    // Productos activos que suenan a empaque de otro: por una palabra del nombre (reja,
    // caja, six pack...), por su unidad o por un número de piezas en el nombre. Para
    // cada uno, hasta 3 productos parecidos que podrían ser su base. Son pistas para el
    // modelo, no una decisión: «caja para pastel» sale aquí y no es presentación.
    private function posiblesPresentacionesIA($ctx) {
        $empaque = ['reja', 'rejas', 'caja', 'cajas', 'cja', 'six', 'sixpack', 'pack', 'paquete', 'paquetes', 'paq', 'pqt', 'bulto', 'bultos',
                    'costal', 'costales', 'charola', 'charolas', 'docena', 'docenas', 'carton', 'display', 'fardo', 'tira', 'tarima'];
        $conPres = [];
        $info    = [];

        foreach ($ctx['presentacion'] as $x) $conPres[(int) $x['item_id']] = true;

        foreach ($ctx['product'] as $p) {
            if ((int) $p['active'] !== 1) continue;

            $clave  = $this->normalizarIA($p['name']);
            $tokens = explode(' ', $clave);

            $info[(int) $p['id']] = [
                'p'       => $p,
                'clave'   => $clave,
                'empaque' => array_values(array_intersect($tokens, $empaque)),
                'nucleo'  => array_values(array_diff($this->nameWords($clave), $empaque))
            ];
        }

        $candidatos = [];

        foreach ($info as $id => $x) {
            if (isset($conPres[$id])) continue;

            $p      = $x['p'];
            $unidad = $this->normalizarIA($p['unidad_nombre'] ?? '');
            $factor = $this->factorEnNombreIA($x['clave']);
            $pistas = [];

            if ($x['empaque'])                     $pistas[] = 'el nombre dice «' . $x['empaque'][0] . '»';
            if (in_array($unidad, $empaque, true)) $pistas[] = 'su unidad es ' . $p['unidad_nombre'];
            if ($factor)                           $pistas[] = 'el nombre trae ' . $factor;

            if (!$pistas || !$x['nucleo']) continue;

            $bases = [];

            foreach ($info as $baseId => $y) {
                if ($baseId === $id || $y['empaque'] || !$y['nucleo']) continue;

                $comunes = count(array_filter($x['nucleo'], function ($w) use ($y) {
                    return $this->hasWord($y['nucleo'], $w);
                }));

                if ($comunes === 0 || ($comunes < count($x['nucleo']) && $comunes < 2)) continue;

                $bases[] = [
                    'id'     => $baseId,
                    'nombre' => $y['p']['name'],
                    'unidad' => $y['p']['unidad_nombre'] ?: '-',
                    'stock'  => (float) $y['p']['quantity'],
                    'score'  => $comunes / (count($x['nucleo']) + count($y['nucleo']) - $comunes)
                ];
            }

            usort($bases, function ($a, $b) {
                return $b['score'] <=> $a['score'];
            });

            $candidatos[] = [
                'producto'          => ['id' => $id, 'nombre' => $p['name'], 'unidad' => $p['unidad_nombre'] ?: '-', 'stock' => (float) $p['quantity']],
                'bases_parecidas'   => array_map(function ($b) {
                    unset($b['score']);
                    return $b;
                }, array_slice($bases, 0, 3)),
                'factor_en_nombre'  => $factor,
                'pistas'            => $pistas
            ];
        }

        // Primero los que tienen con quién emparejarse.
        usort($candidatos, function ($a, $b) {
            return (count($b['bases_parecidas']) > 0) <=> (count($a['bases_parecidas']) > 0);
        });

        return array_slice($candidatos, 0, self::IA_MAX_PRESENTACIONES);
    }

    // «Pieza» → «piezas», «Paquete» → «paquetes»; abreviaturas («kg») y lo que ya
    // termina en s se quedan igual (como pluralUnidad de almacen.js).
    private function pluralIA($unidad) {
        $u = mb_strtolower(trim((string) $unidad), 'UTF-8');

        if ($u === '') return 'unidades';
        if (mb_strlen($u) <= 3 || mb_substr($u, -1) === 's') return $u;

        return preg_match('/[aeiouáéíóú]$/u', $u) ? $u . 's' : $u . 'es';
    }

    // El número de piezas que trae según su nombre: «x12», «c/12», «6 pzs», «reja de 24»,
    // «12 pack», «docena», «six pack». Null si no se lee ninguno de 2 o más.
    private function factorEnNombreIA($clave) {
        $patrones = [
            '/\b(?:x|c)\s?(\d{1,3})\b/',
            '/\b(\d{1,3})\s?(?:pz|pzs|pza|pzas|piezas|pk|pack|unidades|uds|latas|botellas|sobres|bolsas)\b/',
            '/\b(?:reja|caja|paquete|pack|bulto|charola|display|costal)\s(?:de\s|con\s)?(\d{1,3})\b/'
        ];

        foreach ($patrones as $patron) {
            if (preg_match($patron, $clave, $m) && (int) $m[1] >= 2) return (int) $m[1];
        }

        if (preg_match('/\bdocenas?\b/', $clave)) return 12;
        if (preg_match('/\bsix\s?pack\b|\bsixpack\b/', $clave)) return 6;

        return null;
    }

    /*  Convierte lo que propuso el modelo en filas de vista previa. Las que no se
        pueden aplicar (no existe, no cambia nada, ya está dado de baja) se enseñan
        con su motivo pero no entran en 'validos'. El nombre que se enseña es el del
        catálogo, no el que escribió el modelo: así se ve qué registro se toca de verdad.

        Dos vueltas: primero los catálogos y después los productos, para que un
        producto pueda usar la categoría (o unidad, o área) que se da de alta en la
        misma respuesta. Ese orden es también el de aplicación. */
    private function validarCambiosIA($cambios, $ctx) {
        $idx     = $this->indicesIA($ctx);
        // Las sucursales no son entidad del catálogo: van aparte para el campo branch del producto.
        $idx['branch'] = $ctx['branch'];
        $nuevos  = [];
        $vistos  = [];
        $row     = [];
        $validos = [];
        $resumen = ['add' => 0, 'edit' => 0, 'deactivate' => 0, 'activate' => 0, 'invalid' => 0];
        $lista   = [];

        foreach (array_slice($cambios, 0, self::IA_MAX_CAMBIOS) as $c) {
            $n = $this->normalizarCambioIA($c);

            if ($n === null) continue;

            // Dos "edit" del mismo registro (precio en uno, categoría en otro) se juntan.
            $clave = $n['action'] === 'edit' && $n['id'] > 0 ? 'edit|' . $n['entity'] . '|' . $n['id'] : count($lista);

            if (isset($lista[$clave])) {
                $lista[$clave]['set'] = array_merge($lista[$clave]['set'], $n['set']);
                continue;
            }

            $lista[$clave] = $n;
        }

        foreach ([false, true] as $productos) {
            foreach ($lista as $c) {
                if (($c['entity'] === 'product') !== $productos) continue;

                $fila = $productos
                      ? $this->validarProductoIA($c, $idx, $nuevos, $vistos)
                      : $this->validarCatalogoIA($c, $ctx, $idx, $nuevos, $vistos);

                if ($fila === null) continue;

                $i = count($row);

                $fila['row']['idx']    = $i;
                $fila['row']['action'] = $c['action'];
                $fila['row']['tag']    = self::IA_ENTIDADES[$c['entity']]['tag'];
                $fila['row']['valid']  = $fila['cambio'] !== null;

                if ($fila['cambio'] !== null) {
                    $validos[$i] = $fila['cambio'] + ['entity' => $c['entity'], 'action' => $c['action'], 'nombre' => $fila['row']['name']];
                    $resumen[$c['action']]++;
                } else {
                    $resumen['invalid']++;
                }

                $row[] = $fila['row'];
            }
        }

        return [
            'row'     => $row,
            'validos' => $validos,
            'resumen' => $resumen
        ];
    }

    // Acepta sinónimos en español y el formato viejo (campos sueltos, "item_id",
    // action "price") para que un modelo que se sale un poco del contrato no se pierda.
    private function normalizarCambioIA($c) {
        if (!is_array($c)) return null;

        // normalizarIA() vuelve espacio el guion bajo: "transfer_status" llega como "transfer status".
        $entidades = ['producto' => 'product', 'productos' => 'product', 'item' => 'product', 'insumo' => 'product',
                      'categoria' => 'category', 'unidad' => 'unit', 'almacen' => 'warehouse', 'proveedor' => 'supplier',
                      'origen' => 'inflow', 'origen entrada' => 'inflow', 'origen de entrada' => 'inflow', 'inflow origin' => 'inflow',
                      'motivo' => 'shrinkage', 'motivo salida' => 'shrinkage', 'motivo de salida' => 'shrinkage', 'shrinkage reason' => 'shrinkage',
                      'transfer status' => 'transfer_status', 'estado traspaso' => 'transfer_status', 'estado de traspaso' => 'transfer_status'];
        $acciones  = ['alta' => 'add', 'agregar' => 'add', 'nuevo' => 'add', 'crear' => 'add', 'create' => 'add',
                      'editar' => 'edit', 'cambiar' => 'edit', 'modificar' => 'edit', 'update' => 'edit', 'price' => 'edit', 'precio' => 'edit',
                      'baja' => 'deactivate', 'desactivar' => 'deactivate', 'eliminar' => 'deactivate', 'borrar' => 'deactivate', 'delete' => 'deactivate',
                      'reactivar' => 'activate', 'activar' => 'activate'];

        $entidad = $this->normalizarIA($this->textoIA($c['entity'] ?? ''));
        $entidad = $entidades[$entidad] ?? ($entidad === '' ? 'product' : $entidad);
        $accion  = $this->normalizarIA($this->textoIA($c['action'] ?? ''));
        $accion  = $acciones[$accion] ?? $accion;

        if (!isset(self::IA_ENTIDADES[$entidad]) || !in_array($accion, ['add', 'edit', 'deactivate', 'activate'], true)) return null;

        $set = isset($c['set']) && is_array($c['set']) ? $c['set'] : [];

        foreach (array_keys(self::IA_ENTIDADES[$entidad]['campos']) as $campo) {
            if (!array_key_exists($campo, $set) && array_key_exists($campo, $c) && $campo !== 'name') $set[$campo] = $c[$campo];
        }

        // En el formato viejo el nombre suelto de un alta es el nombre nuevo; en lo
        // demás es solo la referencia de a quién se toca.
        if ($accion === 'add' && !array_key_exists('name', $set) && isset($c['name'])) $set['name'] = $c['name'];

        $id = 0;

        if (isset($c['id']) && is_numeric($c['id']))           $id = (int) $c['id'];
        elseif (isset($c['item_id']) && is_numeric($c['item_id'])) $id = (int) $c['item_id'];

        return [
            'entity' => $entidad,
            'action' => $accion,
            'id'     => $id,
            'ref'    => $this->textoIA($c['ref'] ?? ($c['name'] ?? '')),
            'sku'    => $this->textoIA($c['sku'] ?? ''),
            'set'    => $set
        ];
    }

    // Por entidad: filas por id, id por nombre normalizado y, en unidades y
    // productos, id por código o SKU. Con dos nombres iguales gana el activo.
    private function indicesIA($ctx) {
        $idx = [];

        foreach (array_keys(self::IA_ENTIDADES) as $entidad) {
            $idx[$entidad] = ['id' => [], 'nombre' => [], 'codigo' => []];

            foreach ($ctx[$entidad] as $r) {
                $id    = (int) $r['id'];
                $clave = $this->normalizarIA($r['name']);

                $idx[$entidad]['id'][$id] = $r;

                $previo = $idx[$entidad]['nombre'][$clave] ?? null;

                if ($previo === null || ((int) $r['active'] === 1 && (int) $idx[$entidad]['id'][$previo]['active'] !== 1)) {
                    $idx[$entidad]['nombre'][$clave] = $id;
                }

                $codigo = $entidad === 'unit' ? $r['code'] : ($entidad === 'product' ? $r['sku'] : '');
                $codigo = $this->normalizarIA($codigo);

                if ($codigo !== '' && !isset($idx[$entidad]['codigo'][$codigo])) $idx[$entidad]['codigo'][$codigo] = $id;
            }
        }

        return $idx;
    }

    private function buscarIA($entidad, $c, $idx) {
        $i = $idx[$entidad];

        if ($c['id'] > 0 && isset($i['id'][$c['id']])) return $i['id'][$c['id']];

        foreach ([$c['sku'], $c['ref']] as $texto) {
            $clave = $this->normalizarIA($texto);

            if ($clave === '') continue;
            if (isset($i['nombre'][$clave])) return $i['id'][$i['nombre'][$clave]];
            if (isset($i['codigo'][$clave])) return $i['id'][$i['codigo'][$clave]];
        }

        return null;
    }

    private function validarCatalogoIA($c, $ctx, $idx, &$nuevos, &$vistos) {
        $entidad = $c['entity'];
        $def     = self::IA_ENTIDADES[$entidad];

        if ($c['action'] === 'add') {
            if (($def['alta'] ?? true) === false) {
                $pedido = $this->textoIA($c['set']['name'] ?? '') ?: $c['ref'];

                return $this->filaIA(['name' => $pedido ?: ucfirst($def['uno']), 'note' => 'Son fijos del sistema: solo se cambian, no se dan de alta.']);
            }

            $campos = $this->camposCatalogoIA($entidad, $c['set'], null, $ctx);
            $nombre = $campos['values']['name'] ?? '';
            $clave  = $this->normalizarIA($nombre);

            if ($nombre === '') return $this->filaIA(['name' => $c['ref'] ?: ucfirst($def['uno']) . ' sin nombre', 'note' => 'Falta el nombre.']);

            if (isset($vistos['add' . $entidad . $clave])) return null;

            $vistos['add' . $entidad . $clave] = true;

            if (isset($idx[$entidad]['nombre'][$clave])) {
                $existe = $idx[$entidad]['id'][$idx[$entidad]['nombre'][$clave]];

                return $this->filaIA(['name' => $nombre, 'note' => (int) $existe['active'] === 1 ? 'Ya existe.' : 'Existe dado de baja: pídeme reactivarlo.']);
            }

            if ($entidad === 'unit' && !isset($campos['values']['code'])) {
                $campos['values']['code'] = mb_strtoupper(mb_substr($nombre, 0, 20));
                $campos['changes'][]      = ['label' => 'Código', 'before' => '', 'after' => $campos['values']['code']];
                $campos['warn'][]         = 'Código tomado del nombre.';
            }

            if ($entidad === 'warehouse' && !isset($campos['values']['branch_id'])) {
                $campos['values']['branch_id'] = (int) ($_SESSION['branch_id'] ?? 0);
                $campos['changes'][]           = ['label' => 'Sucursal', 'before' => '', 'after' => $this->nombreSucursalIA($campos['values']['branch_id'], $ctx) . ' (la tuya)'];
            }

            // El área vive dentro de un almacén: sin uno pedido, el de por defecto de la sucursal.
            if ($entidad === 'area' && !isset($campos['values']['warehouse_id'])) {
                $porDefecto = $this->getDefaultWarehouseId([$_SESSION['company_id'], $_SESSION['branch_id'] ?? 0]);

                if ($porDefecto !== null) {
                    $campos['values']['warehouse_id'] = (int) $porDefecto;
                    $campos['changes'][]              = ['label' => 'Almacén', 'before' => '', 'after' => $this->nombreAlmacenIA($porDefecto, $ctx) . ' (por defecto)'];
                }
            }

            if (isset(self::IA_ICONO[$entidad]) && !isset($campos['values']['icon'])) {
                $campos['values']['icon'] = self::IA_ICONO[$entidad];
                $campos['changes'][]      = ['label' => 'Ícono', 'before' => '', 'after' => self::IA_ICONO[$entidad], 'icon' => true];
                $campos['warn'][]         = 'Ícono de la pestaña.';
            }

            $nuevos[$entidad][$clave] = $nombre;

            return $this->filaIA([
                'name'    => $nombre,
                'changes' => $this->sinNombreIA($campos['changes']),
                'warn'    => implode(' ', $campos['warn'])
            ], ['values' => $campos['values']]);
        }

        $actual = $this->buscarIA($entidad, $c, $idx);

        if ($actual === null) return $this->filaIA(['name' => $c['ref'] ?: ucfirst($def['uno']) . ' sin identificar', 'note' => 'No lo encontré.']);

        $id    = (int) $actual['id'];
        $aviso = $this->avisoIdentidadIA($c['ref'], $actual['name']);

        if ($c['action'] === 'edit') {
            if (isset($vistos['edit' . $entidad . $id])) return null;

            $vistos['edit' . $entidad . $id] = true;

            $campos = $this->camposCatalogoIA($entidad, $c['set'], $actual, $ctx);
            $fila   = ['name' => $actual['name'], 'changes' => $campos['changes'], 'warn' => trim($aviso . ' ' . implode(' ', $campos['warn']))];

            if (isset($campos['values']['name'])) {
                $otro = $idx[$entidad]['nombre'][$this->normalizarIA($campos['values']['name'])] ?? null;

                if ($otro !== null && $otro !== $id) return $this->filaIA($fila + ['note' => 'Ya existe otro registro con ese nombre.']);
            }

            if (empty($campos['values'])) return $this->filaIA($fila + ['note' => 'No cambia nada.']);

            return $this->filaIA($fila, ['id' => $id, 'values' => $campos['values']]);
        }

        return $this->validarEstadoIA($entidad, $c['action'], $actual, $aviso, $idx, $vistos);
    }

    // Baja o reactivación, igual para productos y catálogos.
    private function validarEstadoIA($entidad, $accion, $actual, $aviso, $idx, &$vistos) {
        $id      = (int) $actual['id'];
        $destino = $accion === 'activate' ? 1 : 0;

        if (isset($vistos['estado' . $entidad . $id])) return null;

        $vistos['estado' . $entidad . $id] = true;

        $fila = [
            'name'   => $actual['name'],
            'sku'    => $entidad === 'product' ? ($actual['sku'] ?? '') : '',
            'before' => (int) $actual['active'] === 1 ? 'Activo' : 'Baja',
            'after'  => $destino === 1 ? 'Activo' : 'Baja'
        ];

        if ((int) $actual['active'] === $destino) {
            return $this->filaIA(['name' => $fila['name'], 'sku' => $fila['sku'], 'note' => $destino === 1 ? 'Ya está activo.' : 'Ya está dado de baja.']);
        }

        $avisos = [$aviso];

        if ($destino === 0) $avisos[] = $this->avisoBajaIA($entidad, $actual, $idx);

        return $this->filaIA($fila + ['warn' => trim(implode(' ', array_filter($avisos)))], ['id' => $id]);
    }

    // Lo que se queda colgando al dar de baja: existencias o productos que la usan.
    private function avisoBajaIA($entidad, $actual, $idx) {
        if ($entidad === 'product') {
            $stock = (float) $actual['quantity'];

            return $stock > 0 ? 'Aún tiene ' . $this->numeroIA($stock) . ' en existencia.' : '';
        }

        if ($entidad === 'warehouse') return (int) $actual['is_default'] === 1 ? 'Es el almacén por defecto de su sucursal.' : '';

        if (isset(self::IA_BAJA[$entidad])) return self::IA_BAJA[$entidad];

        $columna = ['category' => 'categoria', 'unit' => 'unidad', 'area' => 'area'][$entidad] ?? null;

        if ($columna === null) return '';

        $buscado = $this->normalizarIA($entidad === 'unit' ? $actual['code'] : $actual['name']);
        $usos    = 0;

        foreach ($idx['product']['id'] as $p) {
            if ((int) $p['active'] === 1 && $this->normalizarIA($p[$columna]) === $buscado) $usos++;
        }

        return $usos > 0 ? $usos . ($usos === 1 ? ' producto activo la usa.' : ' productos activos la usan.') : '';
    }

    // Campos de un catálogo: solo los que cambian. Devuelve values (columna => valor),
    // changes (para la vista previa) y warn (lo que se ignoró y por qué).
    private function camposCatalogoIA($entidad, $set, $actual, $ctx) {
        $etiquetas = self::IA_ENTIDADES[$entidad]['campos'];
        $out       = ['values' => [], 'changes' => [], 'warn' => []];

        foreach ($set as $campo => $valor) {
            if (!isset($etiquetas[$campo])) continue;

            $etiqueta = $etiquetas[$campo];

            if ($campo === 'branch') {
                $sucursal = $this->buscarSucursalIA($valor, $ctx);

                if ($sucursal === null) {
                    $out['warn'][] = 'La sucursal «' . $this->textoIA($valor) . '» no existe: no se cambia.';
                    continue;
                }

                if ($actual !== null && (int) $actual['branch_id'] === (int) $sucursal['id']) continue;

                $out['values']['branch_id'] = (int) $sucursal['id'];
                $out['changes'][]           = ['label' => $etiqueta, 'before' => $actual ? $this->nombreSucursalIA($actual['branch_id'], $ctx) : '', 'after' => $sucursal['valor']];
                continue;
            }

            if ($campo === 'warehouse') {
                $almacenes = $this->buscarAlmacenIA($valor, $ctx);

                if (count($almacenes) !== 1) {
                    $out['warn'][] = 'El almacén «' . $this->textoIA($valor) . '» ' . (empty($almacenes) ? 'no existe' : 'está repetido') . ': no se cambia.';
                    continue;
                }

                $almacen = $almacenes[0];

                if ($actual !== null && (int) $actual['warehouse_id'] === (int) $almacen['id']) continue;

                $out['values']['warehouse_id'] = (int) $almacen['id'];
                $out['changes'][]              = ['label' => $etiqueta, 'before' => $actual ? $this->nombreAlmacenIA($actual['warehouse_id'], $ctx) : '', 'after' => $almacen['name']];
                continue;
            }

            if ($campo === 'is_default' || $campo === 'requires_supplier') {
                $si = $this->siNoIA($valor);

                if ($si === null || ($actual !== null && (int) $actual[$campo] === $si)) continue;

                $out['values'][$campo] = $si;
                $out['changes'][]      = ['label' => $etiqueta, 'before' => $actual ? ((int) $actual[$campo] === 1 ? 'Sí' : 'No') : '', 'after' => $si === 1 ? 'Sí' : 'No'];
                continue;
            }

            if ($campo === 'color_hex' || $campo === 'bg_hex') {
                $hex   = $this->colorIA($valor);
                $antes = $actual !== null ? (string) $this->colorIA($actual[$campo] ?? '') : '';

                if ($hex === null) {
                    $out['warn'][] = $etiqueta . ': «' . $this->textoIA($valor) . '» no es un color #RRGGBB' . ($actual ? ': no se cambia.' : '.');
                    continue;
                }

                if ($hex === $antes) continue;

                $out['values'][$campo] = $hex;
                $out['changes'][]      = ['label' => $etiqueta, 'before' => $antes, 'after' => $hex, 'swatch' => true];
                continue;
            }

            if ($campo === 'icon') {
                $icono = $this->iconoIA($valor);
                $antes = $actual !== null ? trim((string) ($actual['icon'] ?? '')) : '';

                if ($icono === null) {
                    $out['warn'][] = 'El ícono «' . $this->textoIA($valor) . '» no existe en Lucide' . ($actual ? ': no se cambia.' : '.');
                    continue;
                }

                if ($icono === $antes) continue;

                $out['values']['icon'] = $icono;
                $out['changes'][]      = ['label' => $etiqueta, 'before' => $antes, 'after' => $icono, 'icon' => true];
                continue;
            }

            $texto = mb_substr(preg_replace('/\s+/u', ' ', $this->textoIA($valor)), 0, self::IA_LARGOS[$entidad][$campo]);
            $antes = $actual !== null ? trim((string) ($actual[$campo] ?? '')) : '';

            if ($campo === 'code') $texto = mb_strtoupper($texto);

            // Nombre y código no se pueden dejar vacíos; los demás sí (se borra el dato).
            if (in_array($campo, ['name', 'code'], true) && mb_strlen($texto) < 1) continue;
            if ($actual === null && $texto === '') continue;
            if ($actual !== null && $texto === $antes) continue;

            if ($campo === 'email' && $texto !== '' && !filter_var($texto, FILTER_VALIDATE_EMAIL)) {
                $out['warn'][] = 'El email «' . $texto . '» no es válido: no se cambia.';
                continue;
            }

            $out['values'][$campo] = $texto;
            $out['changes'][]      = ['label' => $etiqueta, 'before' => $antes, 'after' => $texto === '' ? '(vacío)' : $texto];
        }

        return $out;
    }

    private function validarProductoIA($c, $idx, &$nuevos, &$vistos) {
        if ($c['action'] === 'add') {
            $campos = $this->camposProductoIA($c['set'], null, $idx, $nuevos);
            $nombre = $campos['item']['name'] ?? '';
            $clave  = $this->normalizarIA($nombre);

            if ($nombre === '') return $this->filaIA(['name' => $c['ref'] ?: 'Producto sin nombre', 'note' => 'Falta el nombre.']);

            if (isset($vistos['addproduct' . $clave])) return null;

            $vistos['addproduct' . $clave] = true;

            if (isset($idx['product']['nombre'][$clave])) {
                $existe = $idx['product']['id'][$idx['product']['nombre'][$clave]];

                return $this->filaIA([
                    'name' => $nombre,
                    'sku'  => $existe['sku'] ?? '',
                    'note' => (int) $existe['active'] === 1 ? 'Ya existe en el catálogo.' : 'Existe dado de baja: pídeme reactivarlo.'
                ]);
            }

            // Un producto nuevo sin precio entra en 0 (insumo que no se vende).
            $campos['item'] += ['price' => 0, 'price_without_tax' => 0, 'tax' => 0];

            return $this->filaIA([
                'name'    => $nombre,
                'changes' => $this->sinNombreIA($campos['changes']),
                'warn'    => implode(' ', $campos['warn'])
            ], ['item' => $campos['item'], 'attr' => $campos['attr'], 'refs' => $campos['refs']]);
        }

        $actual = $this->buscarIA('product', $c, $idx);

        if ($actual === null) return $this->filaIA(['name' => $c['ref'] ?: 'Producto sin identificar', 'note' => 'No lo encontré en el catálogo.']);

        $id    = (int) $actual['id'];
        $aviso = $this->avisoIdentidadIA($c['ref'], $actual['name']);

        if ($c['action'] !== 'edit') return $this->validarEstadoIA('product', $c['action'], $actual, $aviso, $idx, $vistos);

        if (isset($vistos['editproduct' . $id])) return null;

        $vistos['editproduct' . $id] = true;

        $campos = $this->camposProductoIA($c['set'], $actual, $idx, $nuevos);
        $fila   = [
            'name'    => $actual['name'],
            'sku'     => $actual['sku'] ?? '',
            'changes' => $campos['changes'],
            'warn'    => trim($aviso . ' ' . implode(' ', $campos['warn']))
        ];

        if (isset($campos['item']['name'])) {
            $otro = $idx['product']['nombre'][$this->normalizarIA($campos['item']['name'])] ?? null;

            if ($otro !== null && $otro !== $id) return $this->filaIA($fila + ['note' => 'Ya existe otro producto con ese nombre.']);
        }

        if (empty($campos['item']) && empty($campos['attr']) && empty($campos['refs'])) {
            return $this->filaIA($fila + ['note' => 'Ya tiene esos datos.']);
        }

        return $this->filaIA($fila, ['id' => $id, 'item' => $campos['item'], 'attr' => $campos['attr'], 'refs' => $campos['refs']]);
    }

    /*  Campos de un producto, repartidos donde viven: item (nombre, categoría,
        precio de venta) e item_attribute (unidad, área, costo, mínimos, vida útil,
        descripción). 'refs' guarda la categoría, unidad o área que se da de alta en
        la misma propuesta: su id se conoce hasta aplicarla. */
    private function camposProductoIA($set, $actual, $idx, $nuevos) {
        $etiquetas = self::IA_ENTIDADES['product']['campos'];
        $out       = ['item' => [], 'attr' => [], 'refs' => [], 'changes' => [], 'warn' => []];

        if (array_key_exists('name', $set)) {
            $nombre = mb_substr(preg_replace('/\s+/u', ' ', $this->textoIA($set['name'])), 0, 160);

            if (mb_strlen($nombre) >= 2 && ($actual === null || $nombre !== $actual['name'])) {
                $out['item']['name'] = $nombre;
                $out['changes'][]    = ['label' => 'Nombre', 'before' => $actual['name'] ?? '', 'after' => $nombre];
            }
        }

        // campo => [entidad del catálogo, columna, tabla destino, columna de listMateriales]
        $referencias = [
            'category' => ['category', 'category_id',       'item', 'categoria'],
            'unit'     => ['unit',     'unit_id',           'attr', 'unidad'],
            'area'     => ['area',     'warehouse_area_id', 'attr', 'area']
        ];

        foreach ($referencias as $campo => [$entidad, $columna, $destino, $columnaActual]) {
            $texto = array_key_exists($campo, $set) ? $this->textoIA($set[$campo]) : '';

            if ($texto === '') continue;

            $ref   = $this->refCatalogoIA($entidad, $texto, $idx, $nuevos);
            $antes = $actual !== null ? trim((string) ($actual[$columnaActual] ?? '')) : '';

            if ($ref === null) {
                $out['warn'][] = $etiquetas[$campo] . ' «' . $texto . '» no existe: ' . ($actual ? 'no se cambia.' : 'queda sin ' . mb_strtolower($etiquetas[$campo]) . '.');
                continue;
            }

            $mismo = $actual !== null && (
                $this->normalizarIA($antes) === $this->normalizarIA($ref['name'])
                || ($entidad === 'unit' && $this->normalizarIA($antes) === $this->normalizarIA($ref['code'] ?? ''))
            );

            if ($mismo) continue;

            if (isset($ref['nueva'])) {
                $out['refs'][$campo] = ['clave' => $ref['nueva'], 'nombre' => $ref['name']];
            } else {
                $out[$destino][$columna] = (int) $ref['id'];

                if ((int) $ref['active'] !== 1) $out['warn'][] = $etiquetas[$campo] . ' «' . $ref['name'] . '» está dada de baja.';
            }

            $out['changes'][] = ['label' => $etiquetas[$campo], 'before' => $antes, 'after' => $ref['name'] . (isset($ref['nueva']) ? ' (nueva)' : '')];
        }

        // Precio de venta: el precio con IVA manda y la base se deriva (precioIA()).
        $tocaPrecio = array_key_exists('price', $set) || array_key_exists('base', $set);

        if ($tocaPrecio || array_key_exists('tax', $set)) {
            $ivaActual    = $actual !== null ? (float) $actual['tax'] : 0;
            $precioActual = $actual !== null ? (float) $actual['price'] : 0;
            $entrada      = $set;

            // Solo IVA: se conserva el precio que paga el cliente y se recalcula la base.
            if (!$tocaPrecio) $entrada['price'] = $precioActual;

            [$precio, $base, $iva] = $this->precioIA($entrada, $ivaActual, $actual === null || !$tocaPrecio);

            if ($precio === null) {
                $out['warn'][] = 'El precio no es un número válido: no se cambia.';
            } else {
                $cambiaPrecio = $actual === null || abs($precio - $precioActual) >= 0.005;
                $cambiaIva    = $actual === null || abs($iva - $ivaActual) >= 0.005;

                if ($cambiaPrecio || $cambiaIva) {
                    $out['item'] += ['price' => $precio, 'price_without_tax' => $base, 'tax' => $iva];

                    if ($cambiaPrecio) $out['changes'][] = ['label' => 'Precio', 'before' => $actual ? $this->pesosIA($precioActual) : '', 'after' => $this->pesosIA($precio) . ($iva > 0 ? ' (sin IVA ' . $this->pesosIA($base) . ')' : '')];
                    if ($cambiaIva)    $out['changes'][] = ['label' => 'IVA', 'before' => $actual ? $ivaActual . '%' : '', 'after' => $iva . '%'];
                }
            }
        }

        // campo => [columna en item_attribute, es dinero]
        $numeros = [
            'cost'            => ['cost_unit', true],
            'stock_min'       => ['stock_min', false],
            'stock_max'       => ['stock_max', false],
            'shelf_life_days' => ['shelf_life_days', false]
        ];

        foreach ($numeros as $campo => [$columna, $dinero]) {
            if (!array_key_exists($campo, $set)) continue;

            $n = $this->cifraIA($set[$campo]);

            if ($n === null || $n < 0 || $n > 9999999) {
                $out['warn'][] = $etiquetas[$campo] . ': «' . $this->textoIA($set[$campo]) . '» no es un número válido.';
                continue;
            }

            if ($columna === 'shelf_life_days') $n = (int) round($n);

            $antes = $actual !== null ? $actual[$columna] : null;

            if ($antes !== null && $antes !== '' && abs((float) $antes - $n) < 0.0001) continue;

            $formato = function ($v) use ($dinero, $columna) {
                if ($v === null || $v === '') return '';
                if ($dinero) return $this->pesosIA($v);
                return $this->numeroIA($v) . ($columna === 'shelf_life_days' ? ' días' : '');
            };

            $out['attr'][$columna] = $n;
            $out['changes'][]      = ['label' => $etiquetas[$campo], 'before' => $formato($antes), 'after' => $formato($n)];
        }

        if (array_key_exists('description', $set)) {
            $texto = mb_substr(preg_replace('/\s+/u', ' ', $this->textoIA($set['description'])), 0, 255);
            $antes = $actual !== null ? trim((string) ($actual['description'] ?? '')) : '';

            if ($texto !== $antes && !($actual === null && $texto === '')) {
                $out['attr']['description'] = $texto;
                $out['changes'][]           = ['label' => 'Descripción', 'before' => $antes, 'after' => $texto === '' ? '(vacío)' : $texto];
            }
        }

        // Sucursal dueña: como el campo Sucursal del formulario, solo el administrador la
        // cambia. El stock no se mueve: sigue en el almacén donde está.
        $texto = array_key_exists('branch', $set) ? $this->textoIA($set['branch']) : '';

        if ($texto !== '') {
            $sucursal = $this->buscarSucursalIA($texto, ['branch' => $idx['branch'] ?? []]);

            if (!$this->esAdministrador()) {
                $out['warn'][] = 'Cambiar un producto de sucursal es solo para el administrador: no se cambia.';
            } elseif ($sucursal === null) {
                $out['warn'][] = 'Sucursal «' . $texto . '» no existe: no se cambia.';
            } elseif ($actual === null || (int) $sucursal['id'] !== (int) ($actual['branch_id'] ?? 0)) {
                $out['item']['branch_id'] = (int) $sucursal['id'];
                $out['changes'][]         = ['label' => 'Sucursal', 'before' => $actual !== null ? ($actual['sucursal'] ?? '') : '', 'after' => $sucursal['valor']];

                // La categoría y el área de otra sucursal se le quitan, como en el formulario.
                $categoria = $out['item']['category_id'] ?? ($actual['category_id'] ?? null);
                if (!isset($out['refs']['category']) && !$this->categoriaEsDeSucursal($categoria, (int) $sucursal['id'])) {
                    $out['item']['category_id'] = null;
                    $out['changes'][] = ['label' => 'Categoría', 'before' => $actual['categoria'] ?? '', 'after' => '(sin categoría: es de otra sucursal)'];
                }

                $area = $out['attr']['warehouse_area_id'] ?? ($actual['area_id'] ?? null);
                if (!isset($out['refs']['area']) && !$this->areaEsDeSucursal($area, (int) $sucursal['id'])) {
                    $out['attr']['warehouse_area_id'] = null;
                    $out['changes'][] = ['label' => 'Área', 'before' => $actual['area'] ?? '', 'after' => '(sin área: es de otra sucursal)'];
                }
            }
        }

        return $out;
    }

    // Categoría, unidad o área por nombre (o código de unidad), o la que se da de
    // alta en esta misma propuesta. Sin igual exacto vale una parcial solo si es
    // la única activa ("Bebida" encuentra "Bebidas").
    private function refCatalogoIA($entidad, $texto, $idx, $nuevos) {
        $clave = $this->normalizarIA($texto);

        if ($clave === '') return null;

        $fila = function ($r) {
            return ['id' => (int) $r['id'], 'name' => $r['name'], 'code' => $r['code'] ?? '', 'active' => (int) $r['active']];
        };

        if (isset($idx[$entidad]['nombre'][$clave])) return $fila($idx[$entidad]['id'][$idx[$entidad]['nombre'][$clave]]);
        if (isset($idx[$entidad]['codigo'][$clave])) return $fila($idx[$entidad]['id'][$idx[$entidad]['codigo'][$clave]]);
        if (isset($nuevos[$entidad][$clave]))        return ['nueva' => $clave, 'name' => $nuevos[$entidad][$clave]];

        $parciales = [];

        foreach ($idx[$entidad]['id'] as $r) {
            $valor = $this->normalizarIA($r['name']);

            if ((int) $r['active'] === 1 && $valor !== '' && (strpos($valor, $clave) !== false || strpos($clave, $valor) !== false)) {
                $parciales[] = $r;
            }
        }

        return count($parciales) === 1 ? $fila($parciales[0]) : null;
    }

    private function buscarSucursalIA($valor, $ctx) {
        $clave = $this->normalizarIA($this->textoIA($valor));

        foreach ($ctx['branch'] as $b) {
            if ((string) $b['id'] === $this->textoIA($valor) || ($clave !== '' && $this->normalizarIA($b['valor']) === $clave)) return $b;
        }

        return null;
    }

    private function nombreSucursalIA($id, $ctx) {
        foreach ($ctx['branch'] as $b) {
            if ((int) $b['id'] === (int) $id) return $b['valor'];
        }

        return 'Sucursal ' . $id;
    }

    // Por id o por nombre. Con nombres repetidos se quedan los activos; si aún hay
    // varios (un "General" en cada sucursal), el modelo tiene que mandar el id.
    private function buscarAlmacenIA($valor, $ctx) {
        $texto  = $this->textoIA($valor);
        $clave  = $this->normalizarIA($texto);
        $todos  = [];

        foreach ($ctx['warehouse'] as $w) {
            if ((string) $w['id'] === $texto) return [$w];
            if ($clave !== '' && $this->normalizarIA($w['name']) === $clave) $todos[] = $w;
        }

        $activos = array_values(array_filter($todos, function ($w) { return (int) $w['active'] === 1; }));

        return $activos ?: $todos;
    }

    private function nombreAlmacenIA($id, $ctx) {
        foreach ($ctx['warehouse'] as $w) {
            if ((int) $w['id'] === (int) $id) return $w['name'];
        }

        return $id ? 'Almacén ' . $id : '-';
    }

    // -- Asistente IA · vaciado (Super Admin) --

    private function esSuperAdminIA() {
        if (empty($_SESSION['user_id']) || empty($_SESSION['branch_id'])) return false;

        return $this->isSuperAdmin([$_SESSION['user_id']]);
    }

    /*  null si el modelo no pidió vaciar. Si lo pidió, la vista previa es SOLO el
        vaciado del bloque más grande que nombró: mezclarlo con altas o cambios
        validados contra datos que están por borrarse no tiene sentido. */
    private function vaciadoIA($cambios, $super) {
        $sinonimos = ['movimientos' => 'movements', 'productos' => 'products', 'catalogos' => 'catalogs'];
        $bloques   = array_keys(self::IA_VACIADO);
        $pidio     = false;
        $alcance   = -1;

        foreach ($cambios as $c) {
            if (!is_array($c)) continue;

            $accion  = $this->normalizarIA($this->textoIA($c['action'] ?? ''));
            $entidad = $this->normalizarIA($this->textoIA($c['entity'] ?? ''));

            if (!in_array($accion, ['purge', 'vaciar', 'limpiar'], true) && $entidad !== 'purge') continue;

            $scope = $this->normalizarIA($this->textoIA($c['scope'] ?? ''));
            $i     = array_search($sinonimos[$scope] ?? $scope, $bloques, true);
            $pidio = true;

            if ($i !== false) $alcance = max($alcance, $i);
        }

        if (!$pidio) return null;

        $fila = ['idx' => 0, 'action' => 'purge', 'tag' => 'Vaciar', 'name' => 'Base de datos'];

        if (!$super)       return $this->vistaVaciadoIA($fila, 'Solo el Super Admin puede vaciar la base de datos.');
        if ($alcance < 0)  return $this->vistaVaciadoIA($fila, 'No entendí qué vaciar: movimientos, productos o catálogos.');

        $scope  = $bloques[$alcance];
        $conteo = $this->conteoVaciadoIA($scope, $_SESSION['company_id']);
        $fila   = ['name' => self::IA_VACIADO[$scope]['nombre']] + $fila;

        if (empty($conteo)) return $this->vistaVaciadoIA($fila, 'Ya está vacío.');

        $fila += [
            'detail' => 'Se borra: ' . $this->listaIA($conteo) . '.',
            'warn'   => 'Solo de ' . ($_SESSION['company'] ?? 'tu empresa') . '. No se puede deshacer.' . ($scope === 'catalogs' ? ' Unidades, almacenes y sucursales se quedan.' : '')
        ];

        return $this->vistaVaciadoIA($fila, '', ['entity' => 'purge', 'action' => 'purge', 'scope' => $scope, 'nombre' => $fila['name']]);
    }

    private function vistaVaciadoIA($fila, $nota, $cambio = null) {
        $row = $this->filaIA($fila + ['note' => $nota, 'valid' => $cambio !== null])['row'];

        return [
            'row'     => [$row],
            'validos' => $cambio !== null ? [0 => $cambio] : [],
            'resumen' => ['purge' => $cambio !== null ? 1 : 0, 'invalid' => $cambio !== null ? 0 : 1]
        ];
    }

    // Las tablas del bloque y de todos los anteriores, en orden de borrado.
    private function tablasVaciadoIA($scope) {
        $tablas = [];

        foreach (self::IA_VACIADO as $bloque => $def) {
            $tablas += $def['tablas'];

            if ($bloque === $scope) break;
        }

        return $tablas;
    }

    // ["12 productos", "3 entradas"]: solo lo que tiene algo que borrar.
    private function conteoVaciadoIA($scope, $companies_id) {
        $conteo = [];

        foreach ($this->tablasVaciadoIA($scope) as $tabla => $nombre) {
            if ($nombre === null) continue;

            $n = $this->countPurge($tabla, $companies_id);

            if ($n) $conteo[] = $n . ' ' . ($n === 1 ? $nombre[0] : $nombre[1]);
        }

        return $conteo;
    }

    // Corre dentro de la transacción de applyAsistente: si una tabla falla, no se borra nada.
    private function vaciarIA($scope, $companies_id) {
        $borrados = $this->conteoVaciadoIA($scope, $companies_id);

        foreach (array_keys($this->tablasVaciadoIA($scope)) as $tabla) {
            if ($this->purge($tabla, $companies_id) !== true) throw new Exception('No pude vaciar ' . $tabla . '.');
        }

        return $borrados;
    }

    // -- Asistente IA · aplicación --

    private function aplicarCambioIA($c, $companies_id, $branch_id, $now, &$creados) {
        $entidad = $c['entity'];

        if ($entidad === 'product') {
            if ($c['action'] === 'present') return $this->presentarIA($c, $companies_id);
            if ($c['action'] === 'add')  return $this->altaProductoIA($c, $companies_id, $branch_id, $now, $creados);
            if ($c['action'] === 'edit') return $this->editarProductoIA($c, $companies_id, $creados);

            return $this->estadoIA($entidad, $c, $companies_id);
        }

        if ($c['action'] === 'add')  return $this->altaCatalogoIA($c, $companies_id, $branch_id, $now, $creados);
        if ($c['action'] === 'edit') return $this->editarCatalogoIA($c, $companies_id);

        return $this->estadoIA($entidad, $c, $companies_id);
    }

    private function altaCatalogoIA($c, $companies_id, $branch_id, $now, &$creados) {
        $entidad = $c['entity'];
        $coded   = in_array($entidad, self::CODE_CATALOGS, true);
        $valores = $c['values'] + ['companies_id' => $companies_id] + ($coded ? [] : ['created_at' => $now]) + ['active' => 1];

        if ($entidad === 'warehouse') $valores += ['branch_id' => $branch_id, 'is_default' => 0];
        // Categorías y proveedores son de la sucursal que los da de alta.
        if (in_array($entidad, ['category', 'supplier'], true)) $valores += ['branch_id' => $this->sucursalNuevaCatalogo()];

        // Al final de la lista que se ordena a mano, como el alta de su pestaña. Se calcula
        // aquí (dentro de la transacción) para que dos altas seguidas no empaten.
        if (in_array($entidad, ['unit', 'inflow', 'shrinkage'], true)) $valores['sort_order'] = $this->getNextCatalogSort($entidad, $companies_id);

        if ($coded) $valores['code'] = $this->codigoIA($entidad, $valores['name']);

        if ($this->createCatalog($entidad, $this->sqlIA($valores)) !== true) {
            throw new Exception('No pude dar de alta ' . self::IA_ENTIDADES[$entidad]['uno'] . ' «' . $valores['name'] . '».');
        }

        $creados[$entidad][$this->normalizarIA($valores['name'])] = $this->getMaxCatalogId($entidad);
    }

    private function editarCatalogoIA($c, $companies_id) {
        $donde  = $this->dondeIA($c['entity'], $c['id'], $companies_id);
        $update = $this->updateCatalog($c['entity'], [
            'values' => array_keys($c['values']),
            'where'  => $donde['where'],
            'data'   => array_merge(array_values($c['values']), $donde['data'])
        ]);

        if ($update !== true) throw new Exception('No pude cambiar ' . self::IA_ENTIDADES[$c['entity']]['uno'] . ' «' . $c['nombre'] . '».');
    }

    // Lo mismo que productoAjeno para CoffeeIA: un producto de otra sucursal no se cambia.
    private function bloqueoProductoIA($id, $nombre) {
        if ($this->productoAjeno($this->getMaterialById((int) $id))) {
            throw new Exception('«' . $nombre . '» es de otra sucursal: solo su sucursal o Matriz lo editan.');
        }
    }

    private function estadoIA($entidad, $c, $companies_id) {
        if ($entidad === 'product') $this->bloqueoProductoIA($c['id'], $c['nombre']);

        $donde = $this->dondeIA($entidad, $c['id'], $companies_id);
        $datos = [
            'values' => ['active'],
            'where'  => $donde['where'],
            'data'   => array_merge([$c['action'] === 'activate' ? 1 : 0], $donde['data'])
        ];

        $update = $entidad === 'product' ? $this->updateMaterial($datos) : $this->updateCatalog($entidad, $datos);

        if ($update !== true) throw new Exception('No pude cambiar el estado de ' . self::IA_ENTIDADES[$entidad]['uno'] . ' «' . $c['nombre'] . '».');
    }

    // Igual que Editar > Presentación: la presentación toma el nombre, SKU, unidad y costo
    // que ya tenía el producto (costo vacío: factor × costo del base). Se vuelve a revisar
    // aquí porque pudo cambiar desde la vista previa.
    private function presentarIA($c, $companies_id) {
        $material = $this->getMaterialById($c['id']);
        $base     = $this->getMaterialById($c['base_id']);
        $factor   = (float) $c['factor'];

        if (!$material || (int) $material['companies_id'] !== (int) $companies_id || (int) $material['active'] !== 1) {
            throw new Exception('«' . $c['nombre'] . '» ya no está activo.');
        }

        if (!$base || (int) $base['companies_id'] !== (int) $companies_id || (int) $base['active'] !== 1) {
            throw new Exception('El producto base de «' . $c['nombre'] . '» ya no está activo.');
        }

        if ($this->listPresentaciones([$companies_id, $c['id'], $c['id']])) {
            throw new Exception('«' . $c['nombre'] . '» tiene presentaciones propias: no puede ser presentación de otro.');
        }

        $this->bloqueoProductoIA($c['id'], $c['nombre']);
        $this->bloqueoProductoIA($c['base_id'], $base['name']);

        $costo = (float) $material['cost_unit'];

        $this->moverAPresentacion($material, $base, [
            'name'              => $material['name'],
            'sku'               => ($material['sku'] ?? '') !== '' ? $material['sku'] : null,
            'factor'            => $factor,
            'unit_id'           => $material['unit_id'] ?: null,
            'warehouse_area_id' => $material['warehouse_area_id'] ?: null,
            'cost_unit'         => $costo > 0 ? $costo : round($factor * (float) $base['cost_unit'], 2)
        ]);
    }

    // Misma alta que addMaterial, con los datos ya validados.
    private function altaProductoIA($c, $companies_id, $branch_id, $now, $creados) {
        [$item, $attr] = $this->resolverRefsIA($c, $creados);

        // La sucursal que eligió el administrador gana a la de la sesión.
        if (isset($item['branch_id']) && !$this->esAdministrador()) unset($item['branch_id']);

        $datos = $item + [
            'image'        => '',
            'branch_id'    => $branch_id,
            'companies_id' => $companies_id,
            'created_at'   => $now,
            'active'       => 1
        ];

        if ($this->createMaterial($this->sqlIA($datos)) !== true) throw new Exception('No pude dar de alta «' . $item['name'] . '».');

        $atributos = $attr + [
            'sku'          => $this->skuFor($item['category_id'] ?? null),
            'item_id'      => $this->getMaxItemId(),
            'companies_id' => $companies_id,
            'created_at'   => $now,
            'active'       => 1
        ];

        if ($this->createItemAttribute($this->sqlIA($atributos)) !== true) throw new Exception('No pude guardar los datos de «' . $item['name'] . '».');
    }

    private function editarProductoIA($c, $companies_id, $creados) {
        $this->bloqueoProductoIA($c['id'], $c['nombre']);

        [$item, $attr] = $this->resolverRefsIA($c, $creados);

        if (isset($item['branch_id']) && !$this->esAdministrador()) {
            throw new Exception('Cambiar «' . $c['nombre'] . '» de sucursal es solo para el administrador.');
        }
        if (isset($item['branch_id'])) $this->quitarAreasAjenasPresentaciones([$c['id'], $item['branch_id']]);

        if (!empty($item)) {
            $update = $this->updateMaterial([
                'values' => array_keys($item),
                'where'  => ['id = ?', 'companies_id = ?'],
                'data'   => array_merge(array_values($item), [$c['id'], $companies_id])
            ]);

            if ($update !== true) throw new Exception('No pude cambiar el producto «' . $c['nombre'] . '».');
        }

        if (!empty($attr)) {
            $update = $this->updateItemAttribute([
                'values' => array_keys($attr),
                'where'  => ['item_id = ?', 'companies_id = ?', 'active = 1'],
                'data'   => array_merge(array_values($attr), [$c['id'], $companies_id])
            ]);

            if ($update !== true) throw new Exception('No pude cambiar los datos del producto «' . $c['nombre'] . '».');
        }

        // Igual que editMaterial: si el producto no tenía SKU, lo recibe ahora.
        if (array_key_exists('category_id', $item)) $this->updateItemAttributeSku([$this->skuFor($item['category_id']), $c['id']]);
    }

    // Pone el id de la categoría, unidad o área dada de alta en esta misma propuesta.
    // Si no se marcó, el producto no puede quedar apuntando a la nada: se detiene todo.
    private function resolverRefsIA($c, $creados) {
        $item    = $c['item'];
        $attr    = $c['attr'];
        $destino = ['category' => ['item', 'category_id'], 'unit' => ['attr', 'unit_id'], 'area' => ['attr', 'warehouse_area_id']];

        foreach ($c['refs'] as $campo => $ref) {
            $id = $creados[$campo][$ref['clave']] ?? null;

            if ($id === null) {
                $producto = $item['name'] ?? $c['nombre'];

                throw new Exception('«' . $producto . '» usa ' . self::IA_ENTIDADES[$campo]['uno'] . ' nueva «' . $ref['nombre'] . '», que no marcaste. Márcala también o desmarca el producto.');
            }

            [$tabla, $columna] = $destino[$campo];

            if ($tabla === 'item') $item[$columna] = $id;
            else                   $attr[$columna] = $id;
        }

        return [$item, $attr];
    }

    // WHERE de un registro: siempre dentro de la empresa de la sesión.
    private function dondeIA($entidad, $id, $companies_id) {
        return ['where' => ['id = ?', 'companies_id = ?'], 'data' => [$id, $companies_id]];
    }

    // Clave fija a partir del nombre: "Pedido complementario" -> PEDIDO_COMPLEMENTARIO.
    // Mismo criterio que ctrl-catalogo::codeFromName: mayúsculas sin acentos, máx. 30
    // (largo de la columna) y _2, _3... si ya existe.
    private function codigoIA($entidad, $nombre) {
        $plano = strtr(mb_strtoupper(trim((string) $nombre), 'UTF-8'), ['Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ñ' => 'N']);
        $base  = rtrim(substr(trim(preg_replace('/[^A-Z0-9]+/', '_', $plano), '_'), 0, 30), '_');
        $base  = $base !== '' ? $base : 'CODIGO';
        $code  = $base;
        $n     = 2;

        while ($this->existsCatalogCode($entidad, $code) > 0) {
            $sufijo = '_' . $n++;
            $code   = rtrim(substr($base, 0, 30 - strlen($sufijo)), '_') . $sufijo;
        }

        return $code;
    }

    // INSERT sin util->sql(): ahí un 0 se volvería NULL (gotcha 0 == ''). Los null
    // se omiten para que la BD ponga su DEFAULT.
    private function sqlIA($valores) {
        $valores = array_filter($valores, function ($v) { return $v !== null; });

        return [
            'values' => array_keys($valores),
            'data'   => array_values($valores)
        ];
    }

    // "Listo. Altas: 1 categoría y 2 productos · Cambios: 5 productos."
    private function resumenIA($n) {
        if (isset($n['purge'])) {
            return empty($n['purge']['borrados']) ? 'Listo. Ya estaba vacío.' : 'Listo. Se borró: ' . $this->listaIA($n['purge']['borrados']) . '.';
        }

        $verbos = ['add' => 'Altas', 'edit' => 'Cambios', 'deactivate' => 'Bajas', 'activate' => 'Reactivados', 'present' => 'Pasaron a presentación'];
        $partes = [];

        foreach ($verbos as $accion => $verbo) {
            $items = [];

            foreach (self::IA_ENTIDADES as $entidad => $def) {
                $k = $n[$entidad][$accion] ?? 0;

                if ($k) $items[] = $k . ' ' . ($k === 1 ? $def['uno'] : $def['varios']);
            }

            if (empty($items)) continue;

            $ultimo   = array_pop($items);
            $partes[] = $verbo . ': ' . (empty($items) ? '' : implode(', ', $items) . ' y ') . $ultimo;
        }

        return 'Listo. ' . implode(' · ', $partes) . '.';
    }

    // -- Asistente IA · utilidades --

    // El precio CON IVA manda y la base se deriva, para que las dos columnas cuadren.
    // Devuelve [precio, base, iva]; precio null si no hay un precio usable.
    private function precioIA($c, $ivaActual, $permitirCero) {
        $iva    = $this->ivaIA($c['tax'] ?? null, $ivaActual);
        $precio = $this->cifraIA($c['price'] ?? null);
        $base   = $this->cifraIA($c['base'] ?? null);

        if (!$permitirCero) {
            if ($precio !== null && $precio <= 0) $precio = null;
            if ($base !== null && $base <= 0)     $base   = null;
        }

        if ($precio === null && $base !== null) $precio = round($base * (1 + $iva / 100), 2);

        if ($precio === null || $precio < 0 || $precio > 999999) return [null, null, $iva];

        $precio = round($precio, 2);
        $base   = $iva > 0 ? round($precio / (1 + $iva / 100), 2) : $precio;

        return [$precio, $base, $iva];
    }

    private function ivaIA($valor, $porDefecto) {
        $n = $this->cifraIA($valor);

        if ($n === null) return (float) $porDefecto;

        if ($n > 0 && $n < 1) $n *= 100;

        $n = round($n);

        return in_array($n, [0.0, 8.0, 16.0], true) ? $n : (float) $porDefecto;
    }

    private function cifraIA($valor) {
        if (is_int($valor) || is_float($valor)) return (float) $valor;

        if (!is_string($valor)) return null;

        $s = str_replace(['$', ',', ' ', 'MXN', 'mxn'], '', trim($valor));

        return is_numeric($s) ? (float) $s : null;
    }

    // "#a1b2c3", "A1B2C3" o "#abc" -> "#A1B2C3"; cualquier otra cosa, null.
    private function colorIA($valor) {
        $texto = $this->textoIA($valor);

        if (preg_match('/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i', $texto, $m)) $texto = $m[1] . $m[1] . $m[2] . $m[2] . $m[3] . $m[3];

        $hex = ltrim($texto, '#');

        return preg_match('/^[0-9a-f]{6}$/i', $hex) ? '#' . strtoupper($hex) : null;
    }

    // Nombre canónico de Lucide. Se revisa contra la lista del selector de íconos
    // (cs-icons.js): un nombre inventado dejaría el badge sin ícono. Sin esa lista
    // (archivo movido) vale cualquier nombre bien formado.
    private function iconoIA($valor) {
        static $lista = null;

        $nombre = preg_replace('/([a-z0-9])([A-Z])/', '$1-$2', $this->textoIA($valor));
        $nombre = trim(preg_replace('/[\s_]+/', '-', strtolower($nombre)), '-');

        if (strlen($nombre) > 60 || !preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $nombre)) return null;

        if ($lista === null) {
            $ruta  = __DIR__ . '/../../../src/js/components/cs-icons.js';
            $js    = is_readable($ruta) ? (string) file_get_contents($ruta) : '';
            $lista = [];

            if (preg_match('/CS_ICONS\s*=\s*\[(.*?)\];/s', $js, $m) && preg_match_all("/'([a-z0-9-]+)'/", $m[1], $n)) {
                $lista = array_flip($n[1]);
            }
        }

        return empty($lista) || isset($lista[$nombre]) ? $nombre : null;
    }

    private function siNoIA($valor) {
        if (is_bool($valor)) return $valor ? 1 : 0;

        $v = $this->normalizarIA($this->textoIA($valor));

        if (in_array($v, ['1', 'si', 'yes', 'true', 'verdadero'], true)) return 1;
        if (in_array($v, ['0', 'no', 'false', 'falso'], true))           return 0;

        return null;
    }

    // Si el nombre que escribió el modelo no se parece al del catálogo, se avisa:
    // puede haber elegido el registro equivocado.
    private function avisoIdentidadIA($pedido, $real) {
        $a = $this->normalizarIA($pedido);
        $b = $this->normalizarIA($real);

        if ($a === '' || $a === $b || strpos($a, $b) !== false || strpos($b, $a) !== false) return '';

        similar_text($a, $b, $parecido);

        return $parecido < 60 ? 'En tu lista decía «' . $pedido . '».' : '';
    }

    // "a, b y c"
    private function listaIA($items) {
        $ultimo = array_pop($items);

        return empty($items) ? (string) $ultimo : implode(', ', $items) . ' y ' . $ultimo;
    }

    private function sinNombreIA($changes) {
        return array_values(array_filter($changes, function ($ch) { return $ch['label'] !== 'Nombre'; }));
    }

    private function normalizarIA($texto) {
        $t = mb_strtolower(trim((string) $texto), 'UTF-8');
        $t = strtr($t, ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n']);

        return trim(preg_replace('/[^a-z0-9]+/', ' ', $t));
    }

    private function textoIA($valor) {
        return is_scalar($valor) ? trim((string) $valor) : '';
    }

    private function numeroIA($n) {
        if ($n === null || $n === '') return '';

        return rtrim(rtrim(number_format((float) $n, 2, '.', ''), '0'), '.');
    }

    private function pesosIA($n) {
        return '$' . number_format((float) $n, 2);
    }

    private function filaIA($row, $cambio = null) {
        return [
            'row'    => array_merge([
                'name'    => '',
                'sku'     => '',
                'changes' => [],
                'before'  => '',
                'after'   => '',
                'detail'  => '',
                'warn'    => '',
                'note'    => ''
            ], $row),
            'cambio' => $cambio
        ];
    }
}

// Complements

// La foto se guarda relativa a inventory/ (uploads/productos/...) y la tabla se pinta
// en operacion/almacen/. Una URL completa o absoluta se respeta tal cual.
// `$nota` va debajo del nombre con su ícono: la equivalencia de una presentación (cajas)
// o de qué sucursal es el producto (edificio).
function renderProductImage($foto, $nombre, $nota = '', $icono = 'boxes') {
    $src = '';
    if (!empty($foto)) $src = preg_match('#^(https?:)?//|^/#', $foto) ? $foto : '../../' . $foto;

    $img = !empty($src)
        ? '<img src="' . htmlspecialchars($src) . '" alt="Imagen Insumo" class="w-10 h-10 bg-gray-100 rounded-sm object-cover" />'
        : '<div class="w-10 h-10 bg-gray-200 rounded-sm flex items-center justify-center">
                <i class="icon-picture-5 text-gray-600"></i>
           </div>';

    // El nombre va SIN clase de tamano: asi hereda el font-size que createTable
    // pinta en la celda (f_size). Con text-xs quedaba clavado en 9.8px, porque
    // compact.css lo fija con !important y eso le gana al estilo del <td>.
    // La tabla va en minusculas (lowercase); first-letter devuelve la mayuscula inicial.
    // min-w-0 + break-words: la columna tiene ancho fijo y un nombre largo se parte.
    $texto = $nota === ''
        ? '<div class="min-w-0 break-words first-letter:uppercase">' . htmlspecialchars($nombre) . '</div>'
        : '<div class="min-w-0 break-words text-left">'
            . '<div class="first-letter:uppercase">' . htmlspecialchars($nombre) . '</div>'
            . '<div class="mt-0.5 flex items-center gap-1 text-[11px] normal-case text-gray-500"><i data-lucide="' . htmlspecialchars($icono) . '" class="w-3 h-3 flex-shrink-0"></i><span>' . htmlspecialchars($nota) . '</span></div>'
        . '</div>';

    return '
        <div class="flex items-center justify-start gap-2 py-1 text-center">
            ' . $img . '
            ' . $texto . '
        </div>';
}

// Último costo de la tabla de Productos: sin costo (0) va un guion, como Mín y Máx.
function costoCelda($costo) {
    return (float) $costo > 0 ? '$' . number_format((float) $costo, 2) : '-';
}

// Badge del área: el color elegido en Catálogo > Área, o el automático por id
// (areaColors en conf/_Utileria.php). cs-badge-soft deja que dark-mode.css lo
// convierta en velo si la página va en oscuro. La columna es de ancho fijo: un nombre
// largo se corta con "..." y completo sale al pasar el mouse.
function renderArea($areaId, $name, $hex = null) {
    if (empty($areaId) || $name === null || $name === '') return '-';

    $tone = areaColors($areaId, $hex);

    return '<span class="cs-badge-soft inline-block max-w-full truncate align-middle px-2.5 py-0.5 rounded-full font-semibold whitespace-nowrap first-letter:uppercase"'
         . ' title="' . htmlspecialchars($name) . '"'
         . ' style="--b-fg:' . $tone['fg'] . ';background:' . $tone['bg'] . ';color:' . $tone['fg'] . ';">'
         . htmlspecialchars($name)
         . '</span>';
}

function renderQuantity($cantidad) {
    return (float) $cantidad == 0 ? '-' : $cantidad;
}

function renderStatus($estatus) {
    switch ($estatus) {
        case 1:
            return '<span class="px-2 py-1 rounded-md text-xs font-semibold bg-green-100 text-green-700">Activo</span>';
        case 0:
            return '<span class="px-2 py-1 rounded-md text-xs font-semibold bg-red-100 text-red-700">Inactivo</span>';
        default:
            return '<span class="px-2 py-1 rounded-md text-xs font-semibold bg-gray-100 text-gray-700">Desconocido</span>';
    }
}

$obj = new ctrl();
$opc = $_POST['opc'];
echo json_encode(Permissions::guard('administrador', $opc, ctrl::PERMISSIONS) ?: $obj->{$opc}());
