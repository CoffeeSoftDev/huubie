<?php
require_once __DIR__ . '/../../conf/_Session.php';

if (empty($_SESSION["IDU"])) {
    require_once('../../acceso/ctrl/ctrl-logout.php');
    exit();
}

// El rol necesita al menos una acción en Reportes; si no, de regreso a Inicio.
require_once __DIR__ . '/../../conf/_Permissions.php';
$permissions = Permissions::page('reportes');

require_once('layout/head.php');
require_once('layout/core-libraries.php');
?>

<!-- CoffeeSoft Framework -->
<script src="../../src/js/coffeeSoft.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/plugins.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/complementos.js?t=<?php echo time(); ?>"></script>
<link rel="stylesheet" href="../../src/css/dark-mode.css?v=<?php echo filemtime(__DIR__ . '/../../src/css/dark-mode.css'); ?>">

<body>
    <div id="menu-sidebar" class="bg-white flex flex-col items-center py-4 gap-2"></div>
    <main>
        <div id="menu-navbar"></div>

        <div id="main__content">
            <div class="" id="root"></div>
        </div>
    </main>

    <!-- Importacion navbar y sidebar -->
    <script src="../../acceso/src/js/navbar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/navbar.js'); ?>"></script>
    <script src="../../acceso/src/js/sidebar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/sidebar.js'); ?>"></script>

    <!-- Modulo de Reportes -->
    <!-- Acciones del rol en Reportes: imprimir y el Excel solo salen con Imprimir -->
    <?php echo Permissions::script($permissions); ?>
    <script src="js/reportes.js?t=<?php echo time(); ?>"></script>
</body>
</html>
