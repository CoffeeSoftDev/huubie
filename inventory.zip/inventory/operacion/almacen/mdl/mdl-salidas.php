<?php
require_once '../../../conf/_CRUD.php';
require_once '../../../conf/_Utileria.php';
require_once __DIR__ . '/mdl-borrado.php';
require_once __DIR__ . '/mdl-presentaciones.php';
require_once __DIR__ . '/mdl-visibilidad.php';
require_once __DIR__ . '/mdl-folios.php';

class mdl extends CRUD {

    // Borrado real con su stock (CoffeeIA): deleteSalidaFullById.
    use BorradoInventario;

    // Folio por sucursal: nextFolio (S-KAF-0001).
    use FolioSucursal;

    // Presentaciones en la captura: se guardan como su producto base.
    use PresentacionesCaptura;

    // Qué productos ve la sucursal: los suyos y los de Matriz.
    use VisibilidadProductos;

    public $util;
    public $bd;
    public $bdErp;

    public function __construct() {
        $this->util  = new Utileria;
        $this->bd    = 'fayxzvov_inventory.';
        $this->bdErp = 'fayxzvov_erp.';
    }

    // La Matriz (sucursal del almacén principal) va primero; las demás, por nombre.
    function lsSucursales($array) {
        $companyId = $array['company_id'];
        $userId    = $array['user_id'];
        $isOwner   = (int) $array['is_owner'];

        if ($isOwner === 1) {
            $query = "
                SELECT id, name AS valor, company_id AS companies_id
                FROM {$this->bdErp}branches
                WHERE company_id = ? AND is_active = 1
                ORDER BY id IN (SELECT branch_id FROM {$this->bd}warehouse WHERE is_main = 1 AND active = 1) DESC, name ASC
            ";
            $r = $this->_Read($query, [$companyId]);
        } else {
            $query = "
                SELECT b.id, b.name AS valor, b.company_id AS companies_id
                FROM {$this->bdErp}branches b
                INNER JOIN {$this->bdErp}users_braches ub ON ub.branch_id = b.id
                WHERE b.company_id = ? AND b.is_active = 1 AND ub.user_id = ?
                ORDER BY b.id IN (SELECT branch_id FROM {$this->bd}warehouse WHERE is_main = 1 AND active = 1) DESC, b.name ASC
            ";
            $r = $this->_Read($query, [$companyId, $userId]);
        }
        return is_array($r) ? $r : [];
    }

    function lsWarehouses($array) {
        $where = 'w.active = 1 AND w.companies_id = ?';
        $data  = [$array['companies_id']];

        if (!empty($array['branch_id'])) {
            $where .= ' AND w.branch_id = ?';
            $data[] = $array['branch_id'];
        }

        $query = "
            SELECT
                w.id,
                w.name,
                w.name AS valor,
                w.is_default,
                w.branch_id,
                s.name AS branch_name
            FROM {$this->bd}warehouse w
            LEFT JOIN {$this->bdErp}branches s ON s.id = w.branch_id
            WHERE {$where}
            ORDER BY s.name ASC, w.is_default DESC, w.name ASC
        ";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }

    function lsShrinkageReasons($array) {
        // [companies_id]
        $query = "
            SELECT id, code, name, name AS valor, icon, color_hex
            FROM {$this->bd}shrinkage_reason
            WHERE active = 1 AND companies_id = ?
            ORDER BY sort_order ASC, id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function qProductsForTransfer($array) {
        $query = "
            SELECT
                i.id                                       AS id,
                i.name                                     AS nombre,
                ia.sku                                     AS sku,
                ic.name                                    AS categoria,
                COALESCE(ia.cost_unit, 0)                  AS costo,
                i.price                                    AS precio,
                i.image                                    AS image,
                COALESCE(iu.code, '')                      AS unidad
            FROM {$this->bd}item i
            LEFT JOIN {$this->bd}item_attribute  ia ON ia.item_id = i.id AND ia.active = 1
            LEFT JOIN {$this->bd}unit            iu ON iu.id = ia.unit_id
            LEFT JOIN {$this->bd}item_category   ic ON ic.id = i.category_id
            WHERE i.active = 1 AND i.companies_id = ? {$this->filtroProductosPropios('i')}
            ORDER BY i.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Presentaciones de la captura (mdl-presentaciones): de una sucursal solo sale lo suyo
    // y lo que tiene en sus almacenes, igual que sus productos.
    function filtroCapturaProductos($alias) {
        return $this->filtroProductosPropios($alias);
    }

    function qStockByWarehouse($array) {
        $query = "
            SELECT item_id, quantity
            FROM {$this->bd}stock
            WHERE warehouse_id = ? AND active = 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Filtros comunes de la lista, las cards y su desglose (sin el estado).
    private function salidaFilters($array) {
        $where = 'm.active = 1 AND m.companies_id = ?';
        $data  = [$array['companies_id']];

        if (!empty($array['branch_id'])) {
            $where .= ' AND m.branch_id = ?';
            $data[] = $array['branch_id'];
        }
        if (!empty($array['reason_id'])) {
            $where .= ' AND m.shrinkage_reason_id = ?';
            $data[] = $array['reason_id'];
        }
        if (!empty($array['fi']) && !empty($array['ff'])) {
            $where .= ' AND DATE(m.created_at) BETWEEN ? AND ?';
            $data[] = $array['fi'];
            $data[] = $array['ff'];
        }
        if (!empty($array['q'])) {
            $where .= ' AND (m.folio LIKE ? OR m.note LIKE ?)';
            $data[] = '%' . $array['q'] . '%';
            $data[] = '%' . $array['q'] . '%';
        }

        return ['where' => $where, 'data' => $data];
    }

    // Valor, Registros y Unidades: nunca cuentan las canceladas, que tienen su card.
    private function salidaKpiFilters($array) {
        $filters = $this->salidaFilters($array);
        $filters['where'] .= " AND m.status <> 'Cancelada'";

        if (!empty($array['status'])) {
            $filters['where'] .= ' AND m.status = ?';
            $filters['data'][]  = $array['status'];
        }
        return $filters;
    }

    function qSalidas($array) {
        $filters = $this->salidaFilters($array);
        $where   = $filters['where'];
        $data    = $filters['data'];

        if (!empty($array['status'])) {
            $where .= ' AND m.status = ?';
            $data[] = $array['status'];
        }

        $query = "
            SELECT
                m.id,
                m.folio,
                m.note,
                m.evidence_url,
                m.total_products,
                m.total_units,
                m.total_cost            AS total_cost_loss,
                m.status,
                m.created_at,
                m.updated_at,
                m.shrinkage_reason_id,
                sr.name             AS reason_name,
                sr.color_hex        AS reason_color,
                sr.bg_hex           AS reason_bg,
                sr.icon             AS reason_icon,
                m.warehouse_id,
                w.name              AS warehouse_name,
                m.branch_id,
                s.name              AS branch_name,
                m.user_id,
                m.purchase_order_id,
                TRIM(CONCAT(COALESCE(u.name, ''), ' ', COALESCE(u.last_name, ''))) AS user_name
            FROM {$this->bd}inventory_shrinkage m
            LEFT JOIN {$this->bd}shrinkage_reason sr ON sr.id = m.shrinkage_reason_id
            LEFT JOIN {$this->bd}warehouse         w  ON w.id  = m.warehouse_id
            LEFT JOIN {$this->bdErp}branches   s  ON s.id  = m.branch_id
            LEFT JOIN {$this->bdErp}users          u  ON u.id  = m.user_id
            WHERE {$where}
            ORDER BY m.created_at DESC
        ";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }

    function getSalidaKpis($array) {
        $filters = $this->salidaKpiFilters($array);
        $common  = $this->salidaFilters($array);

        $query = "
            SELECT
                COUNT(m.id)                   AS total_salidas,
                IFNULL(SUM(m.total_cost), 0)  AS total_costo,
                IFNULL(SUM(m.total_units), 0) AS total_unidades
            FROM {$this->bd}inventory_shrinkage m
            WHERE {$filters['where']}
        ";
        $r    = $this->_Read($query, $filters['data']);
        $base = !empty($r) ? $r[0] : [
            'total_salidas'   => 0,
            'total_costo'    => 0,
            'total_unidades' => 0
        ];

        $queryCanc = "
            SELECT COUNT(m.id) AS total_canceladas
            FROM {$this->bd}inventory_shrinkage m
            WHERE {$common['where']} AND m.status = 'Cancelada'
        ";
        $canc                     = $this->_Read($queryCanc, $common['data']);
        $base['total_canceladas'] = !empty($canc) ? (int) $canc[0]['total_canceladas'] : 0;

        return $base;
    }

    function listSalidasByReason($array) {
        $filters = $this->salidaKpiFilters($array);

        $query = "
            SELECT
                sr.name                        AS reason_name,
                sr.color_hex                   AS reason_color,
                sr.bg_hex                      AS reason_bg,
                sr.icon                        AS reason_icon,
                COUNT(m.id)                    AS total_salidas,
                IFNULL(SUM(m.total_units), 0)  AS total_unidades,
                IFNULL(SUM(m.total_cost), 0)   AS total_costo
            FROM {$this->bd}inventory_shrinkage m
            LEFT JOIN {$this->bd}shrinkage_reason sr ON sr.id = m.shrinkage_reason_id
            WHERE {$filters['where']}
            GROUP BY m.shrinkage_reason_id, sr.name, sr.color_hex, sr.bg_hex, sr.icon
            ORDER BY total_salidas DESC, total_costo DESC
        ";
        $r = $this->_Read($query, $filters['data']);
        return is_array($r) ? $r : [];
    }

    function listSalidaProducts($array) {
        $filters = $this->salidaKpiFilters($array);
        $order   = ($array['order'] ?? '') === 'units' ? 'total_unidades' : 'total_costo';

        $query = "
            SELECT
                it.name                     AS product_name,
                ia.sku,
                COALESCE(iu.code, '')       AS unit,
                SUM(d.quantity)             AS total_unidades,
                IFNULL(SUM(d.subtotal), 0)  AS total_costo
            FROM {$this->bd}inventory_shrinkage m
            INNER JOIN {$this->bd}detail_inventory_shrinkage d ON d.inventory_shrinkage_id = m.id AND d.active = 1
            INNER JOIN {$this->bd}item it ON it.id = d.item_id
            LEFT  JOIN {$this->bd}item_attribute ia ON ia.item_id = it.id AND ia.active = 1
            LEFT  JOIN {$this->bd}unit iu ON iu.id = ia.unit_id
            WHERE {$filters['where']}
            GROUP BY d.item_id, it.name, ia.sku, unit
            ORDER BY {$order} DESC, it.name ASC
        ";
        $r = $this->_Read($query, $filters['data']);
        return is_array($r) ? $r : [];
    }

    function qGetSalida($array) {
        $query = "
            SELECT
                m.*,
                m.total_cost   AS total_cost_loss,
                sr.name        AS reason_name,
                sr.color_hex   AS reason_color,
                sr.bg_hex      AS reason_bg,
                sr.icon        AS reason_icon,
                w.name         AS warehouse_name,
                s.name         AS branch_name,
                TRIM(CONCAT(COALESCE(u.name, ''), ' ', COALESCE(u.last_name, ''))) AS user_name
            FROM {$this->bd}inventory_shrinkage m
            LEFT JOIN {$this->bd}shrinkage_reason sr ON sr.id = m.shrinkage_reason_id
            LEFT JOIN {$this->bd}warehouse         w  ON w.id  = m.warehouse_id
            LEFT JOIN {$this->bdErp}branches   s  ON s.id  = m.branch_id
            LEFT JOIN {$this->bdErp}users          u  ON u.id  = m.user_id
            WHERE m.id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function getSalidaDetail($array) {
        $query = "
            SELECT
                d.id,
                d.quantity,
                d.cost,
                d.subtotal AS subtotal_loss,
                d.previous_stock,
                d.resulting_stock,
                d.item_id AS product_id,
                i.name AS product_name,
                ia.sku,
                i.category_id,
                ic.name AS category_name,
                wa.name AS area_name,
                COALESCE(iu.code, '') AS unit,
                d.item_presentation_id  AS presentation_id,
                d.presentation_quantity AS presentation_qty,
                ip.name                 AS presentation_name
            FROM {$this->bd}detail_inventory_shrinkage d
            INNER JOIN {$this->bd}item i ON i.id = d.item_id
            LEFT  JOIN {$this->bd}item_presentation ip ON ip.id = d.item_presentation_id
            LEFT  JOIN {$this->bd}item_attribute ia ON ia.item_id = i.id AND ia.active = 1
            LEFT  JOIN {$this->bd}item_category  ic ON ic.id = i.category_id
            LEFT  JOIN {$this->bd}warehouse_area wa ON wa.id = ia.warehouse_area_id
            LEFT  JOIN {$this->bd}unit           iu ON iu.id = ia.unit_id
            WHERE d.inventory_shrinkage_id = ? AND d.active = 1
            ORDER BY d.id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function insertSalida($array) {
        $query = "
            INSERT INTO {$this->bd}inventory_shrinkage
                (folio, note, evidence_url, total_products, total_units, total_cost,
                 status, shrinkage_reason_id, warehouse_id,
                 branch_id, user_id, companies_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    function insertSalidaDetail($array) {
        $query = "
            INSERT INTO {$this->bd}detail_inventory_shrinkage
                (quantity, cost, subtotal, previous_stock, resulting_stock,
                 item_id, item_presentation_id, presentation_quantity, inventory_shrinkage_id)
            VALUES (?,?,?,?,?,?,?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    function disableSalidaDetail($array) {
        // [salida_id]
        $query = "
            UPDATE {$this->bd}detail_inventory_shrinkage
            SET active = 0
            WHERE inventory_shrinkage_id = ? AND active = 1
        ";
        return $this->_CUD($query, $array);
    }

    function updateSalidaHeader($array) {
        // [note, total_products, total_units, total_cost, shrinkage_reason_id, warehouse_id, branch_id, id, companies_id]
        $query = "
            UPDATE {$this->bd}inventory_shrinkage
            SET note = ?, total_products = ?, total_units = ?, total_cost = ?,
                shrinkage_reason_id = ?, warehouse_id = ?, branch_id = ?, updated_at = NOW()
            WHERE id = ? AND companies_id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function qCancelSalida($array) {
        $query = "
            UPDATE {$this->bd}inventory_shrinkage
            SET status = 'Cancelada', updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // Fecha del último conteo físico aplicado del almacén: nada anterior a ella se edita.
    // Los ajustes automáticos (un producto que pasa a presentación) no cuentan.
    function qLastAdjustmentDate($array) {
        // [warehouse_id, companies_id]
        $query = "
            SELECT MAX(date_adjustment) AS last_date
            FROM {$this->bd}inventory_adjustment
            WHERE status = 'Aplicado' AND adjustment_type = 'fisico' AND active = 1 AND warehouse_id = ? AND companies_id = ?
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) && !empty($r[0]['last_date']) ? $r[0]['last_date'] : null;
    }

    // Credenciales del usuario en sesión para reconfirmar su contraseña al cancelar.
    function qUserPassword($array) {
        // [user_id]
        $query = "
            SELECT password
            FROM {$this->bdErp}users
            WHERE id = ? AND status = 'active'
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function updateSalidaEvidence($array) {
        $query = "
            UPDATE {$this->bd}inventory_shrinkage
            SET evidence_url = ?, updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function deleteSalidaById($array) {
        $query = "
            UPDATE {$this->bd}inventory_shrinkage
            SET active = 0, updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function getStockRow($array) {
        $query = "
            SELECT id, quantity
            FROM {$this->bd}stock
            WHERE item_id = ? AND warehouse_id = ? AND active = 1
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function insertStockRow($array) {
        $query = "
            INSERT INTO {$this->bd}stock
                (quantity, last_movement_at, warehouse_id, item_id, companies_id)
            VALUES (?, NOW(), ?, ?, ?)
        ";
        return $this->_CUD($query, $array);
    }

    function updateStockQuantity($array) {
        $query = "
            UPDATE {$this->bd}stock
            SET quantity = ?, last_movement_at = NOW(), updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // -- CoffeeIA: eliminar --

    // Las salidas que CoffeeIA puede eliminar, también las inactivas (cuentan para el
    // folio). Como la lista del módulo, son las de toda la empresa; `branch_ids` la
    // acota a una sucursal (reiniciar su folio). `pedido` es el folio del pedido que la
    // generó al surtirse: esa se borra en Pedidos.
    function listSalidasIA($array) {
        $where = 's.companies_id = ?';
        $data  = [$array['companies_id']];

        foreach (['branch_ids' => 's.branch_id', 'ids' => 's.id', 'folios' => 's.folio'] as $campo => $columna) {
            if (empty($array[$campo])) continue;
            $where .= " AND {$columna} IN (" . implode(',', array_fill(0, count($array[$campo]), '?')) . ')';
            $data   = array_merge($data, $array[$campo]);
        }

        $query = "
            SELECT
                s.id,
                s.folio,
                s.branch_id,
                s.status,
                s.active,
                s.date_shrinkage,
                s.created_at,
                s.note,
                s.total_products,
                s.total_cost,
                sr.name  AS reason_name,
                w.name   AS warehouse_name,
                b.name   AS branch_name,
                po.folio AS pedido
            FROM {$this->bd}inventory_shrinkage s
            LEFT JOIN {$this->bd}shrinkage_reason sr ON sr.id = s.shrinkage_reason_id
            LEFT JOIN {$this->bd}warehouse        w  ON w.id  = s.warehouse_id
            LEFT JOIN {$this->bdErp}branches    b  ON b.id  = s.branch_id
            LEFT JOIN {$this->bd}purchase_order   po ON po.id = s.purchase_order_id
            WHERE {$where}
            ORDER BY s.id DESC
        ";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }
}
