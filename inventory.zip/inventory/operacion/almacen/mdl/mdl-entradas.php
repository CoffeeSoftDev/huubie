<?php
require_once '../../../conf/_CRUD.php';
require_once '../../../conf/_Utileria.php';
require_once __DIR__ . '/mdl-borrado.php';
require_once __DIR__ . '/mdl-presentaciones.php';
require_once __DIR__ . '/mdl-visibilidad.php';
require_once __DIR__ . '/mdl-folios.php';

class mdl extends CRUD {

    // Borrado real con su stock (CoffeeIA): deleteEntradaFullById.
    use BorradoInventario;

    // Folio por sucursal: nextFolio (ENT-KAF-0001).
    use FolioSucursal;

    // Presentaciones en la captura: se guardan como su producto base.
    use PresentacionesCaptura;

    // Qué productos ve la sucursal: los suyos y los de Matriz.
    use VisibilidadProductos;

    public $util;
    public $bd;
    public $bdErp;

    public function __construct() {
        $this->util  = new Utileria;
        $this->bd    = 'fayxzvov_inventory.';
        $this->bdErp = 'fayxzvov_erp.';
    }

    // La Matriz (sucursal del almacén principal) va primero; las demás, por nombre.
    function lsSucursales($array) {
        $companyId = $array['company_id'];
        $userId    = $array['user_id'];
        $isOwner   = (int) $array['is_owner'];

        if ($isOwner === 1) {
            $query = "
                SELECT id, name AS valor, company_id AS companies_id
                FROM {$this->bdErp}branches
                WHERE company_id = ? AND is_active = 1
                ORDER BY id IN (SELECT branch_id FROM {$this->bd}warehouse WHERE is_main = 1 AND active = 1) DESC, name ASC
            ";
            $r = $this->_Read($query, [$companyId]);
        } else {
            $query = "
                SELECT b.id, b.name AS valor, b.company_id AS companies_id
                FROM {$this->bdErp}branches b
                INNER JOIN {$this->bdErp}users_braches ub ON ub.branch_id = b.id
                WHERE b.company_id = ? AND b.is_active = 1 AND ub.user_id = ?
                ORDER BY b.id IN (SELECT branch_id FROM {$this->bd}warehouse WHERE is_main = 1 AND active = 1) DESC, b.name ASC
            ";
            $r = $this->_Read($query, [$companyId, $userId]);
        }
        return is_array($r) ? $r : [];
    }

    function lsWarehouses($array) {
        $where = 'w.active = 1 AND w.companies_id = ?';
        $data  = [$array['companies_id']];

        if (!empty($array['branch_id'])) {
            $where .= ' AND w.branch_id = ?';
            $data[] = $array['branch_id'];
        }

        $query = "
            SELECT
                w.id,
                w.name,
                w.name AS valor,
                w.is_default,
                w.branch_id,
                w.warehouse_area_id,
                wa.name AS area_name,
                wa.color_hex AS area_color,
                s.name AS branch_name
            FROM {$this->bd}warehouse w
            LEFT JOIN {$this->bd}warehouse_area wa ON wa.id = w.warehouse_area_id
            LEFT JOIN {$this->bdErp}branches s ON s.id = w.branch_id
            WHERE {$where}
            ORDER BY s.name ASC, w.is_default DESC, w.name ASC
        ";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }

    // Categorías y proveedores: los de la sucursal; el administrador, todos.
    function lsCategorias($array) {
        $query = "
            SELECT ic.id, ic.name AS valor
            FROM {$this->bd}item_category ic
            WHERE ic.active = 1 AND ic.companies_id = ? {$this->filtroCatalogoSucursal('ic')}
            ORDER BY ic.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Orden del Catálogo > Unidad (arrastre). sort_order: docs/sql/2026-10-02_unidad-orden.sql.
    function lsUnidades($array) {
        $query = "
            SELECT id, name AS valor, code
            FROM {$this->bd}unit
            WHERE active = 1 AND companies_id = ?
            ORDER BY sort_order ASC, name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // warehouse_id: el Destino del form solo ofrece las áreas del almacén elegido.
    // Cada sucursal ve las áreas de su almacén; Matriz y el dueño, todas.
    function lsAreas($array) {
        $query = "
            SELECT wa.id, wa.name AS valor, wa.warehouse_id
            FROM {$this->bd}warehouse_area wa
            WHERE wa.active = 1 AND wa.companies_id = ? {$this->filtroAreasVisibles('wa')}
            ORDER BY wa.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function lsInflowOrigins($array) {
        // [companies_id]
        $query = "
            SELECT id, code, name, name AS valor, description, icon, color_hex, requires_supplier
            FROM {$this->bd}inflow_origin
            WHERE active = 1 AND companies_id = ?
            ORDER BY sort_order ASC, id ASC
        ";
        $r = $this->_Read($query, $array);
        if (!is_array($r)) return [];
        foreach ($r as &$o) {
            // requires_supplier se administra por dato en la tabla inflow_origin,
            // no por code. Asi cualquier origen puede exigir proveedor sin tocar codigo.
            $o['requires_supplier'] = (int) $o['requires_supplier'];
        }
        return $r;
    }

    function lsSuppliers($array) {
        $query = "
            SELECT s.id, s.name, s.name AS valor
            FROM {$this->bd}supplier s
            WHERE s.active = 1 AND s.companies_id = ? {$this->filtroCatalogoSucursal('s')}
            ORDER BY s.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function findSupplierByName($array) {
        $query = "
            SELECT s.id, s.name
            FROM {$this->bd}supplier s
            WHERE s.active = 1 AND s.companies_id = ? AND LOWER(s.name) = LOWER(?) {$this->filtroCatalogoSucursal('s')}
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    // El alta exprés queda de la sucursal de la sesión.
    function insertSupplier($array) {
        $query = "
            INSERT INTO {$this->bd}supplier
                (name, contact_name, phone, email, companies_id, branch_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ";
        return $this->_CUD($query, array_merge($array, [$this->sucursalNuevaCatalogo()]));
    }

    function qProductsForTransfer($array) {
        $query = "
            SELECT
                i.id                                       AS id,
                i.name                                     AS nombre,
                ia.sku                                     AS sku,
                ic.name                                    AS categoria,
                i.category_id                              AS category_id,
                ia.unit_id                                 AS unit_id,
                {$this->ultimoCostoCols()},
                i.image                                    AS image,
                ia.description                             AS descripcion,
                ia.stock_max                               AS stock_max,
                i.branch_id                                AS branch_id
            FROM {$this->bd}item i
            LEFT JOIN {$this->bd}item_attribute  ia ON ia.item_id = i.id AND ia.active = 1
            LEFT JOIN {$this->bd}item_category   ic ON ic.id = i.category_id
            WHERE i.active = 1 AND i.companies_id = ? {$this->filtroProductosVisibles('i')}
            ORDER BY i.name ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function getInflowOrigin($array) {
        // [id, companies_id]
        $query = "
            SELECT id, code, name, color_hex, requires_supplier
            FROM {$this->bd}inflow_origin
            WHERE id = ? AND companies_id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    // Filtros de la lista, las cards y su desglose: los tres cuentan lo mismo.
    // 'applied' deja solo las aplicadas (card Aplicadas).
    private function entradaFilters($array) {
        $where = 'i.active = 1 AND i.companies_id = ?';
        $data  = [$array['companies_id']];

        if (!empty($array['branch_id'])) {
            $where .= ' AND i.branch_id = ?';
            $data[] = $array['branch_id'];
        } elseif (!empty($array['branch_ids'])) {
            $where .= ' AND i.branch_id IN (' . implode(',', array_fill(0, count($array['branch_ids']), '?')) . ')';
            $data   = array_merge($data, $array['branch_ids']);
        }
        if (!empty($array['origin_id'])) {
            $where .= ' AND i.inflow_origin_id = ?';
            $data[] = $array['origin_id'];
        }
        if (!empty($array['status'])) {
            if ($array['status'] === 'Activas') {
                $where .= " AND i.status <> 'Cancelada'";
            } else {
                $where .= ' AND i.status = ?';
                $data[] = $array['status'];
            }
        }
        if (!empty($array['fi']) && !empty($array['ff'])) {
            $where .= ' AND (i.date_inflow IS NULL OR DATE(i.date_inflow) BETWEEN ? AND ?)';
            $data[] = $array['fi'];
            $data[] = $array['ff'];
        }
        if (!empty($array['q'])) {
            $where .= ' AND (i.folio LIKE ? OR i.note LIKE ?)';
            $data[] = '%' . $array['q'] . '%';
            $data[] = '%' . $array['q'] . '%';
        }
        if (!empty($array['applied'])) {
            $where .= " AND i.status = 'Aplicada'";
        }

        return ['where' => $where, 'data' => $data];
    }

    function qEntradas($array) {
        $filters = $this->entradaFilters($array);

        $query = "
            SELECT
                i.id,
                i.folio,
                i.note,
                i.total_products,
                i.total_units,
                i.total_cost,
                i.status,
                i.date_inflow,
                i.created_at,
                i.inflow_origin_id,
                io.name        AS origin_name,
                io.code        AS origin_code,
                io.color_hex   AS origin_color,
                io.bg_hex      AS origin_bg,
                io.icon        AS origin_icon,
                i.warehouse_id,
                w.name         AS warehouse_name,
                wa.name        AS area_name,
                i.branch_id,
                s.name         AS branch_name,
                i.supplier_id,
                sp.name        AS supplier_name,
                i.user_id,
                TRIM(CONCAT(COALESCE(u.name, ''), ' ', COALESCE(u.last_name, '')))    AS user_name,
                i.confirmed_user_id,
                TRIM(CONCAT(COALESCE(cu.name, ''), ' ', COALESCE(cu.last_name, '')))  AS confirmed_user_name,
                i.confirmed_at
            FROM {$this->bd}inventory_inflow i
            LEFT JOIN {$this->bd}inflow_origin      io ON io.id = i.inflow_origin_id
            LEFT JOIN {$this->bd}warehouse           w  ON w.id  = i.warehouse_id
            LEFT JOIN {$this->bd}warehouse_area      wa ON wa.id = i.warehouse_area_id
            LEFT JOIN {$this->bdErp}branches       s  ON s.id  = i.branch_id
            LEFT JOIN {$this->bd}supplier            sp ON sp.id = i.supplier_id
            LEFT JOIN {$this->bdErp}users            u  ON u.id  = i.user_id
            LEFT JOIN {$this->bdErp}users            cu ON cu.id = i.confirmed_user_id
            WHERE {$filters['where']}
            ORDER BY i.date_inflow DESC, i.id DESC
        ";
        $r = $this->_Read($query, $filters['data']);
        return is_array($r) ? $r : [];
    }

    function getEntradaKpis($array) {
        $filters = $this->entradaFilters($array);

        $query = "
            SELECT
                COUNT(i.id)                        AS total_entradas,
                IFNULL(SUM(i.total_cost), 0)       AS total_costo,
                IFNULL(SUM(i.total_units), 0)      AS total_unidades,
                SUM(i.status = 'Aplicada')         AS total_aplicadas
            FROM {$this->bd}inventory_inflow i
            WHERE {$filters['where']}
        ";
        $r = $this->_Read($query, $filters['data']);
        return !empty($r) ? $r[0] : [
            'total_entradas'  => 0,
            'total_costo'     => 0,
            'total_unidades'  => 0,
            'total_aplicadas' => 0
        ];
    }

    function listEntradasByOrigin($array) {
        $filters = $this->entradaFilters($array);

        $query = "
            SELECT
                io.name                        AS origin_name,
                io.color_hex                   AS origin_color,
                io.bg_hex                      AS origin_bg,
                io.icon                        AS origin_icon,
                COUNT(i.id)                    AS total_entradas,
                IFNULL(SUM(i.total_units), 0)  AS total_unidades,
                IFNULL(SUM(i.total_cost), 0)   AS total_costo
            FROM {$this->bd}inventory_inflow i
            LEFT JOIN {$this->bd}inflow_origin io ON io.id = i.inflow_origin_id
            WHERE {$filters['where']}
            GROUP BY i.inflow_origin_id, io.name, io.color_hex, io.bg_hex, io.icon
            ORDER BY total_entradas DESC, total_costo DESC
        ";
        $r = $this->_Read($query, $filters['data']);
        return is_array($r) ? $r : [];
    }

    // Misma cantidad que suma total_units: la confirmada si existe.
    function listEntradaProducts($array) {
        $filters = $this->entradaFilters($array);
        $order   = ($array['order'] ?? '') === 'units' ? 'total_unidades' : 'total_costo';

        $query = "
            SELECT
                it.name                                          AS product_name,
                ia.sku,
                COALESCE(du.code, iu.code, '')                   AS unit,
                SUM(COALESCE(d.confirmed_quantity, d.quantity))  AS total_unidades,
                IFNULL(SUM(d.subtotal), 0)                       AS total_costo
            FROM {$this->bd}inventory_inflow i
            INNER JOIN {$this->bd}detail_inventory_inflow d ON d.inventory_inflow_id = i.id AND d.active = 1
            INNER JOIN {$this->bd}item it ON it.id = d.item_id
            LEFT  JOIN {$this->bd}item_attribute ia ON ia.item_id = it.id AND ia.active = 1
            LEFT  JOIN {$this->bd}unit du ON du.id = d.unit_id
            LEFT  JOIN {$this->bd}unit iu ON iu.id = ia.unit_id
            WHERE {$filters['where']}
            GROUP BY d.item_id, it.name, ia.sku, unit
            ORDER BY {$order} DESC, it.name ASC
        ";
        $r = $this->_Read($query, $filters['data']);
        return is_array($r) ? $r : [];
    }

    function qGetEntrada($array) {
        $query = "
            SELECT
                i.*,
                io.name        AS origin_name,
                io.code        AS origin_code,
                io.color_hex   AS origin_color,
                io.bg_hex      AS origin_bg,
                io.icon        AS origin_icon,
                w.name         AS warehouse_name,
                wa.name        AS area_name,
                s.name         AS branch_name,
                sp.name        AS supplier_name,
                TRIM(CONCAT(COALESCE(u.name, ''), ' ', COALESCE(u.last_name, '')))    AS user_name,
                TRIM(CONCAT(COALESCE(cu.name, ''), ' ', COALESCE(cu.last_name, '')))  AS confirmed_user_name,
                TRIM(CONCAT(COALESCE(eu.name, ''), ' ', COALESCE(eu.last_name, '')))  AS edited_user_name
            FROM {$this->bd}inventory_inflow i
            LEFT JOIN {$this->bd}inflow_origin    io ON io.id = i.inflow_origin_id
            LEFT JOIN {$this->bd}warehouse         w  ON w.id  = i.warehouse_id
            LEFT JOIN {$this->bd}warehouse_area    wa ON wa.id = i.warehouse_area_id
            LEFT JOIN {$this->bdErp}branches     s  ON s.id  = i.branch_id
            LEFT JOIN {$this->bd}supplier          sp ON sp.id = i.supplier_id
            LEFT JOIN {$this->bdErp}users          u  ON u.id  = i.user_id
            LEFT JOIN {$this->bdErp}users          cu ON cu.id = i.confirmed_user_id
            LEFT JOIN {$this->bdErp}users          eu ON eu.id = i.edited_user_id
            WHERE i.id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function qGetEntradaDetail($array) {
        $query = "
            SELECT
                d.id,
                d.quantity,
                d.confirmed_quantity,
                d.cost,
                d.subtotal,
                d.price_without_tax,
                d.tax,
                d.previous_stock,
                d.resulting_stock,
                d.batch_code,
                d.expires_at,
                d.item_id AS product_id,
                i.name AS product_name,
                ia.sku,
                COALESCE(du.code, iu.code, '') AS unit,
                i.image
            FROM {$this->bd}detail_inventory_inflow d
            INNER JOIN {$this->bd}item i ON i.id = d.item_id
            LEFT  JOIN {$this->bd}item_attribute ia ON ia.item_id = i.id AND ia.active = 1
            LEFT  JOIN {$this->bd}unit du ON du.id = d.unit_id
            LEFT  JOIN {$this->bd}unit iu ON iu.id = ia.unit_id
            WHERE d.inventory_inflow_id = ? AND d.active = 1
            ORDER BY d.id ASC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function insertEntrada($array) {
        $query = "
            INSERT INTO {$this->bd}inventory_inflow
                (folio, note, total_products, total_units, total_cost,
                 total_price_without_tax,
                 status, inflow_origin_id, warehouse_id, warehouse_area_id, supplier_id,
                 branch_id, user_id, companies_id, date_inflow)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    function updateEntradaHeader($array) {
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET note = ?, total_products = ?, total_units = ?, total_cost = ?,
                total_price_without_tax = ?, inflow_origin_id = ?, warehouse_id = ?,
                warehouse_area_id = ?, supplier_id = ?, branch_id = ?, date_inflow = ?,
                updated_at = NOW()
            WHERE id = ? AND companies_id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function updateEntradaVoucher($array) {
        // [voucher_url, id]
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET voucher_url = ?
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // Quién guardó la última edición y cuándo (no se usa updated_at: también lo
    // tocan confirmar, cancelar y el recálculo de totales).
    function qMarkEntradaEdited($array) {
        // [edited_user_id, id]
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET edited_user_id = ?, edited_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // Fecha del último conteo físico aplicado de cada almacén: nada anterior a ella se
    // captura ni se edita. Los ajustes automáticos (un producto que pasa a presentación)
    // no cuentan: no fijan el stock contra lo contado.
    function qLastAdjustments($array) {
        // [companies_id]
        $query = "
            SELECT warehouse_id, MAX(date_adjustment) AS last_date
            FROM {$this->bd}inventory_adjustment
            WHERE status = 'Aplicado' AND adjustment_type = 'fisico' AND active = 1 AND companies_id = ?
            GROUP BY warehouse_id
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function qLastAdjustmentDate($array) {
        // [warehouse_id, companies_id]
        $query = "
            SELECT MAX(date_adjustment) AS last_date
            FROM {$this->bd}inventory_adjustment
            WHERE status = 'Aplicado' AND adjustment_type = 'fisico' AND active = 1 AND warehouse_id = ? AND companies_id = ?
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) && !empty($r[0]['last_date']) ? $r[0]['last_date'] : null;
    }

    // Credenciales del usuario en sesión para reconfirmar su contraseña al editar.
    function qUserPassword($array) {
        // [user_id]
        $query = "
            SELECT password
            FROM {$this->bdErp}users
            WHERE id = ? AND status = 'active'
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    // Los renglones reemplazados se apagan (la vista inventory_movement ya los ignora).
    function qDisableEntradaDetail($array) {
        $query = "
            UPDATE {$this->bd}detail_inventory_inflow
            SET active = 0
            WHERE inventory_inflow_id = ? AND active = 1
        ";
        return $this->_CUD($query, $array);
    }

    function insertEntradaDetail($array) {
        $query = "
            INSERT INTO {$this->bd}detail_inventory_inflow
                (batch_code, quantity, cost, subtotal, price_without_tax, tax,
                 previous_stock, resulting_stock,
                 expires_at, item_id, inventory_inflow_id, unit_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    // Guarda en el producto el ultimo costo de compra: base sin IVA y la tasa de
    // esa compra. Va en item_attribute; item.price es el precio de venta y las
    // entradas ya no lo tocan.
    function updateItemCost($array) {
        // [cost_unit, cost_tax, item_id, companies_id]
        $query = "
            UPDATE {$this->bd}item_attribute
            SET cost_unit = ?, cost_tax = ?
            WHERE item_id = ? AND companies_id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // Columnas del ultimo costo para sembrar un renglon de entrada: base sin IVA,
    // IVA de la ultima compra (si no hay, el IVA del producto) y el costo con IVA.
    private function ultimoCostoCols() {
        return "
                COALESCE(ia.cost_unit, 0)                                                     AS costo_sin_iva,
                COALESCE(ia.cost_tax, i.tax, 0)                                               AS iva_compra,
                ROUND(COALESCE(ia.cost_unit, 0) * (1 + COALESCE(ia.cost_tax, i.tax, 0) / 100), 2) AS costo";
    }

    function confirmEntradaDetail($array) {
        $query = "
            UPDATE {$this->bd}detail_inventory_inflow
            SET confirmed_quantity = ?, subtotal = ?, previous_stock = ?, resulting_stock = ?
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function updateEntradaTotals($array) {
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET total_units = ?, total_cost = ?, total_price_without_tax = ?, updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function qApplyEntrada($array) {
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET status = 'Aplicada', confirmed_user_id = ?, confirmed_at = NOW(), updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function qReverseEntrada($array) {
        $query = "
            UPDATE {$this->bd}inventory_inflow
            SET status = 'Cancelada', updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    function qStockByWarehouse($array) {
        $query = "
            SELECT item_id, quantity
            FROM {$this->bd}stock
            WHERE warehouse_id = ? AND companies_id = ? AND active = 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    function getStockRow($array) {
        $query = "
            SELECT id, quantity
            FROM {$this->bd}stock
            WHERE item_id = ? AND warehouse_id = ? AND active = 1
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function insertStockRow($array) {
        $query = "
            INSERT INTO {$this->bd}stock
                (quantity, last_movement_at, warehouse_id, item_id, companies_id)
            VALUES (?, NOW(), ?, ?, ?)
        ";
        return $this->_CUD($query, $array);
    }

    function updateStockQuantity($array) {
        $query = "
            UPDATE {$this->bd}stock
            SET quantity = ?, last_movement_at = NOW(), updated_at = NOW()
            WHERE id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // -- Formatos (plantillas reutilizables de lote) --

    // Cabeceras visibles para el contexto actual segun el scope guardado:
    // company (toda la empresa), subsidiary (misma sucursal) o user (solo el dueno).
    function qLsFormatos($array) {
        $query = "
            SELECT id, name, scope, created_at
            FROM {$this->bd}inflow_format
            WHERE active = 1 AND companies_id = ?
              AND ( scope = 'company'
                 OR (scope = 'subsidiary' AND branch_id = ?)
                 OR (scope = 'user' AND user_id = ?) )
            ORDER BY created_at DESC, id DESC
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) ? $r : [];
    }

    // Renglones de un conjunto de formatos, enriquecidos con los datos vigentes
    // del catalogo (nombre/sku/categoria/costo/imagen) para rearmar el lote igual
    // que init(). El costo se toma del catalogo, no se congela en el formato.
    function qFormatoItems($ids) {
        if (empty($ids)) return [];
        $place = implode(',', array_fill(0, count($ids), '?'));
        $query = "
            SELECT
                fi.inflow_format_id                AS inflow_format_id,
                fi.quantity                        AS cantidad,
                i.id                               AS id,
                i.name                             AS nombre,
                ia.sku                             AS sku,
                ic.name                            AS categoria,
                {$this->ultimoCostoCols()},
                i.image                            AS image
            FROM {$this->bd}inflow_format_item fi
            INNER JOIN {$this->bd}item            i  ON i.id = fi.item_id AND i.active = 1
            LEFT  JOIN {$this->bd}item_attribute  ia ON ia.item_id = i.id AND ia.active = 1
            LEFT  JOIN {$this->bd}item_category   ic ON ic.id = i.category_id
            WHERE fi.active = 1 AND fi.inflow_format_id IN ({$place})
            ORDER BY i.name ASC
        ";
        $r = $this->_Read($query, $ids);
        return is_array($r) ? $r : [];
    }

    function insertFormato($array) {
        $query = "
            INSERT INTO {$this->bd}inflow_format
                (name, scope, user_id, branch_id, companies_id)
            VALUES (?,?,?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    // _CUD no devuelve el id generado (cierra la conexion); recuperamos el ultimo
    // del usuario+empresa, mismo patron que saveEntrada con el folio.
    function qLastFormatoId($array) {
        $query = "
            SELECT id
            FROM {$this->bd}inflow_format
            WHERE companies_id = ? AND user_id = ?
            ORDER BY id DESC
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? (int) $r[0]['id'] : 0;
    }

    function insertFormatoItem($array) {
        $query = "
            INSERT INTO {$this->bd}inflow_format_item
                (quantity, item_id, inflow_format_id)
            VALUES (?,?,?)
        ";
        return $this->_CUD($query, $array);
    }

    function qGetFormato($array) {
        $query = "
            SELECT id, name, scope, user_id, branch_id, companies_id
            FROM {$this->bd}inflow_format
            WHERE id = ? AND companies_id = ?
            LIMIT 1
        ";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function qDeleteFormato($array) {
        $query = "
            UPDATE {$this->bd}inflow_format
            SET active = 0, updated_at = NOW()
            WHERE id = ? AND companies_id = ?
        ";
        return $this->_CUD($query, $array);
    }

    // -- CoffeeIA: eliminar --

    // Las entradas que CoffeeIA puede eliminar, también las inactivas (cuentan para el
    // folio). `branch_ids` = sucursales del usuario (vacío = dueño, sin tope). `pedido`
    // es el folio del pedido o compra de donde salió la recepción: esa no se borra aquí.
    function listEntradasIA($array) {
        $where = 'i.companies_id = ?';
        $data  = [$array['companies_id']];

        foreach (['branch_ids' => 'i.branch_id', 'ids' => 'i.id', 'folios' => 'i.folio'] as $campo => $columna) {
            if (empty($array[$campo])) continue;
            $where .= " AND {$columna} IN (" . implode(',', array_fill(0, count($array[$campo]), '?')) . ')';
            $data   = array_merge($data, $array[$campo]);
        }

        $query = "
            SELECT
                i.id,
                i.folio,
                i.branch_id,
                i.status,
                i.active,
                i.date_inflow,
                i.created_at,
                i.note,
                i.total_products,
                i.total_cost,
                io.name AS origin_name,
                w.name  AS warehouse_name,
                s.name  AS branch_name,
                sp.name AS supplier_name,
                po.folio AS pedido
            FROM {$this->bd}inventory_inflow i
            LEFT JOIN {$this->bd}inflow_origin  io ON io.id = i.inflow_origin_id
            LEFT JOIN {$this->bd}warehouse      w  ON w.id  = i.warehouse_id
            LEFT JOIN {$this->bdErp}branches  s  ON s.id  = i.branch_id
            LEFT JOIN {$this->bd}supplier       sp ON sp.id = i.supplier_id
            LEFT JOIN {$this->bd}purchase_order po ON po.id = i.purchase_order_id
            WHERE {$where}
            ORDER BY i.id DESC
        ";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }
}
