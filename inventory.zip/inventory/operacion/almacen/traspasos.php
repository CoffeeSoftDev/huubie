<?php
require_once __DIR__ . '/../../conf/_Session.php';

if (empty($_SESSION["IDU"])) {
    require_once('../../acceso/ctrl/ctrl-logout.php');
    exit();
}

// Traspasos está desactivado (sección apagada en Accesos): de regreso a Inicio, para todos.
require_once __DIR__ . '/../../conf/_Permissions.php';
if (!Permissions::sectionOn('traspasos')) {
    header('Location: ../../modulos/');
    exit();
}

require_once('layout/head.php');
require_once('layout/core-libraries.php');
?>

<!-- CoffeeSoft Framework -->
<script src="../../src/js/coffeeSoft.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/plugins.js?t=<?php echo time(); ?>"></script>
<script src="../../src/js/complementos.js?t=<?php echo time(); ?>"></script>
<link rel="stylesheet" href="../../src/css/dark-mode.css?v=<?php echo filemtime(__DIR__ . '/../../src/css/dark-mode.css'); ?>">

<body>
    <div id="menu-sidebar" class="bg-white flex flex-col items-center py-4 gap-2"></div>
    <main>
        <div id="menu-navbar"></div>

        <div id="main__content">
            <div class="" id="root"></div>
        </div>
    </main>

    <!-- Importacion navbar y sidebar -->
    <script src="../../acceso/src/js/navbar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/navbar.js'); ?>"></script>
    <script src="../../acceso/src/js/sidebar.js?v=<?php echo filemtime(__DIR__ . '/../../acceso/src/js/sidebar.js'); ?>"></script>

    <!-- Componentes -->
    <script src="../../src/js/components/traspaso-form.js?v=<?php echo filemtime(__DIR__ . '/../../src/js/components/traspaso-form.js'); ?>"></script>

    <!-- Modulo de Traspasos -->
    <script src="js/traspasos.js?t=<?php echo time(); ?>"></script>
</body>
</html>
