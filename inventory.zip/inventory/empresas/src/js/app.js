// Pantalla de Empresas (solo Super Admin): la misma interfaz del selector de
// sucursales, con una tarjeta por empresa y la del módulo DEV. Entrar a una
// empresa deja la sesión en ella y abre sus módulos; desde ahí la navbar lista
// las sucursales de esa empresa.
let api = 'ctrl/ctrl-empresas.php';
let app;

// Base del host hasta /inventory (ej. "/huubie/inventory" o "/inventory").
function inventoryBase() {
    const p = window.location.pathname;
    const i = p.indexOf('/inventory/');
    return i >= 0 ? p.slice(0, i + '/inventory'.length) : '/inventory';
}

// Colores para los diálogos SweetAlert según el tema activo.
function swalTheme() {
    const dark = document.body.classList.contains('dark-mode');
    return {
        background: dark ? '#111928' : '#FFFFFF',
        color:      dark ? '#F9FAFB' : '#111827'
    };
}

$(async () => {
    const data = await useFetch({ url: api, data: { opc: 'init' } });

    app = new App(api, 'root');
    app.render(data || {});
});

class App extends Templates {
    constructor(link, divModule) {
        super(link, divModule);
        this.PROJECT_NAME = 'Empresas';
    }

    render(data) {
        this.csSelectorCards({
            parent:   this._div_modulo,
            id:       `selector${this.PROJECT_NAME}`,
            title:    'Selecciona tu empresa',
            subtitle: 'Elige a qué empresa quieres entrar hoy',
            user:     data.user || 'Usuario',
            json:     this.jsonCards(data),
            empty: {
                icon:  'building-2',
                title: 'Sin empresas disponibles',
                text:  'No hay empresas activas todavía. Dalas de alta desde el módulo DEV.'
            },
            onSelect: (item) => this.onSelect(item),
            onLogout: () => this.logout()
        });
    }

    // Primero la tarjeta de DEV y después las empresas.
    jsonCards(data) {
        const cards = [];

        if (data.dev && data.dev.route) {
            cards.push({
                id:           'dev',
                type:         'dev',
                title:        String(data.dev.name || 'DEV').toUpperCase(),
                icon:         data.dev.icon || 'code-xml',
                // El anillo lo despega de la tarjeta en tema oscuro (gray-800 ≈ el fondo).
                iconClass:    'bg-gray-800 ring-1 ring-inset ring-white/20',
                location:     data.dev.description || 'Administrador CoffeeSoft',
                locationIcon: 'wrench',
                route:        data.dev.route,
                status:       { text: 'Módulo del Super Admin', tone: 'neutral' }
            });
        }

        (data.companies || []).forEach((c) => cards.push({
            id:       c.id,
            type:     'company',
            title:    c.name,
            icon:     'building-2',
            location: c.ubication,
            badge:    c.current ? 'ACTUAL' : '',
            selected: !!c.current,
            status:   c.branches > 0
                ? { text: `${c.branches} sucursal${c.branches !== 1 ? 'es' : ''} activa${c.branches !== 1 ? 's' : ''}`, tone: 'open' }
                : { text: 'Sin sucursales activas', tone: 'neutral' }
        }));

        return cards;
    }

    onSelect(item) {
        if (item.type === 'dev') {
            this.openRoute(item.route);
            return;
        }
        this.enterCompany(item);
    }

    // El aviso "Cargando empresa" (el mismo de "Aplicando tema") entra antes de
    // pedir la empresa y sigue en modulos/ hasta que la página termina de cargar.
    async enterCompany(item) {
        const loader  = window.InventoryPalette && InventoryPalette.loader;
        const title   = 'Cargando empresa';
        const started = Date.now();

        if (loader) loader.show(item.title, false, title);

        const res = await useFetch({ url: this._link, data: { opc: 'enterCompany', id: item.id } });

        if (res && res.status === 200) {
            // Tiempo mínimo en pantalla: con el servidor rápido el aviso apenas parpadeaba.
            await new Promise((resolve) => setTimeout(resolve, Math.max(0, 900 - (Date.now() - started))));

            if (loader) loader.carry(item.title, title);
            this.openRoute('modulos/');
            return;
        }

        if (loader) loader.hide();

        Swal.fire({
            ...swalTheme(),
            icon:               'error',
            title:              'No se pudo entrar a la empresa',
            text:               (res && res.message) || 'Intenta de nuevo.',
            confirmButtonColor: 'rgb(var(--brand-600, 192 90 64))',
            heightAuto:         false
        });
    }

    // Mismo aviso que el selector de sucursales; la sesión la cierra salir
    // (acceso/ctrl/ctrl-logout.php).
    logout() {
        Swal.fire({
            ...swalTheme(),
            title:              '¿Cerrar sesión?',
            text:               'Se cerrará tu sesión actual y volverás al inicio.',
            icon:               'question',
            showCancelButton:   true,
            confirmButtonText:  'Sí, cerrar sesión',
            cancelButtonText:   'Cancelar',
            confirmButtonColor: 'rgb(var(--brand-600, 192 90 64))',
            cancelButtonColor:  '#9CA3AF',
            reverseButtons:     true,
            scrollbarPadding:   false,
            heightAuto:         false
        }).then((result) => {
            if (result.isConfirmed) this.openRoute('salir');
        });
    }

    openRoute(route) {
        window.location.href = inventoryBase() + '/' + String(route).replace(/^\/+/, '');
    }
}
