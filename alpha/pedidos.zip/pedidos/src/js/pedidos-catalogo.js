class Pos extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "";
    }

    // Components.
    createPOSContainers(options) {
        const opts = Object.assign({
            parent: "container-package",
            id: "posLayout",
            theme: "dark",
            class: "flex flex-col md:flex-row text-sm text-white h-full",
            onChange: (item) => { },
            onBuildCake: () => {
                custom.render();
            }
        }, options);

        const isDark = opts.theme === "dark";

        const colors = {
            containerBg: isDark ? "" : "bg-white",
            textColor: isDark ? "text-white" : "text-gray-600",
            leftPaneBg: isDark ? "bg-[#111928]" : "bg-gray-100",
            orderPaneBg: isDark ? "bg-[#141d2b]" : "bg-white",
            inputBg: isDark ? "bg-[#111827]" : "bg-white",
            borderColor: isDark ? "border-[#374151]" : "border-gray-300",
            cardGridBg: isDark ? "" : "bg-white",
            tabBg: isDark ? "bg-[#151D2B]" : "bg-gray-100"
        };

        const container = $("<div>", {
            id: opts.id,
            class: `${opts.class} ${colors.containerBg} ${colors.textColor}`
        });

        const leftPane = $("<div>", {
            class: `flex-1 flex flex-col overflow-hidden ${colors.leftPaneBg} ${colors.borderColor}`
        });

        const mainContent = $("<div>", {
            class: "flex-1 flex flex-col overflow-hidden px-4 py-3"
        });

        const topRow = $("<div>", {
            class: "flex items-center justify-between gap-3 mb-3"
        });

        const searchInputWrap = $("<div>", {
            class: "relative flex-1 max-w-md"
        });

        const inputSearch = $("<input>", {
            id: "searchProduct",
            type: "text",
            placeholder: "Buscar producto o escanear...",
            class: `pl-10 py-2 pr-3 rounded-lg border ${colors.borderColor} ${isDark ? 'bg-[#1a2332]' : 'bg-white'} ${colors.textColor} w-full focus:outline-none focus:border-[#7C3AED] focus:ring-2 focus:ring-[rgba(124,58,237,0.15)]`
        }).on("input", function () {
            const keyword = $(this).val().toLowerCase();
            opts.onChange(keyword);
        });

        const searchIcon = lucideIcon('search', `absolute left-3 top-2.5 w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-500"}`);

        searchInputWrap.append(inputSearch, searchIcon);

        const buildCakeBtn = $("<button>", {
            id: "buildCakeBtn",
            class: "bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-semibold px-4 py-2 rounded-lg whitespace-nowrap transition-colors duration-200 shadow-lg shadow-[rgba(124,58,237,0.25)]",
            html: "¡Arma tu pastel! 🎂",
            click: () => opts.onBuildCake()
        });

        topRow.append(searchInputWrap, buildCakeBtn);

        // Chips estilo POS: scroll horizontal simple, sin flechas de desplazamiento.
        const categoryWrapper = $("<div>", {
            class: "flex items-center mb-3"
        });

        const categoryTabs = $("<div>", {
            id: "categoryTabs",
            class: `${colors.textColor} flex-1 overflow-x-auto scrollbar-hide`
        });

        categoryWrapper.append(categoryTabs);

        const productGridContainer = $("<div>", {
            class: "flex-1 overflow-auto"
        });

        const grid = $("<div>", {
            id: "productGrid",
            class: `grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 rounded ${colors.cardGridBg}`
        });

        productGridContainer.append(grid);

        mainContent.append(topRow, categoryWrapper, productGridContainer);
        leftPane.append(mainContent);

        const rightPane = $("<div>", {
            id: "orderPanel",
            class: `w-full md:w-[28rem] xl:w-[34rem] max-w-full flex flex-col border-l ${colors.orderPaneBg} ${colors.borderColor}`
        });

        container.append(leftPane, rightPane);
        $(`#${opts.parent}`).html(container);
    }

    createProductTabs(options) {
        const opts = Object.assign({
            parent: "categoryTabs",
            data: [
                { text: "Chocolate", id: "chocolate" },
                { text: "Frutas", id: "frutas" },
                { text: "Queso", id: "queso" },
                { text: "Merengue", id: "merengue" },
                { text: "Todos", id: "todos" }
            ],
            active: null, // Si es null, se activa el primero
            activeColor: "bg-[#7C3AED]",
            inactiveColor: "", // auto-definido por tema
            hoverColor: "",
            theme: "dark",
            onChange: (category) => { }
        }, options);

        const isDark = opts.theme === "dark";
        const activeClass = opts.activeColor;
        const inactiveClass = opts.inactiveColor || "bg-[#1a2332]";
        const hoverClass = opts.hoverColor || (isDark ? "hover:bg-white/10" : "hover:bg-gray-300");
        const containerBorder = isDark ? "border-gray-600x" : "border-gray-300x";
        const containerBg = isDark ? "xbg-[#151D2B]" : "bg-gray-100";

        const container = $(`#${opts.parent}`).empty().addClass(`flex gap-1 flex-nowrap w-max px-1.5 py-1 rounded-lg borderx ${containerBorder} ${containerBg}`);

        // Aseguramos que siempre haya uno activo
        const defaultActiveId = opts.active ?? (opts.data.length > 0 ? opts.data[0].id : null);

        opts.data.forEach((cat, index) => {
            const isActive = cat.id === defaultActiveId;

            const formattedText = cat.text.charAt(0).toUpperCase() + cat.text.slice(1).toLowerCase();

            // Contador de productos por grupo (si el backend lo envia).
            const countHtml = (cat.total !== undefined && cat.total !== null)
                ? `<span class="count-badge ml-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold leading-none ${isActive ? 'bg-white/25 text-white' : 'bg-white/10 text-gray-300'}">${cat.total}</span>`
                : '';

            const btn = $("<button>", {
                class: `tab-btn flex-shrink-0 px-3 py-1.5 rounded-lg text-[10px] font-semibold whitespace-nowrap transition-all duration-200 flex items-center gap-1.5 ${isActive ? `${activeClass} text-white border-[#7C3AED] shadow-[0_2px_8px_rgba(124,58,237,0.3)]` : `${inactiveClass} text-[#9CA3AF] border-[#374151] ${hoverClass}`}`,
                html: `<span>${formattedText}</span>${countHtml}`,
                "data-category": cat.id,
                click: function () {
                    container.find(".tab-btn").each(function () {
                        $(this)
                            .removeClass(`${activeClass} text-white border-[#7C3AED] shadow-[0_2px_8px_rgba(124,58,237,0.3)]`)
                            .addClass(`${inactiveClass} text-[#9CA3AF] border-[#374151] ${hoverClass}`);
                        $(this).find(".count-badge")
                            .removeClass("bg-white/25 text-white")
                            .addClass("bg-white/10 text-gray-300");
                    });

                    $(this)
                        .removeClass(`${inactiveClass} text-[#9CA3AF] border-[#374151] ${hoverClass}`)
                        .addClass(`${activeClass} text-white border-[#7C3AED] shadow-[0_2px_8px_rgba(124,58,237,0.3)]`);
                    $(this).find(".count-badge")
                        .removeClass("bg-white/10 text-gray-300")
                        .addClass("bg-white/25 text-white");

                    // Callback general
                    opts.onChange(cat.id);

                    // Callback individual si existe
                    if (typeof cat.onClick === "function") {
                        cat.onClick(cat.id);
                    }
                }
            });

            container.append(btn);
        });
    }

    createProductGrid(options) {
        const defaults = {
            parent: "productGrid",
            data: [],
            theme: "dark",
            icon: "star",
            onClick: (item) => { }
        };

        const opts = Object.assign(defaults, options);

        const isDark = opts.theme === "dark";
        const cardBg = isDark ? "bg-[#1F2A37]" : "bg-white";
        const imageBg = isDark ? "bg-[#141d2b]" : "bg-gray-100";
        const textColor = isDark ? "text-white" : "text-gray-800";
        const priceColor = isDark ? "text-[#76A9FA]" : "text-blue-600";

        const container = $(`#${opts.parent}`).empty();
        // Se arma el grid en un fragmento y se inserta de una sola vez: con ~180
        // productos, insertar card por card forzaba un reflow por iteracion.
        const frag = document.createDocumentFragment();

        opts.data.forEach(item => {
            // Card estilo POS (ref. app/inventarios/templates/pos-main.html): cabecera
            // de imagen + cuerpo con nombre, precio y accion. Se conservan la clase
            // .card y el <h3> del nombre porque searchFilter() los usa para filtrar.
            const card = $("<div>", {
                class: `card border-0 ${cardBg} rounded-lg overflow-hidden cursor-pointer`,
                click: () => opts.onClick(item)
            });

            const imageWrap = $("<div>", {
                class: `h-24 flex items-center justify-center relative ${imageBg}`
            });

            if (item.image && item.image.trim() !== "") {
                imageWrap.append(
                    $("<img>", {
                        src: fileUrl(item.image),
                        alt: item.name ?? item.valor,
                        // Lazy para no descargarlas todas al montar; solo cargan las
                        // visibles y el resto al hacer scroll.
                        loading: "lazy",
                        decoding: "async",
                        class: "object-cover h-full w-full",
                        on: { error: function () { fileUrlFallback(this); } }
                    })
                );
            } else {
                imageWrap.append(
                    lucideIcon((item.icon || opts.icon).replace(/^icon-/, ''), 'w-7 h-7 text-gray-500')
                );
            }

            const body = $("<div>", { class: "p-2.5" }).append(
                $("<h3>", {
                    class: `${textColor} text-[11px] font-semibold truncate leading-tight`,
                    text: item.name ?? item.valor
                }),
                $("<div>", { class: "flex items-center justify-between mt-1" }).append(
                    $("<p>", {
                        class: `${priceColor} text-xs font-bold`,
                        text: `${formatPrice(item.price)}`
                    }),
                    $("<button>", {
                        class: "w-5 h-5 rounded bg-[#1C64F2] hover:bg-[#1A56DB] flex items-center justify-center flex-shrink-0",
                        title: "Ver detalles",
                        html: lucideIcon('eye', 'w-2.5 h-2.5 text-white'),
                        click: (e) => {
                            e.stopPropagation();
                            this.showProductDetails(item.id);
                        }
                    })
                )
            );

            card.append(imageWrap, body);
            frag.appendChild(card[0]);
        });

        container[0].appendChild(frag);
    }

    createOrderPanel(options) {
        const opts = Object.assign({
            parent: "orderPanel", // ID donde se monta
            title: "Pedido",
            onClear: () => {
                // lógica externa que puedes conectar
            }
        }, options);

        const container = $(`#${opts.parent}`).empty();

        // 🧾 Header
        const header = $("<div>", {
            class: "p-4 border-b border-gray-700 flex justify-between items-center"
        }).append(
            $("<h2>", {
                class: "text-lg font-semibold text-white",
                text: opts.title
            }),
            $("<button>", {
                class: "text-red-400 border border-[#C53030] px-2 py-1 rounded hover:bg-red-700",
                html: "🗑 Limpiar",
                click: opts.onClear
            })
        );

        // 📦 Lista de productos agregados
        const orderItems = $("<div>", {
            id: "orderItems",
            class: "flex-1 overflow-auto p-3 space-y-3"
        });

        // 💰 Totales
        const totals = $("<div>", {
            class: "p-4 border-t border-gray-700 bg-[#333D4C]"
        }).append(
            $("<div>", { class: "space-y-1 text-sm text-gray-300" }).append(
                // $("<div>", { class: "flex justify-between" }).append(
                //     $("<span>").text("Subtotal:"),
                //     $("<span>", { id: "subtotal", text: "$0.00" })
                // ),
                // $("<div>", { class: "flex justify-between" }).append(
                //     $("<span>").text("IVA (16%):"),
                //     $("<span>", { id: "tax", text: "$0.00" })
                // ),
                // $("<div>", { class: "border-t my-2 border-gray-700" }),
                $("<div>", { class: "flex justify-between font-bold text-blue-400" }).append(
                    $("<span>").text("Total:"),
                    $("<span>", { id: "total", text: "$0.00" })
                )
            ),
            $("<div>", { class: "grid grid-cols-3 gap-2 mt-4" }).append(
                $("<button>", {
                    class: "border border-gray-600 text-white rounded px-3 py-2 text-sm flex items-center justify-center gap-1.5",
                    html: lucideIcon('printer', 'w-4 h-4') + ' Imprimir'
                }),

                $("<button>", {
                    id: 'finishOrder',
                    class: "bg-blue-700 text-white rounded px-3 py-2 text-sm hover:bg-blue-800",
                    html: "Terminar"
                }),

                $("<button>", {
                    id: "exitOrder",
                    class: "border border-red-600 text-red-400 rounded px-3 py-2 text-sm hover:bg-red-700 hover:text-white",
                    html: "Salir!!!"
                }),
            )
        );

        $(document).off("click", "#printOrder").on("click", "#printOrder", () => {
            if (typeof opts.onPrint === "function") opts.onPrint(opts.data);
        });

        $(document).off("click", "#exitOrder").on("click", "#exitOrder", () => {
            app.render();
        });

        $(document).off("click", "#finishOrder").on("click", "#finishOrder", () => {
            if (typeof opts.onFinish === "function") opts.onFinish(opts.data);
        });

        // 🧩 Ensamblar
        container.append(header, orderItems, totals);
    }

    renderOrderPanel(options) {
        const defaults = {
            parent: "orderPanel",
            title: "Pedido",
            data: [],
            theme: "dark",
            totalSelector: "#total",
            onClear: () => { },
            onQuanty: (id, action, newQuantity) => { },
            onEdit: (id) => { },
            onRemove: (id) => { },
            onCleared: () => { },
            onPrint: () => { },
            onExit: () => { },
            onFinish: () => { }
        };

        const opts = Object.assign({}, defaults, options);

        const isDark = opts.theme === "dark";
        const textColor = isDark ? "text-white" : "text-gray-800";
        const subColor = isDark ? "text-blue-300" : "text-blue-600";
        const borderColor = isDark ? "border-gray-700" : "border-gray-300";
        const bgCard = isDark ? "bg-[#1E293B]" : "bg-white";
        const mutedColor = isDark ? "text-gray-300" : "text-gray-600";

        const container = $(`#${opts.parent}`).empty();

        // Header
        const header = $("<div>", {
            class: "p-4 border-b border-gray-700 flex justify-between items-center"
        }).append(
            $("<h2>", {
                class: "text-lg font-semibold text-white",
                text: opts.title
            }),
            $("<button>", {
                id: "clearOrder",
                class: "text-red-400 border border-[#C53030] px-2 py-1 rounded hover:bg-red-700",
                html: "🗑 Limpiar",
                click: opts.onClear
            })
        );

        // Contenedor dinámico
        const orderItems = $("<div>", {
            id: "orderItems",
            class: "flex-1 overflow-auto p-3 space-y-3"
        });

        // Footer
        const footer = $("<div>", {
            class: "p-4 border-t border-gray-700 bg-[#333D4C]"
        }).append(
            $("<div>", { class: "space-y-1 text-sm text-gray-300" }).append(
                $("<div>", {
                    class: "flex justify-between font-bold text-blue-400"
                }).append(
                    $("<span>").text("Total:"),
                    $("<span>", { id: "total", text: "$0.00" })
                )
            ),
            $("<div>", { class: "grid grid-cols-3 gap-2 mt-4" }).append(
                $("<button>", {
                    id: "printOrder",
                    class: "border border-gray-600 text-white rounded px-3 py-2 text-sm flex items-center justify-center gap-1.5",
                    html: lucideIcon('printer', 'w-4 h-4') + ' Imprimir'
                }),
                $("<button>", {
                    id: "finishOrder",
                    class: "bg-blue-700 text-white rounded px-3 py-2 text-sm hover:bg-blue-800",
                    html: "Terminar"
                }),
                $("<button>", {
                    id: "exitOrder",
                    class: "border border-red-600 text-red-400 rounded px-3 py-2 text-sm hover:bg-red-700 hover:text-white",
                    html: "Salir"
                }),

            )
        );

        // Ensamblar panel
        container.append(header, orderItems, footer);

        // Render productos
        const data = [...opts.data];
        let totalAcc = 0;

        data.forEach((item, index) => {
            const card = $("<div>", {
                class: `flex justify-between items-center ${bgCard} border ${borderColor} rounded-xl p-3 shadow-sm`
            });

            const info = $("<div>", { class: "flex-1" }).append(
                $("<p>", { class: `${textColor} font-medium text-sm`, text: item.name }),
                $("<p>", { class: `${subColor} font-semibold text-sm`, text: formatPrice(item.price) })
            );

            const actions = $("<div>", { class: "flex flex-col items-end gap-2" });
            const quantityRow = $("<div>", { class: "flex items-center gap-2" });

            console.log('olaaaaa',item);
            quantityRow.append(
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "−",
                    click: () => {
                        if (item.quantity > 1) {
                            item.quantity--;
                            opts.onQuanty(item.id, 0, item.quantity);
                            opts.data = data;
                            this.renderOrderPanel(opts);
                        }
                    }
                }),
                $("<span>", { class: `${textColor}`, text: item.quantity }),
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "+",
                    click: () => {
                        item.quantity++;
                        opts.onQuanty(item.id, 2, item.quantity);
                        opts.data = data;
                        this.renderOrderPanel(opts);
                    }
                }),
                $("<button>", {
                    class: "text-blue-400 hover:text-blue-600",
                    html: lucideIcon('pencil'),
                    click: () => opts.onEdit(item.id)
                }),
                $("<button>", {
                    class: "text-gray-400 hover:text-red-400",
                    html: lucideIcon('trash-2'),
                    click: () => {
                        data.splice(index, 1);
                        opts.onRemove(item.id);
                        opts.data = data;
                        this.renderOrderPanel(opts);
                    }
                })
            );

            const lineTotal = (item.price || 0) * (item.quantity || 0);
            totalAcc += lineTotal;

            const totalEl = $("<p>", {
                class: `${mutedColor} text-sm`,
                text: `Total: ${formatPrice(lineTotal)}`
            });

            actions.append(quantityRow, totalEl);
            card.append(info, actions);
            orderItems.append(card);
        });

        if (opts.totalSelector) $(opts.totalSelector).text(formatPrice(totalAcc));

        // Eventos
        $(document).off("click", "#clearOrder").on("click", "#clearOrder", () => {
            opts.data = [];
            $(`#orderItems`).empty();
            this.renderOrderPanel(opts);
            if (typeof opts.onCleared === "function") opts.onCleared();
        });

        $(document).off("click", "#printOrder").on("click", "#printOrder", () => {
            if (typeof opts.onPrint === "function") opts.onPrint(opts.data);
        });

        $(document).off("click", "#exitOrder").on("click", "#exitOrder", () => {
            if (typeof opts.onExit === "function") opts.onExit();
        });

        $(document).off("click", "#finishOrder").on("click", "#finishOrder", () => {
            if (typeof opts.onFinish === "function") opts.onFinish(opts.data);
        });
    }

    renderCart(options) {

        const opts = Object.assign({
            parent: "orderItems",
            data: [],
            theme: "dark",
            totalSelector: "#total",
            onQuanty: (id, action, newQuantity) => { },
            onEdit: (id) => { },
            onRemove: (id) => { },
            onCleared: () => { }
        }, options);

        const isDark = opts.theme === "dark";
        const textColor = isDark ? "text-white" : "text-gray-800";
        const subColor = isDark ? "text-blue-300" : "text-blue-600";
        const borderColor = isDark ? "border-gray-700" : "border-gray-300";
        const bgCard = isDark ? "bg-[#1E293B]" : "bg-white";
        const mutedColor = isDark ? "text-gray-300" : "text-gray-600";
        const emptyTitle = isDark ? "text-gray-300" : "text-gray-700";
        const emptySub = isDark ? "text-gray-400" : "text-gray-500";

        const container = $(`#${opts.parent}`).empty();
        const data = [...opts.data];
        let totalAcc = 0;

        if (data.length === 0) {
            const empty = $("<div>", {
                class: "w-full h-full flex items-center justify-center"
            }).append(
                $("<div>", { class: "text-center" }).append(
                    $(`<svg xmlns="http://www.w3.org/2000/svg" class="mx-auto mb-3" width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="${isDark ? '#9CA3AF' : '#6B7280'}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h7.72a2 2 0 0 0 2-1.61L21 6H6"></path>
                </svg>`),
                    $("<p>", { class: `text-base font-medium ${emptyTitle}`, text: "No hay productos en la orden" }),
                    $("<p>", { class: `text-sm mt-1 ${emptySub}`, text: "Selecciona productos del catálogo" })
                )
            );

            container.append(empty);
            if (opts.totalSelector) $(opts.totalSelector).text(formatPrice(0));

            $(document).off("click", "#clearOrder").on("click", "#clearOrder", () => {
                opts.data = [];
                this.renderCart(opts);
                if (typeof opts.onCleared === "function") opts.onCleared();
            });

            return;
        }

        data.forEach((item, index) => {
            const card = $("<div>", {
                class: `flex justify-between items-center ${bgCard} border ${borderColor} rounded-xl p-3 shadow-sm`
            });

            const info = $("<div>", { class: "flex-1 space-y-1" }).append(
                $("<p>", { class: `${textColor} font-medium text-sm`, text: item.name }),
                $("<p>", { class: `${subColor} font-semibold text-sm`, text: formatPrice(item.price) }),
                item.dedication ? $("<p>", { class: `${mutedColor} text-xs italic`, text: `Dedicatoria: ${item.dedication}` }) : null,
                item.order_details ? $("<p>", { class: `${mutedColor} text-xs`, text: `Observación: ${item.order_details}` }) : null
            );

            const actions = $("<div>", { class: "flex flex-col items-end gap-2" });
            const quantityRow = $("<div>", { class: "flex items-center gap-2" });

            quantityRow.append(
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "−",
                    click: () => {
                        if (item.quantity > 1) {
                            item.quantity--;
                            opts.onQuanty(item.id, 0, item.quantity);
                            opts.data = data;
                            this.renderCart(opts);
                        }
                    }
                }),
                $("<span>", { class: `${textColor}`, text: item.quantity }),
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "+",
                    click: () => {
                        item.quantity++;
                        opts.onQuanty(item.id, 2, item.quantity);
                        opts.data = data;
                        this.renderCart(opts);
                    }
                }),
                $("<button>", {
                    class: "text-blue-400 hover:text-blue-600",
                    html: lucideIcon('pencil'),
                    click: (e) => {
                        e.stopPropagation();
                        if (typeof opts.onEdit === "function") opts.onEdit(item.id);
                    }
                }),
                $("<button>", {
                    class: "text-gray-400 hover:text-red-400",
                    html: lucideIcon('trash-2'),
                    click: () => {
                        data.splice(index, 1);
                        opts.onRemove(item.id);
                        opts.data = data;
                        this.renderCart(opts);
                    }
                })
            );

            const lineTotal = (item.price || 0) * (item.quantity || 0);
            totalAcc += lineTotal;

            const totalEl = $("<p>", {
                class: `${mutedColor} text-sm`,
                text: `Total: ${formatPrice(lineTotal)}`
            });

            actions.append(quantityRow, totalEl);
            card.append(info, actions);
            container.append(card);
        });

        if (opts.totalSelector) $(opts.totalSelector).text(formatPrice(totalAcc));

        $(document).off("click", "#clearOrder").on("click", "#clearOrder", () => {
            opts.data = [];
            this.renderCart(opts);
            if (typeof opts.onCleared === "function") opts.onCleared();
        });
    }

    orderPanelComponent(options) {
        const defaults = {
            parent: "root",
            id: "orderPanel",
            title: "Pedido",
            data: [],
            theme: "dark",
            totalSelector: "#total",
            emptyTitle: "No hay productos en la orden",
            emptySub: "Selecciona productos del catálogo para continuar.",
            discount: 0,
            onClear: () => { },
            onQuanty: (id, action, newQuantity) => { },
            onEdit: (id) => { },
            onRemove: (id) => { },
            onForceRemove: (item) => { },
            onCleared: () => { },
            onPrint: () => { },
            onExit: () => { },
            onFinish: () => { },
            onBuildCake: () => { armarPastel(); },
            payments: [],
            totalPaid: 0,
            isEdit: false,
            isPaid: false,
            // Baja autorizada de una linea bloqueada: solo admin y supervisor.
            canForceRemove: false,
            animateId: null
        };

        
        const opts = Object.assign({}, defaults, options);

        // Animacion de aparicion de la linea nueva, identica al cart de la plantilla
        // (pos-main.html): slideIn 0.15s desde la derecha. Guard por id.
        if (opts.animateId != null && !document.getElementById('pos-cart-anim-style')) {
            const st = document.createElement('style');
            st.id = 'pos-cart-anim-style';
            st.textContent = '@keyframes posCartSlideIn{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}.pos-cart-in{animation:posCartSlideIn .15s ease}';
            document.head.appendChild(st);
        }

        // Lineas "bloqueadas": en edicion, un producto solo es editable si se agrego
        // HOY (item.is_today lo marca el backend). Las lineas de dias anteriores van
        // de solo lectura: sin −/+ y sin editar. En un pedido liquidado va bloqueado
        // todo el armado: subir una cantidad tambien es agregar producto. La unica
        // excepcion es la baja autorizada (canForceRemove), que sigue otro camino.
        const isLocked = (item) => opts.isPaid || (opts.isEdit && item.is_today === false);

        const isDark = opts.theme === "dark";
        const textColor = isDark ? "text-white" : "text-gray-800";
        const subColor = isDark ? "text-[#76A9FA]" : "text-blue-600";
        const borderColor = isDark ? "border-[rgba(55,65,81,0.5)]" : "border-gray-300";
        const bgCard = isDark ? "bg-[#1a2332]" : "bg-white";
        const mutedColor = isDark ? "text-gray-400" : "text-gray-600";
        const emptyTitle = isDark ? "text-gray-300" : "text-gray-700";
        const emptySub = isDark ? "text-gray-400" : "text-gray-500";

        const container = $(`#${opts.parent}`).empty();

        const header = $("<div>", {
            class: "px-4 py-3 border-b border-[#374151] flex justify-between items-center flex-shrink-0"
        }).append(
            $("<div>", { class: "flex flex-col min-w-0" }).append(
                $("<h2>", { class: "text-sm font-bold text-white truncate", text: opts.title }),
                $("<h3>", {
                    class: "text-[10px] text-[#6B7280] mt-0.5 truncate",
                    html: lucideIcon('user', 'w-3 h-3 inline-block') + ' ' + opts.customName || "Cliente no definido"
                },)
            ),
            opts.isEdit ? null : $("<button>", {
                id: "clearOrder",
                class: "flex-shrink-0 text-red-400 bg-[#1a2332] px-2 py-1 rounded-lg text-xs hover:bg-red-800 hover:text-white transition-colors",
                html: "🗑 Limpiar"
            })
        );

        const orderItems = $("<div>", {
            id: "orderItems",
            class: "flex-1 overflow-auto p-3 space-y-3"
        });

        const lineCount = (opts.data || []).length;

        const footer = $("<div>", {
            class: "px-4 py-3 border-t border-[#374151] flex-shrink-0"
        }).append(
            $("<div>", { class: "space-y-1.5 text-xs text-gray-400" }).append(
                $("<div>", { class: "flex justify-between items-center mb-2" }).append(
                    $("<span>", {
                        class: "text-[10px] font-semibold tracking-[0.14em] uppercase text-[#c4b5fd]",
                        text: "Resumen de pago"
                    }),
                    $("<span>", {
                        id: "lineCount",
                        class: "text-[10px] text-[#6B7280] tabular-nums",
                        text: `${lineCount} ${lineCount === 1 ? 'línea' : 'líneas'}`
                    })
                ),
                $("<div>", {
                    class: "flex justify-between"
                }).append(
                    $("<span>").text("Subtotal"),
                    $("<span>", { id: "subtotal", class: "text-white font-semibold tabular-nums", text: "$0.00" })
                ),
                $("<div>", {
                    id: "discountRow",
                    class: "flex justify-between",
                    css: { display: "none" }
                }).append(
                    $("<span>").text("Descuento"),
                    $("<span>", { id: "discountAmount", class: "text-[#fbbf24] font-semibold tabular-nums", text: "-$0.00" })
                ),
                $("<div>", {
                    id: "pagadoRow",
                    class: "flex justify-between",
                    css: { display: "none" }
                }).append(
                    $("<span>").text("Pagado"),
                    $("<span>", { id: "pagado", class: "text-[#3FC189] font-semibold tabular-nums", text: "$0.00" })
                ),
                $("<div>", {
                    id: "saldoRow",
                    class: "flex justify-between items-center pt-2 mt-1 border-t border-[#374151]"
                }).append(
                    $("<span>", { class: "text-white font-bold" }).text("Saldo"),
                    $("<span>", { id: "saldo", class: "text-white font-bold text-base tabular-nums", text: "$0.00" })
                )
            ),
            $("<div>", { class: "grid grid-cols-[1fr_1.2fr_0.8fr] gap-2 mt-3" }).append(
                $("<button>", {
                    id: "printOrder",
                    class: "bg-[#1a2332] text-[#9CA3AF] rounded-lg px-2 py-2 text-xs hover:bg-white/10 hover:text-white transition-colors flex items-center justify-center gap-1.5",
                    html: lucideIcon('printer', 'w-3.5 h-3.5 text-[#76A9FA]') + ' Imprimir'
                }),
                $("<button>", {
                    id: "finishOrder",
                    class: "bg-[#1C64F2] text-white font-semibold rounded-lg px-2 py-2 text-xs hover:bg-[#1a53d4] shadow-lg shadow-[rgba(28,100,242,0.25)] transition-colors flex items-center justify-center gap-1.5",
                    html: lucideIcon('check', 'w-3.5 h-3.5') + ' Terminar'
                }),
                $("<button>", {
                    id: "exitOrder",
                    class: "bg-[#1a2332] text-[#9CA3AF] rounded-lg px-2 py-2 text-xs hover:bg-white/10 hover:text-white transition-colors flex items-center justify-center gap-1.5",
                    html: lucideIcon('log-out', 'w-3.5 h-3.5 text-red-400') + ' Salir'
                })
            )
        );

        // Pedido con dinero cobrado y sin ninguna linea repetida: no hay nada que dar
        // de baja, asi que el panel ocupa el lugar del boton explicando que sigue.
        const paidNote = (opts.isPaid && opts.canForceRemove && !(opts.data || []).some(item => item.is_repeated))
            ? $("<div>", {
                class: "mx-3 mb-3 p-3 bg-[#1a2332] border border-[#374151] rounded-lg flex-shrink-0",
                css: { borderLeftWidth: "2px", borderLeftColor: "#76A9FA" }
            }).append(
                $("<p>", { class: "text-xs font-semibold text-white", text: "Este pedido ya cuadra" }),
                $("<p>", {
                    class: "text-[11px] text-gray-400 mt-1 leading-relaxed",
                    text: `No puede quedar en un monto menor a los ${formatPrice(opts.totalPaid)} que el cliente ya pagó. `
                        + `Si aun así hay que corregirlo, cancela el folio y genera uno nuevo.`
                })
            )
            : null;

        container.append(header, orderItems, paidNote, footer);

        const data = [...opts.data];
        let totalAcc = 0;

        if (data.length === 0) {
            const empty = $("<div>", {
                class: "w-full h-full flex items-center justify-center"
            }).append(
                $("<div>", { class: "text-center" }).append(
                    $(`<svg xmlns="http://www.w3.org/2000/svg" class="mx-auto mb-3" width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="${isDark ? '#9CA3AF' : '#6B7280'}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h7.72a2 2 0 0 0 2-1.61L21 6H6"></path>
                </svg>`),
                    $("<p>", { class: `text-base font-medium ${emptyTitle}`, text: opts.emptyTitle }),
                    $("<p>", { class: `text-sm mt-1 ${emptySub}`, text: opts.emptySub })
                )
            );
            orderItems.append(empty);
            if (opts.totalSelector) $(opts.totalSelector).text(formatPrice(0));
            return;
        }

        data.forEach((item, index) => {


            const card = $("<div>", {
                class: `order-line flex justify-between items-center gap-2 ${bgCard} rounded-lg p-2.5${String(opts.animateId) === String(item.id) ? ' pos-cart-in' : ''}`
            });

            const infoElements = [
                $("<p>", { class: `${textColor} font-medium text-xs`, text: item.name }),
                $("<p>", { class: `${subColor} font-semibold text-xs`, text: formatPrice(item.price) }),
                item.custom_id ? $("<span>", { class: "inline-flex items-center text-xs font-bold text-purple-400", text: "Personalizado" }) : null,
                item.dedication ? $("<p>", { class: `${mutedColor} text-xs italic`, text: `Dedicatoria: ${item.dedication}` }) : null,
                item.order_details ? $("<p>", { class: `${mutedColor} text-xs`, text: `Detalles: ${item.order_details}` }) : null,
                item.images && item.images.length > 0
                    ? $("<p>", {
                        class: `text-gray-400 text-xs`,
                        html: `${lucideIcon('camera', 'w-4 h-4 inline-block')} Pedido con ${item.images.length} foto${item.images.length > 1 ? 's' : ''} adjunta${item.images.length > 1 ? 's' : ''}`
                    })
                    : null
            ];

            const info = $("<div>", { class: "flex-1 space-y-1" }).append(...infoElements.filter(el => el !== null));

            const actions = $("<div>", { class: "flex flex-col items-end gap-2" });
            const quantityRow = $("<div>", { class: "flex items-center gap-2" });

            const locked = isLocked(item);

            const quantityInput = $("<input>", {
                type: "number",
                class: `${textColor} bg-transparent border border-[#374151] rounded text-center w-12 focus:outline-none focus:border-[#7C3AED]${locked ? ' opacity-60 cursor-not-allowed' : ''}`,
                value: item.quantity,
                min: 1,
                readonly: locked
            });

            const self = this;

            if (!locked) {

                quantityInput.on("focus", function() {
                    $(this).select();
                });

                quantityInput.on("keyup", function(e) {
                    const $input = $(this);
                    const val = $input.val().replace(/[^0-9]/g, '');

                    if ($input.val() !== val) {
                        $input.val(val);
                    }

                    let newQty = parseInt(val, 10);
                    if (!isNaN(newQty) && newQty >= 1) {
                        item.quantity = newQty;

                        const lineTotal = (item.price || 0) * newQty;
                        $input.closest('.order-line').find('p').last().text(`Total: ${formatPrice(lineTotal)}`);

                        let total = 0;
                        data.forEach(i => total += (i.price || 0) * (i.quantity || 0));
                        if (opts.totalSelector) $(opts.totalSelector).text(formatPrice(total));
                    }
                });

                quantityInput.on("focusout", function() {
                    const $input = $(this);
                    let newQty = parseInt($input.val(), 10);
                    if (isNaN(newQty) || newQty < 1) {
                        newQty = 1;
                        $input.val(1);
                        item.quantity = 1;
                    }
                    opts.onQuanty(item.id, 1, item.quantity);
                });
            }

            // Linea de un dia anterior: cantidad fija, solo input de lectura (sin −/+).
            const buttons = locked ? [quantityInput] : [
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "−",
                    click: () => {
                        if (item.quantity > 1) {
                            item.quantity--;
                            opts.onQuanty(item.id, 0, item.quantity);
                            opts.data = data;
                            this.orderPanelComponent(opts);
                        }
                    }
                }),
                quantityInput,
                $("<button>", {
                    class: "w-6 h-6 rounded bg-[#374151] hover:bg-[#4B5563] text-white flex items-center justify-center transition-colors",
                    html: "+",
                    click: () => {
                        item.quantity++;
                        opts.onQuanty(item.id, 2, item.quantity);
                        opts.data = data;
                        this.orderPanelComponent(opts);
                    }
                })
            ];

            // Editar (dedicatoria / observaciones): disponible tambien en lineas
            // bloqueadas; ahi lo unico que queda fijo es la cantidad.
            buttons.push(
                $("<button>", {
                    class: "text-[#c4b5fd] hover:text-white transition-colors",
                    html: lucideIcon('pencil'),
                    click: () => {
                        // Detectar si es pedido personalizado o normal
                        if (item.custom_id) {
                            opts.onCake(item.id, item.custom_id);
                        } else {
                            opts.onEdit(item.id);
                        }
                    }
                })
            );

            // Eliminar: en una linea de hoy es parte del armado y se aplica directo.
            // En una bloqueada (dia anterior o pedido liquidado) deja de ser armado y
            // pasa por confirmacion con motivo, asi que aqui no se toca la lista: el
            // panel se repinta con lo que responda el backend, que puede negarla.
            if (!locked) {
                buttons.push(
                    $("<button>", {
                        class: "text-gray-400 hover:text-red-400 transition-colors",
                        html: lucideIcon('trash-2'),
                        click: () => {
                            data.splice(index, 1);
                            opts.onRemove(item.id);
                            opts.data = data;
                            this.orderPanelComponent(opts);
                        }
                    })
                );
            } else if (opts.canForceRemove && item.is_repeated) {
                buttons.push(
                    $("<button>", {
                        class: "text-red-400 hover:text-red-500 transition-colors",
                        title: "Eliminar esta partida (requiere motivo)",
                        html: lucideIcon('trash-2'),
                        click: () => opts.onForceRemove(item)
                    })
                );
            }

            quantityRow.append(...buttons);

            const lineTotal = (item.price || 0) * (item.quantity || 0);
            totalAcc += lineTotal;

            const totalEl = $("<p>", {
                class: `${mutedColor} text-xs `,
                text: `Total: ${formatPrice(lineTotal)}`
            });

            actions.append(quantityRow, totalEl);
            card.append(info, actions);
            orderItems.append(card);
        });

        // Solo la linea nueva se anima; los re-render internos de los +/- reutilizan
        // este opts, asi que se apaga tras pintar para no re-animarla al cambiarla.
        opts.animateId = null;

        if (opts.totalSelector) {
            const subtotal = totalAcc;
            const discount = parseFloat(opts.discount) || 0;
            const finalTotal = subtotal - discount;
            const totalPaid = parseFloat(opts.totalPaid) || 0;
            const saldo = finalTotal - totalPaid;
            
            $('#subtotal').text(formatPrice(subtotal));
            
            if (discount > 0) {
                $('#discountRow').show();
                $('#discountAmount').text(`-${formatPrice(discount)}`);
            }
            
            if (totalPaid > 0) {
                $('#pagadoRow').show();
                $('#pagado').text(formatPrice(totalPaid));
            }
            
            const $saldo = $('#saldo').removeClass('text-red-400 text-[#3FC189] text-white');

            if (saldo > 0) {
                $('#saldoRow').show();
                $saldo.text(formatPrice(saldo)).addClass('text-red-400');
            } else if (saldo <= 0 && totalPaid > 0) {
                $('#saldoRow').show();
                $saldo.text(formatPrice(0)).addClass('text-[#3FC189]');
            } else {
                $saldo.text(formatPrice(finalTotal)).addClass('text-white');
            }
        }

        // 🔁 Delegación segura para botones
        const $orderPanel = $(`#${opts.parent}`);
        $orderPanel.off("click", "#clearOrder").on("click", "#clearOrder", () => {
            if (typeof opts.onClear === "function") opts.onClear();
        });
        $orderPanel.off("click", "#printOrder").on("click", "#printOrder", () => {
            if (typeof opts.onPrint === "function") opts.onPrint(opts.data);
        });
        $orderPanel.off("click", "#exitOrder").on("click", "#exitOrder", () => {
            if (typeof opts.onExit === "function") opts.onExit();
        });
        $orderPanel.off("click", "#finishOrder").on("click", "#finishOrder", () => {
            if (typeof opts.onFinish === "function") opts.onFinish(opts.data);
        });
    }

    // auxiliares.
    searchFilter(options) {
        const opts = Object.assign({
            parent: "searchProduct",
            gridId: "productGrid",
            selector: ".card",
            targetTextSelector: "h3"

        }, options);

        const input = $(`#${opts.parent}`);
        const grid = document.querySelector(`#${opts.gridId}`);

        console.log(input, grid);

        if (!input.length || !grid) return;

        const search = () => {
            const keyword = input.val().toLowerCase().trim();
            const cards = grid.querySelectorAll(opts.selector);

            cards.forEach(card => {
                const label = card.querySelector(opts.targetTextSelector)?.textContent.toLowerCase() || "";
                card.style.display = label.includes(keyword) ? "" : "none";
            });
        };

        input.off("input").on("input", search);
    }

}

class CatalogProduct extends Pos {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "CatalogProduct";
        this.name_client = '';
        this.discount  = '';
        this.layoutEdit = false;
        // Pedido liquidado en edicion: el armado queda congelado (catalogo y cobro
        // bloqueados) y solo siguen abiertos los datos de entrega del formulario.
        this.layoutPaid = false;
        // Snapshot de cantidades originales por linea (order_package.id -> quantity)
        // al abrir la edicion de un pedido; en edicion no se permite bajar de ahi.
        this.originalQuantities = null;
    }

    init() {
        this.render();
    }

    render() {
        // Crear/editar pedido: se oculta el selector de sucursal del navbar. La
        // sucursal del pedido la define el selector del formulario (#subsidiaryFilter
        // -> #subsidiaries_id). Al volver al listado, App.render() lo vuelve a mostrar.
        $('#navbarBranchControl').addClass('hidden');
        this.layout();
        this.formCreateOrder();
        this.layoutPos();
    }

    layout() {
        // Shell POS full-viewport (ref. app/inventarios/templates/pos-main.html):
        // sin primaryLayout (filterBar/card). Altura = viewport menos el mt-16 del
        // navbar y el p-3 de #mainContainer (64 + 24 px = 5.5rem). La cadena
        // flex-1/min-h-0 baja hasta el POS para que sus paneles llenen y scrolleen
        // internamente, sin scroll de pagina.
        $('#root').html(`
            <div id="${this.PROJECT_NAME}" class="flex flex-col h-[calc(100vh-5.5rem)] overflow-hidden">
                <div id="container${this.PROJECT_NAME}" class="flex-1 min-h-0 flex flex-col overflow-hidden"></div>
            </div>
        `);
    }

    formCreateOrder() {

        const isEditMode = this.layoutEdit;



        this.tabLayout({
            parent: "container" + this.PROJECT_NAME,
            id: "tabsPedido",
            theme: "dark",
            type: 'short',
            // Continua la cadena flex del shell: el contenido llena el alto restante
            // y cada tab decide su propio scroll (form: auto; POS: paneles internos).
            content: { class: "flex-1 min-h-0 overflow-hidden" },
            json: [
                {
                    id: "pedido",
                    tab: isEditMode ? "Información del pedido" : "Crear orden de pedido",
                    // En un pedido liquidado el catalogo va bloqueado, asi que la vista
                    // abre en la informacion del pedido, que es lo unico editable.
                    active: !isEditMode || this.layoutPaid
                },
                {
                    id: "package",
                    tab: "Catálogo de productos",
                    active: isEditMode && !this.layoutPaid
                }
            ]
        });

        // El tab del formulario scrollea por si mismo (sin fondo: hereda el de la
        // pagina) y con padding horizontal mas amplio que el p-3 del tabLayout.
        // El del POS va full-bleed (sin el p-3 del tabLayout, sus paneles ya
        // manejan su overflow interno).
        $('#container-pedido').addClass('overflow-y-auto px-12');
        $('#container-package').removeClass('p-3').addClass('overflow-hidden');

        app.addOrder();
    }

    // System Pos.

    layoutPos() {


        if (!idFolio) {
            // Placeholder sin orden activa: sin fondo (hereda el de la pagina),
            // centrado en el alto disponible del tab e iconos Lucide (helper
            // lucideIcon de lucide-icons.js). El CTA lleva al tab del formulario.
            $("#container-package").html(`
             <div class="w-full h-full flex items-center justify-center">
                <div class="text-center max-w-sm px-4">
                    <div class="mx-auto mb-4 w-24 h-24 rounded-full flex items-center justify-center bg-[rgba(124,58,237,0.12)] text-[#c4b5fd]">
                        ${lucideIcon('cake', 'w-10 h-10')}
                    </div>
                    <h2 class="text-base font-bold text-white">Sin órdenes activas</h2>
                    <p class="text-xs text-[#9CA3AF] mt-2 leading-relaxed">
                        Para agregar productos al carrito primero necesitas iniciar una nueva orden.
                    </p>
                    <button id="btnNuevaOrden"
                        class="mt-5 inline-flex items-center gap-2 bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-xs font-bold px-4 py-2 rounded-lg shadow-lg shadow-[rgba(124,58,237,0.25)] transition-colors">
                        ${lucideIcon('circle-plus', 'w-4 h-4')} Iniciar nueva orden
                    </button>
                </div>
            </div>
            `);
            $('#btnNuevaOrden').on('click', () => $('#tab-pedido').trigger('click'));
            return;
        }

        this.createPOSContainers({
            parent: "container-package",
            id: "pedido",
            theme: 'dark',
            onChange: (item) => {
                this.searchFilter({ parent: 'searchProduct' })
            }
        });

        this.initPos();
    }

    async initPos() {

        const pos = await useFetch({ url: this._link, data: { opc: "init", id: idFolio } });

        if (!pos) {
            console.error("Error: No se pudo cargar la información del catálogo", pos);
            $("#productGrid").html(`
                <div class="col-span-full text-center text-gray-400 py-10">
                    ${lucideIcon('circle-alert', 'w-7 h-7 mb-2')}
                    <p>No se pudieron cargar los productos. Intenta recargar.</p>
                </div>
            `);
            return;
        }

        this.name_client = pos.order?.name ?? '';
        this.discount = pos.order?.discount ?? '';
        this.folio = pos.order?.folio ?? '';
        this.payments = pos.payments ?? [];
        this.total_paid = pos.total_paid ?? 0;
        // Admin (1) y supervisor (6) son los unicos que pueden dar de baja una linea
        // que el armado ya no toca. El backend lo revalida en removeProduct().
        this.rolId = pos.rolId ?? 0;

        // Solo la primera carga en edicion: initPos vuelve a correr tras guardar el
        // formulario y no debe pisar el snapshot con cantidades ya modificadas.
        if (this.layoutEdit && !this.originalQuantities) {
            this.originalQuantities = new Map(
                (pos.list || []).map(i => [i.id, parseInt(i.quantity, 10)])
            );
        }

        this.createProductTabs({
            data: pos.modifier || [],
            onChange: (category) => {
                this.listProduct(category)
            }
        });

        // Products.

        this.createProductGrid({
            data: pos.products || [],
            onClick: (item) => {
                if (this.layoutPaid) return;
                this.addProduct(item.id)
            }
        });


        this.showOrder(pos.list || [])

        // Al final: showOrder repinta el panel (y con el, el boton Terminar), asi que
        // el bloqueo se aplica despues de que existan los dos lados del POS.
        if (this.layoutPaid) this.lockPaidCatalog();
    }

    // Pedido liquidado: el armado ya se cobro y no admite productos nuevos, asi que
    // el catalogo entero (buscador, categorias, grid y armado de pastel) queda de
    // solo lectura y el cobro deja de aplicar.
    lockPaidCatalog() {
        $('#productGrid, #categoryTabs').addClass('opacity-50 pointer-events-none');

        $('#searchProduct, #buildCakeBtn')
            .prop('disabled', true)
            .addClass('opacity-50 cursor-not-allowed pointer-events-none');

        $('#finishOrder')
            .prop('disabled', true)
            .attr('title', 'El pedido ya está liquidado')
            .removeClass('hover:bg-[#1a53d4]')
            .addClass('opacity-50 cursor-not-allowed pointer-events-none');
    }

    showOrder(list, animateId = null) {

        this.orderPanelComponent({
            title: this.folio ? `Pedido ${this.folio}` : "Pedido nuevo",
            parent: "orderPanel",
            animateId: animateId,
            discount: this.discount,
            customName: this.name_client,
            data: list,
            payments: this.payments,
            totalPaid: this.total_paid,

            onFinish: (data) => {
                console.log('finish')
                this.addPayment();
            },
            onEdit: (id) => {
                this.editProduct(id);
            },
            onRemove: (id) => {
                this.removeProduct(id);
            },
            onForceRemove: (item) => {
                this.confirmRemoveLine(item);
            },
            onQuanty: (id, action, newQuantity) => {
                this.quantityProduct(id, newQuantity);
            },
            isEdit: this.layoutEdit,
            isPaid: this.layoutPaid,
            canForceRemove: this.layoutEdit && (this.rolId == 1 || this.rolId == 6),
            onPrint: () => {
                this.printOrder(idFolio);
            },

            onExit: () => {
                app.render();
            },

            onClear: () => {
                // Un pedido existente no se vacia (el boton Limpiar va oculto en edicion).
                if (this.layoutEdit && this.originalQuantities?.size) return;
                this.confirmClearOrder(idFolio);
            },

            onCake: (productId, pedidoCustomId) => {
                // Abrir modal de edición del pastel personalizado
                custom.renderEdit(productId, pedidoCustomId);
            },
        });

    }

    // Product.

    async listProduct(id) {

        const pos = await useFetch({ url: this._link, data: { opc: "lsProducto", id: id } });

        this.createProductGrid({
            data: pos.products,
            onClick: (item) => {
                this.addProduct(item.id)
            }
        });


    }

    async addProduct(product_id) {

        const pos = await useFetch({
            url: this._link,
            data: {
                opc: "addProduct",
                quantity: 1,
                pedidos_id: idFolio,
                product_id: product_id
            }
        });

        // Solo la linea recien agregada se anima: es la de mayor id (autoincrement
        // del INSERT que hace addProduct en el backend).
        const list = pos.list || [];
        const newId = list.length ? Math.max(...list.map(i => parseInt(i.id, 10))) : null;
        this.showOrder(list, newId);
    }

    async removeProduct(id) {
        const pos = await useFetch({
            url: this._link,
            data: {
                opc: "removeProduct",
                pedidos_id: idFolio,
                id: id,
                // Solo se registra en bitacora si es edicion; al crear no (armado inicial).
                isEdit: this.layoutEdit ? 1 : 0
            }
        });

        // El panel ya quito la linea al pulsar, sin esperar respuesta. Si el backend
        // la niega (dejaria el pedido valiendo menos de lo cobrado) hay que devolverla
        // a la vista, o el ticket mostraria un total que la BD no tiene.
        if (pos?.status != 200) {
            alert({
                icon:  'info',
                title: 'No se eliminó',
                text:  pos?.message || 'No se pudo eliminar el producto del pedido.',
                btn1:  true
            });

            // Sin lista fiable no se repinta: dejaria el ticket vacio por un fallo de red.
            if (Array.isArray(pos?.list)) this.showOrder(pos.list);
        }
    }

    // Baja de una linea que el armado ya no toca (de un dia anterior, o de un pedido
    // liquidado). El motivo es la razon de ser del modal: sin el, removeProduct() la
    // rechaza, y con el queda en la bitacora junto al usuario que la autorizo.
    confirmRemoveLine(item) {

        createCoffeeModalForm({
            id: 'frmRemoveLine',
            title: 'Eliminar partida',
            iconSvg: lucideIcon('trash-2', 'w-5 h-5'),
            iconBg: 'bg-red-600',
            theme: 'dark',
            width: 380,
            confirmText: 'Eliminar',
            cancelText: 'Cancelar',
            confirmBg: 'bg-red-600 hover:bg-red-700',
            json: [
                {
                    opc: 'html',
                    html: `
                    <div class="bg-[#1E293B] rounded-lg p-3 space-y-1">
                        <p class="text-white font-semibold text-sm uppercase">${item.name || 'Partida'}</p>
                        <p class="text-gray-400 text-xs">${formatPrice(item.price)} × ${item.quantity}</p>
                        <p class="text-gray-400 text-xs">
                            Cobrado hasta ahora:
                            <span class="text-[#3FC189] font-bold">${formatPrice(this.total_paid)}</span>
                        </p>
                        <p class="text-amber-400 text-xs pt-1">
                            El pedido no puede quedar valiendo menos de lo ya cobrado.
                        </p>
                    </div>`
                },
                {
                    opc:         'text',
                    id:          'reason',
                    lbl:         'Motivo de la eliminación',
                    placeholder: 'Ej: PASTEL CAPTURADO DOS VECES',
                    required:    true
                }
            ],
            onConfirm: async (data, modal) => {
                const response = await useFetch({
                    url: this._link,
                    data: {
                        opc:        'removeProduct',
                        pedidos_id: idFolio,
                        id:         item.id,
                        isEdit:     1,
                        reason:     data.reason
                    }
                });

                modal.close();

                if (response.status != 200) {
                    alert({
                        icon:  'error',
                        title: 'No se eliminó',
                        text:  response.message,
                        btn1:  true
                    });

                    return;
                }

                alert({
                    icon:  'success',
                    title: 'Partida eliminada',
                    text:  response.message,
                    btn1:  true
                });

                this.showOrder(response.list || []);
            }
        });
    }

    confirmClearOrder(id) {

        this.swalQuestion({
            opts: {
                title: "¿Desea eliminar todos los productos del ticket?",
                text: "Esta acción vaciará el pedido actual.",
                icon: "warning"
            },
            data: {
                opc: "deleteAllProducts",
                pedidos_id: idFolio,
                // Solo se registra en bitacora si es edicion; al crear no (armado inicial).
                isEdit: this.layoutEdit ? 1 : 0
            },
            methods: {
                send: (response) => {
                    if (response?.status == 200) {
                        alert({ icon: "success", text: response.message || "Ticket limpiado." });

                        this.renderCart({
                            data: response.list,
                            onEdit: (id) => {
                                console.log('edit', id);
                                this.editProduct(id);
                            },
                            onRemove: (id) => {
                                this.removeProduct(id);
                            }
                        });

                    } else {
                        alert({ icon: "info", title: "Oops!...", text: response?.message || "No se pudo limpiar el ticket." });
                    }
                }
            }
        });
    }

    async editProduct(id) {
        const request = await useFetch({
            url: this._link,
            data: {
                opc: "getProduct",
                id: id
            }
        });

        let product = request.data;
        const isCustom = product.custom_id && product.custom_id !== null && product.custom_id !== '';

        const modal = bootbox.dialog({
            closeButton: true,
            title: `<h2 class="text-lg "> 🎂 ${product.name} </h2>`,
            message: `<div><form id="formEditProducto" novalidate></form></div>`
        });

        const formFields = [
            {
                opc: "input",
                id: "dedication",
                lbl: "dedicatoria",
                class: "col-12  mb-3",
            },
            {
                opc: "textarea",
                id: "order_details",
                lbl: "Observaciones",
                class: "col-12 mb-3",
                height: 32,
                disabled: true
            }
        ];

        if (isCustom) {
            formFields.push({
                opc: "div",
                id: "image",
                lbl: "Imagenes de referencia del producto",
                class: "col-12 ",
                html: `
                    <div class="col-12 mt-2 mb-2">
                        <div class="w-full p-2 border-2 border-dashed border-gray-500 rounded-xl text-center">
                            <input
                                type="file"
                                id="archivos"
                                name="archivos"
                                class="hidden"
                                multiple
                                accept="image/*"
                                onchange="normal.previewImages(this, 'previewImagenes')"
                            >
                            <div class="flex flex-col items-center justify-center py-2 cursor-pointer" onclick="document.getElementById('archivos').click()">
                                <div class="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center mb-2">
                                    ${lucideIcon('upload', 'w-4 h-4 text-white')}
                                </div>
                                <p class="text-xs">Drag & Drop or <span class="text-purple-400 underline">choose file</span></p>
                                <p class="text-[10px] text-gray-400 mt-1">JPEG, PNG</p>
                            </div>
                            <div id="previewImagenes" class="flex gap-2 flex-wrap mt-1"></div>
                        </div>
                    </div>
                `
            });
        }

        formFields.push({
            opc: "button",
            id: "btnEditProducto",
            class: "col-12 ",
            className: "w-full p-2",
            text: "Actualizar Producto",
            onClick: () => {

                const form = document.getElementById('formEditProducto');
                const formData = new FormData(form);

                formData.append('opc', 'editProduct');
                formData.append('id', id);
                formData.append('idFolio', idFolio);

                if (isCustom) {
                    const files = document.getElementById('archivos').files;
                    for (let i = 0; i < files.length; i++) {
                        formData.append('archivos[]', files[i]);
                    }
                }

                fetch(this._link, {
                    method: 'POST',
                    body: formData
                })
                    .then(response => response.json())
                    .then(response => {

                        if (response.status === 200) {

                            this.showOrder(response.list);

                            modal.modal('hide');
                            alert({ icon: "success", text: response.message });

                        } else {

                            alert({ icon: "info", title: "Oops!...", text: response.message, btn1: true, btn1Text: "Ok" });
                        }
                    });
            }
        });

        this.createForm({
            id: 'formEditProductoInternal',
            parent: 'formEditProducto',
            autovalidation: false,
            autofill: product,
            data: { opc: 'editProduct', id: id },
            json: formFields
        });

        if (isCustom) {
            this.renderImages(request.images, 'previewImagenes');
        }
    }

    async quantityProduct(packageId, newQuantity) {
        const response = await useFetch({
            url: this._link,
            data: {
                opc: "quantityProduct",
                id: packageId,
                quantity: newQuantity,
                pedidos_id: idFolio,
                // Solo se registra en bitacora si es edicion; al crear no (armado inicial).
                isEdit: this.layoutEdit ? 1 : 0
            }
        });
        this.showOrder(response.list)
    }

    // aux method.
    previewImages(input, previewId) {

        const previewContainer = document.getElementById(previewId);
        previewContainer.innerHTML = "";

        Array.from(input.files).forEach(file => {
            if (file.type.startsWith("image/")) {
                const reader = new FileReader();
                reader.onload = (e) => {

                    const img = document.createElement("img");
                    img.src = e.target.result;

                    img.classList.add("w-28", "h-28", "object-cover", "rounded");
                    previewContainer.appendChild(img);
                };
                reader.readAsDataURL(file);
            }
        });
    }

    renderImages(images, previewId) {
        const previewContainer = document.getElementById(previewId);
        previewContainer.innerHTML = ""; // Limpia el contenedor

        // Si solo es una imagen (objeto), conviértelo a arreglo
        const imageList = Array.isArray(images) ? images : [{ path: images }];


        imageList.forEach(imgData => {

            const img = document.createElement("img");
            img.src = fileUrl(imgData.path);
            img.onerror = () => fileUrlFallback(img);
            img.alt = imgData.original_name || "Imagen del producto";

            img.classList.add("w-32", "h-32", "object-cover", "rounded", "border");
            previewContainer.appendChild(img);
        });
    }


    // Pos.
    async printOrder() {

        const pos = await useFetch({
            url: api,
            data: { opc: "getOrderDetails", id: idFolio }
        });

        const modal = bootbox.dialog({
            closeButton: true,
            title: ` <div class="flex items-center gap-2 text-white text-lg font-semibold">
                        ${lucideIcon('printer', 'w-5 h-5 text-blue-400')}
                        Imprimir
                    </div>`,
            message: ` <div id="containerPrintOrder"></div>`
        });

        console.log('pos',pos)

        this.ticketPasteleria({
            parent: 'containerPrintOrder',
            data: {
                head: pos.data.order,
                products: pos.data.products,
                paymentMethods: pos.data.paymentMethods || []
            }
        })

    }

    createTicket(options) {
        const defaults = {
            parent: "container", // contenedor donde se insertará
            data: {
                head: { data: {} },
                row: [],
                products: []
            }
        };

        const opts = Object.assign({}, defaults, options);
        const parent = opts.parent;
        const data = opts.data.head.data || {};
        const products = opts.data.products || [];

        const cliente = data.cliente || "[cliente]";
        const fecha = data.pedido || "[fecha]";
        const hora = data.horapedido || "[hora]";
        const observacion = data.observacion || "[nota]";
        const costo = data.total || 0;
        const anticipo = data.anticipo || 0;
        const restante = costo - anticipo;
        const container = $("<div>", { id: "containerTicks", class: "bg-white text-gray-800 rounded-lg mb-4 font-mono p-4" });

        // Header
        container.append(`
        <div class="flex flex-col items-center">
            <img src="https://erp-varoch.com/ERP24/src/img/udn/fz_black.png" alt="Panadería y pastelería" class="w-48 max-w-full mt-2" />
            <h1 class="p-2 text-center font-bold">PEDIDOS DE PASTELERÍA</h1>
        </div>`);

        container.append(`
        <div class="flex-1 text-xs  space-y-4">
            <div class="flex justify-between gap-6">
                <div>
                    <div class="font-bold">NOMBRE:</div>
                    <div class="uppercase">${cliente}</div>
                </div>
                <div>
                    <div class="font-bold">FECHA Y HORA DE ENTREGA:</div>
                    <div class="uppercase">${fecha} ${hora}</div>
                </div>
            </div>
            <div>
                <div class="font-bold">NOTA:</div>
                <div>${observacion}</div>
            </div>
            <hr class="border-dashed" />
        </div>
    `);

        // Productos
        let totalProductos = 0;
        if (products.length > 0) {
            container.append(`
                <div class="text-xs font-mono px-2 mt-2">
                    <div class="text-center font-bold mb-2">PRODUCTOS</div>
                    <div class="flex justify-between  py-3">
                        <div class="w-1/6">CANT.</div>
                        <div class="w-3/6">DESCRIPCIÓN</div>
                        <div class="w-2/6 text-right">IMPORTE</div>
                    </div>

                    ${products.map(product => {
                const price = parseFloat(product.price || 0);
                const quantity = parseInt(product.quantity || 1);
                const total = price * quantity;
                totalProductos += total;

                return `
                            <div class="flex justify-between py-1">
                                <div class="w-1/6">${quantity}</div>
                                <div class="w-3/6 truncate">${product.name}</div>
                                <div class="w-2/6 text-right">${product.price}</div>
                            </div>
                            ${product.dedication ? `<div class="pl-4 italic text-[10px] text-gray-600">* ${product.dedication}</div>` : ""}
                        `;
            }).join("")}

                    <div class="border-t my-2 pt-2 text-right font-bold">
                        TOTAL PRODUCTOS: ${formatPrice(totalProductos)}
                    </div>
                </div>
            `);


        }




        $(`#${parent}`).html(container);
    }

    ticketPasteleria(options) {
        const defaults = {
            parent: "root",
            id: "ticketPasteleria",
            class: "bg-white p-4 rounded-lg shadow text-gray-900",
            data: {
                head: {
                    folio: "",
                    is_quote: false,
                    name: "[cliente]",
                    phone: "",
                    date_order: "[fecha]",
                    time_order: "[hora]",
                    notes: "[nota]",
                    total_pay: 0,
                    anticipo: 0,
                    forma_pago: ""
                },
                products: [],
                clausules: []
            }
        };

        const opts = Object.assign({}, defaults, options);
        const data = opts.data.head || {};
        const productos = opts.data.products || [];
        const clausules = opts.data.clausules || [];

        const total = parseFloat(data.total_pay || 0);
        const anticipo = parseFloat(data.anticipo || 0);

        function formatPrice(value) {
            return `$${parseFloat(value || 0).toFixed(2)}`;
        }

        const layout = $("<div>", {
            id: 'layoutPrintTicket',
            class: ''
        });

        const btnContainer = $("<div>", {
            class: 'flex justify-end mb-3 no-print'
        });

        const btnPrint = $("<button>", {
            id: "btnPrintTicket",
            class: "bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md flex items-center justify-center gap-2",
            html: lucideIcon('printer') + ' Imprimir ',
            click: () => {
                const ticketContent = document.getElementById('ticketPasteleria');
                if (ticketContent) {
                    const printWindow = window.open('', '_blank');
                    if (!printWindow) {
                        alert('Por favor permite las ventanas emergentes para imprimir el ticket');
                        return;
                    }
                    printWindow.document.write(`
                        <html>
                            <head>
                                <title>Ticket de Pedido</title>
                                <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
                                <style>
                                    html, body {
                                        margin: 0;
                                        padding: 0;
                                        width: 100%;
                                        height: 100%;
                                        font-family: 'Consolas', 'Roboto Mono', 'Lucida Console', monospace;
                                        font-size:12px;
                                        background: white;
                                    }

                                    * {
                                        box-sizing: border-box;
                                    }

                                    #ticketPasteleria {
                                        width: 100%;
                                        max-width: 100%;
                                        margin: 0;
                                        padding: 1rem;
                                    }

                                    @page {
                                        margin: 0;
                                        size: auto;
                                    }

                                    @media print {
                                        html, body {
                                            margin: 0;
                                            padding: 0;
                                            width: 100%;
                                            height: auto;
                                        }
                                        
                                        #ticketPasteleria {
                                            box-shadow: none !important;
                                            border-radius: 0 !important;
                                        }
                                        
                                        #lblFecha {
                                            text-align: right !important;
                                        }
                                    }
                                </style>
                            </head>
                            <body>
                                ${ticketContent.outerHTML}
                            </body>
                        </html>
                    `);
                    printWindow.document.close();
                    printWindow.focus();
                    setTimeout(() => {
                        printWindow.print();
                        printWindow.close();
                    }, 250);
                }
            }
        });

        btnContainer.append(btnPrint);
        layout.append(btnContainer)



        const container = $("<div>", {
            id: opts.id,
            class: "bg-white p-4 rounded-lg shadow text-gray-900",
            css: {
                fontFamily: "Consolas, 'Roboto Mono', 'Lucida Console', monospace",
                minHeight: "600px",
                margin: "0 auto"
            }
        });

        const initial = (data.company || data.subsidiarie_name || 'H').charAt(0).toUpperCase();
        const logoPlaceholder = `<div style="width:96px;height:96px;border-radius:50%;background:#7c3aed;display:flex;align-items:center;justify-content:center;" class="mb-1"><span style="color:white;font-size:36px;font-weight:bold;">${initial}</span></div>`;
        const logoHtml = data.logo
            ? `<div style="width:96px;height:96px;border-radius:50%;overflow:hidden;" class="mb-1"><img src="https://huubie.com.mx/alpha${data.logo}" alt="Logo" onerror="this.parentElement.outerHTML='<div style=\\'width:96px;height:96px;border-radius:50%;background:#7c3aed;display:flex;align-items:center;justify-content:center;\\'><span style=\\'color:white;font-size:36px;font-weight:bold;\\'>${initial}</span></div>'" style="width:100%;height:100%;object-fit:cover;display:block;" /></div>`
            : logoPlaceholder;

        const header = `
            <div class="flex flex-col items-center mb-4 mt-3">
                ${logoHtml}
                ${data.company ? `<div class="text-xs font-semibold uppercase mb-1">${data.company}</div>` : ""}
                ${data.subsidiarie_name ? `<div class="text-xs uppercase">${data.subsidiarie_name}</div>` : ""}
                <h1 class="text-lg font-bold">PEDIDOS DE PASTELERÍA</h1>
                ${data.status == 1 ? `<div class="text-xs font-bold text-red-600 uppercase">COTIZACIÓN</div>` : ""}
            </div>
            <div class="text-sm space-y-2">
                <!-- La ENTREGA no depende del folio: es el dato critico del pedido
                     y se imprime siempre, haya folio o no. -->
                <div class="flex justify-between">
                    ${data.folio ? `
                    <div>
                        <div class="font-semibold">FOLIO:</div>
                        <div class="uppercase">${data.folio}</div>
                    </div>` : `<div></div>`}
                    <div>
                        <div class="font-semibold">FECHA Y HORA DE ENTREGA:</div>
                        <div id="lblFecha" class="uppercase text-end">${data.date_order} ${data.time_order}</div>
                    </div>
                </div>

                <div>
                    <div class="font-semibold">NOMBRE:</div>
                    <div class="uppercase">${data.name}</div>
                    ${data.phone ? `<div class="uppercase">TEL: ${data.phone}</div>` : ""}
                </div>

                ${(data.notes || data.note) ? `
                <div>
                    <div class="font-semibold">NOTA:</div>
                    <div>${data.notes || data.note}</div>
                </div>` : ""}

                ${data.date_creation ? `
                <div class="text-xs text-gray-600">Creado: ${moment(data.date_creation).format("DD/MM/YYYY hh:mm A")}</div>` : ""}
                <hr class="border-dashed border-t my-2" />
            </div> `;



        let listaProductos = "";
        if (productos.length > 0) {
            listaProductos += `
                <div class="text-sm mt-3">
                    <div class="text-center font-bold mb-2">PRODUCTOS</div>
                    <div class="flex justify-between pb-2 font-semibold ">
                    <div class="w-1/6">CANT.</div>
                    <div class="w-3/6">DESCRIPCIÓN</div>
                    <div class="w-2/6 text-right">IMPORTE</div>
                </div>

        `;

            listaProductos += productos.map(product => {
                const quantity = parseInt(product.quantity || 1);
                const price = parseFloat(product.price || 0);
                const subtotal = quantity * price;

                // El detalle (porcion, modificadores, dedicatoria) va DEBAJO del renglon
                // del producto ocupando todo el ancho de la fila: confinado a la columna
                // DESCRIPCION se partia en lineas muy cortas y era ilegible.
                let detailsHtml = "";

                if (product.customer_products && Array.isArray(product.customer_products) && product.customer_products.length > 0) {
                    detailsHtml += `<div class="capitalize">Porción: ${product.portion_qty || 1}</div>`;
                    product.customer_products.forEach(cp => {
                        detailsHtml += `<div class="text-xs ml-1">-${cp.modifier_name}: ${cp.name} x ${cp.quantity || 1}</div>`;
                    });
                }

                if (product.dedication) {
                    detailsHtml += `<div class="text-xs font-semibold ml-1">Dedicatoria: ${product.dedication}</div>`;
                }

                return `
                <div class="py-1 pb-2">
                    <div class="flex justify-between">
                        <div class="w-1/6">${quantity}</div>
                        <div class="w-3/6 capitalize font-bold">${product.name}${product.custom_id ? ' (Personalizado)' : ''}</div>
                        <div class="w-2/6 text-right">${formatPrice(subtotal)}</div>
                    </div>
                    ${detailsHtml ? `<div class="mt-0.5 pl-2">${detailsHtml}</div>` : ""}
                </div>
            `;
            }).join("");

            listaProductos += `</div>`;
        }

        const totales = (() => {
            const hasAbono = anticipo > 0;
            const paymentMethods = opts.data.paymentMethods || [];
            const discount = parseFloat(data.discount || 0);
            const hasDiscount = discount > 0;
            const totalConDescuento = total - discount;
            const hasMovimientos = hasAbono || (Array.isArray(paymentMethods) && paymentMethods.length > 0);

            if (!hasMovimientos) {
                return `
                <hr class="border-dashed border-t my-2" />
                <div class="text-right text-sm mt-4 space-y-1">
                    ${hasDiscount ? `
                        <div class="text-base">Subtotal: <span class="font-semibold">${formatPrice(total)}</span></div>
                        <div class="">Descuento: <span class="font-semibold">-${formatPrice(discount)}</span></div>
                        <div class="text-xl font-bold">TOTAL: ${formatPrice(totalConDescuento)}</div>
                    ` : `
                        <div class="text-xl font-bold">TOTAL: ${formatPrice(total)}</div>
                    `}
                </div>`;
            }

            const desglosePagos = [];
            let totalPagado = 0;

            if (hasAbono) {
                desglosePagos.push(`<div class="font-bold">Anticipo: ${formatPrice(anticipo)}</div>`);
                totalPagado += anticipo;
            }

            if (Array.isArray(paymentMethods)) {
                paymentMethods.forEach(pm => {
                    const monto = parseFloat(pm.pay || 0);
                    totalPagado += monto;
                    desglosePagos.push(
                        `<div class="text-sm">${pm.method_pay}: <span class="font-semibold">${formatPrice(monto)}</span></div>`
                    );
                });
            }

            const restante = totalConDescuento - totalPagado;

            return `
    <hr class="border-dashed border-t my-2" />
    <div class="text-right text-sm mt-4 space-y-1">
        ${hasDiscount ? `
        <div class="text-base">Subtotal: <span class="font-semibold">${formatPrice(total)}</span></div>
        <div class="">Descuento: <span class="font-semibold">-${formatPrice(discount)}</span></div>` : ''}
        <div class="text-base font-bold">TOTAL: ${formatPrice(totalConDescuento)}</div>
        ${desglosePagos.join("")}
        <div class="text-xl font-bold mt-2">RESTANTE: ${formatPrice(restante)}</div>
    </div>`;
        })();





        const clausulesSection = clausules.length > 0 ? `
        <div class="mt-4 text-[12px] ">
            <hr class="border-dashed border-t my-2" />
            <div class="font-bold mb-2">RECOMENDACIONES:</div>
            <ul class="list-disc list-inside space-y-1">
                ${clausules.map(c => `<li>${c.name}</li>`).join("")}
            </ul>
        </div>
    ` : "";

        const footer = `
        <div class="text-center mt-6 text-xs font-bold text-gray-900 space-y-1">
            <p>ESTE NO ES UN COMPROBANTE FISCAL</p>
            <p class=" text-sm">Huubie</p>
            <p class="mt-2">GRACIAS POR SU PREFERENCIA</p>
        </div>
    `;

        // Las recomendaciones van ANTES del footer: la despedida (GRACIAS...) cierra el ticket.
        container.append(header);
        container.append(listaProductos);
        container.append(totales);
        container.append(clausulesSection);
        container.append(footer);

        layout.append(container)

        $(`#${opts.parent}`).html(layout);
    }


    // payment.

    _lucide(name, cls = "w-4 h-4") {
        const paths = {
            'dollar-sign'   : '<line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
            'banknote'      : '<rect width="20" height="12" x="2" y="6" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/>',
            'credit-card'   : '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
            'arrow-exchange': '<path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>',
            'check'         : '<path d="M20 6 9 17l-5-5"/>',
            'square-check'  : '<path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
            'square-minus'  : '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M8 12h8"/>',
            'triangle-alert': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
            'file-text'     : '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><line x1="10" x2="8" y1="9" y2="9"/>',
            'percent'       : '<line x1="19" x2="5" y1="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
            'piggy-bank'    : '<path d="M19 5c-1.5 0-2.8 1.4-3 2-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h3v2h4v-4c1-.5 1.7-1 2-2h2v-4h-2c0-1-.5-1.5-1-2V5z"/><path d="M2 9v1c0 1.1.9 2 2 2h1"/><path d="M16 11h.01"/>'
        };
        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="${cls}">${paths[name] || ''}</svg>`;
    }

    async addPayment() {

        let saldoOriginal, total, total_paid, saldo_restante, discount, subtotal;
        const req      = await useFetch({ url: api, data: { opc: "getPayment", id: idFolio } });
        const response = req.order;

        if (req.total_paid) {

            discount       = parseFloat(response.discount) || 0;
            saldoOriginal  = parseFloat(response.total_pay) || 0;
            subtotal       = saldoOriginal;
            total          = saldoOriginal - discount;
            total_paid     = parseFloat(req.total_paid) || 0;
            saldo_restante = total - total_paid;

        } else {
            const totalText = $('#subtotal').text();
            saldoOriginal   = parseFloat(totalText.replace(/[^0-9.-]+/g, "")) || 0;
            discount        = parseFloat($('#discountAmount').text().replace(/[^0-9.-]+/g, "")) || 0;
            subtotal        = saldoOriginal;
            total           = saldoOriginal - discount;
            total_paid      = 0;
            saldo_restante  = total - total_paid;
        }

        this._paymentState = {
            subtotal      : subtotal,
            total         : total,
            total_paid    : total_paid,
            discount      : discount,
            saldo_restante: saldo_restante,
            tabDescuento  : 'monto',
            methodPayId   : null
        };

        const lucide = (n, c) => this._lucide(n, c);

        this.createModalForm({
            id: "modalRegisterPayment",
            bootbox: {
                title: `
                <div class="flex items-center gap-2 text-white text-lg font-semibold">
                    <span class="text-violet-400">${lucide('dollar-sign', 'w-5 h-5')}</span>
                    Registrar Pago
                </div>`,
                id: "registerPaymentModal",
                size: "medium"
            },
            data: {
                opc: 'addPayment',
                id : idFolio
            },
            json: [
                {
                    opc  : "div",
                    id   : "paymentModalContent",
                    class: "col-12",
                    html : `
                    <div class="space-y-3">
                        <input type="hidden" id="hdn_total" name="total" value="${total}">
                        <input type="hidden" id="hdn_saldo" name="saldo" value="${saldo_restante}">
                        <input type="hidden" id="hdn_discount" name="discount" value="${discount}">
                        <input type="hidden" id="hdn_total_paid" name="total_paid" value="${total_paid}">
                        <input type="hidden" id="hdn_target_status" name="target_status" value="">

                        ${this.cardPay(total, total_paid, discount)}

                        <div id="anticipoSwitch" class="flex items-center justify-between text-white p-3 rounded-lg bg-[#1F2937]">
                            <div class="flex items-center gap-2">
                                <span id="iconAnticipo" class="text-gray-400 transition-colors duration-200">${lucide('square-minus', 'w-5 h-5')}</span>
                                <label id="labelAnticipo" class="text-sm cursor-pointer" for="toggleAnticipo">Dejar abono</label>
                            </div>
                            <label class="inline-flex items-center cursor-pointer relative">
                                <input type="checkbox" id="toggleAnticipo" class="sr-only peer" onchange="normal.toggleExtraFields()">
                                <div class="w-11 h-6 bg-gray-700 peer-checked:bg-violet-600 rounded-full transition-colors duration-300"></div>
                                <div class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform duration-300 peer-checked:translate-x-5"></div>
                            </label>
                        </div>

                        <div id="wrapAdvancedPay" class="hidden js-wrap-advanced-pay space-y-2">
                            <div class="space-y-1">
                                <label class="text-xs font-semibold text-gray-400">Importe del abono</label>
                                <div class="relative">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">$</span>
                                    <input type="number" id="advanced_pay" name="advanced_pay" min="0" step="0.01" placeholder="0.00"
                                           class="w-full bg-[#1E293B] border border-gray-700 rounded-lg py-2 pl-8 pr-4 text-lg text-white font-bold focus:outline-none focus:border-violet-500"
                                           oninput="normal.updateTotal()">
                                </div>
                                <p class="text-[10px] text-gray-500">Máximo: <span class="text-violet-400 font-semibold" id="lblMaxMonto">${formatPrice(saldo_restante)}</span></p>
                            </div>

                            <div id="alertaExcede" class="hidden bg-orange-600/10 rounded-xl p-3">
                                <div class="flex items-center gap-2">
                                    <span class="text-orange-400 flex-shrink-0">${lucide('triangle-alert', 'w-4 h-4')}</span>
                                    <p class="text-xs text-orange-400">El importe excede el saldo restante. Se ajustará automáticamente.</p>
                                </div>
                            </div>
                        </div>

                        <div id="wrapMethodPay" class="hidden js-wrap-method-pay space-y-2">
                            <label class="text-xs font-semibold text-gray-400">Método de pago</label>
                            <div class="grid grid-cols-3 gap-2">
                                <button type="button" class="metodo-pay-btn py-3 px-2 rounded-lg text-xs font-bold bg-[#1E293B] text-gray-300 border border-gray-700 hover:border-violet-500 transition-all flex flex-col items-center gap-1"
                                        onclick="normal.seleccionarMetodo(1, this)">
                                    ${lucide('banknote', 'w-5 h-5')}
                                    <span>Efectivo</span>
                                </button>
                                <button type="button" class="metodo-pay-btn py-3 px-2 rounded-lg text-xs font-bold bg-[#1E293B] text-gray-300 border border-gray-700 hover:border-violet-500 transition-all flex flex-col items-center gap-1"
                                        onclick="normal.seleccionarMetodo(2, this)">
                                    ${lucide('credit-card', 'w-5 h-5')}
                                    <span>Tarjeta</span>
                                </button>
                                <button type="button" class="metodo-pay-btn py-3 px-2 rounded-lg text-xs font-bold bg-[#1E293B] text-gray-300 border border-gray-700 hover:border-violet-500 transition-all flex flex-col items-center gap-1"
                                        onclick="normal.seleccionarMetodo(3, this)">
                                    ${lucide('arrow-exchange', 'w-5 h-5')}
                                    <span>Transfer.</span>
                                </button>
                            </div>
                            <input type="hidden" id="method_pay_id" name="method_pay_id" value="">
                        </div>

                        <div id="discountSwitch" class="js-discount-switch flex items-center justify-between text-white p-3 rounded-lg bg-[#1F2937]">
                            <div class="flex items-center gap-2">
                                <span id="iconDiscount" class="text-gray-400 transition-colors duration-200">${lucide('square-minus', 'w-5 h-5')}</span>
                                <label id="labelDiscount" class="text-sm cursor-pointer" for="toggleDiscount">Aplicar descuento</label>
                            </div>
                            <label class="inline-flex items-center cursor-pointer relative">
                                <input type="checkbox" id="toggleDiscount" class="sr-only peer" onchange="normal.toggleDiscount()">
                                <div class="w-11 h-6 bg-gray-700 peer-checked:bg-green-600 rounded-full transition-colors duration-300"></div>
                                <div class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform duration-300 peer-checked:translate-x-5"></div>
                            </label>
                        </div>

                        <div id="wrapDiscount" class="hidden js-wrap-discount space-y-2">
                            <div class="flex gap-2">
                                <button type="button" id="tabDescuentoMonto" class="tab-descuento-btn active flex-1 py-2 px-3 rounded-lg text-xs font-bold bg-[#1E293B] !text-white border !border-green-500 flex items-center justify-center gap-1"
                                        onclick="normal.cambiarTabDescuento('monto', this)">
                                    ${lucide('dollar-sign', 'w-4 h-4')}
                                    <span>Monto fijo</span>
                                </button>
                                <button type="button" id="tabDescuentoPorcentaje" class="tab-descuento-btn flex-1 py-2 px-3 rounded-lg text-xs font-bold bg-[#1E293B] text-gray-300 border border-gray-700 flex items-center justify-center gap-1"
                                        onclick="normal.cambiarTabDescuento('porcentaje', this)">
                                    ${lucide('percent', 'w-4 h-4')}
                                    <span>Porcentaje</span>
                                </button>
                            </div>

                            <div id="panelDescuentoMonto" class="space-y-1">
                                <label class="text-xs font-semibold text-gray-400">Monto del descuento</label>
                                <div class="relative">
                                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">$</span>
                                    <input type="number" id="discount_amount" min="0" step="0.01" placeholder="0.00"
                                           class="w-full bg-[#1E293B] border border-gray-700 rounded-lg py-2 pl-8 pr-4 text-lg text-white font-bold focus:outline-none focus:border-green-500"
                                           oninput="normal.actualizarDescuento()">
                                </div>
                                <p class="text-[10px] text-gray-500">Máximo: <span class="text-green-400 font-semibold" id="lblMaxDescuento">${formatPrice(subtotal)}</span></p>
                            </div>

                            <div id="panelDescuentoPorcentaje" class="hidden space-y-1">
                                <label class="text-xs font-semibold text-gray-400">Porcentaje del descuento</label>
                                <div class="relative">
                                    <input type="number" id="inputDescuentoPorcentaje" min="0" max="100" step="0.5" placeholder="0"
                                           class="w-full bg-[#1E293B] border border-gray-700 rounded-lg py-2 pl-4 pr-8 text-lg text-white font-bold focus:outline-none focus:border-green-500"
                                           oninput="normal.actualizarDescuentoDesdePorcentaje(this.value)">
                                    <span class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold">%</span>
                                </div>
                                <p class="text-[10px] text-gray-500">Equivale a: <span class="text-green-400 font-semibold" id="lblDescuentoEquivalente">${formatPrice(0)}</span></p>
                            </div>
                        </div>

                    </div>
                    `
                }
            ],
            success: (response) => {
                if (response.status == 200) {
                    alert({ icon: "success", text: response.message, timer: 1500 });
                    app.render();
                } else {
                    alert({ icon: "error", text: response.message, btn1: true, btn1Text: "Ok" });
                }
            }
        });

        $(".js-wrap-advanced-pay").addClass("hidden");
        $(".js-wrap-method-pay").addClass("hidden");
        $(".js-wrap-discount").addClass("hidden");

        const $btn             = $("#btnSuccess");
        const originalHandlers = $._data($btn[0], "events")?.click?.map(e => e.handler) || [];

        $btn.off("click");
        $btn.on("click", () => {
            const abonoActivo = $("#toggleAnticipo").is(":checked");
            const abono       = parseFloat($("#advanced_pay").val()) || 0;
            const methodId    = $("#method_pay_id").val();
            const state       = this._paymentState;

            if (abonoActivo && abono > 0 && !methodId) {
                alert({
                    icon: "warning",
                    title: "Método de pago requerido",
                    text: "Selecciona un método de pago para registrar el abono.",
                    btn1: true,
                    btn1Text: "Ok"
                });
                return;
            }

            $("#hdn_total").val(state.total);
            $("#hdn_saldo").val(state.saldo_restante);
            $("#hdn_discount").val(state.discount);
            $("#hdn_total_paid").val(state.total_paid);

            if (abono <= 0 && state.total_paid <= 0) {
                alert({
                    icon: "question",
                    title: "Sin abono",
                    text: "No se registró ningún abono. ¿Cómo deseas guardar el pedido?",
                    btn1Text: "Cotización",
                    btn3: true,
                    btn3Text: "Pendiente",
                    btn2Text: "Cancelar",
                }).then((result) => {
                    if (result.isConfirmed) {
                        $("#hdn_target_status").val(1);
                        originalHandlers.forEach(fn => fn());
                    } else if (result.isDenied) {
                        $("#hdn_target_status").val(2);
                        originalHandlers.forEach(fn => fn());
                    }
                });

                const btnCotizacion = Swal.getConfirmButton();
                const btnPendiente  = Swal.getDenyButton();

                if (btnCotizacion) {
                    btnCotizacion.style.backgroundColor = "#9EBBDB";
                    btnCotizacion.style.color           = "#2A55A3";
                }
                if (btnPendiente) {
                    btnPendiente.style.backgroundColor = "#633112";
                    btnPendiente.style.color           = "#F2C215";
                }
            } else {
                originalHandlers.forEach(fn => fn());
            }
        });

    }

    cardPay(total, total_paid = 0, discount = 0) {
        const restante = total - total_paid;
        const subtotal = total + discount;
        const hasAbono = total_paid > 0;

        return `
            <div id="dueAmount" class="p-4 rounded-xl bg-[#1E293B] text-white space-y-3 border border-slate-700 shadow-sm">

                <div id="vistaSimple" class="${hasAbono ? 'hidden' : ''}">
                    <div id="rowDescuentoSimple" class="${discount > 0 ? '' : 'hidden'} text-center mb-1">
                        <p class="text-sm opacity-80">Subtotal</p>
                        <p class="text-lg font-semibold text-gray-400 line-through" id="lblSubtotalTachado">${formatPrice(subtotal)}</p>
                        <p class="text-sm text-green-400 mb-1" id="lblDescuentoSimple">Descuento: -${formatPrice(discount)}</p>
                    </div>
                    <p class="text-sm opacity-80 text-center">Monto a pagar</p>
                    <p id="SaldoEventSimple" class="text-3xl font-bold mt-1 text-center">${formatPrice(restante)}</p>
                </div>

                <div id="vistaDetallada" class="${hasAbono ? '' : 'hidden'} space-y-3">
                    <div id="rowDescuentoDetalle" class="${discount > 0 ? '' : 'hidden'}">
                        <div class="flex justify-between items-center">
                            <span class="text-sm font-semibold">Subtotal</span>
                            <span class="text-gray-400 line-through" id="lblSubtotalDetalle">${formatPrice(subtotal)}</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm font-semibold text-green-400">Descuento</span>
                            <span class="text-green-400 font-bold" id="lblDescuentoDetalle">-${formatPrice(discount)}</span>
                        </div>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-semibold">Total de la venta</span>
                        <span class="text-white font-bold text-lg" id="lblTotalVenta">${formatPrice(total)}</span>
                    </div>
                    <div class="flex justify-between items-center bg-blue-900/30 p-2 rounded-lg">
                        <div class="flex items-center gap-2">
                            ${lucideIcon('check', 'w-4 h-4 text-blue-400')}
                            <span class="text-sm font-semibold text-blue-300">Abono registrado</span>
                        </div>
                        <span class="text-blue-400 font-bold" id="lblAbonoPrevio">${formatPrice(total_paid)}</span>
                    </div>
                    <hr class="border-slate-600">
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-semibold">Restante</span>
                        <span id="SaldoEvent" class="text-white font-bold text-lg">${formatPrice(restante)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    renderResumenFinanciero() {
        const s = this._paymentState;
        if (!s) return;

        const subtotal = s.subtotal;
        const total    = s.total;
        const restante = s.saldo_restante;
        const hasAbono = s.total_paid > 0;

        $("#vistaSimple").toggleClass("hidden", hasAbono);
        $("#vistaDetallada").toggleClass("hidden", !hasAbono);

        if (hasAbono) {
            $("#rowDescuentoDetalle").toggleClass("hidden", s.discount <= 0);
            $("#lblSubtotalDetalle").text(formatPrice(subtotal));
            $("#lblDescuentoDetalle").text("-" + formatPrice(s.discount));
            $("#lblTotalVenta").text(formatPrice(total));
            $("#lblAbonoPrevio").text(formatPrice(s.total_paid));
            $("#SaldoEvent").text(formatPrice(restante));
        } else {
            $("#rowDescuentoSimple").toggleClass("hidden", s.discount <= 0);
            $("#lblSubtotalTachado").text(formatPrice(subtotal));
            $("#lblDescuentoSimple").text("Descuento: -" + formatPrice(s.discount));
            $("#SaldoEventSimple").text(formatPrice(restante));
        }

        $("#lblMaxMonto").text(formatPrice(restante));
    }

    updateTotal() {
        const input  = document.getElementById("advanced_pay");
        const btnOk  = document.getElementById("btnSuccess");
        const alerta = document.getElementById("alertaExcede");
        const state  = this._paymentState;

        if (!input || !state) return;

        let anticipo = parseFloat(input.value) || 0;
        let restante = state.saldo_restante - anticipo;

        if (anticipo > state.saldo_restante) {
            anticipo    = state.saldo_restante;
            input.value = anticipo.toFixed(2);
            restante    = 0;
            alerta?.classList.remove("hidden");
        } else {
            alerta?.classList.add("hidden");
        }

        const hasAbono = state.total_paid > 0;
        if (hasAbono) {
            $("#SaldoEvent").text(formatPrice(restante));
        } else {
            $("#SaldoEventSimple").text(formatPrice(restante));
        }

        const abonoActivo = $("#toggleAnticipo").is(":checked");
        if (btnOk) btnOk.disabled = abonoActivo && anticipo <= 0;
    }

    seleccionarMetodo(id, btn) {
        if (this._paymentState) this._paymentState.methodPayId = id;
        $("#method_pay_id").val(id);

        document.querySelectorAll(".metodo-pay-btn").forEach(b => {
            b.classList.remove("active", "!border-violet-500", "!text-violet-400", "!bg-violet-500/10");
            b.classList.add("border-gray-700", "text-gray-300");
        });
        btn.classList.add("active", "!border-violet-500", "!text-violet-400", "!bg-violet-500/10");
        btn.classList.remove("border-gray-700", "text-gray-300");
    }

    resetAbono() {
        const state = this._paymentState;

        $("#advanced_pay").val("");
        $("#alertaExcede").addClass("hidden");

        if (state) {
            const restante = state.saldo_restante;
            if (state.total_paid > 0) {
                $("#SaldoEvent").text(formatPrice(restante));
            } else {
                $("#SaldoEventSimple").text(formatPrice(restante));
            }
        }

        const abonoActivo = $("#toggleAnticipo").is(":checked");
        const btnOk       = document.getElementById("btnSuccess");
        if (btnOk) btnOk.disabled = abonoActivo;
    }

    toggleDiscount() {
        const show  = $("#toggleDiscount").is(":checked");
        const icon  = document.getElementById("iconDiscount");
        const label = document.getElementById("labelDiscount");

        if (show) {
            $(".js-wrap-discount").removeClass("hidden");
            if (icon) {
                icon.className = "text-green-400 transition-colors duration-200";
                icon.innerHTML = this._lucide('square-check', 'w-5 h-5');
            }
            if (label) label.textContent = "Descuento activo";
        } else {
            $(".js-wrap-discount").addClass("hidden");
            if (icon) {
                icon.className = "text-gray-400 transition-colors duration-200";
                icon.innerHTML = this._lucide('square-minus', 'w-5 h-5');
            }
            if (label) label.textContent = "Aplicar descuento";

            $("#discount_amount").val("");
            $("#inputDescuentoPorcentaje").val("");
            $("#lblDescuentoEquivalente").text(formatPrice(0));

            this.applyDiscount(0);
        }
    }

    cambiarTabDescuento(tab, btn) {
        if (this._paymentState) this._paymentState.tabDescuento = tab;

        document.querySelectorAll(".tab-descuento-btn").forEach(b => {
            b.classList.remove("active", "!border-green-500", "!text-white");
            b.classList.add("border-gray-700", "text-gray-300");
        });
        btn.classList.add("active", "!border-green-500", "!text-white");
        btn.classList.remove("border-gray-700", "text-gray-300");

        document.getElementById("panelDescuentoMonto").classList.toggle("hidden", tab !== "monto");
        document.getElementById("panelDescuentoPorcentaje").classList.toggle("hidden", tab !== "porcentaje");

        $("#discount_amount").val("");
        $("#inputDescuentoPorcentaje").val("");
        $("#lblDescuentoEquivalente").text(formatPrice(0));
        this.applyDiscount(0);
    }

    actualizarDescuento() {
        const state = this._paymentState;
        if (!state) return;

        let monto = parseFloat($("#discount_amount").val()) || 0;

        if (monto > state.subtotal) {
            monto = state.subtotal;
            $("#discount_amount").val(monto.toFixed(2));
        }

        this.applyDiscount(monto);
    }

    actualizarDescuentoDesdePorcentaje(valor) {
        const state = this._paymentState;
        if (!state) return;

        const pct   = Math.min(parseFloat(valor) || 0, 100);
        const monto = state.subtotal * (pct / 100);

        $("#lblDescuentoEquivalente").text(formatPrice(monto));
        this.applyDiscount(monto);
    }

    applyDiscount(monto) {
        const state = this._paymentState;
        if (!state) return;

        state.discount       = monto;
        state.total          = state.subtotal - monto;
        state.saldo_restante = state.total - state.total_paid;

        const inputAbono = parseFloat($("#advanced_pay").val()) || 0;
        if (inputAbono > state.saldo_restante) {
            $("#advanced_pay").val(state.saldo_restante.toFixed(2));
        }

        this.renderResumenFinanciero();
        this.updateTotal();
    }

    toggleExtraFields() {
        const show           = $("#toggleAnticipo").is(":checked");
        const icon           = document.getElementById("iconAnticipo");
        const label          = document.getElementById("labelAnticipo");
        const btnOk          = document.getElementById("btnSuccess");

        if (show) {
            $(".js-wrap-advanced-pay").removeClass("hidden");
            $(".js-wrap-method-pay").removeClass("hidden");

            if (icon) {
                icon.className = "text-violet-400 transition-colors duration-200";
                icon.innerHTML = this._lucide('square-check', 'w-5 h-5');
            }
            if (label) label.textContent = "Abono seleccionado";

            const anticipo = parseFloat($("#advanced_pay").val()) || 0;
            if (btnOk) btnOk.disabled = anticipo <= 0;
        } else {
            $(".js-wrap-advanced-pay").addClass("hidden");
            $(".js-wrap-method-pay").addClass("hidden");

            if (icon) {
                icon.className = "text-gray-400 transition-colors duration-200";
                icon.innerHTML = this._lucide('square-minus', 'w-5 h-5');
            }
            if (label) label.textContent = "Dejar abono";

            if (btnOk) btnOk.disabled = false;

            this.resetAbono();
        }
    }

    // Products.
    showProductDetails(productId, options = {}) {
        const defaults = {
            theme: "dark"
        };

        const opts = Object.assign({}, defaults, options);

        // Fetch product details from backend
        useFetch({
            url: this._link,
            data: {
                opc: "getProductDetails",
                id: productId
            }
        }).then(response => {
            if (response.status === 200) {
                const product = response.data;

                // Create modal with bootbox
                const modal = bootbox.dialog({
                    title: `<div class="flex items-center gap-2 text-white text-lg font-semibold">
                        ${lucideIcon('info', 'w-5 h-5 text-blue-400')}
                        Detalles del Producto
                    </div>`,
                    message: `
                        <div class="flex flex-col md:flex-row gap-4 bg-[#1F2A37] text-white rounded-lg overflow-hidden">
                            <!-- Left Pane - Product Image -->
                            <div class="w-full md:w-1/2 bg-gray-800 flex items-center justify-center min-h-[300px]">
                                ${product.image && product.image.trim() !== ""
                            ? `<img src="${fileUrl(product.image)}" onerror="fileUrlFallback(this)" alt="${product.name}" class="object-cover w-full h-full rounded-lg">`
                            : `<div class="flex items-center justify-center w-full h-full">
                                         ${lucideIcon('cake', 'w-16 h-16 text-gray-500')}
                                       </div>`
                        }
                            </div>
                            
                            <!-- Right Pane - Product Details -->
                            <div class="w-full md:w-1/2 p-4 flex flex-col justify-between">
                                <div>
                                    <h2 class="text-2xl font-bold text-white mb-2">${product.name}</h2>
                                    
                                    ${product.category
                            ? `<span class="inline-block px-3 py-1 text-sm bg-blue-600 text-white rounded-full mb-3">${product.category}</span>`
                            : ''
                        }
                                    
                                    <div class="mb-4">
                                        <p class="text-sm text-gray-400 mb-1">Precio</p>
                                        <p class="text-3xl font-bold text-blue-400">${formatPrice(product.price)}</p>
                                    </div>
                                    
                                    ${product.description
                            ? `<div class="mb-4">
                                             <p class="text-sm text-gray-400 mb-2">Descripción</p>
                                             <p class="text-gray-300 leading-relaxed">${product.description}</p>
                                           </div>`
                            : ''
                        }
                                </div>
                                
                                <div class="mt-4">
                                    <button id="addToCartFromModal" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200">
                                        ${lucideIcon('shopping-cart', 'w-4 h-4 mr-2 inline-block')}
                                        Agregar al carrito
                                    </button>
                                </div>
                            </div>
                        </div>
                    `,
                    size: 'large',
                    closeButton: true,
                    className: 'product-details-modal'
                });

                // Add event handler for "Add to Cart" button
                $(document).off('click', '#addToCartFromModal').on('click', '#addToCartFromModal', () => {
                    this.addProduct(productId);
                    modal.modal('hide');
                });

            } else {
                alert({
                    icon: "error",
                    title: "Error",
                    text: response.message || "No se pudieron cargar los detalles del producto",
                    btn1: true,
                    btn1Text: "Ok"
                });
            }
        }).catch(error => {
            console.error('Error fetching product details:', error);
            alert({
                icon: "error",
                title: "Error",
                text: "Error de conexión al cargar los detalles del producto",
                btn1: true,
                btn1Text: "Ok"
            });
        });
    }
}




