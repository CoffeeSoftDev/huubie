let api          = 'ctrl/ctrl-pedidos.php';
let api_catalogo = 'ctrl/ctrl-pedidos-catalogo.php';
let api_custom   = 'ctrl/ctrl-pedidos-personalizado.php';

let idFolio, sub_name, user_name;
let normal, app, custom, cierre; //Clases.
let categories, estado, clients;

let rol, subsidiaries, udn;
let subsidiariesCobro = []; // Sucursales para el selector "Sucursal de cobro" (todos los roles).
let dailyClosure = { is_closed: false };
let openShift = { has_open_shift: false };

// Estado activo / inactivo de los botones de metodo de pago (Gestion de Pagos). El
// anillo interior del activo es lo que hace legible la seleccion: sobre el fondo del
// modal, un cambio de fondo solo se percibe apenas.
const METHOD_BTN = {
    on:  'bg-blue-600/25 border-blue-500 text-white ring-1 ring-inset ring-blue-500/50',
    off: 'bg-[#1E293B] border-slate-700 text-gray-400 hover:border-slate-500'
};

// Nombre e icono por id de metodo de pago, para rotular el boton de registrar.
const METHOD_META = {
    '1': { label: 'Efectivo',      icon: 'banknote' },
    '2': { label: 'Tarjeta',       icon: 'credit-card' },
    '3': { label: 'Transferencia', icon: 'arrow-right-left' }
};

$(async () => {
    let dataModifiers = await useFetch({ url: api, data: { opc: "getModifiers" } });
    categories = dataModifiers.data || [];

    const req          = await useFetch({ url: api, data: { opc: "init" } });
          estado       = req.status;
          clients      = req.clients || [];
          rol          = req.access;
          sub_name     = req.subsidiaries_name;
          user_name    = req.user_name; 
          subsidiaries = req.sucursales;
          subsidiariesCobro = req.sucursales_cobro || [];
          dailyClosure = req.daily_closure || { is_closed: false };
          udn          = dailyClosure.subsidiary_id;
          openShift    = req.open_shift || { has_open_shift: false };
          app          = new App(api, 'root');
          custom       = new CustomOrder(api_custom, 'root');
          normal       = new CatalogProduct(api_catalogo, 'root');
          cierre       = new Cierre(apiCierre);

    app.render();

    // La navbar es la duena del filtro de sucursal (solo admin). Cuando el
    // admin cambia de sucursal alli, replicamos el comportamiento del filtro.
    document.addEventListener('branchChanged', () => app.onSubsidiaryChange());

    setInterval(() => {
        app.actualizarFechaHora({ label: app.getSubsidiaryLabel() });
    }, 60000);
});

class App extends Templates {
    constructor(link, divModule) {
        super(link, divModule);
        this.PROJECT_NAME = "Pedidos";
    }

    render() {
        // Vista de listado: el selector de sucursal del navbar SI aplica (filtro de
        // vista), asi que se muestra. En crear/editar se oculta (ver CatalogProduct.render).
        $('#navbarBranchControl').removeClass('hidden');
        this.layout();
        this.createFilterBar();
        this.createSearchBar();
        this.ls();
        this.actualizarFechaHora({ label: this.getSubsidiaryLabel() });
        this.updateDailyClosureStatus();
    }

    // Reportes: vista de SOLO CONSULTA (visor de cierre: cortes Z y turnos).
    // Se monta sobre la vista de pedidos; el regreso lo da la flecha del propio visor.
    // No requiere turno abierto: es consulta, disponible para todos los roles.
    openReports() {
        $('#navbarBranchControl').removeClass('hidden');
        $('#root').html(`<div id="container-reportes" class="mx-2"></div>`);
        reports.render();
    }

    layout() {
        this.createLayout({
            parent: "root",
            design: false,
            data: {
                id: this.PROJECT_NAME,
                class: 'flex mx-2 min-h-screen',
                container: [
                    {
                        type: "div",
                        id: "singleLayout",
                        class: "flex flex-col col-12",
                        children: [
                            { type: "div", class: 'w-full ', id: 'filterBar' },
                            { type: "div", class: 'w-full my-2 bg-[#1F2A37] h-screen rounded p-3 overflow-auto', id: 'container' + this.PROJECT_NAME }
                        ]
                    }
                ]
            }
        });

        // Filter bar.
        $('#filterBar').html(`
            <div id="filterBar${this.PROJECT_NAME}" class="w-full mb-3 " ></div>
            <div id="containerHours"></div>
        `);

        // Tabla: el buscador va en su propio hueco porque createTable reescribe el suyo en
        // cada busqueda y borraria el campo mientras se escribe.
        $(`#container${this.PROJECT_NAME}`).html(`<div id="searchBar${this.PROJECT_NAME}"></div><div id="table${this.PROJECT_NAME}"></div>`);
    }

    createFilterBar() {

        let filterBar = [];

        // El filtro de sucursal vive ahora en la navbar (solo admin).
        // Aqui ya no se agrega; se reacciona a su evento 'subsidiaryChanged'.

        filterBar.push(
            {
                opc: "input-calendar",
                class: "col-12 col-md-3 col-lg-2",
                id: "calendar",
                lbl: "Buscar por fecha de captura:",
            },
            {
                opc: "select",
                id: "status",
                lbl: "Seleccionar estados:",
                class: "col-12 col-md-3 col-lg-2",
                onchange: "app.ls()",
                data: [
                    { id: "", valor: "Todos los estados" },
                    ...estado
                ]
            },
            {
                opc: "select",
                id: "order_type",
                lbl: "Tipo de pedido:",
                class: "col-12 col-md-3 col-lg-2",
                onchange: "app.ls()",
                data: [
                    { id: "", valor: "Todos los pedidos" },
                    { id: "custom", valor: "Personalizados" }
                ]
            }
        );

        filterBar.push(
            {
                opc: 'button',
                id: 'btnNuevoPedido',
                class: 'col-6 col-md-3 col-lg-2',
                text: `${lucideIcon('plus')} Nuevo Pedido`,
                className: 'flex items-center justify-center gap-2',
                onClick: () => this.showTypePedido()
            },
            {
                opc: "button",
                id: "btnDailyClose",
                text: `${lucideIcon('receipt')} Cierre del día`,
                class: "col-6 col-md-3 col-lg-2",
                className: 'flex items-center justify-center gap-2',
                color_btn: 'success',
                onClick: () => this.printDailyClose()
            },
            {
                opc: "button",
                className: 'flex items-center justify-center gap-2',
                class: "col-12 col-md-3 col-lg-2",
                color_btn: "secondary",
                id: "btnCalendario",
                text: `${lucideIcon('calendar')} Calendario`,
                onClick: () => {
                    if (!this.requireOpenShift()) return;
                    window.location.href = '../pedidos/calendario/index.php'
                }
            }
        );


        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            coffeesoft: true,
            theme: 'dark',
            data: filterBar
        });

        // El icono del campo de fecha lo pone coffeeForm con Fontello; se cambia por Lucide.
        $('#calendar').next().html(lucideIcon('calendar'));

        // El #subsidiaries_id lo provee la navbar (admin), ya preseleccionado
        // con la sucursal del usuario; aqui no se inicializa.

        const ranges = {
            "Hoy": [moment(), moment()],
            "Ayer": [moment().subtract(1, "days"), moment().subtract(1, "days")],
            "Semana actual": [moment().startOf("week"), moment().endOf("week")],
            "Mes actual": [moment().startOf("month"), moment().endOf("month")],
            "Mes anterior": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")],
        };

        // Un rango con nombre ("Hoy", "Mes actual") se recalcula al abrir, asi "Hoy" sigue
        // siendo hoy al dia siguiente. El personalizado se respeta mientras no haya pasado;
        // si ya termino, se vuelve a "Mes actual".
        const savedRange = JSON.parse(localStorage.getItem('pedidos3_calendar_range') || 'null');
        let [startDate, endDate] = ranges["Mes actual"];

        if (savedRange && ranges[savedRange.label]) {
            [startDate, endDate] = ranges[savedRange.label];
        } else if (savedRange && !moment(savedRange.ff).isBefore(moment(), 'day')) {
            startDate = moment(savedRange.fi);
            endDate   = moment(savedRange.ff);
        }

        dataPicker({
            parent: "calendar",
            rangepicker: {
                startDate: startDate,
                endDate: endDate,
                showDropdowns: true,
                ranges: ranges,
            },
            onSelect: (start, end) => {
                localStorage.setItem('pedidos3_calendar_range', JSON.stringify({
                    label: $('#calendar').data('daterangepicker').chosenLabel,
                    fi: start.format('YYYY-MM-DD'),
                    ff: end.format('YYYY-MM-DD')
                }));
                this.ls();
            },
        });
    }

    actualizarFechaHora(options) {
        let fecha = new Date();
        let opciones = {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "numeric",
            hour12: true,
            parent: "containerHours",
            label: "Sucursal:",
        };
        let opts = Object.assign({}, opciones, options);
        let fechaFormateada = fecha.toLocaleString("es-ES", opts);

        const isOldShift = openShift.has_open_shift && openShift.opened_at && !moment(openShift.opened_at).isSame(moment(), 'day');

        const shiftTime = openShift.has_open_shift && openShift.opened_at
            ? moment(openShift.opened_at).format('h:mm A')
            : '';
        const showShiftInHeader = openShift.has_open_shift && openShift.opened_at && !isOldShift;
        const borderClass = showShiftInHeader ? 'border-b-2 border-green-500/30' : 'border-b border-gray-300';

        const shiftInfo = showShiftInHeader
            ? `<span class="inline-flex items-center gap-1.5 text-[11px] text-gray-500">
                <span class="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
                Turno desde las ${shiftTime}
               </span>
               <span class="text-gray-700">|</span>`
            : '';

        let div = $("<div>", {
            class: `flex justify-between ${borderClass} mt-2 mb-3`,
        }).append(

            $("<label>", {
                html: lucideIcon('map-pin', 'w-4 h-4 mr-1.5') + opts.label,
                class: "text-xs font-medium text-gray-600 text-left flex-1",
                css: { 'font-size': '1rem', 'align-items': 'center', 'display': 'flex' }
            }),
            $("<div>", {
                class: "flex items-center gap-3",
                html: `${shiftInfo}<span class="text-uppercase font-semibold mb-2">${fechaFormateada}</span>`
            })
        );

        $(`#${opts.parent}`).html(div);
    }

    getSubsidiaryLabel() {
        const selected = $('#subsidiaries_id');
        // "Todas" aplica a cualquier rol (admin o cajero en modo consulta).
        if (selected.length && selected.val() === '0') return 'Todas las sucursales';
        // Admin y cajero (rol 2) tienen selector: el label refleja la sucursal filtrada.
        if (!selected.length) return sub_name;
        const selectedName = selected.find('option:selected').text();
        const isOwnSubsidiary = selected.val() == udn;
        return isOwnSubsidiary ? `${selectedName} (Mi sucursal)` : selectedName;
    }

    // Sucursal con la que se FILTRA la lista. Admin, cajero (rol 2) y vendedor
    // (rol 3) filtran por el selector de navbar (incluye "0" = todas). Otros roles
    // => null => el backend usa su sesion. Tambien alimenta el default del selector
    // de sucursal del formulario de pedido; la escritura final la decide ese
    // selector mas el candado de turno abierto del backend.
    getListFilterSubsidiary() {
        const $sel = $('#subsidiaries_id');
        if (!$sel.length) return null;
        const v = $sel.val();
        if (v === '0') return '0';
        return (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) ? (v || '0') : null;
    }

    async onSubsidiaryChange() {
        this.ls();
        await this.checkAndUpdateDailyClosure();
    }

    async checkAndUpdateDailyClosure() {
        // Roles con filtro de navbar (admin 1, cajero 2, vendedor 3): el estado de
        // turno/cierre y el boton "Nuevo pedido" se evaluan contra la sucursal
        // seleccionada en el navbar (personal rotativo: abre turno donde esta parado
        // y opera esa sucursal). El pedido nuevo nace en la sucursal elegida en el
        // selector del formulario, cuyo default es esta misma.
        let subsidiaries_id = this.getListFilterSubsidiary();

        // "Todas" ('0') no libera el candado de turno. Crear y Calendario siguen el turno
        // de la sucursal de la sesion (checkDailyClosure la usa con '0'); editar, cancelar,
        // descontar y cobrar revisan el de la sucursal de cada pedido (requireOpenShift),
        // por eso se refresca aqui el snapshot de turnos. El rotulo lo pone
        // getSubsidiaryLabel().
        if (subsidiaries_id === '0') await this.refreshSubsidiariesCobro();

        const request = await useFetch({
            url: this._link,
            data: { opc: "checkDailyClosure", subsidiaries_id: subsidiaries_id }
        });

        dailyClosure = request || { is_closed: false };

        if (request.open_shift) {
            openShift = request.open_shift;
        } else {
            openShift = { has_open_shift: false };
        }

        this.updateDailyClosureStatus();
        this.actualizarFechaHora({ label: this.getSubsidiaryLabel() });
    }

    // Abrir o cerrar un turno invalida dos estados que viven en memoria: el de la
    // pantalla principal (boton "Nuevo pedido", alertas, hora de apertura) y el
    // indicador de turno del navbar, que solo se cargaba al abrir la pagina. En vez
    // de suponer el nuevo estado en el cliente, se lo volvemos a preguntar al backend:
    // checkAndUpdateDailyClosure ya consulta la sucursal que corresponde a cada rol.
    async syncShiftState() {
        await this.checkAndUpdateDailyClosure();
        await this.refreshSubsidiariesShift();
        if (window.navbar && typeof navbar.refreshShiftStates === 'function') {
            await navbar.refreshShiftStates();
        }
    }

    // Reabre el snapshot `subsidiaries` (shift_opened_at) tras abrir/cerrar un turno:
    // el estado que pinta la tarjeta "Esta sucursal vende como" se carga una sola vez
    // en el init y quedaba desincronizado hasta recargar. Solo roles con selector.
    async refreshSubsidiariesShift() {
        if (!(rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7)) return;

        const res = await useFetch({ url: this._link, data: { opc: "getSubsidiariesShift" } });
        if (!res || !Array.isArray(res.data) || res.data.length === 0) return;

        subsidiaries      = res.data;
        subsidiariesCobro = res.data;

        // Si el selector del formulario esta montado, refrescar en vivo el estado del
        // trigger (sucursal elegida) y de cada fila del panel, y revalidar "Guardar".
        if (!$('#subsidiarySelectorWrap').length) return;

        const selId = $('#formPedido #subsidiaries_id').val();
        const selSub = subsidiaries.find(s => String(s.id) === String(selId));
        if (selSub) $('#subsidiaryTriggerStatus').html(this.subsidiaryStatusLine(selSub));

        $('#subsidiaryPanel .sub-option').each((_, el) => {
            const sub = subsidiaries.find(s => String(s.id) === String($(el).data('sub-id')));
            if (sub) $(el).find('.sub-option-status').html(this.subsidiaryStatusLine(sub));
        });

        this.validateOrderSubsidiary();
    }

    // Snapshot fresco de las sucursales de cobro (shift_opened_at). El init lo carga
    // una sola vez y con el se decide el candado de turno del modal de pagos: si otra
    // sucursal abrio su turno despues de cargar la pagina, sin esto seguiria bloqueada.
    async refreshSubsidiariesCobro() {
        const res = await useFetch({ url: this._link, data: { opc: "getSubsidiariesShift" } });
        if (res && Array.isArray(res.data) && res.data.length) subsidiariesCobro = res.data;
    }

    updateDailyClosureStatus() {
        const btn = $('#btnNuevoPedido');

        // Limpiar todas las alertas previas antes de evaluar el nuevo estado
        $('#dailyClosureAlert, #shiftAlert, #shiftOldAlert').remove();

        if (dailyClosure.is_closed) {
            btn.prop('disabled', true)
               .addClass('opacity-50 cursor-not-allowed')
               .attr('title', 'Ya se realizó el cierre del día');

            if ($('#dailyClosureAlert').length === 0) {
                const alertHtml = `
                    <div id="dailyClosureAlert" class="flex items-center gap-2 mb-3 pl-1">
                        <span class="w-2 h-2 bg-red-400 rounded-full flex-shrink-0"></span>
                        <p class="text-[11px] text-gray-400">
                            Día cerrado <span class="text-gray-600">—</span> <span class="text-gray-500">${dailyClosure.closed_by || ''}${dailyClosure.closed_at ? ', ' + moment(dailyClosure.closed_at).format('hh:mm A') : ''}</span>
                        </p>
                    </div>
                `;
                $('#containerHours').after(alertHtml);
            }
        } else if (!openShift.has_open_shift) {
            btn.prop('disabled', true)
               .addClass('opacity-50 cursor-not-allowed')
               .attr('title', 'Debes abrir un turno de caja');

            if ($('#shiftAlert').length === 0) {
                const alertHtml = `
                    <div id="shiftAlert" class="flex items-center gap-2 mb-3 pl-1">
                        <span class="w-1.5 h-1.5 bg-amber-400 rounded-full animate-pulse flex-shrink-0"></span>
                        <p class="text-[11px] text-gray-500">
                            Sin turno abierto —
                            <a href="javascript:void(0)" onclick="app.printDailyClose()" class="text-amber-400/80 hover:text-amber-300 underline underline-offset-2">abrir turno</a>
                            en "Cierre del día" para crear pedidos
                        </p>
                    </div>
                `;
                $('#containerHours').after(alertHtml);
            }
        } else if (openShift.has_open_shift && openShift.opened_at && !moment(openShift.opened_at).isSame(moment(), 'day')) {
            const shiftDate = moment(openShift.opened_at).locale('es').format('DD/MMM/YYYY');
            btn.prop('disabled', true)
               .addClass('opacity-50 cursor-not-allowed')
               .attr('title', 'Existe un turno abierto de otro día');

            if ($('#shiftOldAlert').length === 0) {
                const alertHtml = `
                    <div id="shiftOldAlert" class="flex items-center gap-2 mb-3 pl-1">
                        <span class="w-1.5 h-1.5 bg-amber-400 rounded-full animate-pulse flex-shrink-0"></span>
                        <p class="text-[11px] text-gray-500">
                            Turno del <span class="text-amber-400/70">${shiftDate}</span> sin cerrar —
                            <a href="javascript:void(0)" onclick="app.printDailyClose()" class="text-amber-400/80 hover:text-amber-300 underline underline-offset-2">cerrar turno</a>
                            para crear nuevos pedidos
                        </p>
                    </div>
                `;
                $('#containerHours').after(alertHtml);
            }
        } else {
            this.enableNewOrderButton();
        }
    }

    enableNewOrderButton() {
        $('#btnNuevoPedido')
            .prop('disabled', false)
            .removeClass('opacity-50 cursor-not-allowed')
            .attr('title', '');

        $('#dailyClosureAlert').remove();
        $('#shiftAlert').remove();
        $('#shiftOldAlert').remove();
    }

    showTypePedido() {
        if (dailyClosure.is_closed) {
            alert({
                icon: "warning",
                title: "Cierre del día realizado",
                text: "No se pueden crear nuevos pedidos porque ya se realizó el cierre del día para esta sucursal.",
                btn1: true,
                btn1Text: "Entendido"
            });
            return;
        }
        if (!openShift.has_open_shift) {
            alert({
                icon: "warning",
                title: "Sin turno abierto",
                text: "Debes abrir un turno de caja antes de crear pedidos. Ve a 'Cierre del día' para abrir turno.",
                btn1: true,
                btn1Text: "Entendido"
            });
            return;
        }
        if (openShift.has_open_shift && openShift.opened_at && !moment(openShift.opened_at).isSame(moment(), 'day')) {
            alert({
                icon: "warning",
                title: "Turno pendiente de otro día",
                text: "Existe un turno abierto que no corresponde al día de hoy. Debes cerrarlo antes de continuar.",
                btn1: true,
                btn1Text: "Entendido"
            });
            return;
        }
        // Entrada al flujo de CREACION: sin modo edicion ni snapshot de cantidades.
        normal.layoutEdit = false;
        normal.layoutPaid = false;
        normal.originalQuantities = null;
        normal.render();
    }

    // Orders.

    ls() {
        let rangePicker = getDataRangePicker("calendar");
        // El selector de sucursal vive en la navbar; lo enviamos explicitamente
        // porque ya no forma parte de la filterBar. "0" = todas (admin y, en modo
        // consulta, tambien el operador via selector hibrido).
        let subsidiaries_id = this.getListFilterSubsidiary();
        this.createTable({
            parent: `table${this.PROJECT_NAME}`,
            idFilterBar: `filterBar${this.PROJECT_NAME}`,
            // search va explicito: el buscador vive sobre la tabla, fuera del filterBar
            // que createTable recoge solo.
            data: { opc: "listOrders", fi: rangePicker.fi, ff: rangePicker.ff, subsidiaries_id: subsidiaries_id, search: $('#search').val() || '' },
            // Sucursal de cada pedido listado: con "Todas" la usa requireOpenShift().
            success: (data) => {
                this.orders = data.orders || [];
            },
            conf: {
                datatable: true, pag: 10, fn_datatable: 'simple_data_table_filter',
            },
            coffeesoft: true,

            attr: {
                id: `tb${this.PROJECT_NAME}`,
                theme: 'dark',
                center: [1, 2,7, 8, 9, 10, 11, 12],
                extends: true,
                f_size:12,
            },
        });

        this.injectShiftPulseStyle();
    }

    // Buscador de folio o cliente. Se monta fuera de createTable (que reescribe su
    // contenedor en cada busqueda) y el CSS de index.php lo alinea con "Mostrar N
    // registros", en el lugar del "Buscar:" de DataTables. El chip de alcance y el boton
    // de limpiar los muestra renderSearchState() mientras hay texto.
    createSearchBar() {
        this.createfilterBar({
            parent: `searchBar${this.PROJECT_NAME}`,
            id: `searchBarForm${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "input-group",
                    id: "search",
                    lbl: "",
                    class: "col-12",
                    placeholder: "Buscar folio, cliente o teléfono",
                    required: false,
                    onkeyup: "app.searchOrders()"
                }
            ]
        });

        // El plugin deja el hueco del icono (input-group-text); se llena con Lucide.
        $('#search').siblings('.input-group-text').html(lucideIcon('search', 'w-3.5 h-3.5'));

        $('#search').attr('autocomplete', 'off').closest('.input-group').append(
            $('<span>', {
                id: 'searchScope',
                class: 'search-scope hidden'
            }),
            $('<button>', {
                type: 'button',
                id: 'searchClear',
                class: 'search-clear hidden',
                title: 'Limpiar búsqueda',
                'aria-label': 'Limpiar búsqueda',
                html: lucideIcon('x', 'w-3 h-3 mx-auto'),
                click: () => this.clearOrderSearch()
            })
        );
    }

    // Espera a que se deje de escribir para no pedir la lista en cada tecla. El valor
    // llega a listOrders como $_POST['search'] (ver ls()).
    searchOrders() {
        this.renderSearchState();
        clearTimeout(this.searchTimer);
        this.searchTimer = setTimeout(() => this.ls(), 400);
    }

    // Con texto en el buscador, listOrders ignora el rango de fechas y el estado (y la
    // sucursal para los roles que ven "Todas"). Esos filtros se atenuan y bloquean, y el
    // propio buscador muestra el alcance y el boton para volver a la lista normal.
    renderSearchState() {
        const buscando = ($('#search').val() || '').trim() !== '';
        const verTodas = [1, 2, 3, 6, 7].includes(Number(rol));

        $('#calendar, #status').closest('[class*="col-"]')
            .toggleClass('opacity-40 pointer-events-none', buscando);

        $('#search').closest('.input-group').toggleClass('is-searching', buscando);

        $('#searchScope')
            .text('Todas las fechas')
            .attr('title', `Busca en todas las fechas${verTodas ? ' y sucursales' : ' de tu sucursal'}, máximo 15 pedidos`)
            .toggleClass('hidden', !buscando);

        $('#searchClear').toggleClass('hidden', !buscando);
    }

    clearOrderSearch() {
        $('#search').val('');
        this.renderSearchState();
        this.ls();
    }

    injectShiftPulseStyle() {
        if ($('#shiftPulseStyle').length) return;
        $('<style id="shiftPulseStyle">').text(
            `.shift-pulse { animation: shiftPulse 3s ease-in-out infinite; }` +
            `@keyframes shiftPulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }`
        ).appendTo('head');
    }

    addOrder() {
        // OJO: no resetear normal.layoutEdit aqui. formCreateOrder() llama a addOrder()
        // tambien durante el render de EDICION (editOrder), y apagar el flag ahi
        // desactiva la validacion de cantidades. El modo lo fija cada punto de
        // entrada: showTypePedido() (crear) y editOrder() (editar).
        // Host <div> (no <form>): coffeeForm crea su propio <form id="formPedido">,
        // asi se evita el anidamiento de formularios.
        $("#container-pedido").html(`<div id="formCreatePedido"></div>`);


        this.createForm({
            parent: "formCreatePedido",
            id: "formPedido",
            coffeesoft: true,
            theme: 'dark',
            data: { opc: "addOrder" },
            json: this.jsonOrder(),

            // Boton apagado mientras se guarda: un doble clic creaba dos pedidos en el
            // mismo segundo y uno quedaba como cotizacion vacia. Con el boton disabled
            // tampoco aplica el envio con Enter.
            beforeSend: () => $("#btnGuardarPedido").prop("disabled", true),

            success: (response) => {
                if (response.status == 200) {

                    alert({
                        icon: "success",
                        title: "Pedido creado con éxito",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Aceptar"
                    });

                    idFolio = response.id;
                    normal.layoutPos();


                    // 🔵 Activar la pestaña "Catálogo de productos"
                    setTimeout(() => {
                        $("#tab-package")
                            .attr("data-state", "active")
                            .addClass("bg-blue-600 text-white")
                            .removeClass("text-gray-300 hover:bg-gray-700")
                            .trigger("click"); // 👈 simula el click real

                        $("#tab-pedido")
                            .attr("data-state", "inactive")
                            .removeClass("bg-blue-600 text-white")
                            .addClass("text-gray-300 hover:bg-gray-700");
                    }, 300);

                    // 🔒 Bloquear todos los campos después de guardar
                    $("#formPedido :input, #formPedido textarea").prop("disabled", true);
                    $("#subsidiaryFilter").prop("disabled", true);

                    // 🙈 Ocultar "Guardar Pedido" y "Salir": el pedido ya existe, ahora
                    // toca seleccionar productos en la pestaña Catálogo. Se oculta el
                    // botón y su columna contenedora para no dejar hueco en el grid.
                    const ocultarBotonesPedido = () => {
                        $("#btnGuardarPedido, #btnRegresar")
                            .hide()
                            .closest('[class*="col-"]').hide();
                    };
                    ocultarBotonesPedido();
                    // Refuerzo tras el cambio de pestaña, por si algo re-renderiza.
                    setTimeout(ocultarBotonesPedido, 350);


                } else {
                    $("#btnGuardarPedido").prop("disabled", false);

                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });

        // render.
        $('#radioDeliveryType').removeClass('col-12 col-lg-6');
        $('#subsidiaryFilter').removeClass('col-12 col-lg-3').addClass('w-full');
        $('#subsidiaryFilter').prev('label').remove();

        // Candado en el submit de "Guardar Pedido" (fase de captura: corre antes del
        // handler de envio del framework, asi el request ni siquiera sale). El backend
        // valida lo mismo; esto es la primera linea de defensa. Dos bloqueos:
        //   1) Sin turno abierto en la sucursal -> no se puede crear el pedido.
        //   2) Admin sin sucursal especifica seleccionada.
        const formEl = document.getElementById('btnGuardarPedido')?.closest('form');
        if (formEl) {
            formEl.addEventListener('submit', (e) => {
                if (!this.requireOpenShift()) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    return;
                }
                if (rol == 1) {
                    const sub = $('#formPedido #subsidiaries_id').val();
                    if (!sub || sub === '0') {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        alert({
                            icon: 'warning',
                            text: 'Selecciona una sucursal específica antes de guardar el pedido.',
                            btn1: true,
                            btn1Text: 'Ok'
                        });
                    }
                }
            }, true);
        }

        $("#date_order").val(new Date().toISOString().split("T")[0]);
        $("#date_birthday").val(new Date().toISOString().split("T")[0]);

        const ahora = new Date();
        const hora = ahora.toTimeString().split(":").slice(0, 2).join(":");
        $("#time_order").val(hora);

        $("#phone").on("input", function () {
            let value = $(this).val().replace(/\D/g, ""); // Elimina caracteres no numéricos
            if (value.length > 10) {
                value = value.slice(0, 10); // Limita a 10 dígitos
            }
            $(this).val(value);
        });


        $('#formPedido #name').autocomplete({
            source: clients.map(client => ({
                label: client.name,   // lo que se muestra en el dropdown
                phone: client.phone,  // extra
                email: client.email   // extra
            })),
            select: function (event, ui) {
                $('#formPedido #phone').val(ui.item.phone);
                $('#formPedido #email').val(ui.item.email);
            }
        });

        // 🔄 Si borra el nombre, limpiar teléfono y correo
        $('#formPedido #name').on("input", function () {
            if ($(this).val().trim() === "") {
                $('#formPedido #phone').val("");
                $('#formPedido #email').val("");
            }
        });

        // Estado inicial del boton segun el turno de la sucursal por defecto
        // (no-op para roles sin selector).
        this.validateOrderSubsidiary();

    }

    // Candado de turno antes de operar. Con una sucursal elegida en la navbar manda su
    // turno (openShift). Con "Todas" ('0') ninguna sucursal decide, asi que para un
    // pedido se revisa el turno de SU sucursal, igual que si se hubiera elegido esa
    // sucursal. Sin pedido (Calendario, crear) o si no esta en el listado, queda openShift.
    requireOpenShift(orderId = null) {
        const order = orderId && this.getListFilterSubsidiary() === '0'
            ? (this.orders || []).find(o => String(o.id) === String(orderId))
            : null;

        // La sucursal que decide: la del pedido cuando la navbar esta en "Todas", o la que
        // evaluo checkDailyClosure (la del navbar, o la de la sesion si esta en "Todas").
        const subId    = order ? order.subsidiaries_id : (dailyClosure ? dailyClosure.subsidiary_id : null);
        const sucursal = (subsidiariesCobro || []).find(s => String(s.id) === String(subId));

        const abierto = order
            ? this.subsidiaryShift(sucursal).status !== 'none'
            : typeof openShift !== 'undefined' && openShift && openShift.has_open_shift;

        if (abierto) return true;

        // El nombre se escapa porque lo captura el admin al dar de alta la sucursal.
        const nombre = $('<span>').text((sucursal && sucursal.valor) || sub_name || 'tu sucursal').html();

        this.alertBox({
            theme:      'dark',
            type:       'warning',
            title:      'No hay turno abierto',
            detailHtml: `La sucursal <b class="text-gray-200">${nombre}</b> no tiene un turno abierto. Debes abrir un turno antes de continuar.`,
            okLabel:    'Entendido'
        });

        return false;
    }

    async editOrder(id, password = null) {
        if (!this.requireOpenShift(id)) return;

        // El pedido se lee ANTES de renderizar: su estado decide que pestaña abre el
        // POS y si el catalogo va bloqueado, y eso lo resuelve formCreateOrder() al
        // pintar, no despues.
        const request = await useFetch({
            url: this._link,
            data: { opc: "getOrder", id }
        });

        // useFetch devuelve null cuando la respuesta no es JSON (un aviso de PHP
        // impreso antes del json_encode, una sesion caida que responde el login).
        // Sin esta guarda el acceso a .data rompia la promesa y el boton Editar se
        // quedaba sin abrir nada y sin decir por que.
        const order = request?.data;

        if (!order) {
            alert({
                icon: "error",
                title: "No se pudo abrir el pedido",
                text: request?.message ?? "El servidor no devolvió una respuesta válida. Revisa la consola del navegador.",
                btn1: true,
                btn1Text: "Ok"
            });

            return;
        }

        idFolio = id;
        normal.layoutEdit = true;
        // Pedido liquidado: ya se cobro y se entrego el ticket, asi que el armado
        // queda congelado; solo siguen abiertos los datos de entrega.
        normal.layoutPaid = order?.status == 3;
        // Snapshot fresco por sesion de edicion: initPos lo captura en la primera carga.
        normal.originalQuantities = null;
        normal.render();

        $("#container-pedido").html(`<div id="formEditPedido"></div>`);

        // Pedido liquidado: la contraseña se pidió en editOrderPaid() antes de
        // llegar aquí; se reenvía en data para que editOrder() (ctrl) la
        // revalide al guardar. No se confía en que el front ya preguntó.
        const data = password
            ? { opc: "editOrder", id, password }
            : { opc: "editOrder", id };

        this.createForm({
            parent: "formEditPedido",
            id: "formPedido",
            coffeesoft: true,
            theme: 'dark',
            data: data,
            autofill: order,
            json: this.jsonOrder(),
            success: (response) => {
                if (response.status == 200) {

                    // Pedido liquidado: no queda nada más que tocar (catálogo y cobro
                    // bloqueados), así que se confirma el guardado y se vuelve al listado.
                    if (normal.layoutPaid) {
                        this.getListClients();

                        alert({
                            icon: "success",
                            title: "Pedido guardado correctamente",
                            text: response.message,
                            btn1: true,
                            btn1Text: "Aceptar"
                        }).then(() => this.render());

                        return;
                    }

                    alert({
                        icon: "success",
                        title: "Pedido actualizado",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Aceptar"
                    });

                    this.getListClients();

                    // 🔒 Bloquear campos tras guardar
                    // $("#formPedido :input, #formPedido textarea").prop("disabled", true);

                    // 🔵 Mostrar pestaña Catálogo de productos
                    setTimeout(() => {
                        $("#tab-package")
                            .attr("data-state", "active")
                            .addClass("bg-blue-600 text-white")
                            .removeClass("text-gray-300 hover:bg-gray-700")
                            .trigger("click");

                        $("#tab-pedido")
                            .attr("data-state", "inactive")
                            .removeClass("bg-blue-600 text-white")
                            .addClass("text-gray-300 hover:bg-gray-700");
                    }, 250);

                    normal.initPos();

                } else {

                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });

        $('#radioDeliveryType').removeClass('col-12 col-lg-6');
        $('#subsidiaryFilter').removeClass('col-12 col-lg-3').addClass('w-full');
        $('#subsidiaryFilter').prev('label').remove();

        // En edición la sucursal del pedido es fija: mostrar la real y bloquear el cambio.
        this.lockSubsidiarySelector(order.subsidiaries_id);

        $("#date_order").val(new Date().toISOString().split("T")[0]);
        if (!$("#date_birthday").val()) $("#date_birthday").val(new Date().toISOString().split("T")[0]);

        const ahora = new Date();
        const hora = ahora.toTimeString().split(":").slice(0, 2).join(":");
        if (!$("#time_order").val()) $("#time_order").val(hora);

        $("#phone").on("input", function () {
            let value = $(this).val().replace(/\D/g, "");
            if (value.length > 10) value = value.slice(0, 10);
            $(this).val(value);
        });

        $('#formPedido #name').autocomplete({
            source: clients.map(client => ({
                label: client.name,   // lo que se muestra en el dropdown
                phone: client.phone,  // extra
                email: client.email   // extra
            })),

            select: function (event, ui) {
                $('#formPedido #phone').val(ui.item.phone);
                $('#formPedido #email').val(ui.item.email);
            }

        });

        // Tipo de entrega del pedido. cfAutofill hace .val() sobre TODOS los inputs que
        // comparten el name, de modo que los dos radios acaban con el mismo value y
        // ninguno queda marcado por el pedido (siempre se veía "Local"). Se devuelven
        // sus valores y se marca el que corresponde.
        const deliveryType = String(order.delivery_type ?? 0);
        $('#formPedido #local').val('0');
        $('#formPedido #domicilio').val('1');
        $(`#formPedido input[name="delivery_type"][value="${deliveryType}"]`).prop('checked', true);

        // 🔄 Si borra el nombre, limpiar teléfono y correo
        $('#formPedido #name').on("input", function () {
            if ($(this).val().trim() === "") {
                $('#formPedido #phone').val("");
                $('#formPedido #email').val("");
            }
        });

        // Al final: el bloqueo desmonta el autocompletado del nombre, que se acaba
        // de inicializar unas líneas arriba.
        if (normal.layoutPaid) this.lockPaidOrderForm();
    }

    // Pedido liquidado: el cliente ya quedó ligado al pedido cobrado, así que sus
    // datos son de solo lectura y únicamente siguen abiertos los de entrega (fecha,
    // hora, tipo y notas). Se usa readonly y no disabled para que los valores viajen
    // igual en el POST; el candado que manda está en editOrder() del controlador,
    // que ni siquiera reescribe el cliente cuando el pedido está liquidado.
    lockPaidOrderForm() {
        $('#formPedido')
            .find('#name, #phone, #email, #date_birthday')
            .prop('readonly', true)
            .addClass('opacity-60 cursor-not-allowed');

        // readonly no cierra el selector nativo de fecha: ese si necesita quedar
        // fuera del alcance del click.
        $('#formPedido #date_birthday').addClass('pointer-events-none');

        $('#formPedido #name').autocomplete('destroy');
    }

    // Pedido liquidado: pide la contraseña antes de abrir el formulario de edición.
    // Se valida aquí para no descubrir una clave mal escrita hasta después de
    // capturar los cambios; la autorización real la vuelve a exigir editOrder()
    // del controlador al guardar.
    editOrderPaid(id) {
        if (!this.requireOpenShift(id)) return;

        this.alertBox({
            theme:       'dark',
            type:        'cancel',
            icon:        'lock',
            title:       'Pedido liquidado',
            detailHtml:  'Ingresa tu contraseña para editar este pedido.',
            input:       'password',
            inputLabel:  'Contraseña',
            inputPlaceholder: '••••••••',
            inputRequired: true,
            inputError:  'Ingresa tu contraseña',
            okLabel:     'Continuar',
            cancelLabel: 'Cancelar',
            onOk: async (password) => {
                const res = await useFetch({
                    url: this._link,
                    data: { opc: 'verifyOrderEditKey', id: id, password: password }
                });

                if (res.status !== 200) {
                    // Contraseña rechazada: se avisa y se vuelve a abrir el dialogo,
                    // porque alertBox ya se cerro al confirmar.
                    this.alertBox({
                        theme:      'dark',
                        type:       'error',
                        title:      'No se puede editar',
                        detailHtml: res.message || 'Contraseña incorrecta.',
                        okLabel:    'Reintentar',
                        onOk:       () => this.editOrderPaid(id)
                    });
                    return;
                }

                this.editOrder(id, password);
            }
        });
    }

    cancelOrder(id) {
        if (!this.requireOpenShift(id)) return;
        const row = event.target.closest('tr');
        const folio = row.querySelectorAll('td')[0]?.innerText || '';

        this.swalQuestion({
            opts: {
                title: `¿Esta seguro?`,
                html: `¿Deseas cancelar el pedido con folio <strong>${folio}</strong>?
                Esta acción actualizará el estado a "Cancelado".`,
            },
            data: { opc: "cancelOrder", status: 4, id: id },
            methods: {
                request: (data) => {
                    alert({
                        icon: "success",
                        title: "Cancelado",
                        text: "El pedido fue cancelado exitosamente.",
                        btn1: true
                    });
                    this.ls();
                },
            },
        });
    }

    // El controlador revalida motivo y contrasena, y rechaza el pedido que ya tenga
    // cobros: ese se cancela, no se elimina.
    deleteOrder(id) {
        const row = event.target.closest('tr');
        const folio = row.querySelectorAll('td')[0]?.innerText || '';

        this.createModalForm({
            id: 'formDeleteOrder',
            data: { opc: 'deleteOrder', id: id },
            bootbox: {
                title: '<i class="icon-trash text-red-400"></i> Eliminar pedido',
                size: 'medium'
            },
            json: [
                {
                    opc: "div",
                    id: "deleteOrderContext",
                    class: 'col-12 mb-3',
                    html: `
                        <div class="bg-[#1E293B] rounded-lg p-3">
                            <p class="text-white text-sm">Se eliminará el pedido <strong>${folio}</strong>.</p>
                            <p class="text-red-400 text-xs mt-1">Es permanente y no se puede deshacer.</p>
                        </div>
                    `
                },
                {
                    opc: "input",
                    id: "reason",
                    lbl: "Motivo de la eliminación",
                    class: "col-12 mb-3",
                    placeholder: "Ej: PEDIDO CAPTURADO POR ERROR",
                    required: true
                },
                {
                    opc: "input",
                    id: "password",
                    lbl: "Tu contraseña",
                    type: "password",
                    class: "col-12 mb-3",
                    placeholder: "••••••••",
                    required: true
                }
            ],
            success: (response) => {
                if (response.status != 200) {
                    alert({
                        icon: "error",
                        title: "No se eliminó",
                        text: response.message,
                        btn1: true
                    });
                    return;
                }

                alert({
                    icon: "success",
                    title: "Eliminado",
                    text: response.message,
                    btn1: true
                });
                this.ls();
            }
        });
    }

    // Descuentos.

    async addDiscount(id) {
        if (!this.requireOpenShift(id)) return;
        const discountInfo = await useFetch({
            url: this._link,
            data: { opc: "getDiscount", id: id }
        });

        const totalPay = parseFloat(discountInfo.data?.total_pay) || 0;
        const currentDiscount = parseFloat(discountInfo.data?.discount) || 0;
        const hasDiscount = currentDiscount > 0;

        this.createModalForm({
            id: 'formAddDiscount',
            data: { opc: 'addDiscount', id: id },
            autofill: discountInfo.data,
            bootbox: {
                title: '<i class="icon-percent text-green-400"></i> Aplicar Descuento',
                size: 'medium'
            },
            json: [
                {
                    opc: "input-group",
                    id: "total_pay",
                    lbl: "Total del pedido",
                    icon: 'icon-dollar',
                    disabled: true,
                    tipo: "cifra",
                    class: "col-12 mb-3"
                },
                {
                    opc: "input-group",
                    id: "discount",
                    lbl: "Monto del descuento",
                    icon: 'icon-dollar',
                    tipo: "cifra",
                    class: "col-12 mb-3",
                    placeholder: "$ 0.00",
                    required: true,
                    onkeyup: `app.calculateDiscounted(${totalPay})`
                },
                {
                    opc: "input",
                    id: "info_discount",
                    lbl: "Motivo del descuento",
                    class: "col-12 mb-3",
                    placeholder: "Ej: CLIENTE FRECUENTE",
                    required: true
                },
                ...(hasDiscount ? [{
                    opc: "button",
                    id: "btnRemoveDiscount",
                    color_btn: "outline-danger",
                    className: 'w-100',
                    text: "Quitar descuento actual",
                    class: "col-12",
                    onClick: () => {
                        this.removeDiscount(id, {
                            discount: currentDiscount,
                            reason: discountInfo.data?.info_discount || '',
                            total: totalPay
                        });
                        $('#formAddDiscount').closest('.bootbox').modal('hide');
                    }
                }] : []),
                {
                    opc: "div",
                    id: "totalDescontado",
                    class: 'col-12',
                    html: `
                        <div class="w-full mt-3 text-center bg-[#1E293B] p-4 rounded-lg">
                            <p class="text-sm text-gray-400 font-medium mb-1">Total con Descuento</p>
                            <p id="TotalConDescuento" class="text-2xl text-white font-bold">${formatPrice(totalPay)}</p>
                        </div>
                    `
                }
            ],
            success: (response) => {
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento aplicado",
                        text: response.message,
                        btn1: true
                    });
                    this.ls();
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });

        this.calculateDiscounted(totalPay);
    }

    calculateDiscounted(totalOriginal) {
        const descuentoInput = document.getElementById("discount");
        const saldoElement = document.getElementById("TotalConDescuento");
        const applyBtn = document.querySelector(".bootbox .btn-primary");

        if (descuentoInput && saldoElement && applyBtn) {
            const saldoOriginal = parseFloat(totalOriginal) || 0;
            const descuento = parseFloat(descuentoInput.value) || 0;
            const nuevoTotal = saldoOriginal - descuento;

            const totalFormateado = nuevoTotal.toLocaleString("es-MX", {
                style: "currency",
                currency: "MXN",
                minimumFractionDigits: 2
            });

            saldoElement.textContent = totalFormateado;

            if (nuevoTotal < 0) {
                saldoElement.classList.add("text-red-500");
                saldoElement.classList.remove("text-white");
            } else {
                saldoElement.classList.remove("text-red-500");
                saldoElement.classList.add("text-white");
            }

            applyBtn.disabled = nuevoTotal < 0;
        }
    }

    removeDiscount(id, orderData) {
        const { discount, reason, total } = orderData;

        this.createModalForm({
            id: "modalQuitarDescuento",
            parent: "root",
            data: { opc: "deleteDiscount", id: id },
            class: "",
            json: [
                {
                    opc: "div",
                    id: "bloqueDescuentoActual",
                    class: "col-12",
                    html: `
                        <div class="bg-[#334155] text-red-400 p-4 rounded-lg mb-3">
                            <p class="text-sm">Descuento actual:</p>
                            <p class="text-lg font-bold">-${formatPrice(discount)}</p>
                            <p class="text-sm text-white">${reason || 'Sin motivo especificado'}</p>
                        </div>
                    `
                },
                {
                    opc: "div",
                    id: "bloquePrecioSinDescuento",
                    class: "col-12",
                    html: `
                        <div class="bg-[#1E293B] p-4 rounded-lg text-center mb-3">
                            <p class="text-sm text-gray-400">Precio sin descuento</p>
                            <p class="text-2xl font-bold text-white">${formatPrice(total)}</p>
                        </div>
                    `
                },
                {
                    opc: "div",
                    id: "mensajeConfirmacion",
                    class: "col-12 text-center",
                    html: `<p class="text-sm text-gray-400">¿Estás seguro de que deseas quitar el descuento aplicado?</p>`
                }
            ],
            bootbox: {
                title: '<i class="icon-tag text-yellow-400"></i> Quitar Descuento',
                closeButton: true
            },
            success: (response) => {
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento eliminado",
                        text: response.message,
                        btn1: true
                    });
                    this.ls();
                } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });
    }

    async editDiscount(id) {
        const discountInfo = await useFetch({
            url: this._link,
            data: { opc: "getDiscount", id: id }
        });

        const data = discountInfo.data || {};
        const totalPay = parseFloat(data.total_pay) || 0;

        this.createModalForm({
            id: 'formEditDiscount',
            data: { opc: 'editDiscount', id: id },
            bootbox: {
                title: '<i class="icon-pencil text-yellow-400"></i> Editar Descuento',
                size: 'medium'
            },
            autofill: {
                discount: data.discount,
                info_discount: data.info_discount
            },
            json: [
                {
                    opc: "div",
                    id: "infoActual",
                    class: "col-12 mb-3",
                    html: `
                        <div class="bg-[#334155] p-3 rounded-lg">
                            <div class="flex justify-between mb-2">
                                <span class="text-gray-400">Total del pedido:</span>
                                <span class="text-white font-semibold">${formatPrice(totalPay)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Descuento actual:</span>
                                <span class="text-red-400 font-semibold">-${formatPrice(data.discount)}</span>
                            </div>
                        </div>
                    `
                },
                {
                    opc: "input-group",
                    id: "discount",
                    lbl: "Nuevo monto del descuento",
                    icon: 'icon-dollar',
                    tipo: "cifra",
                    class: "col-12 mb-3",
                    placeholder: "$ 0.00",
                    required: true,
                    onkeyup: `app.calculateDiscounted(${totalPay})`
                },
                {
                    opc: "input",
                    id: "info_discount",
                    lbl: "Motivo del cambio",
                    class: "col-12 mb-3",
                    placeholder: "Ej: AJUSTE DE PRECIO"
                },
                {
                    opc: "div",
                    id: "totalDescontado",
                    class: 'col-12',
                    html: `
                        <div class="w-full mt-3 text-center bg-[#1E293B] p-4 rounded-lg">
                            <p class="text-sm text-gray-400 font-medium mb-1">Total con Descuento</p>
                            <p id="TotalConDescuento" class="text-2xl text-white font-bold">${formatPrice(totalPay - data.discount)}</p>
                        </div>
                    `
                }
            ],
            success: (response) => {
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento actualizado",
                        text: response.message,
                        btn1: true
                    });
                    this.ls();
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });

        this.calculateDiscounted(totalPay);
    }

    deleteDiscount(id) {
        this.swalQuestion({
            opts: {
                title: '¿Eliminar descuento?',
                html: `¿Estás seguro de eliminar el descuento de este pedido?
                <br><br>
                <span class="text-yellow-500">⚠️ El total del pedido volverá a su valor original.</span>`,
                icon: 'warning'
            },
            data: { opc: 'deleteDiscount', id: id },
            methods: {
                request: (response) => {
                    alert({
                        icon: 'success',
                        title: 'Descuento eliminado',
                        text: response.message,
                        btn1: true
                    });
                    this.ls();
                }
            }
        });
    }

    async printOrder(id) {

        const pos = await useFetch({
            url: api,
            data: { opc: "getOrderDetails", id: id }
        });

        const modal = bootbox.dialog({
            closeButton: true,
            // size: 'large',
            title: ` <div class="flex items-center gap-2 text-white text-lg font-semibold">
                        <i class="icon-print text-blue-400 text-xl"></i>
                        Imprimir
                    </div>`,
            message: `
                <div class="p-2">
                    <div id="containerPrintOrder"></div>
                </div>
            `
        });



        normal.ticketPasteleria({
            parent: 'containerPrintOrder',
            data: {
                head: pos.data.order,
                products: pos.data.products,
                paymentMethods: pos.data.paymentMethods || [],
                clausules: pos.data.clausules || []
            }
        })

    }

    handleDeliveryClick(orderId, currentStatus, folio) {
        Swal.fire({
            title: '📦 Actualizar estado de entrega',
            html: `<p class="mb-3">Selecciona el estado del pedido <strong>${folio}</strong></p>`,
            icon: 'question',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: '✓ Entregado',
            denyButtonText: '🎂 Para producir',
            cancelButtonText: '✗ No entregado',
            confirmButtonColor: '#10b981',
            denyButtonColor: '#db2777',
            cancelButtonColor: '#ef4444',
            reverseButtons: false,
            customClass: {
                popup: 'bg-[#1F2A37] text-white rounded-lg shadow-lg px-2',
                title: 'text-2xl font-semibold',
                content: 'text-gray-300',
                confirmButton: 'bg-[#10b981] hover:bg-[#0E9E6E] text-white py-2 px-4 rounded',
                denyButton: 'bg-[#db2777] hover:bg-[#be185d] text-white py-2 px-4 rounded',
                cancelButton: 'bg-[#ef4444] hover:bg-[#dc2626] text-white py-2 px-4 rounded',
            }
        }).then(async (result) => {
            let newStatus = null;

            if (result.isConfirmed) {
                newStatus = 1; // Entregado
            } else if (result.isDenied) {
                newStatus = 2; // Para producir
            } else if (result.dismiss === Swal.DismissReason.cancel) {
                newStatus = 0; // No entregado
            }

            if (newStatus !== null) {
                const response = await useFetch({
                    url: this._link,
                    data: {
                        opc: 'updateDeliveryStatus',
                        id: orderId,
                        is_delivered: newStatus
                    }
                });

                if (response.status === 200) {
                    this.ls();
                    alert({
                        icon: 'success',
                        title: 'Estado actualizado',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    alert({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                        btn1: true,
                        btn1Text: 'Ok'
                    });
                }
            }
        });
    }

   jsonOrder() {
    const orderFields = [];

    if (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) {
        // Selector de sucursal del pedido (roles con filtro de navbar: admin,
        // cajero y vendedor rotativo). Durante crear/editar el selector de sucursal
        // del navbar se oculta, y ESTE es la fuente de la sucursal del pedido: su
        // input #subsidiaries_id se envia al guardar y lo consumen el candado de
        // submit + validateOrderSubsidiary() (crear) y lockSubsidiarySelector() (editar).
        orderFields.push({
            opc: "div",
            id: "subsidiaryFilter",
            lbl: "",
            class: "col-12 col-lg-3 mb-1",
            html: this.renderSubsidiarySelector()
        });
    } else {
        // Otros roles: el pedido se registra SIEMPRE en su sucursal de sesion
        // (el backend usa $_SESSION['SUB']). Badge informativo, no editable, para
        // dejar claro en que sucursal se esta vendiendo, sin importar el filtro del navbar.
        orderFields.push({
            opc: "div",
            id: "subsidiarySellBadge",
            lbl: "",
            class: "col-12 mb-1",
            html: `
                <div class="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-md px-3 py-2">
                    <i class="icon-shop text-amber-400"></i>
                    <b class="text-xs text-amber-100">${sub_name || 'tu sucursal'}</b>
                </div>
            `
        });
    }

    // Aviso al lado del filtro de sucursal: comparte fila con el, por eso ocupa las
    // columnas restantes en pantallas grandes.
    if (normal.layoutPaid) {
        orderFields.push({
            opc: "div",
            id: "paidOrderNotice",
            lbl: "",
            class: "col-12 col-lg-9 mb-1",
            html: `
                <div class="h-full flex items-center gap-3 bg-amber-500/10 rounded-lg px-3 py-2">
                    <i class="icon-lock text-amber-400 text-lg"></i>
                    <div class="text-xs leading-relaxed">
                        <b class="text-amber-100 block">Pedido liquidado — no se puede editar sin autorización</b>
                        <span class="text-amber-200/80">
                            Solo puedes cambiar fecha de entrega, hora de entrega, tipo de entrega y notas adicionales.
                        </span>
                    </div>
                </div>
            `
        });
    }

    orderFields.push(
        {
            opc: "div",
            id: "lblCliente",
            class: "col-12 mb-1",
            html: `<h3 class="text-base font-bold text-white border-b border-gray-600/60 pb-1.5">Información del cliente</h3>`
        },
        {
            opc: "input",
            lbl: "Nombre del cliente",
            id: "name",
            tipo: "texto",
            class: "col-12 col-sm-6 col-lg-3 mb-3"
        },
        {
            opc: "input",
            lbl: "Teléfono",
            id: "phone",
            tipo: "tel",
            class: "col-12 col-sm-6 col-lg-3 mb-3"
        },
        {
            opc: "input",
            lbl: "Correo electrónico",
            id: "email",
            tipo: "email",
            class: "col-12 col-sm-6 col-lg-3 mb-3",
            required: false
        },
        {
            opc: "input",
            lbl: "Fecha de cumpleaños",
            id: "date_birthday",
            type: "date",
            class: "col-12 col-sm-6 col-lg-3 mb-3",
            required: false
        },
        {
            opc: "div",
            id: "lblPedido",
            class: "col-12 mb-2 mt-2",
            html: `<h3 class="text-base font-bold text-white border-b border-gray-600/60 pb-1.5 pt-1">Datos del pedido</h3>`
        },
        {
            opc: "input",
            lbl: "Fecha de entrega",
            id: "date_order",
            type: "date",
            class: "col-12 col-lg-3 mb-3"
        },
        {
            opc: "input",
            lbl: "Hora de entrega",
            id: "time_order",
            type: "time",
            class: "col-12  col-lg-3 mb-3"
        },
        {
            opc: "div",
            id: "radioDeliveryType",
            lbl: "Tipo de entrega",
            class: "col-12 col-lg-6",
            html: `
                <div class="flex gap-2 mt-2">
                    <label class="w-1/3 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                        <input
                            class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                            type="radio"
                            name="delivery_type"
                            id="local"
                            value="0"
                            onclick="this.value='0'"
                            checked
                        >
                        ${lucideIcon('store', 'w-4 h-4')}
                        <span class="text-sm font-medium">Local</span>
                    </label>

                    <label class="w-1/3 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                        <input
                            class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                            type="radio"
                            name="delivery_type"
                            id="domicilio"
                            value="1"
                            onclick="this.value='1'"
                        >
                        <i class="icon-motorcycle text-amber-500"></i>
                        <span class="text-sm font-medium">A domicilio</span>
                    </label>
                </div>
            `
        },
        {
            opc: "textarea",
            id: "note",
            lbl: "Notas adicionales",
            rows: 3,
            class: "col-12 mb-3",
            required: false
        },
        {
            opc: "btn-submit",
            id: "btnGuardarPedido",
            text: "Guardar Pedido",
            class: "col-12  offset-md-8 offset-lg-8 col-md-2 col-lg-2 "
        },
        {
            opc: "button",
            id: "btnRegresar",
            text: "Salir",
            class: "col-12 col-lg-2 col-md-2 ",
            className: 'w-full',
            icon: "icon-left-open",
            color_btn: "danger",
            onClick: () => this.render()
        }
    );

        return orderFields;
   }


    async getListClients(){
       const response = await useFetch({
           url: api,
           data: { opc: "getListClients" }
       });

       if (response.status === 200) {
           clients = response.data;
       }
   }

    // Estado de turno de una sucursal a partir del snapshot (sub.shift_opened_at):
    // sin turno (gris), turno abierto hoy (verde) o turno de otro dia sin cerrar (ambar).
    subsidiaryShift(sub) {
        const opened = sub && sub.shift_opened_at;
        if (!opened) return { status: 'none', label: 'Sin turno', dot: 'bg-gray-500', canSell: false };
        if (moment(opened).isSame(moment(), 'day')) return { status: 'open', label: 'Turno abierto', dot: 'bg-green-500', canSell: true };
        return { status: 'old', label: 'Turno sin cerrar', dot: 'bg-amber-500', canSell: false };
    }

    subsidiaryStatusLine(sub) {
        const s = this.subsidiaryShift(sub);
        const ubic = (sub && sub.ubication ? sub.ubication : '').trim();
        return `<span class="w-1.5 h-1.5 rounded-full ${s.dot} flex-shrink-0"></span>`
            + `<span>${s.label}</span>`
            + (ubic ? `<span class="text-gray-500 truncate">· ${ubic}</span>` : '');
    }

    // Habilita/bloquea "Guardar Pedido" segun el turno de la sucursal seleccionada.
    // Solo aplica cuando existe el selector (roles 1/2/3); si no, no toca el boton.
    validateOrderSubsidiary() {
        const el = $('#formPedido #subsidiaries_id');
        if (!el.length) return;
        const sub = subsidiaries.find(s => String(s.id) === String(el.val()));
        if (!sub) return;

        const btn = $('#btnGuardarPedido');
        if (this.subsidiaryShift(sub).canSell) {
            btn.prop('disabled', false).removeClass('opacity-50 cursor-not-allowed');
        } else {
            btn.prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
        }
    }

    // Selector de sucursal del formulario (roles con filtro de navbar: admin, cajero
    // y vendedor): card con avatar + panel desplegable con radios. El value real vive
    // en el input hidden #subsidiaries_id (name para el submit) y lo consumen
    // validateOrderSubsidiary() y el candado de submit.

    renderSubsidiarySelector() {
        const current = subsidiaries.find(s => String(s.id) === String(dailyClosure.subsidiary_id ?? udn))
            || subsidiaries[0] || { id: '', valor: '', ubication: '' };

        const chevron = `<svg id="subsidiaryChevron" class="w-4 h-4 text-gray-400 flex-shrink-0 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>`;

        const rows = subsidiaries.map(sub => {
            const isSel = String(sub.id) === String(current.id);
            return `
                <div data-sub-id="${sub.id}" onclick="app.selectSubsidiary('${sub.id}')"
                    class="sub-option flex items-center gap-3 px-3 py-2.5 cursor-pointer transition-colors border-l-2 ${isSel ? 'border-violet-500 bg-violet-500/10' : 'border-transparent hover:bg-white/5'}">
                    <span class="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white text-[11px] font-bold">${this.subsidiaryInitials(sub.valor)}</span>
                    <span class="flex-1 min-w-0">
                        <span class="block text-sm font-medium text-white truncate">${sub.valor}</span>
                        <span class="sub-option-status flex items-center gap-1.5 text-xs text-gray-400 truncate mt-0.5">${this.subsidiaryStatusLine(sub)}</span>
                    </span>
                    <span class="sub-radio flex-shrink-0 w-4 h-4 rounded-full border-2 ${isSel ? 'border-violet-500' : 'border-gray-500'} flex items-center justify-center">
                        <span class="w-2 h-2 rounded-full bg-violet-500 ${isSel ? '' : 'hidden'}"></span>
                    </span>
                </div>`;
        }).join('');

        return `
            <div id="subsidiarySelectorWrap" class="relative w-full">
                <button type="button" id="subsidiaryTrigger" onclick="app.toggleSubsidiarySelector()"
                    class="w-full flex items-center gap-3 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-left hover:border-violet-500/60 transition-colors">
                    <span id="subsidiaryTriggerAvatar" class="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white text-[11px] font-bold">${this.subsidiaryInitials(current.valor)}</span>
                    <span class="flex-1 min-w-0">
                        <span class="block text-[10px] font-semibold tracking-wider text-gray-400 uppercase">Esta sucursal vende como</span>
                        <span id="subsidiaryTriggerName" class="block text-sm font-bold text-white truncate">${current.valor}</span>
                        <span id="subsidiaryTriggerStatus" class="flex items-center gap-1.5 text-xs text-gray-400 truncate mt-0.5">${this.subsidiaryStatusLine(current)}</span>
                    </span>
                    ${chevron}
                </button>
                <input type="hidden" id="subsidiaries_id" name="subsidiaries_id" value="${current.id}">
                <div id="subsidiaryPanel" class="hidden fixed z-[9999] bg-[#161d29] border border-[#2a3444] rounded-xl shadow-2xl overflow-hidden py-1">
                    <p class="px-3 pt-2 pb-1 text-[10px] font-semibold tracking-wider text-gray-400 uppercase">Vender como</p>
                    ${rows}
                </div>
            </div>`;
    }

    subsidiaryInitials(name) {
        const n = (name || '').trim();
        if (!n) return '--';
        return n.replace(/\s+/g, '').slice(0, 2).toUpperCase();
    }

    toggleSubsidiarySelector() {
        const panel = document.getElementById('subsidiaryPanel');
        const trigger = document.getElementById('subsidiaryTrigger');
        const chevron = document.getElementById('subsidiaryChevron');
        if (!panel || !trigger) return;

        if (!panel.classList.contains('hidden')) {
            this.closeSubsidiarySelector();
            return;
        }

        // Posicion fixed bajo el trigger: inmune al overflow del tab (no se recorta).
        const r = trigger.getBoundingClientRect();
        const width = Math.max(r.width, 260);
        const left = Math.max(8, Math.min(r.left, window.innerWidth - width - 8));
        panel.style.top = (r.bottom + 6) + 'px';
        panel.style.left = left + 'px';
        panel.style.width = width + 'px';
        panel.classList.remove('hidden');
        if (chevron) chevron.classList.add('rotate-180');

        if (this.subsidiaryOutsideClose) document.removeEventListener('click', this.subsidiaryOutsideClose);
        setTimeout(() => {
            this.subsidiaryOutsideClose = (e) => {
                if (!trigger.contains(e.target) && !panel.contains(e.target)) this.closeSubsidiarySelector();
            };
            document.addEventListener('click', this.subsidiaryOutsideClose);
        }, 0);
    }

    closeSubsidiarySelector() {
        const panel = document.getElementById('subsidiaryPanel');
        const chevron = document.getElementById('subsidiaryChevron');
        if (panel) panel.classList.add('hidden');
        if (chevron) chevron.classList.remove('rotate-180');
        if (this.subsidiaryOutsideClose) {
            document.removeEventListener('click', this.subsidiaryOutsideClose);
            this.subsidiaryOutsideClose = null;
        }
    }

    selectSubsidiary(id) {
        const sub = subsidiaries.find(s => String(s.id) === String(id));
        if (!sub) return;

        $('#formPedido #subsidiaries_id').val(sub.id);
        $('#subsidiaryTriggerName').text(sub.valor);
        $('#subsidiaryTriggerAvatar').text(this.subsidiaryInitials(sub.valor));
        $('#subsidiaryTriggerStatus').html(this.subsidiaryStatusLine(sub));

        $('#subsidiaryPanel .sub-option').each(function () {
            const isSel = String($(this).data('sub-id')) === String(sub.id);
            $(this).toggleClass('border-violet-500 bg-violet-500/10', isSel)
                   .toggleClass('border-transparent hover:bg-white/5', !isSel);
            $(this).find('.sub-radio').toggleClass('border-violet-500', isSel).toggleClass('border-gray-500', !isSel);
            $(this).find('.sub-radio > span').toggleClass('hidden', !isSel);
        });

        this.closeSubsidiarySelector();
        this.validateOrderSubsidiary();
    }

    // Edición: fija la sucursal del pedido y bloquea el cambio del selector.
    lockSubsidiarySelector(id) {
        const sub = subsidiaries.find(s => String(s.id) === String(id));
        // El hidden NO se deshabilita: un campo disabled no viaja en el FormData y el
        // guardado llegaría sin sucursal. Lo que se bloquea es el trigger visible, que
        // es lo único que el usuario puede tocar.
        $('#formPedido #subsidiaries_id').val(id);
        if (sub) {
            $('#subsidiaryTriggerName').text(sub.valor);
            $('#subsidiaryTriggerAvatar').text(this.subsidiaryInitials(sub.valor));
            $('#subsidiaryTriggerStatus').html(this.subsidiaryStatusLine(sub));
        }
        $('#subsidiaryTrigger').prop('disabled', true).attr('onclick', null)
            .removeClass('hover:border-violet-500/60').addClass('opacity-70 cursor-not-allowed');
        $('#subsidiaryChevron').addClass('hidden');
    }


    // Payments.

    async historyPay(id) {
        if (!this.requireOpenShift(id)) return;

        const data  = await useFetch({ url: this._link, data: { opc: 'initHistoryPay', id } });
        const order = data.order;

        // El candado de turno de la sucursal que cobra se decide con este snapshot.
        await this.refreshSubsidiariesCobro();

        // Escala del modal. El diseño no cambia: se dibuja mas chico, igual que con el
        // zoom del navegador al 75%. Los anchos de abajo van en coordenadas sin escalar,
        // asi que el ancho real en pantalla es el valor por ZOOM.
        const ZOOM = 0.75;

        // El ancho lo manda el tab: el formulario de pago se descuadra si el modal se
        // estira, y el historial son 6 columnas (fecha, metodo, monto, sucursal,
        // observacion y acciones) que no caben en el ancho del formulario. El tope
        // por vw evita que el modal se salga en pantallas chicas.
        const WIDTH_PAY     = '600px';
        // En px: con la transicion activa el navegador no interpola entre una longitud
        // y una funcion como min(), y el ancho se quedaba clavado en el valor anterior.
        const WIDTH_HISTORY = Math.min(820, Math.round(window.innerWidth * 0.95 / ZOOM)) + 'px';
        // La tarjeta del modal es ANCESTRO de #modalAdvance, no descendiente: el ancho
        // se toca por la referencia que devuelve el componente.
        const setModalWidth = width => this.payModal?.el.find('.cf-card').css('max-width', width);

        // createCoffeeModalForm no maneja pestañas, asi que el contenido va como bloque
        // 'html' y el tabLayout se monta dentro. El wrapper conserva el id modalAdvance
        // porque index.php cuelga de el la regla que colapsa los <label> vacios del
        // plugin de formularios.
        const modal = createCoffeeModalForm({
            id: 'frmHistoryPay',
            title: 'Gestión de Pagos',
            iconSvg: lucideIcon('wallet', 'w-5 h-5'),
            iconBg: 'bg-blue-600',
            theme: 'dark',
            width: 600,
            confirmText: 'Registrar Pago',
            confirmBg: 'bg-blue-600 hover:bg-blue-700',
            json: [
                {
                    opc: 'html',
                    html: '<div id="modalAdvance"><div id="containerChat"></div></div>'
                }
            ],
            // El submit del formulario ya trae su propia confirmacion, asi que el boton
            // del modal solo lo dispara. Se devuelve false para que el modal siga abierto:
            // lo cierra el flujo de exito del pago.
            onConfirm: () => {
                document.getElementById('form-payment')?.requestSubmit();
                return false;
            }
        });

        this.payModal = modal;

        // El diseño se mantiene tal cual y se dibuja al 75%, que es como se ve bien con
        // el zoom del navegador en esa escala. zoom (no transform: scale) porque rehace
        // el layout: la tarjeta ocupa de verdad menos espacio y los clics siguen cayendo
        // donde toca. El max-height es solo una red de seguridad para pantallas bajas.
        const $card = modal.el.find('.cf-card');

        $card.css({
            'zoom':           ZOOM,
            'max-height':     Math.round(92 / ZOOM) + 'vh',
            'display':        'flex',
            'flex-direction': 'column',
            'overflow':       'hidden',
            'transition':     'max-width .2s ease'
        });

        $card.children('.space-y-3').css({ 'overflow-y': 'auto', 'flex': '1 1 auto', 'min-height': '0' });

        // Folio y fecha como subtitulo del encabezado, aprovechando el hueco que deja el
        // icono: en su propia linea gastaban una fila entera del cuerpo. El componente no
        // admite subtitulo por opciones, asi que se inserta sobre el header ya montado.
        const $header = $card.children().first();
        const $titulo = $header.find('span').first();

        $header.removeClass('items-center mb-3').addClass('items-start mb-2');
        $titulo.wrap('<div class="flex-1 min-w-0"></div>').after(`
            <p class="text-[13px] text-gray-400 flex items-center gap-3 mt-0.5">
                <span class="flex items-center gap-1.5">
                    ${lucideIcon('file-text', 'w-3.5 h-3.5')}
                    Folio <b class="text-blue-400 font-semibold">${order.folio}</b>
                </span>
                <span class="flex items-center gap-1.5">
                    ${lucideIcon('calendar', 'w-3.5 h-3.5')}
                    ${order.formatted_date_order || order.date_order}
                </span>
            </p>`);

        // Se elimina el boton cancelar del componente: el modal ya se cierra con la X,
        // Escape o clic fuera, y sin el hermano el de registrar (flex-1) toma el ancho
        // completo. El footer entero se oculta en el historial, donde no hay que
        // registrar nada y un boton suelto solo estorba.
        modal.el.find('.cf-cancel').remove();
        const footerBtns = modal.el.find('.cf-confirm').parent();

        this.tabLayout({
            parent: 'containerChat',
            id: 'tabsHistoryPay',
            theme: 'dark',
            json: [
                { id: 'payment', tab: 'Registrar Pago', icon: 'icon-plus-circled', active: true, onClick: () => { setModalWidth(WIDTH_PAY); footerBtns.show(); } },
                { id: 'listPayment', tab: 'Historial de Pagos', icon: 'icon-list', onClick: () => { setModalWidth(WIDTH_HISTORY); footerBtns.hide(); } },
            ]
        });

        // Renders
        $('#container-listPayment').html('<div id="container-info-payment"></div><div id="container-methodPay"></div>');

        this.addPayment(order, id);
        this.renderResumenPagos(data.details);
        this.lsPay(id);
    }

    async addPayment(order, id) {
        // Totales base
        this.totalPay = order.total_pay;
        this.totalPaid = order.total_paid;
        this.discount = order.discount ?? 0;

        const saldoOriginal = order.total_pay;
        const discount = order.discount ?? 0;
        const saldoRestante = order.total_pay - discount - order.total_paid;
        const isPaidInFull = saldoRestante <= 0;

        // El candado de turno no debe reactivar el formulario de un pedido ya pagado.
        this.payIsPaidInFull = isPaidInFull;

        // Sucursal de cobro (cobro cruzado). Default = sucursal activa: roles con
        // filtro de navbar (admin 1, cajero 2, vendedor 3) -> filtro de la navbar
        // (si "Todas"/0, cae a su sesion udn o a la del pedido). Fallback final:
        // la sucursal del pedido.
        const navbarSub = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) ? ($('#subsidiaries_id').val() || '') : '';
        const defaultCobroSub = (navbarSub && navbarSub !== '0')
            ? navbarSub
            : ((rol != 1 && udn) ? udn : (order.subsidiaries_id ?? ''));

        // Sucursal de origen del pedido (referencia para el cobro cruzado).
        const origenSub    = (subsidiariesCobro || []).find(s => String(s.id) === String(order.subsidiaries_id));
        const origenNombre = origenSub ? origenSub.valor : '—';

        // Estado inicial de la tarjeta "Sucursal que cobrará".
        const origenSubId      = String(order.subsidiaries_id ?? '');
        const cobroSubSel      = (subsidiariesCobro || []).find(s => String(s.id) === String(defaultCobroSub));
        const cobroNombre      = cobroSubSel ? cobroSubSel.valor : origenNombre;
        const cobroEsMismaSuc  = String(defaultCobroSub) === origenSubId;
        const cobroSubtitulo   = cobroEsMismaSuc ? 'Misma sucursal de origen' : 'Cobro en otra sucursal';
        const cobroOptionsHtml = (subsidiariesCobro || [])
            .map(s => `<option value="${s.id}" ${String(s.id) === String(defaultCobroSub) ? 'selected' : ''}>${s.valor}</option>`)
            .join('');

        // Metodos de pago. El value es el id que espera el backend (1=Efectivo,
        // 2=Tarjeta, 3=Transferencia) y vive en el input hidden #method_pay_id que
        // lee el form al registrar el pago.
        const metodosPago = [
            { id: '1', label: 'Efectivo',      sub: 'Pago en efectivo', icon: 'banknote' },
            { id: '2', label: 'Tarjeta',       sub: 'Débito o crédito', icon: 'credit-card' },
            { id: '3', label: 'Transferencia', sub: 'Depósito o SPEI',  icon: 'arrow-right-left' }
        ];
        const metodoDefault = metodosPago[0];

        // Los tres a la vista en lugar de un desplegable: con solo tres opciones,
        // plegarlas escondia dos y cobraba un clic por verlas. Ocupan el mismo alto.
        const methodPayOptionsHtml = metodosPago.map((m, i) => `
            <button type="button" data-value="${m.id}"
                class="js-method-btn flex flex-col items-center justify-center gap-1 rounded-lg border px-1 py-2 text-center transition-colors ${i === 0 ? METHOD_BTN.on : METHOD_BTN.off}"
                ${isPaidInFull ? 'disabled' : ''}>
                ${window.lucideIcon(m.icon, 'w-5 h-5')}
                <span class="text-[11px] font-semibold leading-tight">${m.label}</span>
                <span class="text-[9px] leading-tight opacity-75">${m.sub}</span>
            </button>`).join('');

        const methodPayCardHtml = `
            <input type="hidden" id="method_pay_id" name="method_pay_id" value="${metodoDefault.id}" required>
            <div class="grid grid-cols-3 gap-1.5 ${isPaidInFull ? 'opacity-60' : ''}">
                ${methodPayOptionsHtml}
            </div>`;

        // Contenedor del formulario centrado y reducido
        $("#container-payment").html(`
            <div class="flex justify-center items-start">
                <div class="w-full">
                    <form id="form-payment" novalidate></form>
                </div>
            </div>
        `);

        this.createForm({
            id: "formRegisterPayment",
            parent: "form-payment",
            data: {
                opc: "addPayment",
                total: order.total_pay,
                saldo: saldoRestante,
                id: id
            },
            json: [
                {
                    opc: "div",
                    id: "Amount",
                    class: "col-12 mb-2",
                    html: `
                    <div id="dueAmount" class="p-2.5 rounded-xl ${isPaidInFull ? 'bg-green-900/30' : 'bg-[#1E293B]'} text-white text-center">
                        <p class="text-[13px] opacity-80">${isPaidInFull ? 'Pedido pagado completamente' : 'Monto restante a pagar'}</p>
                        <p id="SaldoEvent" class="text-lg font-bold leading-tight">
                            ${formatPrice(saldoRestante)}
                        </p>
                        ${discount > 0 ? `
                            <div class="mt-1.5 pt-1.5 border-t border-gray-600">
                                <p class="text-[11px] text-gray-400">Total original: <span class="line-through">${formatPrice(saldoOriginal)}</span></p>
                                <p class="text-[11px] text-green-400 flex items-center justify-center gap-1">${lucideIcon('tag', 'w-3 h-3')} Descuento aplicado: -${formatPrice(discount)}</p>
                            </div>
                        ` : ''}
                        ${isPaidInFull ? lucideIcon('circle-check', 'w-5 h-5 text-green-400 mt-0.5 inline-block') : ''}
                    </div>`
                },
                {
                    opc: "div",
                    id: "cardMethodPay",
                    class: "col-12 mb-2",
                    lbl: "Método de pago",
                    html: methodPayCardHtml
                },
                {
                    opc: "div",
                    id: "origenPedido",
                    lbl: "Origen del pedido",
                    class: "col-12 mb-2",
                    html: `<div class="flex items-center gap-2.5 bg-[#1E293B] border border-slate-700 rounded-lg px-2.5 py-1.5">
                        <div class="flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 text-gray-300 shrink-0">
                            ${lucideIcon('house', 'w-4 h-4')}
                        </div>
                        <div class="flex flex-col leading-tight min-w-0">
                            <span class="text-sm text-white font-semibold truncate">${origenNombre}</span>
                            <span class="text-[11px] text-gray-400">Sucursal donde se generó la venta</span>
                        </div>
                    </div>`
                },
                {
                    opc: "div",
                    id: "cobroWrapper",
                    lbl: "Sucursal que cobrará",
                    // mb-2 como el resto: el mb-3 abria un hueco mayor justo antes de Importe.
                    class: "col-12 mb-2",
                    html: `<div class="relative">
                        <div id="cobroCard" class="flex items-center gap-2.5 bg-[#1E293B] border ${cobroEsMismaSuc ? 'border-slate-700' : 'border-amber-500/60'} rounded-lg px-2.5 py-1.5 pointer-events-none">
                            <div id="cobroCardIcon" class="flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 ${cobroEsMismaSuc ? 'text-blue-400' : 'text-amber-400'} shrink-0">
                                ${lucideIcon('landmark', 'w-4 h-4')}
                            </div>
                            <div class="flex flex-col leading-tight flex-1 min-w-0">
                                <span id="cobroCardName" class="text-sm text-white font-semibold truncate">${cobroNombre}</span>
                                <span id="cobroCardSub" class="text-[11px] text-gray-400">${cobroSubtitulo}</span>
                            </div>
                            ${lucideIcon('chevron-down', 'w-4 h-4 text-gray-400 shrink-0')}
                        </div>
                        <select id="payment_subsidiaries_id" name="payment_subsidiaries_id" data-origen="${origenSubId}" required
                            class="absolute inset-0 w-full h-full opacity-0 ${isPaidInFull ? 'cursor-not-allowed' : 'cursor-pointer'}"
                            ${isPaidInFull ? 'disabled' : ''} onchange="app.onCobroChange(this)">
                            ${cobroOptionsHtml}
                        </select>
                    </div>
                    <div id="cobroShiftAlert" class="hidden mt-1.5"></div>`
                },
                {
                    opc: "input",
                    type: "number",
                    id: "advanced_pay",
                    lbl: "Importe",
                    class: "col-12 mb-2",
                    placeholder: "0.00",
                    required: true,
                    min: 0,
                    onkeyup: "app.updateTotal()",
                    disabled: isPaidInFull
                },
                {
                    opc: "textarea",
                    id: "description",
                    lbl: "Observación",
                    class: "col-12 mb-2",
                    disabled: isPaidInFull
                }
                // Sin btn-submit: el boton de registrar es el del footer del modal
                // (.cf-confirm), que dispara el submit de este formulario.
            ],
            success: async (response) => {
                if (response.status === 200) {

                    const data = response.data;

                    // ✅ Alert con cierre automático
                    alert({
                        icon: "success",
                        text: "Pago registrado correctamente ✅",
                        timer: 1000
                    });

                    // Refrescar pagos y vista general
                    this.lsPay(id);
                    this.ls();
                    this.renderResumenPagos(data.details);

                    // Recalcular saldo restante sin redibujar
                    const order = data.order;
                    const discount = order.discount ?? 0;
                    const restante2 = order.total_pay - discount - order.total_paid;
                    this.totalPay = order.total_pay;
                    this.totalPaid = order.total_paid;
                    this.discount = discount;

                    // Verificar si se pagó completamente
                    if (restante2 <= 0) {
                        // Recargar el formulario para mostrar estado pagado
                        this.addPayment(order, id);
                    } else {
                        $("#SaldoEvent").text(formatPrice(restante2));
                        $("#advanced_pay").val("");
                        $("#description").val("");
                        app.updateTotal();
                    }

                } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }

            }
        });

        // ── Interacción del selector de método ─────────────────────────────────
        const $payRoot = $('#container-payment');
        $payRoot.off('click.dd');

        // Elegir metodo: mueve el estado activo entre los tres botones, actualiza el
        // hidden que viaja al backend y reescribe el boton de registrar.
        $payRoot.on('click.dd', '.js-method-btn:not([disabled])', function (e) {
            e.preventDefault();
            const $btn = $(this);

            $btn.siblings('.js-method-btn').removeClass(METHOD_BTN.on).addClass(METHOD_BTN.off);
            $btn.removeClass(METHOD_BTN.off).addClass(METHOD_BTN.on);

            $('#method_pay_id').val($btn.attr('data-value'));
            app.refreshPayButton();
        });

        // Confirmación antes de registrar el pago. Se intercepta el submit en fase
        // de captura (antes de validation_form): si no está confirmado, se bloquea,
        // se valida el importe y se pregunta; al confirmar se reenvía con bandera
        // para que el flujo normal (validación + AJAX) continúe.
        const formEl = document.getElementById('form-payment');
        if (formEl) {
            formEl.addEventListener('submit', async (e) => {
                if (formEl.dataset.payConfirmed === '1') {
                    formEl.dataset.payConfirmed = '';
                    return; // ya confirmado: dejar pasar a validation_form
                }
                e.preventDefault();
                e.stopImmediatePropagation();

                // Sin turno abierto en la sucursal que cobra el dinero no entra a
                // ningun corte: se bloquea aqui y tambien en el backend.
                if (!this.requireCobroShift()) return;

                const importe = parseFloat($('#advanced_pay').val()) || 0;
                if (importe <= 0) {
                    alert({ icon: 'error', text: 'Ingresa un importe válido para registrar el pago.', btn1: true, btn1Text: 'Ok' });
                    return;
                }

                // Datos legibles para que el usuario entienda cómo se registrará el pago.
                const metodos = { '1': 'Efectivo', '2': 'Tarjeta', '3': 'Transferencia' };
                const metodoTxt = metodos[String($('#method_pay_id').val())] || '—';
                const subCobroId = String($('#payment_subsidiaries_id').val() || '');
                const subCobroObj = (subsidiariesCobro || []).find(s => String(s.id) === subCobroId);
                const subCobroNombre = subCobroObj ? subCobroObj.valor : origenNombre;
                // Cobro cruzado: la sucursal que cobra es distinta a la de origen del pedido.
                const esCruzado = subCobroId !== '' && String(order.subsidiaries_id ?? '') !== subCobroId;

                const row = (lbl, val, color = '#fff') => `
                    <div style="display:flex;justify-content:space-between;gap:16px;padding:3px 0;">
                        <span style="color:#9ca3af;">${lbl}</span><b style="color:${color};">${val}</b>
                    </div>`;

                const htmlConfirm = `
                    <div style="text-align:left;font-size:14px;line-height:1.5;">
                        ${row('Importe', formatPrice(importe))}
                        ${row('Método de pago', metodoTxt)}
                        ${row('Sucursal que cobra', subCobroNombre, '#A78BFA')}
                        ${esCruzado ? `
                        <div style="margin-top:10px;padding:8px 10px;border-radius:8px;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.4);color:#fcd34d;font-size:12.5px;line-height:1.45;">
                            Cobro cruzado: el pedido es de <b>${origenNombre}</b>, pero el cobro se registrará en <b>${subCobroNombre}</b>.
                        </div>` : ''}
                    </div>`;

                const res = await alert({
                    icon: 'question',
                    title: '¿Registrar pago?',
                    html: htmlConfirm,
                    btn1Text: 'Sí, registrar',
                    btn2Text: 'Cancelar'
                });

                if (res && res.isConfirmed) {
                    formEl.dataset.payConfirmed = '1';
                    formEl.requestSubmit();
                }
            }, true);
        }

        // Aplicar estilos disabled si está pagado
        if (isPaidInFull) {
            setTimeout(() => {
                $("#advanced_pay, #description, #btnSuccess").prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
                $('.cf-confirm').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Pedido Pagado');
            }, 100);
        }

        // Estado inicial del candado de turno. Va despues del bloque de "pagado" para
        // no pelearse con el, y con retraso porque el boton vive en el footer del modal.
        setTimeout(() => this.applyCobroShiftLock(), 120);
    }

    // Turno de la sucursal que cobra: sin turno abierto de hoy el pago no puede
    // registrarse (el dinero no caeria en ningun corte). Pinta el aviso bajo el
    // selector y bloquea importe, observacion y el boton de registrar.
    applyCobroShiftLock() {
        const sub = (subsidiariesCobro || []).find(s => String(s.id) === String($('#payment_subsidiaries_id').val() || ''));
        const st  = this.subsidiaryShift(sub);

        const $alert = $('#cobroShiftAlert');

        if (st.canSell) {
            $alert.addClass('hidden').empty();
        } else {
            const nombre  = sub ? sub.valor : 'seleccionada';
            const titulo  = st.status === 'old' ? 'Turno sin cerrar' : 'Sucursal sin turno abierto';
            const detalle = st.status === 'old'
                ? `La sucursal <b class="text-gray-300">${nombre}</b> tiene un turno de otro día sin cerrar; no se puede registrar este pago.`
                : `La sucursal <b class="text-gray-300">${nombre}</b> debe abrir su turno para poder registrar este pago.`;

            $alert.removeClass('hidden').html(`
                <div class="flex items-start gap-2 bg-amber-500/10 rounded-lg px-2.5 py-1.5">
                    <span class="text-amber-400 shrink-0 mt-0.5">${lucideIcon('circle-alert', 'w-4 h-4')}</span>
                    <div class="flex flex-col leading-tight min-w-0">
                        <span class="text-[12px] font-semibold text-amber-300">${titulo}</span>
                        <span class="text-[11px] text-gray-400">${detalle}</span>
                    </div>
                </div>`);
        }

        if (this.payIsPaidInFull) return st;

        const locked = !st.canSell;
        $('#advanced_pay, #description').prop('disabled', locked).toggleClass('opacity-50 cursor-not-allowed', locked);
        $('.cf-confirm').prop('disabled', locked).toggleClass('opacity-50 cursor-not-allowed', locked);

        return st;
    }

    requireCobroShift() {
        const st = this.applyCobroShiftLock();
        if (st.canSell) return true;

        const sub    = (subsidiariesCobro || []).find(s => String(s.id) === String($('#payment_subsidiaries_id').val() || ''));
        const nombre = sub ? sub.valor : 'seleccionada';

        alert({
            icon: 'warning',
            title: st.status === 'old' ? 'Turno sin cerrar' : 'Sucursal sin turno abierto',
            text: st.status === 'old'
                ? `La sucursal ${nombre} tiene un turno de otro día sin cerrar. Debe cerrarlo y abrir el turno de hoy para registrar este pago.`
                : `La sucursal ${nombre} debe abrir su turno de caja para poder registrar este pago.`,
            btn1: true,
            btn1Text: 'Entendido'
        });

        return false;
    }

    onCobroChange(sel) {
        const $sel   = $(sel);
        const id     = String($sel.val() || '');
        const nombre = $sel.find('option:selected').text().trim();
        const origen = String($sel.data('origen') || '');
        const same   = id === origen;

        $('#cobroCardName').text(nombre);
        $('#cobroCardSub').text(same ? 'Misma sucursal de origen' : 'Cobro en otra sucursal');
        $('#cobroCard')
            .toggleClass('border-slate-700', same)
            .toggleClass('border-amber-500/60', !same);
        $('#cobroCardIcon')
            .toggleClass('text-blue-400', same)
            .toggleClass('text-amber-400', !same);

        this.applyCobroShiftLock();
    }

    // Desde el historial el monto se lee de su fila de la tabla. El resumen de pago del
    // detalle lo manda en amount porque sus abonos no son filas <tr>, y pide la
    // contraseña siempre (pedirClave), este o no liquidado el pedido.
    deletePay(id, idFolio, requiereClave = 0, amount = null, pedirClave = false) {
        if (amount === null) {
            const row = event.target.closest("tr");
            amount = parseFloat(row.cells[2].textContent.replace(/[^\d.-]/g, ""));
        }

        // Pedido liquidado: el controlador exige la contraseña del usuario en
        // sesión, así que se confirma con ella en vez del sí/no de siempre.
        if (requiereClave == 1 || pedirClave) {
            this.deletePayWithKey(id, idFolio, amount, requiereClave == 1);
            return;
        }

        this.swalQuestion({
            opts: {
                title: "¿Confirmar eliminación?",
                text: `Se eliminará el pago de ${formatPrice(amount)} de forma permanente.`,
                icon: "warning"
            },
            data: { opc: "deletePay", id: idFolio, amount: amount, idPay: id },
            methods: {
                success: (res) => {
                    if (res.status === 200) {
                        this.afterDeletePay(res, idFolio);
                    } else {
                        alert({ icon: "error", text: res.message });
                    }
                }
            }
        });
    }

    // Borrado autorizado. Liquidado: el saldo del pedido ya es cero, por lo que
    // eliminar un abono reabre un pedido cerrado. Sin liquidar: confirmacion con
    // contraseña desde el resumen de pago del detalle. Este modal solo recolecta la
    // contraseña; quien la valida es deletePay() del controlador.
    deletePayWithKey(id, idFolio, amount, liquidado = true) {
        this.alertBox({
            theme:       'dark',
            type:        'cancel',
            icon:        'lock',
            title:       liquidado ? 'Pedido liquidado' : 'Eliminar pago',
            detailHtml:  `Ingresa tu contraseña para eliminar el pago de <b class="text-gray-200">${formatPrice(amount)}</b>.`,
            input:       'password',
            inputLabel:  'Contraseña',
            inputPlaceholder: '••••••••',
            inputRequired: true,
            inputError:  'Ingresa tu contraseña',
            okLabel:     'Eliminar pago',
            okBg:        'bg-[#E02424] hover:bg-[#C81E1E]',
            cancelLabel: 'Cancelar',
            onOk: async (password) => {
                const res = await useFetch({
                    url: this._link,
                    data: { opc: 'deletePay', id: idFolio, amount: amount, idPay: id, password: password }
                });

                if (res.status !== 200) {
                    // Contraseña rechazada: se avisa y se vuelve a abrir el dialogo,
                    // porque alertBox ya se cerro al confirmar.
                    this.alertBox({
                        theme:      'dark',
                        type:       'error',
                        title:      'No se eliminó el pago',
                        detailHtml: res.message || 'Contraseña incorrecta.',
                        okLabel:    'Reintentar',
                        onOk:       () => this.deletePayWithKey(id, idFolio, amount, liquidado)
                    });
                    return;
                }

                this.afterDeletePay(res, idFolio);
            }
        });
    }

    // Refresco comun tras eliminar un pago (con o sin contraseña): resumen, lista,
    // tabla de pedidos y formulario de cobro con el saldo nuevo. Si se borro desde el
    // resumen de pago del detalle, Gestion de Pagos (#modalAdvance) no esta abierto y
    // lo que se repinta es el detalle.
    afterDeletePay(res, idFolio) {
        const data = res.initHistoryPay;

        if ($('#orderInfoPanel').length) this.refreshOrderDetails(idFolio);

        if ($('#modalAdvance').length) {
            this.renderResumenPagos(data.details);
            this.lsPay(idFolio);

            const order = data.order;
            this.totalPay = order.total_pay;
            this.totalPaid = order.total_paid;

            // Recargar el formulario para reflejar el nuevo estado
            this.addPayment(order, idFolio);
        }

        this.ls();

        alert({
            icon: "success",
            text: res.message || "Pago eliminado correctamente. Saldo actualizado.",
            timer: 2000
        });
    }

    async lsPay(id) {
        // Obtener los pagos primero para verificar si existen
        const response = await useFetch({
            url: this._link,
            data: { opc: 'listPayment', id: id }
        });

        // Verificar si hay pagos
        if (!response.row || response.row.length === 0) {
            // Mostrar mensaje cuando no hay pagos
            $("#container-methodPay").html(`
                <div class="flex flex-col items-center justify-center py-12 text-center bg-[#1E293B] border border-slate-700 rounded-xl">
                    <div class="w-16 h-16 rounded-2xl bg-slate-700/60 flex items-center justify-center mb-4">
                        ${lucideIcon('history', 'w-7 h-7 text-gray-400')}
                    </div>
                    <p class="text-gray-300 text-base font-semibold mb-1">Aún no se ha realizado ningún abono</p>
                    <p class="text-gray-500 text-sm">Los pagos registrados aparecerán aquí</p>
                </div>
            `);
            return;
        }

        // Si hay pagos, mostrar la tabla
        this.createTable({
            parent: "container-methodPay",
            idFilterBar: "filterBarEventos",
            data: { opc: 'listPayment', id: id },
            conf: { datatable: false, pag: 8 },
            coffeesoft: true,

            attr: {
                id: "tableOrder",
                theme: 'dark',
                center: [1, , 3, 6, 7],
                right: [4,],
                f_size: 11,
                extends: true,
            },
        });

    }

    renderResumenPagos(totales) {
        const totalPagado = totales?.pagado ?? 0;
        const discount = totales?.discount ?? 0;
        const totalEvento = totales?.total ?? 0;

        // El total sin descuento es el total actual + lo descontado
        const totalConDescuento = totalEvento - discount;
        const restante = totalConDescuento - totalPagado;

        // Formateador de moneda
        const fmt = (n) => n.toLocaleString('es-MX', {
            style: 'currency',
            currency: 'MXN',
            minimumFractionDigits: 2
        });

        // Liquidado: el restante deja de ser una alerta y se pinta en verde como el
        // total pagado, para que la tarjeta no siga en rojo con saldo cero.
        const liquidado = restante <= 0;

        let originalHTML = `<p class="text-lg font-bold text-blue-400 mt-1" id="totalEvento">${formatPrice(totalEvento)}</p>`;

        // Si hay descuento, mostrar desglose visual
        if (discount > 0) {
            originalHTML = `
            <p class="text-lg font-bold text-blue-400 mt-1" id="totalEvento">${fmt(totalConDescuento)}</p>
            <p class="text-xs text-gray-500 line-through">${fmt(totalEvento)}</p>
            <p class="text-xs text-emerald-400 mt-1 flex items-center justify-center gap-1">
                ${lucideIcon('tag', 'w-3 h-3')} Descuento:
                <span class="font-semibold">${fmt(discount)}</span>
            </p>
        `;
        }

        $('#container-info-payment').html(`
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">

            <div class="bg-emerald-500/10 rounded-xl p-3 text-center">
                <p class="text-xs text-emerald-400/80 flex items-center justify-center gap-1.5">
                    ${lucideIcon('circle-check', 'w-3.5 h-3.5')} Total pagado
                </p>
                <p class="text-lg font-bold text-emerald-400 mt-1" id="totalPagado">${fmt(totalPagado)}</p>
            </div>

            <div class="bg-blue-500/10 rounded-xl p-3 text-center">
                <p class="text-xs text-blue-400/80 flex items-center justify-center gap-1.5">
                    ${lucideIcon('wallet', 'w-3.5 h-3.5')} Total
                </p>
                ${originalHTML}
            </div>

            <div class="${liquidado ? 'bg-emerald-500/10' : 'bg-red-500/10'} rounded-xl p-3 text-center">
                <p class="text-xs ${liquidado ? 'text-emerald-400/80' : 'text-red-400/80'} flex items-center justify-center gap-1.5">
                    ${lucideIcon(liquidado ? 'circle-check' : 'clock', 'w-3.5 h-3.5')} Restante
                </p>
                <p class="text-lg font-bold ${liquidado ? 'text-emerald-400' : 'text-red-400'} mt-1" id="totalRestante">${fmt(restante)}</p>
            </div>

        </div>
    `);
    }

    renderOrderInfo(order) {
        const html = `
            <div class="space-y-4">
                <!-- Información del Cliente -->
                <div class="bg-[#1F2A37] rounded-lg p-4">
                    <h3 class="text-white font-semibold mb-3 flex items-center gap-2">
                        <i class="icon-user text-blue-400"></i>
                        Información del Cliente
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="flex items-center gap-3">
                            <i class="icon-user-1 text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Nombre:</p>
                                <p class="text-white font-semibold">${order.name || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-phone text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Teléfono:</p>
                                <p class="text-white font-semibold">${order.phone || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-mail text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Correo:</p>
                                <p class="text-white font-semibold">${order.email || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-birthday text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Cumpleaños:</p>
                                <p class="text-white font-semibold">${order.date_birthday || 'N/A'}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Detalles del Pedido -->
                <div class="bg-[#1F2A37] rounded-lg p-4">
                    <h3 class="text-white font-semibold mb-3 flex items-center gap-2">
                        <i class="icon-doc-text text-blue-400"></i>
                        Detalles del Pedido
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="flex items-center gap-3">
                            <i class="icon-doc-text-1 text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Folio:</p>
                                <p class="text-white font-semibold">${order.folio || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-calendar text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Fecha de Entrega:</p>
                                <p class="text-white font-semibold">${order.formatted_date_order || order.date_order || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-clock text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Hora de Entrega:</p>
                                <p class="text-white font-semibold">${order.time_order || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <i class="icon-money text-gray-400"></i>
                            <div>
                                <p class="text-gray-400 text-xs mb-0.5">Total:</p>
                                <p class="text-white font-semibold">${formatPrice(order.total_pay)}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Observaciones -->
                ${order.note ? `
                <div class="bg-[#1F2A37] rounded-lg p-4">
                    <h3 class="text-white font-semibold mb-2 flex items-center gap-2">
                        <i class="icon-doc-text text-blue-400"></i>
                        Observaciones
                    </h3>
                    <div class="bg-[#28324c] rounded p-3 text-gray-300">
                        ${order.note}
                    </div>
                </div>
                ` : ''}
            </div>
        `;

        $('#order-details-info').html(html);
    }

    // History.
    async showHistory(id) {
        const data = await useFetch({ url: this._link, data: { opc: 'getHistory', id: id } });

        bootbox.dialog({
            title: `
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-purple-600 rounded flex items-center justify-center">
                        <i class="icon-clock text-white text-sm"></i>
                    </div>
                    <div>
                        <h2 class="text-lg font-semibold text-white">Historial del Pedido</h2>
                        <p class="text-sm text-gray-400">Actividad y comentarios</p>
                    </div>
                </div>
            `,
            size: "large",
            id: 'modalHistory',
            closeButton: true,
            message: `<div id="containerHistory"></div>`,
        });

        this.createTimelineChat({
            parent: 'containerHistory',
            data: data.history || [],
            input_id: 'iptHistorial',
            success: () => {
                this.addHistory(id);
            }
        });
    }

    async addHistory(id) {
        const comment = $('#iptHistorial').val().trim();

        if (!comment) {
            alert({
                icon: "warning",
                text: "Por favor escribe un comentario",
                timer: 1500
            });
            return;
        }

        const response = await useFetch({
            url: this._link,
            data: {
                opc: 'addHistory',
                order_id: id,
                comment: comment,
                action: comment,
                title: 'Comentario',
                type: 'comment'
            }
        });

        if (response.status === 200) {
            $('#iptHistorial').val('');

            this.createTimelineChat({
                parent: 'containerHistory',
                data: response.history || [],
                input_id: 'iptHistorial',
                success: () => {
                    this.addHistory(id);
                }
            });

            alert({
                icon: "success",
                text: "Comentario agregado",
                timer: 1000
            });


        } else {
            alert({
                icon: "error",
                text: response.message || "Error al agregar comentario"
            });
        }
    }




    // Show Order.

    async showOrder(orderId) {
        const response = await useFetch({
            url: this._link,
            data: { opc: 'getOrderDetails', id: orderId }
        });

        if (!response?.data?.order) {
            alert({
                icon: 'error',
                title: 'No se pudo abrir el pedido',
                text: response?.message ?? 'El servidor no devolvió una respuesta válida. Revisa la consola del navegador.',
                btn1: true,
                btn1Text: 'Ok'
            });

            return;
        }

        const tipo = response.data.order.delivery_type;
        const badgeTipo = this.getBadgeDeliveryType(tipo);
        const subsidiarieName = response.data.order.subsidiarie_name || '';

        // createCoffeeModalForm no trae modo solo lectura, asi que el detalle va como
        // bloque 'html' y del footer se quita Confirmar mas abajo.
        const modal = createCoffeeModalForm({
            id: 'modalOrderDetails',
            title: `Pedido #${response.data.order.folio}`,
            iconSvg: lucideIcon('cake', 'w-5 h-5'),
            iconBg: 'bg-blue-500',
            theme: 'dark',
            width: 900,
            cancelText: 'Cerrar',
            cancelBg: 'bg-[#2C3A4C] hover:bg-[#36475D] text-white',
            json: [
                {
                    opc: 'html',
                    html: '<div id="orderDetailsContainer" class="max-h-[70vh] overflow-y-auto"></div>'
                }
            ]
        });

        // Encabezado y footer a todo el ancho de la tarjeta, separados del cuerpo por
        // una linea. El componente no trae esas opciones, se ajustan sus clases. Los
        // espaciados van como valores arbitrarios (px-[20px]) porque bootstrap.min.css
        // pisa px-5, p-4 y similares con !important.
        const $card   = modal.el.find('.cf-card');
        const $header = $card.children().first();

        $card.removeClass('p-4').addClass('overflow-hidden');
        $header.removeClass('items-center mb-3').addClass('items-start px-[20px] py-[16px] border-b border-white/10');
        $header.children().first().removeClass('w-9 h-9 rounded-lg').addClass('w-11 h-11 rounded-xl');
        $header.find('.cf-close').removeClass('p-1 -mr-1').addClass('w-8 h-8 rounded-lg border border-gray-600');

        // Tipo de entrega, sucursal y estado de entrega como subtitulo del encabezado: el
        // componente no admite subtitulo por opciones. Los badges conservan su id porque
        // refreshOrderDetails() los repinta.
        $header.find('span').first().removeClass('text-base truncate').addClass('text-lg block')
            .wrap('<div class="flex-1 min-w-0"></div>').after(`
            <div class="flex flex-wrap items-center gap-2 mt-1.5">
                <span id="orderDeliveryBadge">${badgeTipo}</span>
                <span class="inline-flex items-center gap-1 text-xs text-gray-400">
                    ${lucideIcon('house', 'w-3.5 h-3.5')} ${subsidiarieName}
                </span>
                <span id="orderStatusBadge">${this.statusDelivery(response.data.order.is_delivered)}</span>
            </div>`);

        // El detalle es de consulta: sin Confirmar. El boton de cancelar queda como
        // "Cerrar", a la derecha del footer, con la nota de consulta a la izquierda.
        modal.el.find('.cf-confirm').remove();
        modal.el.find('.cf-cancel').removeClass('flex-1').addClass('px-6').parent()
            .removeClass('mt-4').addClass('items-center justify-between px-[20px] py-[12px] border-t border-white/10')
            .prepend(`
                <p class="text-xs text-gray-400 flex items-center gap-1.5">
                    ${lucideIcon('info', 'w-3.5 h-3.5')} Pedido de consulta — sin edición de productos
                </p>`);

        this.layoutManager = {
            isMobile: () => window.innerWidth < 768,
            isTablet: () => window.innerWidth >= 768 && window.innerWidth < 1024,
            isDesktop: () => window.innerWidth >= 1024,

            applyLayout: function () {
                const container = $('#orderDetailsContainer');
                container.removeClass('flex flex-col flex-row space-y-4 p-[16px] p-[20px]');

                if (this.isMobile()) {
                    container.addClass('flex flex-col space-y-4 p-[16px]');
                } else if (this.isTablet()) {
                    container.addClass('flex flex-col lg:flex-row p-[20px]');
                } else {
                    container.addClass('flex flex-row p-[20px]');
                }
            }
        };

        this.layoutManager.applyLayout();

        const orderData = response.data.order || {};
        const products = response.data.products || [];
        const paymentMethods = response.data.paymentMethods || [];
        const payments = response.data.payments || [];

        $('#orderDetailsContainer').html(`
            <div id="orderInfoPanel" class="w-full lg:w-1/3 mb-6 lg:mb-0 lg:pr-2">
                <div class="lg:sticky lg:top-0">
                    ${this.detailsCard(orderData, paymentMethods, payments)}
                </div>
            </div>

            <div id="productDisplayArea" class="w-full lg:w-2/3 lg:pl-2">
                ${this.listProducts(products)}
            </div>
        `);

        return modal;
    }

    // Repinta el panel de informacion del modal de detalles con datos frescos, sin
    // cerrarlo ni volver a armar el modal completo.
    async refreshOrderDetails(orderId) {
        const response = await useFetch({
            url: this._link,
            data: { opc: 'getOrderDetails', id: orderId }
        });

        if (!response?.data) return;

        const orderData      = response.data.order || {};
        const paymentMethods = response.data.paymentMethods || [];
        const payments       = response.data.payments || [];

        $('#orderInfoPanel .lg\\:sticky').html(this.detailsCard(orderData, paymentMethods, payments));
        // El tipo y el estado de entrega se muestran en el encabezado, fuera del panel.
        $('#orderDeliveryBadge').html(this.getBadgeDeliveryType(orderData.delivery_type));
        $('#orderStatusBadge').html(this.statusDelivery(orderData.is_delivered));
    }

    // Edicion acotada desde el detalle del pedido: solo los datos de entrega (fecha,
    // hora, tipo y descripcion). El cliente y los productos siguen editandose con
    // editOrder, que abre el POS completo.
    async editOrderDelivery(id, password = null) {
        const response = await useFetch({
            url: this._link,
            data: { opc: 'getOrderDelivery', id: id }
        });

        if (!response || response.status != 200 || !response.data) {
            alert({
                icon: 'error',
                title: 'Error',
                text: response?.message ?? 'El servidor no devolvió una respuesta válida. Revisa la consola del navegador.',
                btn1: true,
                btn1Text: 'Ok'
            });
            return;
        }

        const order         = response.data;
        const delivery_type = order.delivery_type;

        // Pedido liquidado: la contraseña se pide antes de abrir el formulario y se
        // reenvia en data para que editOrderDelivery (ctrl) la revalide al guardar.
        const liquidado = order.status == 3;

        if (liquidado && !password) {
            this.editOrderDeliveryPaid(id);
            return;
        }

        // El tipo de entrega marcado se resuelve aqui, al construir el HTML: los radios
        // van dentro de un bloque libre y el componente no los autocompleta.
        const esDomicilio = String(delivery_type ?? 0) === '1';

        // Fecha minima de entrega. Se arma con los getters locales y no con
        // toISOString(), que pasa a UTC y en la tarde adelanta un dia.
        const ahora = new Date();
        const hoy   = `${ahora.getFullYear()}-${String(ahora.getMonth() + 1).padStart(2, '0')}-${String(ahora.getDate()).padStart(2, '0')}`;

        createCoffeeModalForm({
            id: 'formEditDelivery',
            title: 'Editar datos de entrega',
            iconSvg: lucideIcon('calendar', 'w-5 h-5'),
            iconBg: 'bg-blue-600',
            theme: 'dark',
            width: 460,
            confirmText: 'Guardar',
            cancelText: 'Cancelar',
            confirmBg: 'bg-blue-600 hover:bg-blue-700',
            json: [
                ...(liquidado ? [{
                    opc: 'html',
                    html: `
                        <div class="flex items-center gap-3 bg-amber-500/10 rounded-lg px-3 py-2">
                            <i class="icon-lock text-amber-400 text-lg"></i>
                            <div class="text-xs leading-relaxed">
                                <b class="text-amber-100 block">Pedido liquidado — edición autorizada</b>
                                <span class="text-amber-200/80">Solo se guardarán los datos de entrega.</span>
                            </div>
                        </div>`
                }] : []),
                {
                    opc: 'text',
                    type: 'date',
                    id: 'date_order',
                    lbl: 'Fecha de entrega',
                    value: order.date_order,
                    min: hoy,
                    required: true
                },
                {
                    // Aviso junto al campo: el modal sigue abierto con lo capturado y
                    // queda marcado el dato que hay que corregir.
                    opc:  'html',
                    html: `<p id="msgDateOrder" class="hidden text-xs text-red-400 -mt-1">La fecha de entrega no puede ser menor a la fecha actual.</p>`
                },
                {
                    opc: 'text',
                    type: 'time',
                    id: 'time_order',
                    lbl: 'Hora de entrega',
                    value: order.time_order,
                    required: true
                },
                {
                    opc: 'html',
                    html: `
                        <div>
                            <label class="text-[10px] font-bold text-gray-400 uppercase tracking-wide block mb-1.5">Tipo de entrega</label>
                            <div class="flex gap-2">
                                <label class="w-1/2 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                                    <input class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                                        type="radio" name="delivery_type" value="0" ${esDomicilio ? '' : 'checked'}>
                                    ${lucideIcon('store', 'w-4 h-4')}
                                    <span class="text-sm font-medium">Local</span>
                                </label>

                                <label class="w-1/2 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                                    <input class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                                        type="radio" name="delivery_type" value="1" ${esDomicilio ? 'checked' : ''}>
                                    <i class="icon-motorcycle text-amber-500"></i>
                                    <span class="text-sm font-medium">A domicilio</span>
                                </label>
                            </div>
                        </div>`
                },
                {
                    // El id sigue el patron que arma el componente para sus campos, con
                    // lo que collect() recoge la descripcion junto al resto.
                    opc: 'html',
                    id: 'note',
                    html: `
                        <div>
                            <label class="text-[10px] font-bold text-gray-400 uppercase tracking-wide block mb-1.5">Descripción</label>
                            <textarea id="formEditDelivery-note" data-field="note" rows="3"
                                class="w-full bg-[#1a2332] border border-gray-600 text-white focus:border-emerald-500 rounded-lg px-3 py-2.5 text-sm focus:outline-none">${order.note ?? ''}</textarea>
                        </div>`
                }
            ],
            onConfirm: async (data, modal) => {
                // La entrega no puede quedar antes de hoy. Se deja pasar la fecha que ya
                // traia el pedido, para que uno viejo se siga pudiendo corregir sin
                // moverle la fecha. El mismo candado lo repite editOrderDelivery() del
                // controlador, que es el que manda.
                const fechaInvalida = data.date_order < hoy && data.date_order !== order.date_order;

                $('#msgDateOrder').toggleClass('hidden', !fechaInvalida);
                $('#formEditDelivery-date_order').toggleClass('!border-red-500', fechaInvalida);

                if (fechaInvalida) return;

                const response = await useFetch({
                    url: this._link,
                    data: {
                        opc: 'editOrderDelivery',
                        id: id,
                        ...(password ? { password: password } : {}),
                        date_order: data.date_order,
                        time_order: data.time_order,
                        note: data.note,
                        delivery_type: $('input[name="delivery_type"]:checked').val() ?? '0'
                    }
                });

                modal.close();

                if (response.status == 200) {
                    const cambios = Array.isArray(response.changes) ? response.changes : [];

                    this.alertBox({
                        theme:      'dark',
                        type:       'success',
                        title:      'Pedido actualizado',
                        detailHtml: cambios.length ? this.deliveryChangesDetail(cambios) : response.message,
                        okLabel:    'Aceptar'
                    });

                    this.refreshOrderDetails(id);
                    // La fecha y la hora de entrega son columnas del listado.
                    this.ls();
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });
    }

    // Pedido liquidado: pide la contraseña antes de abrir el formulario de entrega, el
    // mismo flujo que editOrderPaid. Se valida aqui para no descubrir una clave mal
    // escrita hasta despues de capturar los cambios; la autorizacion real la vuelve a
    // exigir editOrderDelivery() del controlador al guardar.
    editOrderDeliveryPaid(id) {
        this.alertBox({
            theme:       'dark',
            type:        'cancel',
            icon:        'lock',
            title:       'Pedido liquidado',
            detailHtml:  'Este pedido ya se liquidó (está pagado completo). Cambiar sus datos de entrega requiere autorización: ingresa tu contraseña para continuar.',
            input:       'password',
            inputLabel:  'Contraseña',
            inputPlaceholder: '••••••••',
            inputRequired: true,
            inputError:  'Ingresa tu contraseña',
            okLabel:     'Continuar',
            cancelLabel: 'Cancelar',
            onOk: async (password) => {
                const res = await useFetch({
                    url: this._link,
                    data: { opc: 'verifyOrderDeliveryKey', id: id, password: password }
                });

                if (res.status !== 200) {
                    // Contraseña rechazada: se avisa y se vuelve a abrir el dialogo,
                    // porque alertBox ya se cerro al confirmar.
                    this.alertBox({
                        theme:      'dark',
                        type:       'error',
                        title:      'No se puede editar',
                        detailHtml: res.message || 'Contraseña incorrecta.',
                        okLabel:    'Reintentar',
                        onOk:       () => this.editOrderDeliveryPaid(id)
                    });
                    return;
                }

                this.editOrderDelivery(id, password);
            }
        });
    }

    // Detalle del aviso de guardado: una fila por campo con el valor anterior tachado
    // y el nuevo resaltado. changes llega de editOrderDelivery() como
    // [{ field, before, after }]. Los valores se escapan con .text() porque la nota
    // la escribe el usuario. Todo va en <span>: alertBox mete detailHtml dentro de un
    // <p>, donde un <div> rompe el marcado.
    deliveryChangesDetail(changes) {
        const iconos = {
            Entrega: 'calendar',
            Hora:    'clock',
            Tipo:    'truck',
            Nota:    'file-text'
        };

        const valor = (v) => v === '' || v == null ? '—' : $('<span>').text(v).html();

        const filas = changes.map(c => `
            <span class="flex items-start gap-3 rounded-lg bg-[#111928] px-3 py-2.5">
                <span class="w-8 h-8 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                    ${lucideIcon(iconos[c.field] || 'pencil', 'w-4 h-4')}
                </span>
                <span class="flex-1 min-w-0">
                    <span class="block text-[10px] font-bold uppercase tracking-wide text-gray-500">${c.field}</span>
                    <span class="flex flex-wrap items-center gap-1.5 text-[13px] break-words">
                        <span class="text-gray-500 line-through">${valor(c.before)}</span>
                        ${lucideIcon('chevron-right', 'w-3.5 h-3.5 text-gray-500 shrink-0')}
                        <span class="font-semibold text-green-400">${valor(c.after)}</span>
                    </span>
                </span>
            </span>`).join('');

        const resumen = changes.length === 1 ? 'Se guardó 1 cambio' : `Se guardaron ${changes.length} cambios`;

        return `
            <span class="block text-gray-400">${resumen}</span>
            <span class="flex flex-col gap-2 mt-3 text-left">${filas}</span>`;
    }

    // Pildora con contorno del encabezado del detalle. border-[1px] y no `border`: el
    // .border de bootstrap lleva !important y pintaria el contorno gris.
    getBadgeDeliveryType(tipo) {
        if (tipo == 0 || tipo === '0') {
            return `<span class="px-2.5 py-0.5 rounded-full border-[1px] border-blue-500/50 bg-blue-500/10 text-blue-300 text-xs font-semibold inline-flex items-center gap-1">${lucideIcon('store', 'w-3.5 h-3.5')} Local</span>`;
        } else if (tipo == 1 || tipo === '1') {
            return `<span class="px-2.5 py-0.5 rounded-full border-[1px] border-amber-500/50 bg-amber-500/10 text-amber-300 text-xs font-semibold inline-flex items-center gap-1">${lucideIcon('truck', 'w-3.5 h-3.5')} A domicilio</span>`;
        }
        return '<span class="px-2.5 py-0.5 rounded-full border-[1px] border-gray-500/50 bg-gray-500/10 text-gray-300 text-xs font-semibold inline-flex items-center">Sin especificar</span>';
    }

    detailsCard(orderData, paymentMethods = [], payments = []) {
        return `
            <div class="space-y-3">
                ${this.infoOrder(orderData)}
                ${this.infoSales(orderData, paymentMethods, payments)}
            </div>
        `;
    }

    // Editar los datos de entrega va al pie de la tarjeta que los muestra.
    // Un pedido liquidado (3) lo corrigen admin (1) y supervisores (6, 7), y ahi la
    // edicion pide contraseña; el resto de los pedidos, cualquiera que opere la lista.
    // El cancelado (4) no se edita.
    editDeliveryButton(orderData) {
        const liquidado  = orderData.status == '3';
        const autorizado = rol == 1 || rol == 6 || rol == 7;
        const editable   = orderData.status != '4' && (!liquidado || autorizado);

        if (!editable) return '';

        return `
            <button onclick="app.editOrderDelivery(${orderData.id})"
                title="${liquidado ? 'Editar datos de entrega (requiere contraseña)' : 'Editar datos de entrega'}"
                class="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-gray-600 text-xs font-semibold text-gray-200 hover:text-white hover:bg-white/10 transition-colors">
                ${lucideIcon('pencil', 'w-3.5 h-3.5')}
                Editar entrega
            </button>`;
    }

    // Fecha y hora de entrega van en una sola fila. getOrderID ya las manda con formato
    // de pantalla (12/10/2026 y 04:00 PM). El estado de entrega se muestra en el
    // encabezado del modal. Capturó y Produjo solo los consultan admin (1), SuperAdmin
    // (5) y supervisores (6, 7), como en el detalle del calendario.
    infoOrder(orderData) {
        const entrega    = [orderData.date_order, orderData.time_order].filter(Boolean).join(' · ');
        const supervisa  = [1, 5, 6, 7].includes(Number(rol));

        const fila = (icono, label, valor) => `
                    <div class="flex items-center gap-2">
                        ${lucideIcon(icono, 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-300 text-sm">${label}</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${valor || 'N/A'}</span>
                    </div>`;

        return `
            <div class="bg-[#29374A] rounded-xl p-[16px]">
                <h3 class="text-white font-semibold text-base mb-3 flex items-center">
                    ${lucideIcon('info', 'w-4 h-4 text-blue-400 mr-2')}
                    Información del pedido
                </h3>

                <div class="space-y-2.5">
                    ${fila('file-text', 'Folio:', orderData.folio)}
                    ${fila('user', 'Cliente:', orderData.name)}
                    ${fila('clock', 'Creado:', this.formatDateTime(orderData.date_creation))}
                    ${supervisa ? fila('user-pen', 'Capturó:', orderData.created_by_name || 'Sin registro') : ''}
                    ${supervisa ? this.producedByRow(orderData) : ''}
                    ${fila('calendar', 'Entrega:', entrega)}
                </div>

                ${this.editDeliveryButton(orderData)}
            </div>
        `;
    }

    // Quien palomeo el pedido en Produccion y cuando: 09/OCT/2026 10:15pm. produced_at
    // llega de getOrderID como 09/10/2026 10:15 PM. "Sin registro" = la palomita existe
    // pero el usuario ya no esta en usr_users.
    producedByRow(orderData) {
        const meses = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
        const fecha = moment(orderData.produced_at, 'DD/MM/YYYY hh:mm A', true);

        const value = orderData.produced_at
            ? `<span class="block text-white font-semibold text-sm">${orderData.produced_by_name || 'Sin registro'}</span>
               <span class="block text-gray-400 text-[11px]">${fecha.isValid()
                    ? `${fecha.format('DD')}/${meses[fecha.month()]}/${fecha.format('YYYY')} ${fecha.format('hh:mma')}`
                    : orderData.produced_at}</span>`
            : `<span class="block text-gray-400 font-semibold text-sm">Aún sin producir</span>`;

        return `
                    <div class="flex items-center gap-2">
                        ${lucideIcon('cake', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-300 text-sm">Produjo:</span>
                        <span class="ml-auto text-right leading-tight">${value}</span>
                    </div>`;
    }

    // border-1 no existe en Tailwind (la utilidad es `border`), por eso las etiquetas
    // quedaban sin contorno. El ancho va como border-[1px] y no como `border` porque
    // bootstrap.min.css se carga despues y su .border lleva !important, con lo que el
    // contorno salia gris en lugar del color del estado. Las clases se guardan enteras
    // y no armadas por concatenacion, que Tailwind no detecta.
    statusDelivery(is_delivered) {
        const estados = {
            '1': { tono: 'bg-green-500/10 border-green-500/50 text-green-300',   icono: 'circle-check', texto: 'Entregado' },
            '2': { tono: 'bg-purple-500/10 border-purple-500/50 text-purple-300', icono: 'cake',         texto: 'Para Producir' }
        };

        const estado = estados[is_delivered]
            || { tono: 'bg-red-500/10 border-red-500/50 text-red-300', icono: 'circle-x', texto: 'No entregado' };

        return `<span class="px-2.5 py-0.5 text-xs font-semibold rounded-full border-[1px] ${estado.tono} inline-flex items-center gap-1 whitespace-nowrap">
                    ${lucideIcon(estado.icono, 'w-3 h-3')} ${estado.texto}
                </span>`;
    }

    formatDateTime(dateStr) {
        if (!dateStr) return '';
        const d = new Date(String(dateStr).replace(' ', 'T'));
        if (isNaN(d.getTime())) return dateStr;
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yyyy = d.getFullYear();
        const hh = String(d.getHours()).padStart(2, '0');
        const mi = String(d.getMinutes()).padStart(2, '0');
        return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
    }

    // Fecha de los abonos en el resumen de pago: 12/sep/2026 19:22 pm. El resto del
    // detalle (Creado) sigue con formatDateTime.
    formatPayDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(String(dateStr).replace(' ', 'T'));
        if (isNaN(d.getTime())) return dateStr;
        const meses = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
        const dd = String(d.getDate()).padStart(2, '0');
        const hh = String(d.getHours()).padStart(2, '0');
        const mi = String(d.getMinutes()).padStart(2, '0');
        const ampm = d.getHours() < 12 ? 'am' : 'pm';
        return `${dd}/${meses[d.getMonth()]}/${d.getFullYear()} ${hh}:${mi} ${ampm}`;
    }

    paymentMethodStyle(method) {
        const m = String(method || '').toLowerCase();
        if (m.includes('efect')) return { icon: 'banknote', bg: 'bg-green-500/15', text: 'text-green-400', dot: 'bg-green-400' };
        if (m.includes('tarj') || m.includes('tdc') || m.includes('tarjeta')) return { icon: 'credit-card', bg: 'bg-blue-500/15', text: 'text-blue-400', dot: 'bg-blue-400' };
        if (m.includes('transf')) return { icon: 'arrow-right-left', bg: 'bg-purple-500/15', text: 'text-purple-400', dot: 'bg-purple-400' };
        return { icon: 'wallet', bg: 'bg-gray-500/15', text: 'text-gray-300', dot: 'bg-gray-400' };
    }

    infoSales(orderData, paymentMethods = [], payments = []) {
        const totalPay = parseFloat(orderData.total_pay || 0);
        const discount = parseFloat(orderData.discount || 0);
        const totalPaid = parseFloat(orderData.total_paid || 0);
        const balance = parseFloat(orderData.balance || 0);
        const infoDiscount = orderData.info_discount || '';

        // Total a cobrar y avance del pago para la barra: Pagado N% · Faltan $X.
        const total   = totalPay - discount;
        const avance  = total > 0 ? Math.min(100, Math.round(totalPaid / total * 100)) : 0;
        const faltan  = Math.max(balance, 0);

        // Eliminar abono: el mismo boton del historial de pagos (listPayment). Solo el
        // admin (1) borra pagos y aqui siempre confirma con contraseña (ultimo
        // argumento de deletePay). Con el pedido liquidado lleva candado, como en el
        // historial.
        const requiereClave = balance <= 0.009 ? 1 : 0;
        const deleteBtn = (p) => rol == 1 ? `
                                <button type="button" onclick="app.deletePay(${p.id}, ${orderData.id}, ${requiereClave}, ${parseFloat(p.pay || 0)}, true)"
                                    title="Eliminar pago (requiere contraseña)"
                                    class="${requiereClave ? 'text-amber-400 hover:text-amber-300' : 'text-red-400 hover:text-red-300'} p-1 shrink-0">
                                    ${lucideIcon(requiereClave ? 'lock' : 'trash-2', 'w-3.5 h-3.5')}
                                </button>` : '';

        // Historial detallado: cada abono con su fecha y metodo, sin agrupar.
        // Si no llega el historial, se cae al resumen agrupado por metodo.
        const methodsHtml = (Array.isArray(payments) && payments.length > 0) ? `
                    <div class="border-l-2 border-gray-600 pl-3">
                        <span class="text-gray-400 text-[11px] font-semibold uppercase tracking-wide flex items-center gap-1.5 mb-1">
                            ${lucideIcon('clock', 'w-3.5 h-3.5')}
                            Abonos (${payments.length})
                        </span>
                        <div class="divide-y divide-gray-600/60">
                            ${payments.map(p => {
                                const st = this.paymentMethodStyle(p.method_pay);
                                return `
                            <div class="flex items-center justify-between gap-2 py-2">
                                <div class="flex flex-col min-w-0">
                                    <span class="text-white text-xs font-semibold flex items-center gap-1.5">
                                        ${lucideIcon(st.icon, 'w-3.5 h-3.5 ' + st.text)}
                                        ${p.method_pay || 'Sin método'}
                                    </span>
                                    <span class="text-gray-500 text-[11px]">${this.formatPayDate(p.date_pay)}</span>
                                </div>
                                <span class="flex items-center gap-1 ml-auto">
                                    <span class="text-green-400 font-bold text-sm whitespace-nowrap">${formatPrice(p.pay)}</span>
                                    ${deleteBtn(p)}
                                </span>
                            </div>
                            `;
                            }).join('')}
                        </div>
                    </div>
        ` : (Array.isArray(paymentMethods) && paymentMethods.length > 0) ? `
                    <div class="pl-3 space-y-1 border-l-2 border-gray-600">
                        ${paymentMethods.map(m => `
                        <div class="flex items-center justify-between">
                            <span class="text-gray-400 text-xs flex items-center gap-1.5">
                                ${lucideIcon('credit-card', 'w-3.5 h-3.5')}
                                ${m.method_pay || 'Sin método'}:
                            </span>
                            <span class="text-gray-300 text-xs">${formatPrice(m.pay)}</span>
                        </div>
                        `).join('')}
                    </div>
        ` : '';

        const discountHtml = discount > 0 ? `
                    <div>
                        <div class="flex items-center justify-between">
                            <span class="text-gray-300 text-sm">Descuento:</span>
                            <span class="text-amber-400 font-bold text-sm">−${formatPrice(discount)}</span>
                        </div>
                        ${infoDiscount ? `<span class="block text-gray-500 text-[11px] italic mt-0.5">${infoDiscount}</span>` : ''}
                    </div>
        ` : '';

        return `
            <div class="bg-[#29374A] rounded-xl p-[16px]">
                <h3 class="text-white font-semibold text-base mb-3 flex items-center">
                    ${lucideIcon('dollar-sign', 'w-4 h-4 text-green-400 mr-2')}
                    Resumen de pago
                </h3>

                <div class="space-y-2.5">
                    <div class="flex items-center justify-between">
                        <span class="text-gray-300 text-sm">Subtotal:</span>
                        <span class="text-white font-bold text-sm">${formatPrice(totalPay)}</span>
                    </div>

                    ${discountHtml}

                    <div class="flex items-center justify-between">
                        <span class="text-gray-300 text-sm">Total:</span>
                        <span class="text-white font-bold text-base">${formatPrice(total)}</span>
                    </div>

                    <div>
                        <div class="h-1.5 rounded-full bg-gray-700 overflow-hidden">
                            <div class="h-full rounded-full bg-emerald-400" style="width:${avance}%"></div>
                        </div>
                        <div class="flex items-center justify-between mt-1.5 text-[11px]">
                            <span class="text-emerald-400 font-semibold">Pagado: ${avance}%</span>
                            <span class="text-gray-400">Faltan ${formatPrice(faltan)}</span>
                        </div>
                    </div>

                    <div class="flex items-center justify-between">
                        <span class="text-gray-300 text-sm">Pagado:</span>
                        <span class="text-green-400 font-bold text-sm">${formatPrice(totalPaid)}</span>
                    </div>

                    ${methodsHtml}

                    <div class="flex items-center justify-between pt-1">
                        <span class="text-gray-300 text-sm">Saldo:</span>
                        <span class="text-red-400 font-bold text-sm">${formatPrice(balance)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    listProducts(products) {



        if (!products || products.length === 0) {
            return `
                <div class="bg-[#283341] rounded-lg p-2 text-center h-full flex flex-col items-center justify-center">
                    ${lucideIcon('shopping-basket', 'w-12 h-12 text-gray-500 mb-4')}
                    <h3 class="text-white text-lg font-semibold mb-2">No hay productos</h3>
                    <p class="text-gray-400">Este pedido no contiene productos.</p>
                </div>
            `;
        }

        const totalItems = products.reduce((acc, item) => acc + parseInt(item.quantity || 1), 0);

        // Sin scroll propio: la lista crece y lo que se desplaza es el contenedor del
        // modal (#orderDetailsContainer), con una sola barra.
        return `
            <div class="flex flex-col">
                <div class="bg-[#29374A] rounded-xl px-[16px] py-[12px] mb-3 flex items-center justify-between">
                    <h3 class="text-white font-semibold text-base flex items-center">
                        ${lucideIcon('shopping-bag', 'w-4 h-4 mr-2 text-blue-400')}
                        Productos del pedido
                    </h3>
                    <span class="text-gray-400 text-sm">${totalItems} productos</span>
                </div>
                <div id="productsContainer" class="space-y-3">
                    ${products.map(product =>
                        product.is_custom || (product.customer_products && product.customer_products.length > 0)
                            ? this.cardCustom(product)
                            : this.cardNormal(product)
                    ).join('')}
                </div>
            </div>
        `;
    }

    cardNormal(product) {
        const total = parseFloat(product.price || 0) * parseInt(product.quantity || 1);
        const hasDedication = product.dedication && product.dedication.trim() !== '';
        const hasDetails = product.order_details && product.order_details.trim() !== '';

        return `
            <div class="bg-[#29374A] rounded-xl p-[16px] flex items-start gap-[16px]">
                <div class="w-14 h-14 rounded-lg overflow-hidden bg-[#D8B4E2] flex-shrink-0">
                    ${this.renderProductImage(product)}
                </div>

                <div class="flex-1 min-w-0">
                    <h4 class="text-white font-bold text-sm uppercase">${product.name || 'Producto sin nombre'}</h4>
                    <p class="text-blue-400 text-xs mt-0.5">${formatPrice(product.price)} c/u</p>

                    ${hasDedication ? `
                    <p class="text-gray-400 text-xs mt-3">Dedicatoria:</p>
                    <p class="text-white text-xs font-semibold">${product.dedication}</p>
                    ` : ''}
                    ${hasDetails ? `
                    <p class="text-gray-400 text-xs mt-2">Observaciones:</p>
                    <p class="text-white text-xs font-semibold">${product.order_details}</p>
                    ` : ''}
                </div>

                <div class="self-stretch flex flex-col items-end justify-between gap-3 text-right shrink-0">
                    <span class="text-gray-400 text-sm">Cantidad: <span class="text-white font-bold">${product.quantity || 1}</span></span>
                    <div>
                        <span class="text-gray-400 text-xs block">Importe</span>
                        <p class="text-white font-bold text-lg">${formatPrice(total)}</p>
                    </div>
                </div>
            </div>
        `;
    }

    cardCustom(product) {
        const hasDedication    = product.dedication && product.dedication.trim()       !== '';
        const hasDetails       = product.order_details && product.order_details.trim() !== '';
        const hasCustomization = product.customer_products && product.customer_products.length > 0;

        // price es order_custom.price_real: el precio que se cobra y que ya incluye la
        // personalizacion. El total de la linea es ese precio por la cantidad, igual que
        // lo suma updateTotalOrder() en total_pay.
        const total = parseFloat(product.price || 0) * parseInt(product.quantity || 1);

        return `
        <div class="bg-[#29374A] rounded-xl p-[16px]">
            <div class="flex items-center justify-between gap-3 mb-3">
                <div class="flex items-center gap-2 min-w-0">
                    <h4 class="text-white font-bold text-sm uppercase truncate">${product.name || 'Pastel Personalizado'}</h4>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-purple-500/20 text-purple-300 shrink-0">Personalizado</span>
                </div>
                <span class="text-gray-400 text-sm shrink-0">Cantidad: <span class="text-white font-bold">${product.quantity || 1}</span></span>
            </div>

            <div class="flex flex-col sm:flex-row gap-[16px]">
                <div class="sm:w-[190px] shrink-0">${this.customGallery(product)}</div>

                <div class="flex-1 min-w-0 space-y-3">
                    <div>
                        <p class="text-gray-400 text-xs">Porción:</p>
                        <p class="text-white text-sm font-semibold">${product.portion_qty || 1} personas</p>
                    </div>
                    ${hasDedication ? `
                    <div>
                        <p class="text-gray-400 text-xs">Dedicatoria:</p>
                        <p class="text-white text-sm font-semibold">${product.dedication}</p>
                    </div>
                    ` : ''}
                    ${hasDetails ? `
                    <div>
                        <p class="text-gray-400 text-xs">Observaciones:</p>
                        <p class="text-white text-sm font-semibold">${product.order_details}</p>
                    </div>
                    ` : ''}
                </div>
            </div>

            ${hasCustomization ? `
            <div class="border-t border-gray-600/60 mt-[16px] pt-[16px]">
                <h5 class="text-purple-300 font-bold text-xs uppercase tracking-wide mb-3">Personalización</h5>
                ${this.renderPersonalizationGrid(product.customer_products)}
            </div>
            ` : ''}

            <div class="text-right mt-3">
                <span class="text-gray-400 text-xs block">Importe</span>
                <p class="text-emerald-400 font-bold text-lg">${formatPrice(total)}</p>
            </div>
        </div>
    `;
    }

    // Fotos de referencia del pastel personalizado: la grande con su contador y las
    // miniaturas numeradas. Clic en una miniatura la pasa a la grande (selectCustomImage)
    // y clic en la grande la amplia. La vista previa lee el src de la <img> y no la
    // ruta original: si la foto solo existe en produccion, fileUrlFallback() ya la cambio.
    customGallery(product) {
        const images = Array.isArray(product.images) ? product.images : [];

        if (!images.length) {
            return `
                <div class="w-40 h-40 rounded-lg bg-[#D8B4E2] flex items-center justify-center">
                    ${lucideIcon('cake', 'w-10 h-10 text-white')}
                </div>`;
        }

        const total = images.length;
        const first = images[0];

        const thumbs = total > 1 ? `
            <div class="flex flex-wrap gap-1.5 mt-2">
                ${images.map((img, i) => `
                <button type="button" onclick="app.selectCustomImage(this, ${product.id})"
                    class="relative w-6 h-6 rounded overflow-hidden bg-gray-700 ${i === 0 ? 'ring-2 ring-blue-500' : ''}">
                    <img src="${fileUrl(img.path)}" alt="${img.original_name || 'Imagen'}"
                         onerror="app.productImageError(this)"
                         class="object-cover w-full h-full pointer-events-none">
                    <span class="absolute bottom-0 right-0 px-0.5 rounded-tl bg-black/70 text-[8px] font-bold leading-tight text-white">${i + 1}</span>
                </button>`).join('')}
            </div>` : '';

        return `
            <div class="relative w-40 h-40 rounded-lg overflow-hidden bg-gray-700 cursor-pointer"
                 onclick="app.previewImage(this.querySelector('img').src, this.querySelector('img').alt)">
                <img id="customMain${product.id}" src="${fileUrl(first.path)}" alt="${first.original_name || 'Imagen'}"
                     onerror="app.productImageError(this)"
                     class="object-cover w-full h-full pointer-events-none">
                <span id="customCount${product.id}" class="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/60 text-[11px] font-semibold text-white">1 / ${total}</span>
                <span class="absolute bottom-1.5 right-1.5 w-7 h-7 rounded-md bg-black/60 flex items-center justify-center text-white">${lucideIcon('zoom-in', 'w-4 h-4')}</span>
            </div>
            ${thumbs}
            <p class="text-gray-500 text-[11px] mt-2">${total} ${total === 1 ? 'foto' : 'fotos'} de referencia · clic para ampliar</p>
        `;
    }

    // La miniatura elegida pasa a la foto grande y se marca con el anillo azul.
    selectCustomImage(thumb, packageId) {
        const $thumb = $(thumb);
        const $img   = $thumb.find('img');

        if ($img.length) {
            $(`#customMain${packageId}`).attr({ src: $img.attr('src'), alt: $img.attr('alt') });
        }

        $(`#customCount${packageId}`).text(`${$thumb.index() + 1} / ${$thumb.parent().children().length}`);
        $thumb.addClass('ring-2 ring-blue-500').siblings().removeClass('ring-2 ring-blue-500');
    }

    renderProductImage(product) {
        const hasImage = product.image && product.image.trim() !== '';

        if (hasImage) {
            const imageUrl = fileUrl(product.image);
            // La vista previa toma this.src y no imageUrl: si fileUrlFallback() cambio
            // la ruta porque la original fallo, se amplia la que si cargo.
            return `
                <img src="${imageUrl}" alt="${product.name}"
                     class="object-cover w-full h-full cursor-pointer hover:opacity-80 transition-opacity"
                     onclick="app.previewImage(this.src, this.alt)"
                     onerror="app.productImageError(this)">
            `;
        } else {
            return `
                <div class="w-full h-full flex items-center justify-center">
                    ${lucideIcon('cake', 'w-6 h-6 text-white')}
                </div>
            `;
        }
    }

    // Foto de producto que no carga. Las fotos viejas solo viven en el servidor de
    // produccion: primero se reintenta ahi (fileUrlFallback) y, si tampoco esta, se
    // pone el icono de pastel en su lugar. El recuadro deja de abrir la vista previa
    // porque ya no hay foto que ampliar.
    productImageError(img) {
        if (!img.dataset.fileFallback) return fileUrlFallback(img);

        const $box = $(img).parent();

        $box.removeAttr('onclick').removeClass('cursor-pointer hover:opacity-80 transition-opacity');
        $box.addClass('flex items-center justify-center');
        $(img).replaceWith(lucideIcon('cake', 'w-1/2 h-1/2 text-white'));
    }

    // Modificadores agrupados por categoria (Relleno, Cobertura...), en dos columnas.
    // Cada opcion lleva su precio de modificador, o "Incluida" si no tiene costo.
    renderPersonalizationGrid(customizations) {
        const grouped = {};

        customizations.forEach(item => {
            const category = `${item.modifier_name || ''}:`;
            if (!grouped[category]) grouped[category] = [];
            grouped[category].push(item);
        });

        const precio = (item) => {
            const price = parseFloat(item.custom_price || 0);
            const qty   = parseInt(item.custom_quantity || 1);
            if (price <= 0) return 'Incluida';
            return `${qty > 1 ? qty + ' × ' : ''}+${formatPrice(price)}`;
        };

        return `
            <div class="grid grid-cols-2 gap-x-6 gap-y-3">
                ${Object.entries(grouped).map(([category, items]) => `
                    <div class="flex flex-col">
                        <span class="text-purple-300 font-bold text-[11px] tracking-wide uppercase">${category}</span>
                        ${items.map(item => `
                            <span class="text-white font-semibold text-sm">${item.name || 'N/A'}</span>
                            <span class="text-gray-400 text-[11px]">${precio(item)}</span>
                        `).join('')}
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Se abre desde el detalle del pedido, cuyo overlay (createCoffeeModalForm) va en
    // z-index 100000: la vista previa tiene que quedar por encima.
    previewImage(imageUrl, imageName = 'Imagen') {
        const modal = $(`
            <div id="imagePreviewModal" class="fixed inset-0 z-[100001] flex items-center justify-center bg-black/80" onclick="if(event.target === this) $(this).remove()">
                <div class="relative max-w-4xl max-h-[90vh] p-2">
                    <button onclick="$('#imagePreviewModal').remove()"
                            class="absolute -top-2 -right-2 w-10 h-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-xl font-bold z-10 shadow-lg">
                        ×
                    </button>
                    <img src="${imageUrl}" alt="${imageName}"
                         class="max-w-full max-h-[85vh] rounded-lg shadow-2xl object-contain">
                    <p class="text-white text-center mt-3 text-sm">${imageName}</p>
                </div>
            </div>
        `);

        $('body').append(modal);

        $(document).on('keydown.imagePreview', function(e) {
            if (e.key === 'Escape') {
                $('#imagePreviewModal').remove();
                $(document).off('keydown.imagePreview');
            }
        });
    }


    // Components.
    detailCard(options = {}) {
        const defaults = {
            parent: "body",
            title: "",
            subtitle: "",
            class: "space-y-2",
            data: [],
        };

        const opts = Object.assign({}, defaults, options);

        const isCols2 = opts.class.includes("cols-2");
        let contentClass = isCols2
            ? `grid grid-cols-2 ${opts.class.replace("cols-2", "")}`
            : `flex flex-col ${opts.class}`;

        let infoHtml = `<div class="${contentClass}">`;

        opts.data.forEach(item => {
            if (item.type === "div") {
                infoHtml += `<div class="${item.class || ''}">${item.html || ''}</div>`;
            } else if (item.type === "status") {
                infoHtml += `
                <div class="flex items-center mb-1">
                    <span class="text-gray-400 font-medium flex items-center text-base">
                        ${item.icon ? `<i class="${item.icon} mr-2"></i>` : ""}
                        ${item.text}:
                    </span>
                    <span class="ml-2 px-3 py-1 rounded-full text-xs font-bold ${item.color || "bg-gray-500"}">${item.value}</span>
                </div>
            `;
            } else if (item.type === "observacion") {
                infoHtml += `
                <div class="col-span-2 mt-2">
                    <label class="text-gray-400 font-medium text-base mb-1 block">${item.text || "Observación"}:</label>
                    <div class="bg-[#28324c] rounded p-3 text-gray-300 min-h-[80px]">${item.value || ""}</div>
                </div>
            `;
            } else {
                infoHtml += `
                <div class="flex items-center mb-1">
                    <span class="text-gray-400 font-medium flex items-center text-base">
                        ${item.icon ? `<i class="${item.icon} mr-2"></i>` : ""}
                        ${item.text}:
                    </span>
                    <span class="ml-2 font-semibold text-white text-base">${item.value}</span>
                </div>
            `;
            }
        });

        infoHtml += `</div>`;

        const html = `
        <div class="text-white rounded-xl p-3 min-w-[320px]">
            ${infoHtml}
        </div>
    `;

        $(`#${opts.parent}`).html(html);
    }


    // El boton de registrar nombra la operacion completa: importe y metodo. Es lo
    // ultimo que se mira antes de confirmar, asi que es donde un metodo equivocado
    // tiene su mejor oportunidad de saltar a la vista. Sin importe capturado vuelve
    // a su texto neutro.
    refreshPayButton() {
        // #method_pay_id solo existe en Gestion de Pagos: evita reescribir el boton
        // de cualquier otro modal coffee que este abierto.
        if (!$('#method_pay_id').length) return;

        const $btn = $('.cf-confirm');
        if (!$btn.length) return;

        const importe = parseFloat($('#advanced_pay').val()) || 0;
        const metodo  = METHOD_META[String($('#method_pay_id').val())];

        if (importe <= 0 || !metodo) {
            $btn.text('Registrar Pago');
            return;
        }

        $btn.html(`<span class="inline-flex items-center gap-2">
            ${window.lucideIcon(metodo.icon, 'w-4 h-4')}
            Registrar ${formatPrice(importe)} en ${metodo.label}
        </span>`);
    }

    updateTotal(total, totalPaid) {
        const val = parseFloat($("#advanced_pay").val()) || 0;
        const t = typeof total === 'number' ? total : (this.totalPay || 0);
        const tp = typeof totalPaid === 'number' ? totalPaid : (this.totalPaid || 0);
        const d = this.discount || 0;
        const restante = (t - d - (tp || 0)) - val;
        // .cf-confirm: en Gestion de Pagos el boton de registrar vive en el footer del
        // modal, no dentro del formulario.
        const btn = $("#btnSuccess").add('.cf-confirm');
        const display = $("#SaldoEvent");
        if (display && display.length) {
            display.text(formatPrice(restante < 0 ? 0 : restante));
        }
        // Sin turno en la sucursal que cobra el boton se queda bloqueado: este metodo
        // corre en cada tecla y despues de cada pago, y sin esto reabriria el candado.
        const shiftLocked = $('#cobroShiftAlert').length && !$('#cobroShiftAlert').hasClass('hidden');

        if (restante < 0 || shiftLocked) {
            btn.prop("disabled", true).addClass("opacity-50 cursor-not-allowed");
        } else {
            btn.prop("disabled", false).removeClass("opacity-50 cursor-not-allowed");
        }

        this.refreshPayButton();
    }

    // =============================================
    // Cierre del Día - Sistema de Turnos
    // =============================================

    printDailyClose() {
        this.reportMode = 'summary';
        this._selectedShiftId = null;

        // La sucursal activa la define el filtro de navbar (#subsidiaries_id): es la
        // sucursal que el admin esta trabajando. Si esta en "0" (Todas) o no existe,
        // caemos a la sucursal de sesion (udn) para no dejar el select sin seleccion.
        const navbarSub = $('#subsidiaries_id').val();
        const activeSub = (navbarSub && navbarSub !== '0') ? navbarSub : (dailyClosure.subsidiary_id ?? udn);

        // Roles con filtro de navbar (admin 1, cajero 2, vendedor 3) eligen la sucursal
        // del cierre en el modal; arranca en la seleccionada en el navbar (activeSub).
        const subsidiarySelect = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) ? `
            <div>
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1 block">Sucursal</label>
                <select id="subsidiariesDailyClose" class="w-full bg-[#1F2A37] border border-[rgba(51,65,85,0.6)] text-[#F1F5F9] rounded-lg px-3 py-2 text-sm font-normal" onchange="app.onDailyCloseFilterChange()">
                    ${subsidiaries.map(s => `<option value="${s.id}" ${activeSub == s.id ? 'selected' : ''}>${s.valor}</option>`).join('')}
                </select>
            </div>
        ` : `
            <div>
                <label class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1 block">Sucursal</label>
                <div class="flex items-center gap-2 w-full bg-[#1F2A37] border border-purple-500/40 rounded-lg px-3 py-2" title="Abrirás, cerrarás turno y harás el cierre de esta sucursal">
                    <i class="icon-location-8 text-purple-400"></i>
                    <span class="text-sm font-semibold text-white truncate">${sub_name || 'Mi sucursal'}</span>
                </div>
            </div>
        `;

        const modalContent = `
            <div class="flex flex-col lg:flex-row gap-3 lg:min-h-[380px] lg:h-[62vh]">
                <!-- Sidebar -->
                <div class="w-full lg:w-[220px] flex-shrink-0 space-y-3">
                    <div class="grid grid-cols-2 md:grid-cols-1 gap-3">
                        ${subsidiarySelect}
                        <div id="dateFieldWrapper">
                            <label class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1 block">Fecha</label>
                            <div class="relative">
                                <input type="text" id="calendarDailyClose" class="w-full bg-[#1F2A37] border border-[rgba(51,65,85,0.6)] text-[#F1F5F9] rounded-lg pl-3 pr-9 py-2 text-sm font-normal cursor-pointer focus:border-purple-500 focus:outline-none" readonly placeholder="Fecha" />
                                <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-300 pointer-events-none">
                                    ${lucideIcon('calendar', 'w-[18px] h-[18px]')}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div id="openShiftsAlert" class="hidden"></div>
                    <div id="closeDayAlert" class="hidden"></div>
                    <div>
                        <label class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1 block">Seleccionar turno</label>
                        <select id="shiftSelector" class="w-full bg-[#1F2A37] border border-[rgba(51,65,85,0.6)] text-[#F1F5F9] rounded-lg px-3 py-2 text-sm font-normal" onchange="app.viewShiftPreview()">
                            <option value="">-- Seleccionar --</option>
                        </select>
                    </div>
                    <div class="grid grid-cols-3 md:grid-cols-1 gap-2 mt-2">
                        <button id="btnOpenShift" class="py-2.5 rounded-lg text-xs md:text-sm font-semibold bg-green-600 hover:bg-green-700 text-white flex flex-col md:flex-row items-center justify-center gap-1 md:gap-2" onclick="app.openShift()">
                            ${lucideIcon('circle-plus')} <span>Abrir<span class="hidden md:inline"> Turno</span></span>
                        </button>
                        <button id="btnCloseShift" class="py-2.5 rounded-lg text-xs md:text-sm font-semibold bg-purple-600 hover:bg-purple-700 text-white flex flex-col md:flex-row items-center justify-center gap-1 md:gap-2 opacity-50 cursor-not-allowed" disabled onclick="app.closeShift()">
                            ${lucideIcon('lock')} <span>Cerrar<span class="hidden md:inline"> Turno</span></span>
                        </button>
                        <button id="btnPrintTicket" class="py-2.5 rounded-lg text-xs md:text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white flex flex-col md:flex-row items-center justify-center gap-1 md:gap-2 opacity-50 cursor-not-allowed" disabled onclick="app.printDailyCloseTicket()">
                            ${lucideIcon('printer')} <span>Imprimir</span>
                        </button>
                    </div>
                    <div id="closeDayBtnArea" class="border-t border-gray-600 pt-2 mt-2 space-y-2">
                        <button id="btnCerrarDia" class="w-full py-2.5 rounded-lg text-sm font-semibold bg-orange-600 hover:bg-orange-700 text-white flex items-center justify-center gap-2 opacity-50 cursor-not-allowed" disabled onclick="cierre.initCierre()">
                            ${lucideIcon('check-check')} Cerrar Dia
                        </button>
                    </div>
                </div>
                <!-- Ticket Preview -->
                <div class="flex-1 relative">
                    <div id="ticketPreview" class="relative lg:absolute lg:inset-0 w-full min-h-[380px] lg:min-h-0 bg-[#151d2a] rounded-lg p-4 overflow-y-auto">
                        <div id="ticketModeBar" class="flex items-center justify-between mb-3 gap-3 hidden">
                            <p class="text-xs text-gray-500">Vista previa de impresión</p>
                            <div class="inline-flex items-center gap-1 bg-[#1a2332] p-1 rounded-lg border border-gray-700/50 text-[11px] flex-shrink-0">
                                <button id="btnModeSummary" class="px-3 py-1 rounded-md font-semibold bg-purple-600 text-white shadow-sm transition-all" onclick="app.toggleReportMode('summary')">Resumido</button>
                                <button id="btnModeDetailed" class="px-3 py-1 rounded-md font-semibold text-gray-400 hover:text-gray-200 transition-all" onclick="app.toggleReportMode('detailed')">Detallado</button>
                            </div>
                        </div>
                        <div id="ticketContainer">
                            <div class="text-center text-gray-400 py-16">
                                <i class="icon-doc-text text-5xl mb-4"></i>
                                <p class="mt-4">Selecciona un turno para ver el ticket</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const dialog = bootbox.dialog({
            title: `
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                        ${lucideIcon('calendar', 'w-5 h-5 text-white')}
                    </div>
                    <span class="text-lg font-bold text-white">Cierre del Día</span>
                </div>`,
            message: modalContent,
            size:'large',
            closeButton: true,
            className: 'daily-close-enhanced-modal'
        });

        $("<style>").text(`
            .daily-close-enhanced-modal .modal-dialog {
                max-width: 940px !important;
                width: 82vw !important;
            }
            .daily-close-enhanced-modal .modal-body {
                max-height: 78vh;
                overflow-y: auto;
            }
            @media (max-width: 768px) {
                .daily-close-enhanced-modal .modal-dialog {
                    width: 98vw !important;
                    margin: 10px auto !important;
                }
            }
        `).appendTo("head");

        dialog.on('shown.bs.modal', () => {
            dataPicker({
                parent: "calendarDailyClose",
                type: 'simple',
                rangeDefault: {
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoApply: true,
                    startDate: moment(),
                    locale: { format: 'YYYY-MM-DD' }
                },
            });

            // Recargar turnos al seleccionar una fecha en el calendario
            $('#calendarDailyClose').on('apply.daterangepicker', () => this.loadShifts());

            this.loadShifts();
        });
    }

    onDailyCloseFilterChange() {
        this.loadShifts();
    }

    // -- renderPendingDaysAlert --
    renderPendingDaysAlert(pendingDays, currentDate) {
        const closeDayAlert = $('#closeDayAlert');
        if (pendingDays.length > 0) {
            const dayItems = pendingDays.map(d => {
                const isViewing = d.date === currentDate;
                const label = moment(d.date).locale('es').format('DD/MM/YYYY');
                const weekday = moment(d.date).locale('es').format('dddd');
                const openTag = d.open_shifts > 0
                    ? `<span class="text-[10px] font-semibold text-orange-300">${d.open_shifts} turno(s) abierto(s)</span>`
                    : `<span class="text-[10px] font-semibold text-orange-300/70">${d.shifts} turno(s)</span>`;
                return `
                    <div class="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-md cursor-pointer transition-colors ${isViewing ? 'bg-orange-500/20 ring-1 ring-orange-500/40' : 'bg-slate-800/40 hover:bg-slate-800/70'}" onclick="app.goToPendingDay('${d.date}')">
                        <div class="flex flex-col gap-0.5">
                            <span class="text-xs font-bold text-white leading-none capitalize">${weekday} ${label}</span>
                            ${openTag}
                        </div>
                        <span class="inline-flex items-center gap-1 text-orange-400">
                            ${lucideIcon('chevron-right', 'w-4 h-4')}
                        </span>
                    </div>
                `;
            }).join('');

            closeDayAlert.html(`
                <div class="rounded-lg border border-orange-500/40 bg-orange-500/10 p-2.5">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="relative inline-flex items-center justify-center w-[18px] h-[18px]">
                            <span class="relative inline-flex items-center justify-center w-[18px] h-[18px] rounded-full bg-orange-500 text-white">
                                ${lucideIcon('alert-triangle', 'w-3 h-3')}
                            </span>
                        </span>
                        <span class="text-[10px] font-bold text-orange-400 uppercase tracking-wide">Días sin cerrar</span>
                    </div>
                    <p class="text-[11px] text-slate-300 leading-tight mb-2">Cierra estas fechas antes de operar hoy.</p>
                    <div class="space-y-1.5">${dayItems}</div>
                </div>
            `).removeClass('hidden');
        } else {
            closeDayAlert.addClass('hidden').html('');
        }
    }

    async loadShifts() {
        let rangePicker     = getDataRangePicker("calendarDailyClose");
        let date            = rangePicker.fi;
        let subsidiaries_id = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) ? $('#subsidiariesDailyClose').val() : null;

        // Limpiar badge de cierre (opcion C) y restaurar boton Cerrar Dia
        $('.closure-badge').remove();
        const wrapper = $('.closure-wrapper');
        if (wrapper.length) {
            const label = wrapper.find('label');
            label.removeClass('!mb-0').addClass('mb-1');
            wrapper.replaceWith(label);
        }
        $('#calendarDailyClose').removeClass('!border-green-600/50');
        // Restaurar el boton "Cerrar Dia" en su contenedor estable (#closeDayBtnArea).
        // Al visitar un dia cerrado, loadClosedView reemplaza ese contenedor por "Reabrir
        // Dia" (admin) o lo vacia (otros roles); por eso se reconstruye por id y no via
        // .parent() de un boton que pudo dejar de existir (bug: el boton no volvia). Nace
        // deshabilitado y mas abajo se habilita si el dia tiene turnos cerrados y no esta cerrado.
        if (!$('#btnCerrarDia').length) {
            $('#closeDayBtnArea').html(`
                <button id="btnCerrarDia" class="w-full py-2.5 rounded-lg text-sm font-semibold bg-orange-600 hover:bg-orange-700 text-white flex items-center justify-center gap-2 opacity-50 cursor-not-allowed" disabled onclick="cierre.initCierre()">
                    ${lucideIcon('check-check')} Cerrar Dia
                </button>
            `);
        }

        const [response, openRes, pendingRes] = await Promise.all([
            useFetch({ url: this._link, data: { opc: "getShiftsByDate", date: date, subsidiaries_id: subsidiaries_id } }),
            useFetch({ url: this._link, data: { opc: "getOpenShifts", subsidiaries_id: subsidiaries_id } }),
            useFetch({ url: cierre.api, data: { opc: "getPendingDays", subsidiaries_id: subsidiaries_id } })
        ]);

        const shifts = response.shifts || [];
        const today = moment().format('YYYY-MM-DD');
        // Fechas pasadas (rango 15 días) con turnos y sin cierre diario: bloquean operar hoy.
        const pendingDays = pendingRes.days || [];
        const allOpenShifts = openRes.shifts || [];
        const openShifts = allOpenShifts.filter(s => !moment(s.opened_at).isSame(today, 'day'));
        const hasAnyOpenShift = allOpenShifts.length > 0;
        const select = $('#shiftSelector');
        select.html('<option value="">-- Cerrar turno --</option>');

        shifts.forEach(s => {
            const time = moment(s.opened_at).format('YYYY-MM-DD hh:mm A');
            const badge = s.status === 'open' ? ' [ABIERTO]' : ' [CERRADO]';
            select.append(`<option value="${s.id}" data-status="${s.status}">${time}${badge}</option>`);
        });

        // Mostrar turnos abiertos pendientes
        const alertContainer = $('#openShiftsAlert');
        if (openShifts.length > 0) {
            const shiftItems = openShifts.map(s => {
                const date = moment(s.opened_at).format('DD/MM/YYYY');
                const time = moment(s.opened_at).format('hh:mm').replace(/^0/, '');
                const meridiem = moment(s.opened_at).format('A');
                return `
                    <div class="flex items-center justify-between gap-2 px-2.5 py-1.5 bg-slate-800/40 rounded-md cursor-pointer hover:bg-slate-800/70 transition-colors" onclick="app.selectOpenShift('${s.id}', '${moment(s.opened_at).format('YYYY-MM-DD')}')">
                        <div class="flex flex-col gap-0.5">
                            <div class="flex items-baseline gap-1">
                                <span class="text-xs font-bold text-white leading-none">${time}</span>
                                <span class="text-[10px] font-semibold text-slate-400">${meridiem}</span>
                            </div>
                            <div class="flex items-center gap-1 text-[10px] text-slate-400">
                                <i class="icon-calendar text-[10px]"></i>
                                <span>${date}</span>
                            </div>
                        </div>
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/15 border border-orange-500/30">
                            <span class="w-1 h-1 bg-orange-400 rounded-full"></span>
                            <span class="text-[10px] font-semibold text-orange-400">Abierto</span>
                        </span>
                    </div>
                `;
            }).join('');

            alertContainer.html(`
                <div class="rounded-lg border border-slate-700/60 bg-slate-900/40 p-2.5">
                    <div class="flex items-center justify-between gap-2 mb-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Turnos sin cerrar</span>
                        <span class="inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-orange-500 text-[10px] font-bold text-white">${openShifts.length}</span>
                    </div>
                    <div class="space-y-1.5">${shiftItems}</div>
                </div>
            `).removeClass('hidden');

        } else {
            alertContainer.addClass('hidden').html('');
        }

        // "Abrir Turno" solo aplica a HOY: el turno nace con opened_at = NOW, no con la
        // fecha del selector. Con el selector en un dia pasado (o futuro) el boton no debe
        // invitar a abrir turno de ese dia. Ademas se deshabilita si ya hay un turno abierto
        // en la sucursal (cualquier dia, que hay que cerrar antes).
        const isToday = date === today;
        // Bloqueo de operar hoy: si hay una fecha pasada sin cerrar (rango 15 días) no se
        // puede abrir/cerrar turno ni cerrar el día de hoy. Se fija aquí (antes de
        // viewShiftPreview) para que esa función lo respete al habilitar "Cerrar Turno".
        this._operationBlocked = isToday && pendingDays.length > 0;
        if (isToday && !hasAnyOpenShift) {
            $('#btnOpenShift').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed').attr('title', '');
        } else {
            $('#btnOpenShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').removeClass('hover:bg-green-700')
                .attr('title', !isToday ? 'Solo puedes abrir turno en la fecha de hoy' : 'Ya hay un turno abierto en esta sucursal');
        }

        // Verificar si el día ya está cerrado ANTES de pintar (para mostrar el Corte Z, no el ticket de un turno)
        const closureCheck = await useFetch({ url: cierre.api, data: { opc: 'getCierre', date: date, subsidiaries_id: subsidiaries_id } });
        const isDayClosed = closureCheck.status === 200 && !!closureCheck.closure;

        if (isDayClosed) {
            // Día cerrado: mostrar el Corte Z (opción "CIERRE DIARIO"). No pintar el ticket de un turno.
            await cierre.loadClosedView(date, subsidiaries_id);
        } else if (shifts.length > 0) {
            // Seleccionar el turno más reciente y mostrar su ticket.
            select.val(shifts[0].id);
            this.viewShiftPreview();
        } else {
            $('#ticketContainer').html(`
                <div class="text-center text-gray-400 py-16">
                    <i class="icon-clock text-5xl mb-4"></i>
                    <p class="mt-4">No hay turnos para esta fecha</p>
                    <p class="text-sm mt-2">Abre un turno para comenzar</p>
                </div>
            `);
            $('#btnCloseShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
            $('#btnPrintTicket').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
            $('#ticketModeBar').addClass('hidden');
        }

        // Habilitar botón Cerrar Día solo si hay al menos un turno cerrado (y el día no está cerrado)
        const hasClosedShifts = shifts.some(s => s.status === 'closed');

        // Nota "Día sin cerrar": solo si hay una fecha PASADA (u otra) con turnos y sin
        // cierre diario. NO aplica a hoy (hoy todavía se opera). Cada fila lleva a esa
        // fecha para cerrarla. Mientras exista un pendiente se bloquea operar hoy.
        this.renderPendingDaysAlert(pendingDays, date);

        // Refuerza el bloqueo visual de "operar hoy" (el flag se fijó arriba). En la
        // propia fecha pendiente (isToday=false) no se bloquea, para poder cerrarla.
        if (this._operationBlocked) {
            const blockTitle = 'Cierra primero los días pendientes';
            $('#btnOpenShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').attr('title', blockTitle);
            $('#btnCloseShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').attr('title', blockTitle);
        }

        if (!isDayClosed) {
            if (hasClosedShifts && !this._operationBlocked) {
                $('#btnCerrarDia').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed');
            } else {
                $('#btnCerrarDia').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
            }

            if (date === moment().format('YYYY-MM-DD')) {
                // Sincronizar estado de la pantalla principal si hoy no hay cierre activo
                dailyClosure = { is_closed: false, subsidiary_id: subsidiaries_id || udn };
                this.updateDailyClosureStatus();
            }
        }
    }

    async selectOpenShift(shiftId, date) {
        const picker = $('#calendarDailyClose').data('daterangepicker');
        const momentDate = moment(date);
        picker.setStartDate(momentDate);
        picker.setEndDate(momentDate);
        await this.loadShifts();
        $('#shiftSelector').val(shiftId).trigger('change');
    }

    // Navega el modal a una fecha pendiente de cierre (desde la nota "Días sin cerrar").
    // En esa fecha el bloqueo de "operar hoy" no aplica, así que se puede cerrar.
    async goToPendingDay(date) {
        const picker = $('#calendarDailyClose').data('daterangepicker');
        const momentDate = moment(date);
        picker.setStartDate(momentDate);
        picker.setEndDate(momentDate);
        await this.loadShifts();
    }

    async viewShiftPreview() {
        const shiftId = $('#shiftSelector').val();
        if (!shiftId) {
            $('#btnCloseShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
            $('#btnPrintTicket').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
            $('#ticketModeBar').addClass('hidden');
            return;
        }

        // "CIERRE DIARIO": mostrar el corte Z del día, no un turno individual.
        if (shiftId === 'daily') {
            if (typeof cierre !== 'undefined') cierre.renderDaily();
            return;
        }

        this._selectedShiftId = shiftId;

        // Animación de carga mientras se consulta el ticket del turno.
        $('#ticketContainer').html(`
            <div class="flex flex-col items-center justify-center text-gray-400 min-h-[340px]">
                <div class="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full mb-4"></div>
                <p>Cargando ticket...</p>
            </div>
        `);

        const selectedOption = $(`#shiftSelector option[value="${shiftId}"]`);
        const shiftStatus = selectedOption.data('status');

        // Obtener métricas
        const [metricsRes] = await Promise.all([
            useFetch({ url: this._link, data: { opc: "getShiftMetrics", shift_id: shiftId } }),
            new Promise(resolve => setTimeout(resolve, 500))
        ]);

        if (metricsRes.status !== 200) {
            $('#ticketContainer').html(`<p class="text-center text-gray-400 py-10">${metricsRes.message || 'Error al obtener datos'}</p>`);
            return;
        }

        // Obtener órdenes si modo detallado
        let orders = [];
        let externalPayments = [];
        let crossPayments = [];
        if (this.reportMode === 'detailed') {
            const ordersRes = await useFetch({
                url: this._link,
                data: { opc: "getShiftOrders", shift_id: shiftId }
            });
            orders            = ordersRes.orders || [];
            externalPayments  = ordersRes.external_payments || [];
            crossPayments     = ordersRes.cross_payments || [];
        }

        this.ticketShiftClose({
            data: metricsRes.data,
            shift: metricsRes.shift,
            subsidiary_name: metricsRes.subsidiary_name,
            company_name: metricsRes.company_name,
            logo: metricsRes.logo,
            orders: orders,
            externalPayments: externalPayments,
            crossPayments: crossPayments
        });

        // Habilitar botón imprimir
        $('#btnPrintTicket').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed');

        // Botón cerrar caja: solo si turno está abierto y no hay días pendientes que
        // bloqueen operar hoy (this._operationBlocked lo fija loadShifts).
        if (shiftStatus === 'open' && !this._operationBlocked) {
            $('#btnCloseShift').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed');
        } else {
            $('#btnCloseShift').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
        }
    }

    // El formato del ticket de turno vive en shift-ticket.js (fuente unica, compartida
    // con el modulo order-visor). Aqui solo se inyecta el modo de reporte del modulo.
    ticketShiftClose(options) {
        renderShiftTicket({ ...options, reportMode: this.reportMode });
        const containerId = options.containerId || 'ticketContainer';
        if (containerId === 'ticketContainer') $('#ticketModeBar').removeClass('hidden');
    }

    toggleReportMode(mode) {
        this.reportMode = mode;

        if (mode === 'detailed') {
            $('#btnModeDetailed').addClass('bg-purple-600 text-white shadow-sm').removeClass('text-gray-400 hover:text-gray-200');
            $('#btnModeSummary').addClass('text-gray-400 hover:text-gray-200').removeClass('bg-purple-600 text-white shadow-sm');
        } else {
            $('#btnModeSummary').addClass('bg-purple-600 text-white shadow-sm').removeClass('text-gray-400 hover:text-gray-200');
            $('#btnModeDetailed').addClass('text-gray-400 hover:text-gray-200').removeClass('bg-purple-600 text-white shadow-sm');
        }

        if (this._selectedShiftId) {
            this.viewShiftPreview();
        }
    }

    openShift() {
        let subsidiaries_id = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7) ? ($('#subsidiariesDailyClose').val() || null) : null;
        const subName = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7)
            ? $('#subsidiariesDailyClose option:selected').text()
            : sub_name;

        createCoffeeModalForm({
            id: 'frmOpenShift',
            title: 'Abrir Turno',
            iconSvg: lucideIcon('clock', 'w-5 h-5'),
            iconBg: 'bg-emerald-600',
            theme: 'dark',
            confirmText: 'Confirmar Apertura',
            cancelText: 'Cancelar',
            json: [
                { opc: 'display', id: 'sucursal',    lbl: 'Sucursal',             icon: lucideIcon('house', 'w-4 h-4'), value: subName },
                { opc: 'display', id: 'responsable', lbl: 'Responsable',          icon: lucideIcon('user', 'w-4 h-4'),  value: (typeof user_name !== 'undefined' && user_name) ? user_name : 'Sin asignar' },
                { opc: 'money',   id: 'openingAmount', lbl: 'Fondo inicial de caja', placeholder: '0.00', min: 0, step: 0.01, autofocus: true }
            ],
            onConfirm: async (data, modal) => {
                const opening_amount = parseFloat(data.openingAmount) || 0;

                const confirm = await Swal.fire({
                    title: '¿Aperturar turno?',
                    html: `<p>Se abrirá un nuevo turno de caja en <strong>${subName}</strong> con un fondo inicial de <strong>$${opening_amount.toFixed(2)}</strong>.</p>`,
                    icon: 'question',
                    iconColor: '#8b5cf6',
                    showCancelButton: true,
                    confirmButtonText: 'Sí, aperturar',
                    cancelButtonText: 'Cancelar',
                    confirmButtonColor: '#8b5cf6',
                    customClass: { popup: 'bg-[#1F2A37] text-white rounded-lg' },
                    // El modal de apertura usa z-index 100000; subimos el Swal por encima.
                    didOpen: () => { const c = document.querySelector('.swal2-container'); if (c) c.style.zIndex = 100010; }
                });

                if (!confirm.isConfirmed) return;

                const response = await useFetch({
                    url: this._link,
                    data: {
                        opc: "openShift",
                        shift_name: '',
                        opening_amount: opening_amount,
                        subsidiaries_id: subsidiaries_id
                    }
                });

                modal.modal('hide');

                if (response.status === 200) {
                    alert({ icon: "success", title: "Turno abierto", text: response.message, timer: 2000 });
                    await this.selectOpenShift(response.shift_id, moment().format('YYYY-MM-DD'));
                    // Va al final: loadShifts() reescribe dailyClosure con la sucursal del
                    // modal, y syncShiftState deja el estado real de la que se esta viendo.
                    await this.syncShiftState();
                } else if (response.status === 423) {
                    // El dia de hoy ya esta cerrado: no es un error de captura, es un bloqueo
                    // de negocio (requiere reabrir el cierre). Se avisa como advertencia.
                    alert({ icon: "warning", title: "Día cerrado", text: response.message, btn1: true });
                } else {
                    alert({ icon: "error", title: "Error", text: response.message, btn1: true });
                }
            }
        });
    }

    async closeShift() {
        const shiftId = this._selectedShiftId || $('#shiftSelector').val();
        if (!shiftId) return;

        const ordersRes = await useFetch({
            url: this._link,
            data: { opc: "getShiftOrders", shift_id: shiftId }
        });
        const orderCount = (ordersRes.orders || []).length;

        // Sucursal del turno a cerrar: la del selector del modal (admin) o la de sesión.
        const subName = (rol == 1 || rol == 2 || rol == 3 || rol == 6 || rol == 7)
            ? $('#subsidiariesDailyClose option:selected').text()
            : sub_name;

        Swal.fire({
            title: '¿Cerrar ticket de turno?',
            html: `<p>Se procederá a realizar el corte de caja en <strong>${subName}</strong>. Se cerrarán <strong><u>${orderCount}</u></strong> tickets de venta con la información actual.</p>`,
            icon: 'question',
            iconColor: '#8b5cf6',
            showCancelButton: true,
            confirmButtonText: 'Sí, cerrar turno',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: '#8b5cf6',
            customClass: {
                popup: 'bg-[#1F2A37] text-white rounded-lg',
            }
        }).then(async (result) => {
            if (result.isConfirmed) {
                const response = await useFetch({
                    url: this._link,
                    data: { opc: "closeShift", shift_id: shiftId }
                });

                if (response.status === 200) {
                    alert({ icon: "success", title: "Turno cerrado", text: response.message, timer: 2000 });
                    await this.loadShifts();
                    this.ls();
                    await this.syncShiftState();
                } else {
                    alert({ icon: "error", title: "Error", text: response.message, btn1: true });
                }
            }
        });
    }

    printDailyCloseTicket() {
        const ticketContent = document.getElementById('ticketDailyClose');

        if (!ticketContent) {
            alert({ icon: "warning", text: "No hay ticket para imprimir.", btn1: true, btn1Text: "Ok" });
            return;
        }

        // Reutiliza el CSS de Fontello ya cargado en la pagina (href absoluto) para que
        // los iconos (icon-shop, icon-bank) se rendericen tambien en la ventana de impresion.
        const fontelloHref = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
            .map(l => l.href)
            .find(h => /fontello/i.test(h)) || '';

        const printWindow = window.open('', '', 'height=600,width=400');
        printWindow.document.write('<html><head><title>Cierre de Turno</title>');
        if (fontelloHref) {
            printWindow.document.write(`<link rel="stylesheet" href="${fontelloHref}">`);
        }
        printWindow.document.write(`
            <style>
                /* Sin este reset, el padding p-4 del ticket suma al width:100% inline
                   y el contenido se desborda/recorta por la derecha al imprimir. */
                * { box-sizing: border-box; }
                body { font-family: 'Courier New', monospace; padding: 10px; max-width: 320px; margin: 0 auto; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                .bg-white { background-color: white; }
                .p-4 { padding: 1rem; }
                .p-3 { padding: 0.75rem; }
                .rounded-lg { border-radius: 0.5rem; }
                .rounded { border-radius: 0.25rem; }
                .shadow-lg { box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                .font-mono { font-family: 'Courier New', monospace; }
                .text-gray-900 { color: #111827; }
                .flex { display: flex; }
                .flex > * { min-width: 0; }
                .flex-col { flex-direction: column; }
                .flex-1 { flex: 1 1 0%; }
                .items-center { align-items: center; }
                .justify-between { justify-content: space-between; }
                .justify-center { justify-content: center; }
                .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                .text-right { text-align: right; }
                .mb-3 { margin-bottom: 0.75rem; }
                .mb-2 { margin-bottom: 0.5rem; }
                .mb-1 { margin-bottom: 0.25rem; }
                .mb-0\\.5 { margin-bottom: 2px; }
                .mt-4 { margin-top: 1rem; }
                .mt-3 { margin-top: 0.75rem; }
                .mt-2 { margin-top: 0.5rem; }
                .mt-1 { margin-top: 0.25rem; }
                .mt-0\\.5 { margin-top: 2px; }
                .pt-2 { padding-top: 0.5rem; }
                .pt-1 { padding-top: 0.25rem; }
                .pt-0\\.5 { padding-top: 2px; }
                .px-1\\.5 { padding-left: 6px; padding-right: 6px; }
                .py-0\\.5 { padding-top: 2px; padding-bottom: 2px; }
                .text-sm { font-size: 0.875rem; }
                .text-xs { font-size: 0.75rem; }
                .text-\\[11px\\] { font-size: 11px; }
                .text-\\[10px\\] { font-size: 10px; }
                .text-\\[9px\\] { font-size: 9px; }
                .font-bold { font-weight: bold; }
                .font-semibold { font-weight: 600; }
                .font-normal { font-weight: normal; }
                .text-gray-600 { color: #4B5563; }
                .text-gray-500 { color: #6B7280; }
                .text-gray-400 { color: #9CA3AF; }
                .text-green-700 { color: #15803D; }
                .text-purple-800 { color: #6B21A8; }
                .text-purple-700 { color: #7E22CE; }
                .text-purple-500 { color: #A855F7; }
                .text-purple-400 { color: #C084FC; }
                .text-center { text-align: center; }
                .uppercase { text-transform: uppercase; }
                .italic { font-style: italic; }
                .space-y-1 > * + * { margin-top: 0.25rem; }
                .space-y-0\\.5 > * + * { margin-top: 0.125rem; }
                hr { border: 0; border-top: 1px dashed #D1D5DB; margin: 0.5rem 0; }
                .border { border: 1px solid #E5E7EB; }
                .border-t { border-top: 1px solid #E5E7EB; }
                .border-dashed { border-style: dashed; }
                .border-gray-200 { border-color: #E5E7EB; }
                .border-purple-200 { border-color: #E9D5FF; }
                .bg-green-100, .bg-blue-100 { padding: 2px 8px; border-radius: 9999px; display: inline-block; }
                .bg-green-100 { background: #dcfce7; color: #166534; }
                .bg-blue-100 { background: #dbeafe; color: #1e40af; }
                .bg-gray-100 { background: #F3F4F6; }
                .bg-purple-50 { background: #FAF5FF; }
                @page { margin: 5mm; }
                @media print {
                    /* En papel el ancho lo define la impresora (termica 58/80mm o carta),
                       no el max-width de 320px de la vista previa. */
                    body { padding: 0; max-width: none; margin: 0; }
                    #ticketDailyClose {
                        max-width: none !important;
                        width: 100% !important;
                        padding: 0 !important;
                        border: none !important;
                        box-shadow: none !important;
                        border-radius: 0 !important;
                    }
                }
            </style>
        `);
        printWindow.document.write('</head><body>');
        printWindow.document.write(ticketContent.outerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();

        // Espera a que cargue la fuente de iconos antes de imprimir; si no, fallback por tiempo.
        const triggerPrint = () => printWindow.print();
        if (printWindow.document.fonts && printWindow.document.fonts.ready) {
            printWindow.document.fonts.ready.then(() => setTimeout(triggerPrint, 100));
        } else {
            setTimeout(triggerPrint, 400);
        }
    }

}



