<?php
session_start();
if (empty($_POST['opc'])) exit(0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

require_once '../mdl/mdl-cierre.php';
require_once '../../conf/_Message.php';

class Cierre extends MCierre {

    const WHATSAPP_CIERRE = '9621501886';

    private function resolveSubsidiary() {
        // Roles con filtro de navbar (admin 1, cajero 2, vendedor 3) operan el cierre
        // sobre la sucursal que eligen en el modal. Si no llega una sucursal util,
        // se cae a la sucursal de sesion. El resto de roles siempre usa su sesion.
        if (in_array($_SESSION['ROLID'], [1, 2, 3, 6, 7])) {
            $postSub = $_POST['subsidiaries_id'] ?? null;
            if ($postSub !== null && $postSub !== '' && $postSub != '0') {
                return $postSub;
            }
        }
        return $_SESSION['SUB'];
    }

    function showCierre() {
        $date            = $_POST['date'];
        $subsidiaries_id = $this->resolveSubsidiary();

        if ($subsidiaries_id == 0 || $subsidiaries_id == '0') {
            return ['status' => 400, 'message' => 'Selecciona una sucursal'];
        }

        $checks   = [];
        $can_close = true;

        $existing = $this->getDailyClosureByDate([$date, $subsidiaries_id]);
        if ($existing) {
            $checks[] = ['key' => 'no_existing', 'ok' => false, 'blocker' => true, 'label' => 'Ya existe un cierre para esta fecha', 'detail' => 'Cerrado por ' . $existing['closed_by_name']];
            $can_close = false;
        }

        $openShifts = $this->listOpenShifts([$date, $subsidiaries_id]);
        if (count($openShifts) > 0) {
            $items = [];
            foreach ($openShifts as $shift) {
                $items[] = ['id' => $shift['id'], 'name' => $shift['shift_name'], 'opened_at' => $shift['opened_at'], 'employee' => $shift['employee_name']];
            }
            $checks[] = ['key' => 'shifts_closed', 'ok' => false, 'blocker' => true, 'label' => count($openShifts) . ' turno(s) sin cerrar', 'items' => $items];
            $can_close = false;
        } else {
            $metrics = $this->getConsolidatedMetrics([$date, $subsidiaries_id]);
            $checks[] = ['key' => 'shifts_closed', 'ok' => true, 'blocker' => true, 'label' => 'Todos los turnos cerrados', 'detail' => $metrics['total_shifts'] . ' turno(s) cerrado(s) correctamente'];
        }

        $orphans = $this->listOrphanOrders([$date, $subsidiaries_id]);
        if (count($orphans) > 0) {
            $items = [];
            foreach ($orphans as $order) {
                $items[] = ['folio' => $order['folio'], 'date' => $order['date_creation'], 'total' => floatval($order['total_pay'])];
            }
            $checks[] = ['key' => 'orphan_orders', 'ok' => false, 'blocker' => false, 'label' => count($orphans) . ' pedido(s) sin turno asignado', 'items' => $items];
        } else {
            $checks[] = ['key' => 'orphan_orders', 'ok' => true, 'blocker' => false, 'label' => 'Todos los pedidos tienen turno', 'detail' => ''];
        }

        $pending = $this->listPendingBalance([$date, $subsidiaries_id]);
        if (count($pending) > 0) {
            $items = [];
            foreach ($pending as $order) {
                $items[] = ['folio' => $order['folio'], 'date' => $order['date_creation'], 'total' => floatval($order['total_pay']), 'paid' => floatval($order['total_paid']), 'pending' => floatval($order['pending_balance'])];
            }
            $checks[] = ['key' => 'pending_balance', 'ok' => false, 'blocker' => false, 'label' => count($pending) . ' pedido(s) con saldo pendiente', 'items' => $items];
        } else {
            $checks[] = ['key' => 'pending_balance', 'ok' => true, 'blocker' => false, 'label' => 'Sin saldos pendientes', 'detail' => ''];
        }

        $payments = $this->getConsolidatedPayments([$date, $subsidiaries_id]);
        $cash = 0; $card = 0; $transfer = 0;
        if (is_array($payments)) {
            foreach ($payments as $pay) {
                switch ($pay['method_pay_id']) {
                    case 1: $cash     = floatval($pay['total_paid']); break;
                    case 2: $card     = floatval($pay['total_paid']); break;
                    case 3: $transfer = floatval($pay['total_paid']); break;
                }
            }
        }
        $checks[] = ['key' => 'payments_ok', 'ok' => true, 'blocker' => false, 'label' => 'Formas de pago registradas', 'detail' => "Efectivo: $" . number_format($cash, 2) . " | Tarjeta: $" . number_format($card, 2) . " | Transf: $" . number_format($transfer, 2)];

        if (!isset($metrics)) {
            $metrics = $this->getConsolidatedMetrics([$date, $subsidiaries_id]);
        }
        $discount = $this->getDiscountTotal([$date, $subsidiaries_id]);
        $shifts   = $this->listShiftsDetail([$date, $subsidiaries_id]);

        $sub = $this->getSubsidiaryName([$subsidiaries_id]);
        $subsidiary_name = $sub ? $sub['sucursal'] : 'Sucursal';

        return [
            'status'          => 200,
            'can_close'       => $can_close,
            'checks'          => $checks,
            'summary'         => [
                'total_sales'    => floatval($metrics['total_sales']),
                'total_orders'   => intval($metrics['total_orders']),
                'total_shifts'   => intval($metrics['total_shifts']),
                'total_cash'     => $cash,
                'total_card'     => $card,
                'total_transfer' => $transfer,
                'total_discount' => $discount
            ],
            'shifts'           => $shifts,
            'subsidiary_name'  => $subsidiary_name
        ];
    }

    function addCierre() {
        $date            = $_POST['date'];
        $subsidiaries_id = $this->resolveSubsidiary();

        if ($subsidiaries_id == 0 || $subsidiaries_id == '0') {
            return ['status' => 400, 'message' => 'Selecciona una sucursal'];
        }

        $existing = $this->getDailyClosureByDate([$date, $subsidiaries_id]);
        if ($existing) {
            return ['status' => 409, 'message' => 'Ya existe un cierre para esta fecha y sucursal'];
        }

        $openShifts = $this->listOpenShifts([$date, $subsidiaries_id]);
        if (count($openShifts) > 0) {
            return ['status' => 400, 'message' => 'Hay turnos sin cerrar. Cierra todos los turnos antes de continuar.'];
        }

        $metrics  = $this->getConsolidatedMetrics([$date, $subsidiaries_id]);
        $payments = $this->getConsolidatedPayments([$date, $subsidiaries_id, $date, $subsidiaries_id]);
        $statuses = $this->getConsolidatedStatuses([$date, $subsidiaries_id]);
        $discount = $this->getDiscountTotal([$date, $subsidiaries_id]);

        $total_sales = floatval($metrics['total_sales']);

        $cash = 0; $card = 0; $transfer = 0;
        if (is_array($payments)) {
            foreach ($payments as $pay) {
                switch ($pay['method_pay_id']) {
                    case 1: $cash     = floatval($pay['total_paid']); break;
                    case 2: $card     = floatval($pay['total_paid']); break;
                    case 3: $transfer = floatval($pay['total_paid']); break;
                }
            }
        }

        $this->createClosure([
            'values' => 'total, tax, subtotal, employee_id, subsidiary_id, created_at, active, total_orders, closure_date, total_shifts, total_cash, total_card, total_transfer, total_discount, status, is_legacy',
            'data'   => [
                $total_sales,
                0,
                $total_sales,
                $_SESSION['ID'],
                $subsidiaries_id,
                date('Y-m-d H:i:s'),
                1,
                intval($metrics['total_orders']),
                $date,
                intval($metrics['total_shifts']),
                $cash,
                $card,
                $transfer,
                $discount,
                0,
                0
            ]
        ]);

        $maxId = $this->getMaxClosureId();
        $closure_id = $maxId['id'];

        $paymentRows = [
            ['method_id' => 1, 'amount' => $cash],
            ['method_id' => 2, 'amount' => $card],
            ['method_id' => 3, 'amount' => $transfer]
        ];
        foreach ($paymentRows as $row) {
            $this->createClosurePayments([
                'values' => 'daily_closure_id, payment_method_id, amount',
                'data'   => [$closure_id, $row['method_id'], $row['amount']]
            ]);
        }

        if (is_array($statuses)) {
            foreach ($statuses as $st) {
                $this->createClosureStatuses([
                    'values' => 'daily_closure_id, status_process_id, amount',
                    'data'   => [$closure_id, $st['status'], intval($st['count'])]
                ]);
            }
        }

        $this->updateOrdersClosure([$closure_id, $date, $subsidiaries_id]);

        // Aviso del cierre diario por WhatsApp (resumido). No debe afectar el cierre si falla.
        $this->notifyDailyClosed($subsidiaries_id, $date, $metrics, $cash, $card, $transfer, $discount);

        return [
            'status'     => 200,
            'message'    => 'Cierre diario realizado correctamente',
            'closure_id' => $closure_id
        ];
    }

    // Aviso de cierre del dia por WhatsApp con el corte consolidado. Nunca debe tumbar
    // el cierre: el dia ya quedo cerrado y el envio depende de una API externa.
    private function notifyDailyClosed($subsidiaries_id, $date, $metrics, $cash, $card, $transfer, $discount) {
        if (self::WHATSAPP_CIERRE === '' || self::WHATSAPP_CIERRE === []) return;

        try {
            $sub       = $this->getSubsidiaryName([$subsidiaries_id]);
            $nombreSuc = $sub ? $sub['sucursal'] : 'Sucursal';
            $fecha     = date('d/m/Y', strtotime($date));
            $cajero    = $_SESSION['USER'] ?? 'un usuario';

            $mensaje = "*CIERRE DEL DIA*\n"
                     . $nombreSuc . ' - ' . $fecha . "\n"
                     . 'Cerro: ' . $cajero . "\n\n"
                     . '*Ventas:* $' . number_format(floatval($metrics['total_sales']), 2) . "\n"
                     . 'Efectivo: $' . number_format(floatval($cash), 2) . "\n"
                     . 'Tarjeta: $' . number_format(floatval($card), 2) . "\n"
                     . 'Transferencia: $' . number_format(floatval($transfer), 2) . "\n"
                     . 'Descuentos: $' . number_format(floatval($discount), 2) . "\n"
                     . 'Pedidos: ' . intval($metrics['total_orders']) . "\n"
                     . 'Turnos: ' . intval($metrics['total_shifts']);

            $msg = new Message();
            $msg->whatsapp(self::WHATSAPP_CIERRE, $mensaje);
        } catch (Exception $e) {
            error_log('[ WHATSAPP addCierre ] :: ' . $e->getMessage() . PHP_EOL, 3, 'error.log');
        }
    }

    // Lista de fechas pasadas (dentro de un rango) con turnos y sin cierre diario,
    // de la sucursal activa. El frontend la usa para mostrar la nota "Dia sin cerrar"
    // y bloquear la operacion de hoy hasta que se cierren.
    function getPendingDays() {
        $subsidiaries_id = $this->resolveSubsidiary();

        if ($subsidiaries_id == 0 || $subsidiaries_id == '0') {
            return ['status' => 200, 'days' => []];
        }

        $today = date('Y-m-d');
        $from  = date('Y-m-d', strtotime('-15 days'));

        $rows = $this->listPendingDays([$subsidiaries_id, $today, $from]);
        $days = [];
        foreach ($rows as $r) {
            $days[] = [
                'date'        => $r['pending_date'],
                'shifts'      => intval($r['shifts']),
                'open_shifts' => intval($r['open_shifts'])
            ];
        }

        return ['status' => 200, 'days' => $days];
    }

    function getCierre() {
        $date            = $_POST['date'];
        $subsidiaries_id = $this->resolveSubsidiary();

        $closure   = $this->getDailyClosureByDate([$date, $subsidiaries_id]);
        $isPending = !$closure;

        // Vista previa del Corte Z sin cierre (reportes manda preview=1): solo el admin
        // puede consultar el dia aunque falte el cierre diario; el reporte se arma con
        // los datos en vivo y viaja marcado como pendiente. El resto sigue viendo 404.
        if ($isPending && ($_SESSION['ROLID'] != 1 || empty($_POST['preview']))) {
            return ['status' => 404, 'message' => 'No hay cierre para esta fecha'];
        }

        $shifts   = $this->listShiftsDetail([$date, $subsidiaries_id]);
        $statuses = $this->getConsolidatedStatuses([$date, $subsidiaries_id]);
        $paymentTx = $this->getPaymentTransactions([$date, $subsidiaries_id, $date, $subsidiaries_id]);
        $ordersRaw = $this->getOrdersBreakdown([$date, $subsidiaries_id]);

        $summary    = $this->getOrdersSummary([$date, $subsidiaries_id]);
        $categories = $this->getSalesByCategory([$date, $subsidiaries_id]);
        $cashShifts = $this->getCashShiftsSummary([$date, $subsidiaries_id]);
        $livePays   = $this->getConsolidatedPayments([$date, $subsidiaries_id, $date, $subsidiaries_id]);
        $prevRaw    = $this->getDailyPrevPayments([$date . ' 23:59:59', $date, $date, $subsidiaries_id]);
        $prevByTx   = $this->getDailyPrevPaymentsByMethod([$date, $date, $subsidiaries_id]);
        $crossRaw   = $this->getDailyCrossPayments([$date, $subsidiaries_id, $subsidiaries_id]);

        $sub = $this->getSubsidiaryName([$subsidiaries_id]);
        $subsidiary_name = $sub ? $sub['sucursal'] : 'Sucursal';
        $company_name    = $sub ? $sub['company'] : '';

        $quotation_count = 0;
        $pending_count   = 0;
        $cancelled_count = 0;
        $delivered_count  = 0;
        if (is_array($statuses)) {
            foreach ($statuses as $st) {
                switch ($st['status']) {
                    case 1: $quotation_count = intval($st['count']); break;
                    case 2: $pending_count   = intval($st['count']); break;
                    case 3: $delivered_count  = intval($st['count']); break;
                    case 4: $cancelled_count = intval($st['count']); break;
                }
            }
        }

        $countCash = 0; $countCard = 0; $countTransfer = 0;
        foreach ($paymentTx as $tx) {
            switch (intval($tx['method_pay_id'])) {
                case 1: $countCash     = intval($tx['transactions']); break;
                case 2: $countCard     = intval($tx['transactions']); break;
                case 3: $countTransfer = intval($tx['transactions']); break;
            }
        }

        // Abonos de dias anteriores cobrados hoy, repartidos en su metodo de pago:
        // el desglose de Metodos de Pago suma el dinero que entro a esta caja, venga
        // de un pedido del dia o de uno anterior.
        $prevCash = 0; $prevCard = 0; $prevTransfer = 0;
        $prevCountCash = 0; $prevCountCard = 0; $prevCountTransfer = 0;
        foreach ($prevByTx as $tx) {
            switch (intval($tx['method_pay_id'])) {
                case 1: $prevCash     = floatval($tx['total_paid']); $prevCountCash     = intval($tx['transactions']); break;
                case 2: $prevCard     = floatval($tx['total_paid']); $prevCountCard     = intval($tx['transactions']); break;
                case 3: $prevTransfer = floatval($tx['total_paid']); $prevCountTransfer = intval($tx['transactions']); break;
            }
        }

        $orders = [];
        foreach ($ordersRaw as $o) {
            $orders[] = [
                // id crudo del pedido (getOrdersBreakdown lo devuelve como 'folio' antes de formatear);
                // lo usa el visor de cierre para abrir el ticket al hacer clic en la fila.
                'id'              => intval($o['folio']),
                'folio'           => formatFolioCierre($subsidiaries_id, $o['folio']),
                'date'            => $o['date_creation'],
                'time'            => $o['order_time'],
                'client'          => $o['client_name'],
                'status'          => intval($o['status']),
                'total'           => floatval($o['total_pay']),
                'discount'        => floatval($o['discount']),
                'payment_real'    => floatval($o['payment_real']),
                'total_paid_upto' => floatval($o['total_paid_upto']),
                'method'          => $o['method'],
                'shift_id'        => $o['shift_id'] !== null ? intval($o['shift_id']) : null
            ];
        }

        // Cobranza real de pedidos del dia: solo pagos con fecha de pago de ese dia
        // y cobrados en esta sucursal. Los abonos a pedidos anteriores van en prev_*.
        $liveCash = 0; $liveCard = 0; $liveTransfer = 0;
        foreach ($livePays as $pay) {
            switch (intval($pay['method_pay_id'])) {
                case 1: $liveCash     = floatval($pay['total_paid']); break;
                case 2: $liveCard     = floatval($pay['total_paid']); break;
                case 3: $liveTransfer = floatval($pay['total_paid']); break;
            }
        }

        $openingTotal = 0;
        foreach ($cashShifts as $cs) {
            $openingTotal += floatval($cs['fondo_caja']);
        }

        $categoriesList = [];
        foreach ($categories as $name => $total) {
            $categoriesList[] = ['categoria' => $name, 'total' => floatval($total)];
        }

        $prevPayments = [];
        foreach ($prevRaw as $p) {
            $prevPayments[] = [
                'id'                => intval($p['id']),
                'folio'             => formatFolioCierre($p['origin_subsidiary_id'], $p['id']),
                'order_date'        => $p['date_creation'],
                'pay_time'          => $p['pay_time'],
                'client_name'       => $p['client_name'],
                'origin_subsidiary' => $p['origin_subsidiary'],
                'is_cross'          => intval($p['origin_subsidiary_id']) != intval($subsidiaries_id),
                'total_pay'         => floatval($p['total_pay']),
                'discount'          => floatval($p['discount']),
                'payment_real'      => floatval($p['payment_real']),
                'total_paid_upto'   => floatval($p['total_paid_upto']),
                'method'            => $p['method'],
                'shift_id'          => $p['shift_id'] !== null ? intval($p['shift_id']) : null
            ];
        }

        $crossPayments = [];
        foreach ($crossRaw as $p) {
            $crossPayments[] = [
                'id'                 => intval($p['id']),
                'folio'              => formatFolioCierre($subsidiaries_id, $p['id']),
                'client_name'        => $p['client_name'],
                'charged_subsidiary' => $p['charged_subsidiary'],
                'total_pay'          => floatval($p['total_pay']),
                'payment_cross'      => floatval($p['payment_cross'])
            ];
        }

        $totalCuentas = intval($summary['total_cuentas']);
        $canceladas   = intval($summary['canceladas']);

        $openShiftsCount = 0;
        if ($isPending) {
            // Cierre sintetico con el mismo criterio que usaria addCierre al cerrar:
            // metodos = lo cobrado hoy de pedidos del dia; venta/turnos de los cerrados.
            $metrics = $this->getConsolidatedMetrics([$date, $subsidiaries_id]);
            $closure = [
                'id'             => null,
                'closure_date'   => $date,
                'created_at'     => null,
                'closed_by_name' => null,
                'total'          => floatval($metrics['total_sales']),
                'total_orders'   => intval($metrics['total_orders']),
                'total_shifts'   => intval($metrics['total_shifts']),
                'total_cash'     => $liveCash,
                'total_card'     => $liveCard,
                'total_transfer' => $liveTransfer,
                'total_discount' => $this->getDiscountTotal([$date, $subsidiaries_id]),
                'status'         => 'pending'
            ];
            $openShiftsCount = count($this->listOpenShifts([$date, $subsidiaries_id]));
        }

        return [
            'status'  => 200,
            'pending' => $isPending,
            'open_shifts' => $openShiftsCount,
            'closure' => [
                'id'              => $closure['id'],
                'closure_date'    => $closure['closure_date'],
                'created_at'      => $closure['created_at'],
                'closed_by'       => $closure['closed_by_name'],
                'total_sales'     => floatval($closure['total']),
                'total_orders'    => intval($closure['total_orders']),
                'total_shifts'    => intval($closure['total_shifts']),
                'total_cash'      => floatval($closure['total_cash']),
                'total_card'      => floatval($closure['total_card']),
                'total_transfer'  => floatval($closure['total_transfer']),
                'total_discount'  => floatval($closure['total_discount']),
                'status'          => $closure['status']
            ],
            'shifts'            => $shifts,
            'subsidiary_name'   => $subsidiary_name,
            'company_name'      => $company_name,
            'counts'            => [
                'quotations' => $quotation_count,
                'pending'    => $pending_count,
                'delivered'  => $delivered_count,
                'cancelled'  => $cancelled_count
            ],
            // amount/count = pedidos creados hoy; prev_* = abonos cobrados hoy de pedidos anteriores.
            // Se usa el cobro EN VIVO ($liveCash/Card/Transfer), no el snapshot guardado en daily_closure:
            // si un pago se edita o elimina despues de cerrar el dia, el snapshot queda congelado y
            // descuadra el desglose por metodo contra los turnos (que ya se listan en vivo). En un dia
            // sin ediciones ambos coinciden, y el cierre pendiente ya calculaba asi.
            'payments'          => [
                'cash'     => ['amount' => $liveCash,     'count' => $countCash,     'prev_amount' => $prevCash,     'prev_count' => $prevCountCash],
                'card'     => ['amount' => $liveCard,     'count' => $countCard,     'prev_amount' => $prevCard,     'prev_count' => $prevCountCard],
                'transfer' => ['amount' => $liveTransfer, 'count' => $countTransfer, 'prev_amount' => $prevTransfer, 'prev_count' => $prevCountTransfer]
            ],
            'orders'            => $orders,
            'prev_payments'     => $prevPayments,
            'cross_payments'    => $crossPayments,
            'report'            => [
                'cuentas' => [
                    'total'              => $totalCuentas,
                    'cotizaciones'       => $quotation_count,
                    'pendientes'         => $pending_count,
                    'pagadas'            => $delivered_count,
                    'canceladas'         => $canceladas,
                    'con_descuento'      => intval($summary['con_descuento']),
                    'importe_descuentos' => floatval($summary['total_descuentos']),
                    'cuenta_promedio'    => floatval($summary['cuenta_promedio']),
                    'folio_inicial'      => $summary['folio_inicial'] ? formatFolioCierre($subsidiaries_id, $summary['folio_inicial']) : '-',
                    'folio_final'        => $summary['folio_final']   ? formatFolioCierre($subsidiaries_id, $summary['folio_final'])   : '-'
                ],
                'caja' => [
                    'efectivo_inicial' => $openingTotal,
                    'efectivo'         => $liveCash,
                    'tarjeta'          => $liveCard,
                    'transferencia'    => $liveTransfer,
                    'saldo_final'      => $openingTotal + $liveCash + $liveCard + $liveTransfer
                ],
                'ventas' => [
                    'subtotal'    => floatval($summary['total_ventas']),
                    'descuentos'  => floatval($summary['total_descuentos']),
                    'venta_neta'  => floatval($summary['total_ventas']) - floatval($summary['total_descuentos']),
                    // Venta bruta con el descuento ya aplicado: cuadra con el subtotal del
                    // desglose de pedidos, que tambien suma el neto (total - discount).
                    'venta_bruta' => floatval($summary['total_ventas']) - floatval($summary['total_descuentos'])
                ],
                'categorias' => $categoriesList,
                'shifts'     => $cashShifts
            ]
        ];
    }

    function showCorteCaja() {
        $date            = $_POST['date'];
        $subsidiaries_id = $this->resolveSubsidiary();

        $sub = $this->getSubsidiaryName([$subsidiaries_id]);
        $subsidiary_name = $sub ? $sub['sucursal'] : 'Sucursal';
        $company_name    = $sub ? $sub['company'] : '';

        $summary    = $this->getOrdersSummary([$date, $subsidiaries_id]);
        $payments   = $this->getPaymentBreakdown([$date, $subsidiaries_id]);
        $categories = $this->getSalesByCategory([$date, $subsidiaries_id]);
        $shifts     = $this->getCashShiftsSummary([$date, $subsidiaries_id]);

        $total_cuentas  = intval($summary['total_cuentas']);
        $canceladas     = intval($summary['canceladas']);
        $con_descuento  = intval($summary['con_descuento']);
        $total_ventas   = floatval($summary['total_ventas']);
        $cuenta_promedio = floatval($summary['cuenta_promedio']);
        $folio_inicial  = $summary['folio_inicial'];
        $folio_final    = $summary['folio_final'];
        $total_descuentos = floatval($summary['total_descuentos']);

        $efectivo      = floatval($payments['Efectivo'] ?? 0);
        $tarjeta       = floatval($payments['Tarjeta'] ?? 0);
        $transferencia = floatval($payments['Transferencia'] ?? 0);

        $opening_total = 0;
        foreach ($shifts as $shift) {
            $opening_total += floatval($shift['fondo_caja']);
        }

        $saldo_final = $opening_total + $efectivo;

        return [
            'status' => 200,
            'cuentas' => [
                'normales'        => $total_cuentas - $canceladas,
                'canceladas'      => $canceladas,
                'con_descuento'   => $con_descuento,
                'cuenta_promedio' => $cuenta_promedio,
                'folio_inicial'   => $folio_inicial,
                'folio_final'     => $folio_final,
                'total_ventas'    => $total_ventas
            ],
            'caja' => [
                'efectivo_inicial'  => $opening_total,
                'efectivo'          => $efectivo,
                'tarjeta'           => $tarjeta,
                'transferencia'     => $transferencia,
                'saldo_final'       => $saldo_final,
                'total_descuentos'  => $total_descuentos
            ],
            'forma_pago'   => $payments,
            'ventas_categoria' => $categories,
            'shifts'       => $shifts,
            'subsidiary_name' => $subsidiary_name,
            'company_name'    => $company_name,
            'date'            => $date
        ];
    }

    function lsCorteCaja() {
        $date            = $_POST['date'];
        $subsidiaries_id = $this->resolveSubsidiary();

        $orders = $this->getOrdersDetail([$date, $subsidiaries_id]);
        $__row  = [];

        foreach ($orders as $orden) {
            $isCancelled = intval($orden['status_id']) === 4;

            $__row[] = [
                'id'        => $orden['folio_cuenta'],
                'Folio'     => $orden['folio_cuenta'],
                'Fecha'     => formatSpanishDate($orden['fecha']),
                'Estado'    => statusCorte($orden['status_id']),
                'Descuento' => [
                    'html'  => evaluar($orden['descuento_importe']),
                    'class' => 'text-end'
                ],
                'Importe'   => [
                    'html'  => $isCancelled
                        ? '<span class="line-through text-red-400">' . evaluar($orden['importe']) . '</span>'
                        : evaluar($orden['importe']),
                    'class' => 'text-end'
                ],
                'Efectivo'  => [
                    'html'  => evaluar($orden['efectivo']),
                    'class' => 'text-end'
                ],
                'Tarjeta'   => [
                    'html'  => evaluar($orden['tarjeta']),
                    'class' => 'text-end'
                ],
                'Transferencia' => [
                    'html'  => evaluar($orden['transferencia']),
                    'class' => 'text-end'
                ],
                'opc' => 0
            ];
        }

        return ['row' => $__row, 'thead' => ''];
    }

    function statusCierre() {
        if ($_SESSION['ROLID'] != 1) {
            return ['status' => 403, 'message' => 'Solo administradores pueden reabrir un cierre'];
        }

        $closure_id = $_POST['closure_id'];
        $reason     = $_POST['reason'];

        if (empty($reason)) {
            return ['status' => 400, 'message' => 'Debes indicar el motivo de reapertura'];
        }

        $closure = $this->getClosureById([$closure_id]);
        if (!$closure) {
            return ['status' => 404, 'message' => 'Cierre no encontrado'];
        }

        if ($closure['status'] == 1) {
            return ['status' => 409, 'message' => 'Este cierre ya fue reabierto'];
        }

        $this->updateClosureReopen([$_SESSION['ID'], $reason, date('Y-m-d H:i:s'), $closure_id]);
        $this->updateOrdersUnlink([$closure_id]);

        return [
            'status'  => 200,
            'message' => 'Cierre reabierto correctamente'
        ];
    }

    // Recalcula el corte de un turno (cash_shift) a partir de los pagos actuales.
    // No cambia status ni fechas del turno: solo regenera cash/card/transfer,
    // total_sales, total_orders y el desglose en shift_payment. Es idempotente.
    function recalcShift() {
        if ($_SESSION['ROLID'] != 1) {
            return ['status' => 403, 'message' => 'Solo administradores pueden recalcular un corte'];
        }

        $shift_id = $_POST['shift_id'] ?? null;
        if (empty($shift_id)) {
            return ['status' => 400, 'message' => 'Falta el turno a recalcular'];
        }

        $shift = $this->getShiftById([$shift_id]);
        if (!$shift) {
            return ['status' => 404, 'message' => 'Turno no encontrado'];
        }

        $opened_at     = $shift['opened_at'];
        // Turno cerrado: recalcula sobre su ventana original. Abierto: hasta ahora.
        $end_at        = !empty($shift['closed_at']) ? $shift['closed_at'] : date('Y-m-d H:i:s');
        $subsidiary_id = $shift['subsidiary_id'];

        // Totales de venta / pedidos (mismo criterio de vinculación que el cierre).
        $orderTotals  = $this->getShiftOrderTotals([$shift_id, $opened_at, $end_at, $subsidiary_id]);
        $od           = is_array($orderTotals) && !empty($orderTotals) ? $orderTotals[0] : ['total_orders' => 0, 'total_sales' => 0];
        $total_sales  = floatval($od['total_sales']);
        $total_orders = intval($od['total_orders']);

        // Desglose por método recomputado desde los pagos actuales.
        $rows = $this->getShiftPaymentTotals([$opened_at, $end_at, $subsidiary_id]);
        $cash = 0; $card = 0; $transfer = 0;
        if (is_array($rows)) {
            foreach ($rows as $r) {
                switch (intval($r['method_pay_id'])) {
                    case 1: $cash     = floatval($r['total_paid']); break;
                    case 2: $card     = floatval($r['total_paid']); break;
                    case 3: $transfer = floatval($r['total_paid']); break;
                }
            }
        }

        // Guardar el snapshot recalculado (sin tocar status ni fechas del turno).
        $this->updateCashShiftTotals([$total_sales, $cash, $card, $transfer, $total_orders, $shift_id]);

        // Regenerar el desglose de pagos del turno (borrar + reinsertar los 3 métodos).
        $this->deleteShiftPayments([$shift_id]);
        foreach ([[1, $cash], [2, $card], [3, $transfer]] as $pm) {
            $this->insertShiftPayment([
                'values' => 'cash_shift_id, payment_method_id, amount',
                'data'   => [$shift_id, $pm[0], $pm[1]]
            ]);
        }

        $message = 'Corte del turno recalculado correctamente';
        if (!empty($shift['daily_closure_id'])) {
            $message .= '. Este turno pertenece a un cierre diario; si aplica, revisa también el cierre del día.';
        }

        return [
            'status'   => 200,
            'message'  => $message,
            'shift_id' => intval($shift_id),
            'totals'   => [
                'cash'         => $cash,
                'card'         => $card,
                'transfer'     => $transfer,
                'total_sales'  => $total_sales,
                'total_orders' => $total_orders
            ]
        ];
    }
}

// Complements
function statusCorte($statusId) {
    $statuses = [
        1 => ['bg' => 'bg-blue-100',   'text' => 'text-blue-700',   'label' => 'Cotización'],
        2 => ['bg' => 'bg-yellow-100', 'text' => 'text-yellow-700', 'label' => 'Pendiente'],
        3 => ['bg' => 'bg-green-100',  'text' => 'text-green-700',  'label' => 'Pagado'],
        4 => ['bg' => 'bg-red-100',    'text' => 'text-red-700',    'label' => 'Cancelado']
    ];

    $style = $statuses[$statusId] ?? ['bg' => 'bg-gray-100', 'text' => 'text-gray-700', 'label' => 'Desconocido'];

    return '<span class="px-2 py-1 rounded text-xs font-bold ' . $style['bg'] . ' ' . $style['text'] . '">' . $style['label'] . '</span>';
}

// Mismo formato de folio que formatSucursal() en ctrl-pedidos.php (P{numero}-{sucursal}).
function formatFolioCierre($subsidiariesId = null, $numero = null) {
    $sucursal = ($subsidiariesId === null || $subsidiariesId === '') ? 'X' : str_pad($subsidiariesId, 2, '0', STR_PAD_LEFT);
    return 'P' . $numero . '-' . $sucursal;
}

$obj = new Cierre();
$encode = $obj->{$_POST['opc']}();
echo json_encode($encode);
