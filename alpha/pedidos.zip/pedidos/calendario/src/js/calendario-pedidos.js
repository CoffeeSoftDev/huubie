let api = 'ctrl/ctrl-calendario.php';
let app;

$(function () {
    app = new App(api, 'root');
    app.init();
});

class App extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Calendario";
        this.calendar = null;
        this.subsidiaries = [];
        this.isAdmin = false;
        this._pedidosLink = '../ctrl/ctrl-pedidos.php';
        this._calendarLink = link;
    }

    async init() {
        const data = await useFetch({ url: this._link, data: { opc: 'init' } });
        this.subsidiaries = data.subsidiaries;
        this.subsidiariesCobro = data.subsidiariesCobro || [];
        this.isAdmin = data.isAdmin;
        // Supervisores (rol 6 y 7): perfil de consulta -> se les ocultan acciones de
        // operacion (Volver a Lista, Entregar, Pagar). El 7 (restringido) ademas no
        // puede aplicar descuentos.
        this.rolId = data.rolId || 0;
        this.isSupervisor = this.rolId == 6 || this.rolId == 7;
        this.canDiscount = this.rolId != 7;
        this.subsidiaryName = data.subsidiaryName || '';
        this.subsidiaryId = data.subsidiaryId || null;
        this.render();

        // Sincronizar con el navbar global (menus): cuando el admin cambia de sucursal
        // en el navbar filtra la vista y dispara 'subsidiaryChanged' SIN recargar. El
        // calendario refleja ese cambio en su propio filtro (#subsidiaryFilter) y
        // recarga. (El cajero hace switch de sesion con recarga, que ya reinicia el
        // calendario por si mismo.)
        document.addEventListener('subsidiaryChanged', (e) => {
            const id = (e.detail && e.detail.id != null) ? String(e.detail.id) : '0';
            $('#subsidiaryFilter').val(id);
            this.createCalendar();
        });
    }

    render() {
        this.layout();
        this.createCalendar();
    }

    layout() {
        this.primaryLayout({
            parent: this._div_modulo,
            id: this.PROJECT_NAME,
            class: 'd-flex lg:mx-2 lg:my-2 h-100  lg:p-2',
            card: {
                container: {
                    id: `container${this.PROJECT_NAME}`,
                    class: 'w-full h-auto my-3 rounded-lg p-3 bg-[#1F2A37]'
                }
            }
        });

        $(`#container${this.PROJECT_NAME}`).html(`
            <div class="p-2 flex flex-wrap items-center justify-between gap-3">
                ${this.isSupervisor ? '<div></div>' : `
                <button title="Regresar" type="button"
                    class="btn bg-gray-700 hover:bg-purple-950 text-white px-4 py-2 rounded w-full sm:w-auto"
                    onclick="window.location.href = '/alpha/pedidos/'">
                    <small><i class="icon-reply"></i> Volver a Lista</small>
                </button>`}

                <div class="flex flex-wrap items-center gap-3">
                    <div class="relative">
                        <button id="statusFilterBtn" type="button" 
                            class="flex items-center gap-2 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-300 text-blue-700 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                            <i class="icon-filter"></i>
                            <span>Filtrar Estados</span>
                            <span id="statusCount" class="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full">4</span>
                            <i class="icon-down-open text-xs"></i>
                        </button>
                        
                        <div id="statusDropdown" class="hidden absolute top-full left-0 mt-2 bg-[#2B3D4F] border border-gray-300 rounded-lg shadow-lg z-50 min-w-[240px]">
                            <div class="p-3 border-b border-gray-200">
                                <p class="text-xs font-semibold text-white uppercase">Seleccionar Estados</p>
                            </div>
                            <div class="p-2 space-y-1">
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="1" class="status-checkbox w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500" checked>
                                    <i class="icon-blank text-lg" style="color: #6E95C0"></i>
                                    <span class="text-sm text-white">Cotización</span>
                                </label>
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="2" class="status-checkbox w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500" checked>
                                    <i class="icon-blank text-lg" style="color: #FE6F00"></i>
                                    <span class="text-sm text-white">Pendiente</span>
                                </label>
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="3" class="status-checkbox w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500" checked>
                                    <i class="icon-blank text-lg" style="color: #0E9E6E"></i>
                                    <span class="text-sm text-white">Pagado</span>
                                </label>
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="4" class="status-checkbox w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500" checked>
                                    <i class="icon-blank text-lg" style="color: #E60001"></i>
                                    <span class="text-sm text-white">Cancelado</span>
                                </label>
                            </div>
                            <div class="p-2 border-t border-gray-200 flex gap-2">
                                <button id="selectAllBtn" class="flex-1 text-xs px-3 py-1.5 bg-green-100 hover:bg-green-200 text-green-700 rounded transition-colors">
                                    Todos
                                </button>
                                <button id="clearAllBtn" class="flex-1 text-xs px-3 py-1.5 bg-red-100 hover:bg-red-200 text-gray-700 rounded transition-colors">
                                    Ninguno
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="relative">
                        <button id="deliveryFilterBtn" type="button" 
                            class="flex items-center gap-2 bg-green-500/10 hover:bg-green-500/20 border border-green-300 text-green-700 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                            <i class="icon-truck"></i>
                            <span>Estado Entrega</span>
                            <span id="deliveryCount" class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">3</span>
                            <i class="icon-down-open text-xs"></i>
                        </button>
                        
                        <div id="deliveryDropdown" class="hidden absolute top-full left-0 mt-2 bg-[#2B3D4F] border border-gray-300 rounded-lg shadow-lg z-50 min-w-[240px]">
                            <div class="p-3 border-b border-gray-200">
                                <p class="text-xs font-semibold text-white uppercase">Estado de Entrega</p>
                            </div>
                            <div class="p-2 space-y-1">
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="1" class="delivery-checkbox w-4 h-4 text-green-600 rounded focus:ring-2 focus:ring-green-500" checked>
                                    <i class="icon-ok text-lg text-green-400"></i>
                                    <span class="text-sm text-white">Entregado</span>
                                </label>
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="2" class="delivery-checkbox w-4 h-4 text-green-600 rounded focus:ring-2 focus:ring-green-500" checked>
                                    <span class="text-lg">🎂</span>
                                    <span class="text-sm text-white">Para Producir</span>
                                </label>
                                <label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-800 rounded cursor-pointer transition-colors">
                                    <input type="checkbox" value="0" class="delivery-checkbox w-4 h-4 text-green-600 rounded focus:ring-2 focus:ring-green-500" checked>
                                    <i class="icon-cancel text-lg text-orange-400"></i>
                                    <span class="text-sm text-white">No Entregado</span>
                                </label>
                            </div>
                            <div class="p-2 border-t border-gray-200 flex gap-2">
                                <button id="selectAllDeliveryBtn" class="flex-1 text-xs px-3 py-1.5 bg-green-100 hover:bg-green-200 text-green-700 rounded transition-colors">
                                    Todos
                                </button>
                                <button id="clearAllDeliveryBtn" class="flex-1 text-xs px-3 py-1.5 bg-red-100 hover:bg-red-200 text-gray-700 rounded transition-colors">
                                    Ninguno
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex flex-col gap-1 bg-purple-500/10 px-3 py-2 rounded-md shadow-sm w-fit">
                        <label for="subsidiaryFilter" class="text-xs font-medium text-purple-700">Sucursal:</label>
                        <select id="subsidiaryFilter" class="text-xs border border-purple-300 rounded-md px-2 py-1 focus:ring-1 focus:ring-purple-400 focus:border-purple-400" style="min-width: 180px;">
                            <option value="0">Todas las sucursales</option>
                        </select>
                    </div>

                    <div class="flex flex-wrap items-center gap-2 text-xs sm:text-sm">
                        <p class="flex items-center">
                            <i class="icon-blank text-lg" style="color: #6E95C0"></i> Cotización
                        </p>
                        <p class="flex items-center">
                            <i class="icon-blank text-lg" style="color: #0E9E6E"></i> Pagado
                        </p>
                        <p class="flex items-center">
                            <i class="icon-blank text-lg" style="color: #FE6F00"></i> Pendiente
                        </p>
                        <p class="flex items-center">
                            <i class="icon-blank text-lg" style="color: #E60001"></i> Cancelado
                        </p>
                    </div>
                </div>
            </div>

            <div class="row h-full mt-4">
                <div class="bg-[#111928] rounded-lg p-4 h-100 w-full" id="calendarFull"></div>
            </div>
        `);

        this.initSubsidiaryFilter();
        this.initStatusFilter();
    }

    initSubsidiaryFilter() {
        // Selector disponible para todos: permite ver una sucursal o "Todas".
        const $select = $('#subsidiaryFilter');

        this.subsidiaries.forEach(sub => {
            $select.append(`<option value="${sub.id}">${sub.valor}</option>`);
        });

        // Arranca en la sucursal activa del usuario; puede cambiar a "Todas".
        if (this.subsidiaryId) {
            $select.val(this.subsidiaryId);
        }

        $select.on('change', () => {
            this.createCalendar();
        });
    }

    initStatusFilter() {
        const $statusBtn = $('#statusFilterBtn');
        const $statusDropdown = $('#statusDropdown');
        const $statusCheckboxes = $('.status-checkbox');
        const $statusCount = $('#statusCount');

        const $deliveryBtn = $('#deliveryFilterBtn');
        const $deliveryDropdown = $('#deliveryDropdown');
        const $deliveryCheckboxes = $('.delivery-checkbox');
        const $deliveryCount = $('#deliveryCount');

        $statusBtn.on('click', (e) => {
            e.stopPropagation();
            $statusDropdown.toggleClass('hidden');
            $deliveryDropdown.addClass('hidden');
        });

        $deliveryBtn.on('click', (e) => {
            e.stopPropagation();
            $deliveryDropdown.toggleClass('hidden');
            $statusDropdown.addClass('hidden');
        });

        $(document).on('click', (e) => {
            if (!$(e.target).closest('#statusFilterBtn, #statusDropdown, #deliveryFilterBtn, #deliveryDropdown').length) {
                $statusDropdown.addClass('hidden');
                $deliveryDropdown.addClass('hidden');
            }
        });

        const updateStatusCount = () => {
            const count = $statusCheckboxes.filter(':checked').length;
            $statusCount.text(count);
        };

        const updateDeliveryCount = () => {
            const count = $deliveryCheckboxes.filter(':checked').length;
            $deliveryCount.text(count);
        };

        $statusCheckboxes.on('change', () => {
            updateStatusCount();
            this.createCalendar();
        });

        $deliveryCheckboxes.on('change', () => {
            updateDeliveryCount();
            this.createCalendar();
        });

        $('#selectAllBtn').on('click', () => {
            $statusCheckboxes.prop('checked', true);
            updateStatusCount();
            this.createCalendar();
        });

        $('#clearAllBtn').on('click', () => {
            $statusCheckboxes.prop('checked', false);
            updateStatusCount();
            this.createCalendar();
        });

        $('#selectAllDeliveryBtn').on('click', () => {
            $deliveryCheckboxes.prop('checked', true);
            updateDeliveryCount();
            this.createCalendar();
        });

        $('#clearAllDeliveryBtn').on('click', () => {
            $deliveryCheckboxes.prop('checked', false);
            updateDeliveryCount();
            this.createCalendar();
        });
    }

    async createCalendar() {
        const selectedStatuses = $('.status-checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        const selectedDelivery = $('.delivery-checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedStatuses.length === 0 || selectedDelivery.length === 0) {
            if (this.calendar) {
                this.calendar.destroy();
            }
            $('#calendarFull').html('<div class="flex items-center justify-center h-full text-gray-400"><p>Selecciona al menos un estado y un tipo de entrega para ver los pedidos</p></div>');
            return;
        }

        // Cualquier usuario filtra por la sucursal elegida en el selector
        // ("0" = todas las sucursales).
        const subsidiaryId = $('#subsidiaryFilter').val() || 0;

        let data = await useFetch({
            url: this._calendarLink,
            data: {
                opc: 'getCalendar',
                statuses: selectedStatuses.join(','),
                delivery: selectedDelivery.join(','),
                subsidiaries_id: subsidiaryId
            }
        });

        const calendarEl = document.getElementById('calendarFull');

        if (!calendarEl) {
            console.error('Elemento del calendario no encontrado');
            return;
        }

        if (this.calendar) {
            this.calendar.destroy();
        }

        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'es',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            height: 'auto',
            contentHeight: 'auto',
            dayMaxEvents: 3,
            moreLinkClick: 'popover',
            eventMaxStack: 3,
            events: data,
            eventContent: (arg) => this.renderEventContent(arg),
            eventClick: (info) => this.showOrder(info.event.id),
            datesSet: () => this.customizeCalendarAppearance()
        });

        this.calendar.render();
        this.applyCalendarStyles();
    }

    renderEventContent(arg) {
        let envio_domicilio = arg.event.extendedProps.type == 'Envío a Domicilio' ? true : false;
        let entregado = arg.event.extendedProps.delivery == 'Entregado' ? true : false;
        let paraProducir = arg.event.extendedProps.delivery == 'Para Producir' ? true : false;

        // Si es para producir, usar emoji de pastel, sino usar el emoji según tipo de entrega
        let emoji = paraProducir ? "🎂" : (envio_domicilio ? "🚚" : "🏠");

        // Contenedor principal
        let containerEl = document.createElement("div");
        containerEl.classList.add("p-2", "w-full");

        // Nombre del cliente
        let titleEl = document.createElement("div");
        titleEl.classList.add("font-semibold", "text-sm", "mb-1", "truncate");
        titleEl.innerHTML = arg.event.title;

        // Tipo de entrega
        let deliveryEl = document.createElement("div");
        deliveryEl.classList.add("flex", "items-center", "gap-1", "text-xs", "mb-1", "opacity-80");
        deliveryEl.innerHTML = `
        <span>${emoji}</span>
        <span>${arg.event.extendedProps.type}</span>
    `;

        // Hora
        let timeEl = document.createElement("div");
        timeEl.classList.add("flex", "items-center", "gap-1", "text-xs", "opacity-80");
        timeEl.innerHTML = `
        <i class='icon-clock'></i>
        <span>${arg.event.extendedProps.hour}</span>
    `;

        // Badge de estado
        let badgeEl = document.createElement("div");
        badgeEl.classList.add("mt-1.5");

        let badgeClass = "bg-orange-100 text-orange-700 border-1 border-orange-300";

        if (entregado) {
            badgeClass = "bg-green-100 text-green-700 border-1 border-green-300";
        } else if (paraProducir) {
            badgeClass = "bg-purple-100 text-purple-700 border-1 border-purple-300";
        }

        badgeEl.innerHTML = `
        <span class="${badgeClass} px-2 py-0.5 rounded-full text-xs font-medium inline-block">
            ${arg.event.extendedProps.delivery}
        </span>
    `;

        // Ensamblar elementos
        containerEl.appendChild(titleEl);
        containerEl.appendChild(deliveryEl);
        containerEl.appendChild(timeEl);
        containerEl.appendChild(badgeEl);

        return { domNodes: [containerEl] };
    }

    customizeCalendarAppearance() {
        document.querySelectorAll('.fc-day-today').forEach(el => {
            el.style.backgroundColor = '#2C3E50';
        });

        document.querySelectorAll('.fc-daygrid-day, .fc-scrollgrid, .fc-theme-standard td, .fc-theme-standard th').forEach(el => {
            el.style.border = '1px solid #1F2A37';
        });
    }

    applyCalendarStyles() {
        const styleId = 'calendar-custom-styles';
        if ($('#' + styleId).length === 0) {
            $('<style>', {
                id: styleId,
                text: `
                    thead {
                        background: #2B3D4F;
                    }

                    .fc-daygrid-day-frame {
                        min-height: 120px !important;
                        max-height: 600px !important;
                    }
                    
                    .fc-daygrid-day-events {
                        max-height: 600px !important;
                        overflow-y: auto !important;
                        margin-bottom: 2px !important;
                    }
                    
                    .fc-daygrid-day-events::-webkit-scrollbar {
                        width: 4px;
                    }
                    
                    .fc-daygrid-day-events::-webkit-scrollbar-track {
                        background: #1F2A37;
                        border-radius: 2px;
                    }
                    
                    .fc-daygrid-day-events::-webkit-scrollbar-thumb {
                        background: #4B5563;
                        border-radius: 2px;
                    }
                    
                    .fc-daygrid-day-events::-webkit-scrollbar-thumb:hover {
                        background: #6B7280;
                    }
                    
                    .fc-daygrid-event {
                        margin-bottom: 2px !important;
                        font-size: 0.75rem !important;
                    }
                    
                    .fc-daygrid-event-harness {
                        margin-bottom: 2px !important;
                    }
                    
                    .fc-more-link {
                        font-size: 0.7rem !important;
                        padding: 2px 4px !important;
                        background: #374151 !important;
                        color: #9CA3AF !important;
                        border-radius: 4px !important;
                        margin-top: 2px !important;
                    }
                    
                    .fc-more-link:hover {
                        background: #4B5563 !important;
                        color: #D1D5DB !important;
                    }
                    
                    .fc-popover {
                        background: #1F2A37 !important;
                        border: 1px solid #374151 !important;
                        max-height: 600px !important;
                        overflow-y: auto !important;         
                    }
                    
                    .fc-popover-header {
                        background: #111928 !important;
                        color: #fff !important;
                        padding: 8px 12px !important;
                    }
                    
                    .fc-popover-body {
                        padding: 8px !important;
                    }
                `
            }).appendTo('head');
        }
    }



    // Show Order.

    async showOrder(orderId) {
        const response = await useFetch({
            url: this._pedidosLink,
            data: { opc: 'getOrderDetails', id: orderId }
        });



        const tipo = response.data.order.delivery_type;
        const badgeTipo = this.getBadgeDeliveryType(tipo);
        const subsidiarieName = response.data.order.subsidiarie_name || '';

        const modal = bootbox.dialog({
            title: `
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                        ${lucideIcon('cake', 'w-4 h-4 text-white')}
                    </div>
                    <div>
                        <h2 class="text-lg font-semibold text-white">Detalles del Pedido</h2>
                        <div class="flex items-center gap-2 mt-1">
                            <span id="orderDeliveryBadge">${badgeTipo}</span>
                            <span class="px-2 py-0.5 text-xs font-medium rounded bg-gray-600 text-gray-200 inline-flex items-center gap-1">
                                ${lucideIcon('house', 'w-3.5 h-3.5')}${subsidiarieName}
                            </span>
                        </div>
                    </div>
                </div>
            `,
            message: '<div id="orderDetailsContainer" class="max-h-[70vh] overflow-y-auto"></div>',
            size: 'lg',
            closeButton: true,
            className: 'order-details-enhanced-modal'
        });

        this.layoutManager = {
            isMobile: () => window.innerWidth < 768,
            isTablet: () => window.innerWidth >= 768 && window.innerWidth < 1024,
            isDesktop: () => window.innerWidth >= 1024,

            applyLayout: function () {
                const container = $('#orderDetailsContainer');
                container.removeClass('flex flex-col flex-row space-y-4   p-3');

                if (this.isMobile()) {
                    container.addClass('flex flex-col space-y-4 p-3');
                } else if (this.isTablet()) {
                    container.addClass('flex flex-col lg:flex-row p-3');
                } else {
                    container.addClass('flex flex-row  p-3');
                }
            }
        };

        setTimeout(() => {
            this.layoutManager.applyLayout();
            const orderData = response.data.order || {};
            const products = response.data.products || [];
            const paymentMethods = response.data.paymentMethods || [];
            const payments = response.data.payments || [];

            const container = $('#orderDetailsContainer');
            container.html(`
                <div id="orderInfoPanel" class="w-full lg:w-1/3 mb-6 lg:mb-0 lg:pr-3">
                    <div class="lg:sticky lg:top-4">
                        ${this.orderActions(orderData, orderId)}
                        ${this.detailsCard(orderData, paymentMethods, payments)}
                    </div>
                </div>

                <div id="productDisplayArea" class="w-full lg:w-2/3 lg:pl-3">
                    ${this.listProducts(products)}
                </div>
            `);

            $(window).on('resize.orderDetails', () => {
                // this.layoutManager.applyLayout();
            });
        }, 100);

        modal.on('hidden.bs.modal', () => {
            $(window).off('resize.orderDetails');
        });

        $("<style>").text(`
            .order-details-enhanced-modal .modal-dialog {
                max-width: 900px !important;
                width: 85vw !important;
            }
            .order-details-enhanced-modal .modal-body {
                padding: 0 !important;
                max-height: 70vh !important;
                overflow-y: auto !important;
            }
            .order-details-enhanced-modal .modal-content {
                max-height: 85vh !important;
            }

            @media (max-width: 768px) {
                .order-details-enhanced-modal .modal-dialog {
                    width: 95vw !important;
                    margin: 10px auto !important;
                }
                .order-details-enhanced-modal .modal-body {
                    max-height: 65vh !important;
                }
            }

            @media (max-width: 480px) {
                .order-details-enhanced-modal .modal-dialog {
                    width: 98vw !important;
                    margin: 5px auto !important;
                }
                .order-details-enhanced-modal .modal-body {
                    max-height: 60vh !important;
                }
            }
        `).appendTo("head");

        return modal;
    }

    getBadgeDeliveryType(tipo) {
        if (tipo == 0 || tipo === '0') {
            return `<span class="px-3 py-1 rounded text-xs font-semibold bg-blue-100 text-blue-700 inline-flex items-center gap-1 w-24 justify-center">${lucideIcon('house', 'w-3.5 h-3.5')} Local</span>`;
        } else if (tipo == 1 || tipo === '1') {
            return `<span class="px-3 py-1 rounded text-xs font-semibold bg-amber-100 text-amber-700 inline-flex items-center gap-1 w-28 justify-center">${lucideIcon('truck', 'w-3.5 h-3.5')} Domicilio</span>`;
        }
        return '<span class="px-3 py-1 rounded text-xs font-semibold bg-gray-100 text-gray-700 inline-block w-24 text-center">Sin especificar</span>';
    }

    detailsCard(orderData, paymentMethods = [], payments = []) {
        return `
            <div class="space-y-3">
                ${this.infoOrder(orderData)}
                ${this.infoSales(orderData, paymentMethods, payments)}
            </div>
        `;
    }

    // Acciones del pedido en el panel de detalles. Se pintan igual al abrir el modal y
    // al refrescarlo despues de un cambio, por eso viven en un solo lugar. Editar los
    // datos de entrega no esta aqui: es el icono del titulo de la tarjeta que los
    // muestra (editDeliveryIcon).
    orderActions(orderData, orderId) {
        const cerrado    = orderData.status == '3' || orderData.status == '4';
        const operable   = !cerrado && orderData.is_delivered != '2';
        const entregable = !this.isSupervisor && (orderData.is_delivered == '0' || orderData.is_delivered == null) && (orderData.status != '4');

        const botones = [];

        if (operable && !this.isSupervisor) botones.push(`
            <button onclick="app.historyPay(${orderId})"
                class="flex items-center justify-center gap-1.5 bg-green-600 hover:bg-green-700 text-white text-[11px] font-medium px-2 py-2 rounded-md transition-colors">
                ${lucideIcon('dollar-sign', 'w-3.5 h-3.5')} Pagar
            </button>`);

        if (operable) botones.push(`
            <button onclick="app.printOrder(${orderId})"
                class="flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-medium px-2 py-2 rounded-md transition-colors">
                ${lucideIcon('printer', 'w-3.5 h-3.5')} Imprimir
            </button>`);

        if (operable && this.canDiscount) botones.push(`
            <button onclick="app.addDiscount(${orderId})"
                class="flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-medium px-2 py-2 rounded-md transition-colors">
                ${lucideIcon('percent', 'w-3.5 h-3.5')} Descuento
            </button>`);

        return `
            ${botones.length ? `
                <div class="grid ${this.actionGridCols(botones.length)} gap-2 mb-3">
                    ${botones.join('')}
                </div>
            ` : ''}
            ${entregable ? `
                <button onclick="app.handleDeliveryClick(${orderId}, ${orderData.is_delivered || 0}, '${orderData.folio || ''}')"
                        class="w-full mb-3 flex items-center justify-center gap-1.5
                            text-white text-[11px] font-medium px-2 py-2 rounded-md
                            glass-purple-btn">
                    Entregar productos
                </button>
            ` : ''}
        `;
    }

    // Columnas del grid de acciones segun cuantos botones quedaron visibles por rol y
    // estado del pedido: una columna por boton, de modo que todos comparten fila.
    actionGridCols(visibles) {
        return ['grid-cols-1', 'grid-cols-2', 'grid-cols-3'][visibles - 1] || 'grid-cols-3';
    }

    handleDeliveryClick(orderId, currentStatus, folio) {
        Swal.fire({
            title: '📦 Actualizar estado de entrega',
            html: `<p class="mb-3">Selecciona el estado del pedido <strong>${folio}</strong></p>`,
            icon: 'question',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: '✓ Entregado',
            denyButtonText: '🎂 Para producir',
            cancelButtonText: '✗ No entregado',
            confirmButtonColor: '#10b981',
            denyButtonColor: '#db2777',
            cancelButtonColor: '#ef4444',
            reverseButtons: false,
            customClass: {
                popup: 'bg-[#1F2A37] text-white rounded-lg shadow-lg px-2',
                title: 'text-2xl font-semibold',
                content: 'text-gray-300',
                confirmButton: 'bg-[#10b981] hover:bg-[#0E9E6E] text-white py-2 px-4 rounded',
                denyButton: 'bg-[#db2777] hover:bg-[#be185d] text-white py-2 px-4 rounded',
                cancelButton: 'bg-[#ef4444] hover:bg-[#dc2626] text-white py-2 px-4 rounded',
            }
        }).then(async (result) => {
            let newStatus = null;

            if (result.isConfirmed) {
                newStatus = 1; // Entregado
            } else if (result.isDenied) {
                newStatus = 2; // Para producir
            } else if (result.dismiss === Swal.DismissReason.cancel) {
                newStatus = 0; // No entregado
            }

            if (newStatus !== null) {
                const response = await useFetch({
                    url: this._link,
                    data: {
                        opc: 'updateDeliveryStatus',
                        id: orderId,
                        is_delivered: newStatus
                    }
                });

                if (response.status == 200) {
                    // Cierra el modal de detalles del pedido
                    $('.order-details-enhanced-modal').modal('hide');
                     alert({
                        icon: 'success',
                        title: 'Estado actualizado',
                        text: response.message,
                        timer: 2000,
                        showConfirmButton: false
                    });
                    // Recarga el calendario para reflejar el cambio
                    this.createCalendar();
                   
                } else {
                    alert({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                        btn1: true,
                        btn1Text: 'Ok'
                    });
                }
            }
        });
    }

    // Editar los datos de entrega vive junto al titulo de la tarjeta que los muestra,
    // no en la barra de acciones. Un pedido liquidado (3) lo corrigen admin y
    // supervisores, y ahi la edicion pide contraseña; el resto de los pedidos, cualquiera
    // que opere el calendario. El cancelado (4) no se edita.
    editDeliveryIcon(orderData) {
        const liquidado  = orderData.status == '3';
        const autorizado = this.isAdmin || this.isSupervisor;
        const editable   = orderData.status != '4' && (!liquidado || autorizado);

        if (!editable) return '';

        return `
            <button onclick="app.editOrderDelivery(${orderData.id})"
                title="${liquidado ? 'Editar datos de entrega (requiere contraseña)' : 'Editar datos de entrega'}"
                class="ml-auto flex items-center justify-center w-7 h-7 rounded-md text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
                ${lucideIcon('pencil', 'w-4 h-4')}
            </button>`;
    }

    infoOrder(orderData) {
        return `
            <div class="bg-[#2C3E50] rounded-lg p-3">
                <h3 class="text-white font-semibold text-base mb-2 flex items-center">
                    ${lucideIcon('info', 'w-4 h-4 text-blue-400 mr-2')}
                    Información del Pedido
                    ${this.editDeliveryIcon(orderData)}
                </h3>

                <div class="space-y-1.5">
                    <div class="flex items-center gap-2">
                        ${lucideIcon('file-text', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Folio:</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${orderData.folio || 'N/A'}</span>
                    </div>

                    <div class="flex items-center gap-2">
                        ${lucideIcon('user', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Cliente:</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${orderData.name || 'N/A'}</span>
                    </div>

                    <div class="flex items-center gap-2">
                        ${lucideIcon('history', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Creado:</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${this.formatDateTime(orderData.date_creation) || 'N/A'}</span>
                    </div>

                    <div class="flex items-center gap-2">
                        ${lucideIcon('calendar', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Fecha de entrega:</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${orderData.formatted_date_order || orderData.date_order || 'N/A'}</span>
                    </div>

                    <div class="flex items-center gap-2">
                        ${lucideIcon('clock', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Hora:</span>
                        <span class="text-white font-semibold text-sm ml-auto text-right">${orderData.time_order || 'N/A'}</span>
                    </div>
                    <div class="flex items-center gap-2">
                        ${lucideIcon('truck', 'w-4 h-4 text-gray-400 shrink-0')}
                        <span class="text-gray-400 text-xs">Estado de entrega:</span>
                        <span class="ml-auto">${this.statusDelivery(orderData.is_delivered)}</span>
                    </div>

                </div>
            </div>
        `;
    }

    // border-1 no existe en Tailwind (la utilidad es `border`), por eso las etiquetas
    // quedaban sin contorno. El ancho va como border-[1px] y no como `border` porque
    // bootstrap.min.css se carga despues y su .border lleva !important, con lo que el
    // contorno salia gris en lugar del color del estado. Las clases se guardan enteras
    // y no armadas por concatenacion, que Tailwind no detecta.
    statusDelivery(is_delivered) {
        const estados = {
            '1': { tono: 'bg-green-500/10 border-green-500/50 text-green-300',   icono: 'circle-check', texto: 'Entregado' },
            '2': { tono: 'bg-purple-500/10 border-purple-500/50 text-purple-300', icono: 'cake',         texto: 'Para Producir' }
        };

        const estado = estados[is_delivered]
            || { tono: 'bg-red-500/10 border-red-500/50 text-red-300', icono: 'circle-x', texto: 'No entregado' };

        return `<span class="px-2 py-0.5 text-[10px] font-semibold rounded-full border-[1px] ${estado.tono} inline-flex items-center gap-1 whitespace-nowrap leading-none">
                    ${lucideIcon(estado.icono, 'w-3 h-3')} ${estado.texto}
                </span>`;
    }

    formatDateTime(dateStr) {
        if (!dateStr) return '';
        const d = new Date(String(dateStr).replace(' ', 'T'));
        if (isNaN(d.getTime())) return dateStr;
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yyyy = d.getFullYear();
        const hh = String(d.getHours()).padStart(2, '0');
        const mi = String(d.getMinutes()).padStart(2, '0');
        return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
    }

    paymentMethodStyle(method) {
        const m = String(method || '').toLowerCase();
        if (m.includes('efect')) return { icon: 'banknote', bg: 'bg-green-500/15', text: 'text-green-400', dot: 'bg-green-400' };
        if (m.includes('tarj') || m.includes('tdc') || m.includes('tarjeta')) return { icon: 'credit-card', bg: 'bg-blue-500/15', text: 'text-blue-400', dot: 'bg-blue-400' };
        if (m.includes('transf')) return { icon: 'arrow-right-left', bg: 'bg-purple-500/15', text: 'text-purple-400', dot: 'bg-purple-400' };
        return { icon: 'wallet', bg: 'bg-gray-500/15', text: 'text-gray-300', dot: 'bg-gray-400' };
    }

    infoSales(orderData, paymentMethods = [], payments = []) {
        const totalPay = parseFloat(orderData.total_pay || 0);
        const discount = parseFloat(orderData.discount || 0);
        const totalPaid = parseFloat(orderData.total_paid || 0);
        const balance = parseFloat(orderData.balance || 0);
        const infoDiscount = orderData.info_discount || '';

        // Historial detallado: cada abono con su fecha y metodo, sin agrupar.
        // Si no llega el historial, se cae al resumen agrupado por metodo.
        const methodsHtml = (Array.isArray(payments) && payments.length > 0) ? `
                    <div class="space-y-1">
                        <span class="text-gray-400 text-xs font-semibold uppercase tracking-wide flex items-center gap-1.5 mb-1">
                            ${lucideIcon('history', 'w-3.5 h-3.5 text-gray-400')}
                            Abonos (${payments.length})
                        </span>
                        <div>
                            ${payments.map((p, idx) => {
                                const st = this.paymentMethodStyle(p.method_pay);
                                const isLast = idx === payments.length - 1;
                                return `
                            <div class="flex gap-2.5">
                                <div class="flex flex-col items-center w-3 shrink-0">
                                    <span class="w-3 h-3 mt-1 rounded-full ${st.bg} border-2 border-[#2C3E50] flex items-center justify-center shrink-0">
                                        <span class="w-1.5 h-1.5 rounded-full ${st.dot}"></span>
                                    </span>
                                    ${!isLast ? `<span class="w-px grow bg-gray-600/70 my-1"></span>` : ''}
                                </div>
                                <div class="flex-1 flex items-center justify-between gap-2 ${!isLast ? 'pb-3' : ''}">
                                    <div class="flex flex-col min-w-0">
                                        <span class="text-white text-xs font-medium flex items-center gap-1.5">
                                            ${lucideIcon(st.icon, 'w-3.5 h-3.5 ' + st.text)}
                                            ${p.method_pay || 'Sin método'}
                                        </span>
                                        <span class="text-gray-500 text-[11px]">${this.formatDateTime(p.date_pay)}</span>
                                    </div>
                                    <span class="text-green-400 font-bold text-sm whitespace-nowrap">$${parseFloat(p.pay || 0).toFixed(2)}</span>
                                </div>
                            </div>
                            `;
                            }).join('')}
                        </div>
                    </div>
        ` : (Array.isArray(paymentMethods) && paymentMethods.length > 0) ? `
                    <div class="pl-2 space-y-1 border-l-2 border-gray-600">
                        ${paymentMethods.map(m => `
                        <div class="flex items-center justify-between">
                            <span class="text-gray-500 text-xs flex items-center gap-1.5">
                                ${lucideIcon('credit-card', 'w-3.5 h-3.5')}
                                ${m.method_pay || 'Sin método'}:
                            </span>
                            <span class="text-gray-300 text-xs">$${parseFloat(m.pay || 0).toFixed(2)}</span>
                        </div>
                        `).join('')}
                    </div>
        ` : '';

        const discountHtml = discount > 0 ? `
                    <div class="flex items-center justify-between">
                        <span class="text-gray-400 text-sm">Descuento:</span>
                        <span class="text-yellow-400 font-bold text-sm">-$${discount.toFixed(2)}</span>
                    </div>
                    ${infoDiscount ? `
                    <div class="flex items-center justify-start">
                        <span class="text-gray-500 text-xs italic">${infoDiscount}</span>
                    </div>
                    ` : ''}
        ` : '';

        return `
            <div class="bg-[#2C3E50] rounded-lg p-3">
                <h3 class="text-white font-semibold text-base mb-2 flex items-center">
                    ${lucideIcon('dollar-sign', 'w-4 h-4 text-green-400 mr-2')}
                    Resumen de pago
                </h3>

                <div class="space-y-2">
                    <div class="flex items-center justify-between">
                        <span class="text-gray-400 text-sm">Subtotal:</span>
                        <span class="text-white font-bold text-sm">$${totalPay.toFixed(2)}</span>
                    </div>

                    ${discountHtml}

                    <div class="flex items-center justify-between">
                        <span class="text-gray-400 text-sm">Pagado:</span>
                        <span class="text-green-400 font-bold text-sm">$${totalPaid.toFixed(2)}</span>
                    </div>

                    ${methodsHtml}

                    <div class="border-t border-gray-600 my-1.5"></div>

                    <div class="flex items-center justify-between">
                        <span class="text-gray-400 text-sm">Saldo:</span>
                        <span class="text-red-400 font-bold text-sm">$${balance.toFixed(2)}</span>
                    </div>
                </div>
            </div>
        `;
    }

    listProducts(products) {



        if (!products || products.length === 0) {
            return `
                <div class="bg-[#283341] rounded-lg p-2 text-center h-full flex flex-col items-center justify-center">
                    ${lucideIcon('shopping-basket', 'w-12 h-12 text-gray-500 mb-4')}
                    <h3 class="text-white text-lg font-semibold mb-2">No hay productos</h3>
                    <p class="text-gray-400">Este pedido no contiene productos.</p>
                </div>
            `;
        }

        const totalItems = products.reduce((acc, item) => acc + parseInt(item.quantity || 1), 0);

        return `
            <div class="flex flex-col h-full">
                <div class="bg-[#283341] rounded-lg p-3 mb-3">
                    <div class="flex items-center justify-between">
                        <h3 class="text-white font-semibold text-lg flex items-center">
                            ${lucideIcon('shopping-basket', 'w-5 h-5 mr-2 text-blue-400')}
                            Productos del Pedido
                        </h3>
                        <span class="text-gray-300 font-medium"> ${totalItems} productos</span>
                    </div>
                </div>
                <div id="productsContainer" class="space-y-4 overflow-y-auto flex-1">
            ${products.map(product => {

            console.log('recorrido de product: ', product);


            if (product.is_custom || (product.customer_products && product.customer_products.length > 0)) {

                return this.cardCustom(product);

            } else {
                return this.cardNormal(product);
            }
        }).join('')}
                </div>
            </div>
        `;
    }

    cardNormal(product) {
        const total = parseFloat(product.price || 0) * parseInt(product.quantity || 1);
        const hasDedication = product.dedication && product.dedication.trim() !== '';
        const hasDetails = product.order_details && product.order_details.trim() !== '';

        return `
            <div class="bg-[#2C3E50] rounded-lg p-3 relative">
                <div class="absolute top-5 right-6 text-right">
                    <span class="text-gray-400 text-sm">Cantidad: <span class="text-white font-bold text-sm">${product.quantity || 1}</span></span>
                </div>

                <div class="flex items-start gap-6 pr-32">
                    <div class="w-28 h-28 rounded-lg overflow-hidden bg-[#D8B4E2] flex-shrink-0">
                        ${this.renderProductImage(product)}
                    </div>

                    <div class="flex-1">
                        <h4 class="text-white font-bold text-lg mb-2 uppercase">${product.name || 'Producto sin nombre'}</h4>
                        <p class="text-blue-400 font-semibold text-xs mb-4">$${parseFloat(product.price || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} c/u</p>

                        ${(hasDedication || hasDetails) ? `
                        <div class="flex gap-12">
                            ${hasDedication ? `
                            <div class="flex-1">
                                <span class="text-gray-400 text-sm font-medium">Dedicatoria:</span>
                                <p class="text-white text-xs">${product.dedication}</p>
                            </div>
                            ` : ''}
                            ${hasDetails ? `
                            <div class="flex-1">
                                <span class="text-gray-400 text-sm font-medium">Observaciones:</span>
                                <p class="text-white text-xs">${product.order_details}</p>
                            </div>
                            ` : ''}
                        </div>
                        ` : ''}
                    </div>
                </div>

                <div class="absolute bottom-5 right-6 text-right">
                    <span class="text-gray-400 text-sm block mb-1">Total:</span>
                    <p class="text-white font-bold text-lg">$${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                </div>
            </div>
        `;
    }

    cardCustom(product) {

        console.log('🧩 cardCustom: ', product);

        const hasDedication = product.dedication && product.dedication.trim() !== '';
        const hasDetails = product.order_details && product.order_details.trim() !== '';
        const hasImages = product.images && Array.isArray(product.images) && product.images.length > 0;
        const hasCustomization = product.customer_products && product.customer_products.length > 0;

        const customizationTotal = product.customer_products ?
            product.customer_products.reduce((sum, item) => sum + parseFloat(item.custom_price || 0), 0) : 0;

        const finalTotal = (parseFloat(product.price || 0) + customizationTotal) * parseInt(product.quantity || 1);


        return `
        <div class="bg-[#2C3E50] rounded-lg p-3 relative">
            <div class=" mb-6">
                <h4 class="text-white font-bold text-sm uppercase">${product.name || 'Pastel Personalizado'}</h4>
                <span class="inline-flex items-center px-3 py-2 mt-2 rounded-2xl text-[10px] font-bold bg-purple-200 text-purple-500 lowercase">
                    Personalizado
                </span>
            </div>

            <div class="absolute top-5 right-6">
                <span class="text-gray-400 text-sm">Cantidad: <span class="text-white font-bold">${product.quantity || 1}</span></span>
            </div>

            ${hasImages ? `
            <div class="flex gap-3 pb-4 border-b border-gray-700">
                ${product.images.slice(0, 3).map(img => {
            const thumbUrl = img.path.startsWith('http') ? img.path : `${img.path}`;
            const fullUrl = `https://huubie.com.mx/${thumbUrl}`;
            return `
                        <div class="w-28 h-28 rounded-lg overflow-hidden bg-gray-700 cursor-pointer hover:opacity-80 transition-opacity"
                             onclick="app.previewImage('${fullUrl}', '${(img.original_name || 'Imagen').replace(/'/g, "\\'")}')">
                            <img src="${fullUrl}"
                                 alt="${img.original_name || 'Imagen'}"
                                 class="object-cover w-full h-full pointer-events-none">
                        </div>
                    `;
        }).join('')}
            </div>
            ` : ''}

            <div class="mb-3">
                <span class="text-gray-400 text-sm">Porción: <span class="text-white font-bold text-sm">${product.portion_qty || 1}</span></span>
            </div>

            ${(hasDedication || hasDetails) ? `
            <div class="flex gap-12 mb-6 ">
                ${hasDedication ? `
                <div class="flex-1">
                    <span class="text-gray-400 text-sm font-medium">Dedicatoria:</span>
                    <p class="text-white text-base text-justify">${product.dedication}</p>
                </div>
                ` : ''}
                ${hasDetails ? `
                <div class="flex-1">
                    <span class="text-gray-400 text-sm font-medium">Observaciones:</span>
                    <p class="text-white text-base text-justify">${product.order_details}</p>
                </div>
                ` : ''}
            </div>
            ` : ''}

            ${hasCustomization ? `
            <div class="border-t border-gray-600 pt-4 mb-6 pr-32">
                <h5 class="text-purple-300 font-bold text-sm mb-2 uppercase">Personalización:</h5>
                ${this.renderPersonalizationGrid(product.customer_products)}
            </div>
            ` : ''}

            <div class="absolute bottom-5 right-6 text-right">
                <span class="text-gray-400 text-sm block mb-1 ">Total:</span>
                <p class="text-green-300 font-bold text-lg ">${formatPrice(product.price)}</p>
            </div>
        </div>
    `;
    }

    renderProductImage(product) {
        const hasImage = product.image && product.image.trim() !== '';

        if (hasImage) {
            const imageUrl = product.image.startsWith('http') ?
                product.image : `https://huubie.com.mx/${product.image}`;
            return `
                <img src="${imageUrl}" alt="${product.name}"
                     class="object-cover w-full h-full"
                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="w-full h-full items-center justify-center hidden">
                    <i class="icon-birthday text-white text-4xl"></i>
                </div>
            `;
        } else {
            return `
                <div class="w-full h-full flex items-center justify-center">
                    <i class="icon-birthday text-white text-4xl"></i>
                </div>
            `;
        }
    }

    renderPersonalizationGrid(customizations) {

        const grouped = {};
        customizations.forEach(item => {
            const category = `${item.modifier_name || ''}:` || '';
            if (!grouped[category]) {
                grouped[category] = [];
            }
            grouped[category].push(item);
        });

        const entries = Object.entries(grouped);
        const half = Math.ceil(entries.length / 2);
        const leftColumn = entries.slice(0, half);
        const rightColumn = entries.slice(half);
        // <span class="text-white text-sm">$${parseFloat(item.custom_price || 0).toFixed(2)}</span>

        //  ${
        //     item.custom_price && parseFloat(item.custom_price) > 0 ?
        //     `<span class="text-white text-sm">$${parseFloat(item.custom_price).toFixed(2)}</span>` :
        //     ''
        // }
        return `
            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-4">
                    ${leftColumn.map(([category, items]) => `
                        <div class="flex flex-col">
                            <span class="text-purple-300 font-bold text-sm tracking-wide uppercase">${category}</span>
                            ${items.map(item => `
                                <span class="text-white font-medium text-sm">${item.name || 'N/A'}</span>
                            `).join('')}
                        </div>
                    `).join('')}
                </div>

                <div class="space-y-4">
                    ${rightColumn.map(([category, items]) => `
                        <div class="flex flex-col">
                            <span class="text-purple-300 font-bold text-sm tracking-wide uppercase">${category}</span>
                            ${items.map(item => `
                                <span class="text-white font-medium text-sm">${item.name || 'N/A'}</span>
                            `).join('')}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // =============================================
    // Migrado desde app.js - Descuentos
    // =============================================

    // El guardado de los modales (createModalForm) sale por this._link, asi que se
    // apunta al ctrl de pedidos y se restaura al cerrar. Solo se recuerda el link del
    // calendario si no estaba ya cambiado: dos modales seguidos (pagar y luego editar)
    // lo perderian y el calendario dejaria de recargar.
    _switchToPedidos() {
        if (this._link !== this._pedidosLink) this._calendarLink = this._link;
        this._link = this._pedidosLink;
    }

    _restoreLink() {
        this._link = this._calendarLink;
    }

    async refreshOrderDetails(orderId) {
        const response = await useFetch({
            url: this._pedidosLink,
            data: { opc: 'getOrderDetails', id: orderId }
        });
        const orderData = response.data.order || {};
        const paymentMethods = response.data.paymentMethods || [];
        const payments = response.data.payments || [];
        $('#orderInfoPanel .lg\\:sticky').html(`
            ${this.orderActions(orderData, orderId)}
            ${this.detailsCard(orderData, paymentMethods, payments)}
        `);
        // El tipo de entrega se muestra en el encabezado del modal, fuera del panel.
        $('#orderDeliveryBadge').html(this.getBadgeDeliveryType(orderData.delivery_type));
    }

    // Edicion acotada desde el calendario: solo los datos de entrega (fecha, hora,
    // tipo y descripcion). Cliente, productos y cobros se siguen editando desde el
    // listado de pedidos, que tiene el flujo completo y sus autorizaciones.
    async editOrderDelivery(id, password = null) {
        const response = await useFetch({
            url: this._pedidosLink,
            data: { opc: 'getOrderDelivery', id: id }
        });

        if (response.status != 200) {
            alert({
                icon: 'error',
                title: 'Error',
                text: response.message,
                btn1: true,
                btn1Text: 'Ok'
            });
            return;
        }

        // El tipo de entrega queda fuera del autofill: sus dos radios comparten name y
        // el autofill hace .val() sobre TODOS los inputs que lo comparten, con lo que
        // los dos acabarian con el mismo value. Se marca a mano al final.
        const order = response.data;
        const { delivery_type, ...autofill } = order;

        // Pedido liquidado: la contraseña se pide antes de abrir el formulario y se
        // reenvia en data para que editOrderDelivery (ctrl) la revalide al guardar.
        const liquidado = order.status == 3;

        if (liquidado && !password) {
            this.editOrderDeliveryPaid(id);
            return;
        }

        this._switchToPedidos();

        this.createModalForm({
            id: 'formEditDelivery',
            data: password
                ? { opc: 'editOrderDelivery', id: id, password: password }
                : { opc: 'editOrderDelivery', id: id },
            autofill: autofill,
            bootbox: {
                title: `<div class="flex items-center gap-2 text-white text-lg font-semibold">
                            ${lucideIcon('calendar', 'w-5 h-5 text-blue-400')}
                            Editar datos de entrega
                        </div>`,
                size: 'medium'
            },
            json: [
                ...(liquidado ? [{
                    opc: "div",
                    id: "paidOrderNotice",
                    class: "col-12 mb-3",
                    html: `
                        <div class="flex items-center gap-3 bg-amber-500/10 rounded-lg px-3 py-2">
                            <i class="icon-lock text-amber-400 text-lg"></i>
                            <div class="text-xs leading-relaxed">
                                <b class="text-amber-100 block">Pedido liquidado — edición autorizada</b>
                                <span class="text-amber-200/80">Solo se guardarán los datos de entrega.</span>
                            </div>
                        </div>
                    `
                }] : []),
                {
                    opc: "input",
                    id: "date_order",
                    lbl: "Fecha de entrega",
                    type: "date",
                    class: "col-12 col-sm-6 mb-3",
                    required: true
                },
                {
                    opc: "input",
                    id: "time_order",
                    lbl: "Hora de entrega",
                    type: "time",
                    class: "col-12 col-sm-6 mb-3",
                    required: true
                },
                {
                    opc: "div",
                    id: "radioDeliveryType",
                    lbl: "Tipo de entrega",
                    class: "col-12 mb-3",
                    html: `
                        <div class="flex gap-2 mt-2">
                            <label class="w-1/2 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                                <input
                                    class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                                    type="radio"
                                    name="delivery_type"
                                    id="local"
                                    value="0"
                                    onclick="this.value='0'"
                                >
                                ${lucideIcon('store', 'w-4 h-4')}
                                <span class="text-sm font-medium">Local</span>
                            </label>

                            <label class="w-1/2 shrink-0 inline-flex items-center justify-center gap-2 rounded-lg bg-white/5 px-3 py-1.5 cursor-pointer select-none transition-colors text-gray-300 hover:bg-white/10 has-[:checked]:bg-indigo-500/[12.5%] has-[:checked]:text-white">
                                <input
                                    class="h-4 w-4 shrink-0 accent-indigo-500 cursor-pointer"
                                    type="radio"
                                    name="delivery_type"
                                    id="domicilio"
                                    value="1"
                                    onclick="this.value='1'"
                                >
                                <i class="icon-motorcycle text-amber-500"></i>
                                <span class="text-sm font-medium">A domicilio</span>
                            </label>
                        </div>
                    `
                },
                {
                    opc: "textarea",
                    id: "note",
                    lbl: "Descripción",
                    rows: 3,
                    class: "col-12 mb-3",
                    required: false
                }
            ],
            success: (response) => {
                this._restoreLink();

                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Pedido actualizado",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Aceptar"
                    });

                    this.refreshOrderDetails(id);
                    // La fecha de entrega manda la posicion del pedido en el calendario.
                    this.createCalendar();
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });

        // El link vuelve al calendario aunque se cierre el modal sin guardar.
        $('#formEditDelivery').closest('.bootbox').one('hidden.bs.modal', () => this._restoreLink());

        $(`#formEditDelivery input[name="delivery_type"][value="${String(delivery_type ?? 0)}"]`).prop('checked', true);
    }

    // Pedido liquidado: pide la contraseña antes de abrir el formulario de entrega, el
    // mismo flujo que editOrderPaid en el listado. Se valida aqui para no descubrir una
    // clave mal escrita hasta despues de capturar los cambios; la autorizacion real la
    // vuelve a exigir editOrderDelivery() del controlador al guardar.
    editOrderDeliveryPaid(id) {
        this.alertBox({
            theme:       'dark',
            type:        'cancel',
            icon:        'lock',
            title:       'Pedido liquidado',
            detailHtml:  'Ingresa tu contraseña para editar los datos de entrega.',
            input:       'password',
            inputLabel:  'Contraseña',
            inputPlaceholder: '••••••••',
            inputRequired: true,
            inputError:  'Ingresa tu contraseña',
            okLabel:     'Continuar',
            cancelLabel: 'Cancelar',
            onOk: async (password) => {
                const res = await useFetch({
                    url: this._pedidosLink,
                    data: { opc: 'verifyOrderDeliveryKey', id: id, password: password }
                });

                if (res.status !== 200) {
                    // Contraseña rechazada: se avisa y se vuelve a abrir el dialogo,
                    // porque alertBox ya se cerro al confirmar.
                    this.alertBox({
                        theme:      'dark',
                        type:       'error',
                        title:      'No se puede editar',
                        detailHtml: res.message || 'Contraseña incorrecta.',
                        okLabel:    'Reintentar',
                        onOk:       () => this.editOrderDeliveryPaid(id)
                    });
                    return;
                }

                this.editOrderDelivery(id, password);
            }
        });
    }

    async addDiscount(id) {
        const discountInfo = await useFetch({
            url: this._pedidosLink,
            data: { opc: "getDiscount", id: id }
        });

        const totalPay = parseFloat(discountInfo.data?.total_pay) || 0;
        const currentDiscount = parseFloat(discountInfo.data?.discount) || 0;
        const hasDiscount = currentDiscount > 0;

        this._switchToPedidos();
        this.createModalForm({
            id: 'formAddDiscount',
            data: { opc: 'addDiscount', id: id },
            autofill: discountInfo.data,
            bootbox: {
                title: '<i class="icon-percent text-green-400"></i> Aplicar Descuento',
                size: 'medium'
            },
            json: [
                {
                    opc: "input-group",
                    id: "total_pay",
                    lbl: "Total del pedido",
                    icon: 'icon-dollar',
                    disabled: true,
                    tipo: "cifra",
                    class: "col-12 mb-3"
                },
                {
                    opc: "input-group",
                    id: "discount",
                    lbl: "Monto del descuento",
                    icon: 'icon-dollar',
                    tipo: "cifra",
                    class: "col-12 mb-3",
                    placeholder: "$ 0.00",
                    required: true,
                    onkeyup: `app.calculateDiscounted(${totalPay})`
                },
                {
                    opc: "input",
                    id: "info_discount",
                    lbl: "Motivo del descuento",
                    class: "col-12 mb-3",
                    placeholder: "Ej: CLIENTE FRECUENTE",
                    required: true
                },
                ...(hasDiscount ? [{
                    opc: "button",
                    id: "btnRemoveDiscount",
                    color_btn: "outline-danger",
                    className: 'w-100',
                    text: "Quitar descuento actual",
                    class: "col-12",
                    onClick: () => {
                        this.removeDiscount(id, {
                            discount: currentDiscount,
                            reason: discountInfo.data?.info_discount || '',
                            total: totalPay
                        });
                        $('#formAddDiscount').closest('.bootbox').modal('hide');
                    }
                }] : []),
                {
                    opc: "div",
                    id: "totalDescontado",
                    class: 'col-12',
                    html: `
                        <div class="w-full mt-3 text-center bg-[#1E293B] p-4 rounded-lg">
                            <p class="text-sm text-gray-400 font-medium mb-1">Total con Descuento</p>
                            <p id="TotalConDescuento" class="text-2xl text-white font-bold">${formatPrice(totalPay)}</p>
                        </div>
                    `
                }
            ],
            success: (response) => {
                this._restoreLink();
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento aplicado",
                        text: response.message,
                        btn1: true
                    });
                    this.refreshOrderDetails(id);
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });

        this.calculateDiscounted(totalPay);
    }

    calculateDiscounted(totalOriginal) {
        const descuentoInput = document.getElementById("discount");
        const saldoElement = document.getElementById("TotalConDescuento");
        const applyBtn = document.querySelector(".bootbox .btn-primary");

        if (descuentoInput && saldoElement && applyBtn) {
            const saldoOriginal = parseFloat(totalOriginal) || 0;
            const descuento = parseFloat(descuentoInput.value) || 0;
            const nuevoTotal = saldoOriginal - descuento;

            const totalFormateado = nuevoTotal.toLocaleString("es-MX", {
                style: "currency",
                currency: "MXN",
                minimumFractionDigits: 2
            });

            saldoElement.textContent = totalFormateado;

            if (nuevoTotal < 0) {
                saldoElement.classList.add("text-red-500");
                saldoElement.classList.remove("text-white");
            } else {
                saldoElement.classList.remove("text-red-500");
                saldoElement.classList.add("text-white");
            }

            applyBtn.disabled = nuevoTotal < 0;
        }
    }

    removeDiscount(id, orderData) {
        const { discount, reason, total } = orderData;

        this._switchToPedidos();
        this.createModalForm({
            id: "modalQuitarDescuento",
            parent: "root",
            data: { opc: "deleteDiscount", id: id },
            class: "",
            json: [
                {
                    opc: "div",
                    id: "bloqueDescuentoActual",
                    class: "col-12",
                    html: `
                        <div class="bg-[#334155] text-red-400 p-4 rounded-lg mb-3">
                            <p class="text-sm">Descuento actual:</p>
                            <p class="text-lg font-bold">-${formatPrice(discount)}</p>
                            <p class="text-sm text-white">${reason || 'Sin motivo especificado'}</p>
                        </div>
                    `
                },
                {
                    opc: "div",
                    id: "bloquePrecioSinDescuento",
                    class: "col-12",
                    html: `
                        <div class="bg-[#1E293B] p-4 rounded-lg text-center mb-3">
                            <p class="text-sm text-gray-400">Precio sin descuento</p>
                            <p class="text-2xl font-bold text-white">${formatPrice(total)}</p>
                        </div>
                    `
                },
                {
                    opc: "div",
                    id: "mensajeConfirmacion",
                    class: "col-12 text-center",
                    html: `<p class="text-sm text-gray-400">¿Estás seguro de que deseas quitar el descuento aplicado?</p>`
                }
            ],
            bootbox: {
                title: '<i class="icon-tag text-yellow-400"></i> Quitar Descuento',
                closeButton: true
            },
            success: (response) => {
                this._restoreLink();
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento eliminado",
                        text: response.message,
                        btn1: true
                    });
                    this.refreshOrderDetails(id);
                } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });
    }

    async editDiscount(id) {
        const discountInfo = await useFetch({
            url: this._pedidosLink,
            data: { opc: "getDiscount", id: id }
        });

        const data = discountInfo.data || {};
        const totalPay = parseFloat(data.total_pay) || 0;

        this._switchToPedidos();
        this.createModalForm({
            id: 'formEditDiscount',
            data: { opc: 'editDiscount', id: id },
            bootbox: {
                title: '<i class="icon-pencil text-yellow-400"></i> Editar Descuento',
                size: 'medium'
            },
            autofill: {
                discount: data.discount,
                info_discount: data.info_discount
            },
            json: [
                {
                    opc: "div",
                    id: "infoActual",
                    class: "col-12 mb-3",
                    html: `
                        <div class="bg-[#334155] p-3 rounded-lg">
                            <div class="flex justify-between mb-2">
                                <span class="text-gray-400">Total del pedido:</span>
                                <span class="text-white font-semibold">${formatPrice(totalPay)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Descuento actual:</span>
                                <span class="text-red-400 font-semibold">-${formatPrice(data.discount)}</span>
                            </div>
                        </div>
                    `
                },
                {
                    opc: "input-group",
                    id: "discount",
                    lbl: "Nuevo monto del descuento",
                    icon: 'icon-dollar',
                    tipo: "cifra",
                    class: "col-12 mb-3",
                    placeholder: "$ 0.00",
                    required: true,
                    onkeyup: `app.calculateDiscounted(${totalPay})`
                },
                {
                    opc: "input",
                    id: "info_discount",
                    lbl: "Motivo del cambio",
                    class: "col-12 mb-3",
                    placeholder: "Ej: AJUSTE DE PRECIO"
                },
                {
                    opc: "div",
                    id: "totalDescontado",
                    class: 'col-12',
                    html: `
                        <div class="w-full mt-3 text-center bg-[#1E293B] p-4 rounded-lg">
                            <p class="text-sm text-gray-400 font-medium mb-1">Total con Descuento</p>
                            <p id="TotalConDescuento" class="text-2xl text-white font-bold">${formatPrice(totalPay - data.discount)}</p>
                        </div>
                    `
                }
            ],
            success: (response) => {
                this._restoreLink();
                if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Descuento actualizado",
                        text: response.message,
                        btn1: true
                    });
                    this.refreshOrderDetails(id);
                } else {
                    alert({
                        icon: "error",
                        title: "Error",
                        text: response.message,
                        btn1: true
                    });
                }
            }
        });

        this.calculateDiscounted(totalPay);
    }

    deleteDiscount(id) {
        this._switchToPedidos();
        this.swalQuestion({
            opts: {
                title: '¿Eliminar descuento?',
                html: `¿Estás seguro de eliminar el descuento de este pedido?
                <br><br>
                <span class="text-yellow-500">El total del pedido volverá a su valor original.</span>`,
                icon: 'warning'
            },
            data: { opc: 'deleteDiscount', id: id },
            methods: {
                request: (response) => {
                    this._restoreLink();
                    alert({
                        icon: 'success',
                        title: 'Descuento eliminado',
                        text: response.message,
                        btn1: true
                    });
                    this.refreshOrderDetails(id);
                }
            }
        });
    }

    // =============================================
    // Migrado desde app.js - Imprimir Pedido
    // =============================================

    async printOrder(id) {
        const pos = await useFetch({
            url: this._pedidosLink,
            data: { opc: "getOrderDetails", id: id }
        });

        const modal = bootbox.dialog({
            closeButton: true,
            title: `<div class="flex items-center gap-2 text-white text-lg font-semibold">
                        <i class="icon-print text-blue-400 text-xl"></i>
                        Imprimir
                    </div>`,
            message: `
                <div class="p-2">
                    <div id="containerPrintOrder"></div>
                </div>
            `
        });

        // Usa CatalogProduct (pedidos-catalogo.js) para generar el ticket
        const printer = new CatalogProduct(this._pedidosLink, 'root');
        printer.ticketPasteleria({
            parent: 'containerPrintOrder',
            data: {
                head: pos.data.order,
                products: pos.data.products,
                paymentMethods: pos.data.paymentMethods || [],
                clausules: pos.data.clausules || []
            }
        });
    }

    // =============================================
    // Migrado desde app.js - Historial de Pagos
    // =============================================

    async historyPay(id) {
        this._switchToPedidos();

        const data  = await useFetch({ url: this._link, data: { opc: 'initHistoryPay', id } });
        const order = data.order;

        // El candado de turno de la sucursal que cobra se decide con este snapshot.
        await this.refreshSubsidiariesCobro();

        // Escala del modal. El diseño no cambia: se dibuja mas chico, igual que con el
        // zoom del navegador al 75%. Los anchos de abajo van en coordenadas sin escalar,
        // asi que el ancho real en pantalla es el valor por ZOOM.
        const ZOOM = 0.75;

        // El ancho lo manda el tab: el formulario de pago se descuadra si el modal se
        // estira, y el historial son 6 columnas (fecha, metodo, monto, sucursal,
        // observacion y acciones) que no caben en el ancho del formulario. El tope
        // por vw evita que el modal se salga en pantallas chicas.
        const WIDTH_PAY     = '600px';
        // En px: con la transicion activa el navegador no interpola entre una longitud
        // y una funcion como min(), y el ancho se quedaba clavado en el valor anterior.
        const WIDTH_HISTORY = Math.min(820, Math.round(window.innerWidth * 0.95 / ZOOM)) + 'px';
        // La tarjeta del modal es ANCESTRO de #modalAdvance, no descendiente: el ancho
        // se toca por la referencia que devuelve el componente.
        const setModalWidth = width => this.payModal?.el.find('.cf-card').css('max-width', width);

        // createCoffeeModalForm no maneja pestañas, asi que el contenido va como bloque
        // 'html' y el tabLayout se monta dentro. El wrapper conserva el id modalAdvance
        // porque index.php cuelga de el la regla que colapsa los <label> vacios del
        // plugin de formularios.
        const modal = createCoffeeModalForm({
            id: 'frmHistoryPay',
            title: 'Gestión de Pagos',
            iconSvg: lucideIcon('wallet', 'w-5 h-5'),
            iconBg: 'bg-blue-600',
            theme: 'dark',
            width: 600,
            confirmText: 'Registrar Pago',
            confirmBg: 'bg-blue-600 hover:bg-blue-700',
            json: [
                {
                    opc: 'html',
                    html: '<div id="modalAdvance"><div id="containerChat"></div></div>'
                }
            ],
            // El submit del formulario ya trae su propia confirmacion, asi que el boton
            // del modal solo lo dispara. Se devuelve false para que el modal siga abierto:
            // lo cierra el flujo de exito del pago.
            onConfirm: () => {
                document.getElementById('form-payment')?.requestSubmit();
                return false;
            }
        });

        this.payModal = modal;

        // El diseño se mantiene tal cual y se dibuja al 75%, que es como se ve bien con
        // el zoom del navegador en esa escala. zoom (no transform: scale) porque rehace
        // el layout: la tarjeta ocupa de verdad menos espacio y los clics siguen cayendo
        // donde toca. El max-height es solo una red de seguridad para pantallas bajas.
        const $card = modal.el.find('.cf-card');

        $card.css({
            'zoom':           ZOOM,
            'max-height':     Math.round(92 / ZOOM) + 'vh',
            'display':        'flex',
            'flex-direction': 'column',
            'overflow':       'hidden',
            'transition':     'max-width .2s ease'
        });

        $card.children('.space-y-3').css({ 'overflow-y': 'auto', 'flex': '1 1 auto', 'min-height': '0' });

        // Folio y fecha como subtitulo del encabezado, aprovechando el hueco que deja el
        // icono: en su propia linea gastaban una fila entera del cuerpo. El componente no
        // admite subtitulo por opciones, asi que se inserta sobre el header ya montado.
        const $header = $card.children().first();
        const $titulo = $header.find('span').first();

        $header.removeClass('items-center mb-3').addClass('items-start mb-2');
        $titulo.wrap('<div class="flex-1 min-w-0"></div>').after(`
            <p class="text-[13px] text-gray-400 flex items-center gap-3 mt-0.5">
                <span class="flex items-center gap-1.5">
                    ${lucideIcon('file-text', 'w-3.5 h-3.5')}
                    Folio <b class="text-blue-400 font-semibold">${order.folio}</b>
                </span>
                <span class="flex items-center gap-1.5">
                    ${lucideIcon('calendar', 'w-3.5 h-3.5')}
                    ${order.formatted_date_order || order.date_order}
                </span>
            </p>`);

        // Se elimina el boton cancelar del componente: el modal ya se cierra con la X,
        // Escape o clic fuera, y sin el hermano el de registrar (flex-1) toma el ancho
        // completo. El footer entero se oculta en el historial, donde no hay que
        // registrar nada y un boton suelto solo estorba.
        modal.el.find('.cf-cancel').remove();
        const footerBtns = modal.el.find('.cf-confirm').parent();

        this.tabLayout({
            parent: 'containerChat',
            theme: 'dark',
            class: '',
            json: [
                { id: 'payment', tab: 'Registrar Pago', icon: 'icon-plus-circled', active: true, onClick: () => { setModalWidth(WIDTH_PAY); footerBtns.show(); } },
                { id: 'listPayment', tab: 'Historial de Pagos', icon: 'icon-list', onClick: () => { setModalWidth(WIDTH_HISTORY); footerBtns.hide(); } },
            ]
        });

        // Renders
        $('#container-listPayment').html('<div id="container-info-payment"></div><div id="container-methodPay"></div>');

        this.addPayment(order, id);
        this.renderResumenPagos(data.details);
        this.lsPay(id);
    }

    async addPayment(order, id) {
        // Totales base
        this.totalPay = order.total_pay;
        this.totalPaid = order.total_paid;
        this.discount = order.discount ?? 0;

        const saldoOriginal = order.total_pay;
        const discount = order.discount ?? 0;
        const saldoRestante = order.total_pay - discount - order.total_paid;
        const isPaidInFull = saldoRestante <= 0;

        // El candado de turno no debe reactivar el formulario de un pedido ya pagado.
        this.payIsPaidInFull = isPaidInFull;

        // Sucursal de cobro (cobro cruzado). El calendario no tiene el filtro de sucursal
        // de la navbar, asi que el default es la sucursal activa que entrega su init();
        // si no hay, la del pedido.
        const defaultCobroSub = this.subsidiaryId
            ? String(this.subsidiaryId)
            : String(order.subsidiaries_id ?? '');

        // Sucursal de origen del pedido (referencia para el cobro cruzado).
        const origenSub    = (this.subsidiariesCobro || []).find(s => String(s.id) === String(order.subsidiaries_id));
        const origenNombre = origenSub ? origenSub.valor : '—';

        // Estado inicial de la tarjeta "Sucursal que cobrará".
        const origenSubId      = String(order.subsidiaries_id ?? '');
        const cobroSubSel      = (this.subsidiariesCobro || []).find(s => String(s.id) === String(defaultCobroSub));
        const cobroNombre      = cobroSubSel ? cobroSubSel.valor : origenNombre;
        const cobroEsMismaSuc  = String(defaultCobroSub) === origenSubId;
        const cobroSubtitulo   = cobroEsMismaSuc ? 'Misma sucursal de origen' : 'Cobro en otra sucursal';
        const cobroOptionsHtml = (this.subsidiariesCobro || [])
            .map(s => `<option value="${s.id}" ${String(s.id) === String(defaultCobroSub) ? 'selected' : ''}>${s.valor}</option>`)
            .join('');

        // Metodos de pago del dropdown custom (.js-dd). El value es el id que espera
        // el backend (1=Efectivo, 2=Tarjeta, 3=Transferencia) y vive en el input
        // hidden #method_pay_id que lee el form al registrar el pago.
        const metodosPago = [
            { id: '1', label: 'Efectivo',      sub: 'Pago en efectivo', icon: 'banknote' },
            { id: '2', label: 'Tarjeta',       sub: 'Débito o crédito', icon: 'credit-card' },
            { id: '3', label: 'Transferencia', sub: 'Depósito o SPEI',  icon: 'arrow-right-left' }
        ];
        const metodoDefault = metodosPago[0];
        const methodPayOptionsHtml = metodosPago.map((m, i) => `
            <div class="js-dd-option flex items-center gap-2.5 px-2.5 py-2 cursor-pointer hover:bg-slate-700/50"
                data-value="${m.id}" data-label="${m.label}" data-sub="${m.sub}" data-icon="${m.icon}">
                <div class="flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 text-gray-300 shrink-0">
                    ${window.lucideIcon(m.icon, 'w-4 h-4')}
                </div>
                <div class="flex flex-col leading-tight flex-1 min-w-0">
                    <span class="text-sm text-white font-semibold truncate">${m.label}</span>
                    <span class="text-[11px] text-gray-400">${m.sub}</span>
                </div>
                <span class="js-dd-check text-emerald-400 shrink-0 ${i === 0 ? '' : 'opacity-0'}">${window.lucideIcon('check', 'w-4 h-4')}</span>
            </div>`).join('');

        const methodPayCardHtml = `
            <input type="hidden" id="method_pay_id" name="method_pay_id" value="${metodoDefault.id}" required>
            <div class="js-dd relative">
                <div class="js-dd-trigger flex items-center gap-2.5 bg-[#1E293B] border border-slate-700 rounded-lg px-2.5 py-1.5 ${isPaidInFull ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}" ${isPaidInFull ? 'disabled' : ''}>
                    <div class="js-dd-trigger-icon flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 text-gray-300 shrink-0">
                        ${window.lucideIcon(metodoDefault.icon, 'w-4 h-4')}
                    </div>
                    <div class="flex flex-col leading-tight flex-1 min-w-0">
                        <span class="js-dd-trigger-label text-sm text-white font-semibold truncate">${metodoDefault.label}</span>
                        <span class="js-dd-trigger-sub text-[11px] text-gray-400">${metodoDefault.sub}</span>
                    </div>
                    <span class="js-dd-chevron text-gray-400 shrink-0 transition-transform">${window.lucideIcon('chevron-down', 'w-4 h-4')}</span>
                </div>
                <div class="js-dd-menu hidden absolute left-0 right-0 mt-1 z-20 bg-[#1E293B] border border-slate-700 rounded-lg shadow-xl overflow-hidden">
                    ${methodPayOptionsHtml}
                </div>
            </div>`;

        // Contenedor del formulario centrado y reducido
        $("#container-payment").html(`
            <div class="flex justify-center items-start">
                <div class="w-full">
                    <form id="form-payment" novalidate></form>
                </div>
            </div>
        `);

        this.createForm({
            id: "formRegisterPayment",
            parent: "form-payment",
            data: {
                opc: "addPayment",
                total: order.total_pay,
                saldo: saldoRestante,
                id: id
            },
            json: [
                {
                    opc: "div",
                    id: "Amount",
                    class: "col-12 mb-2",
                    html: `
                    <div id="dueAmount" class="p-2.5 rounded-xl ${isPaidInFull ? 'bg-green-900/30' : 'bg-[#1E293B]'} text-white text-center">
                        <p class="text-[13px] opacity-80">${isPaidInFull ? 'Pedido pagado completamente' : 'Monto restante a pagar'}</p>
                        <p id="SaldoEvent" class="text-lg font-bold leading-tight">
                            ${formatPrice(saldoRestante)}
                        </p>
                        ${discount > 0 ? `
                            <div class="mt-1.5 pt-1.5 border-t border-gray-600">
                                <p class="text-[11px] text-gray-400">Total original: <span class="line-through">${formatPrice(saldoOriginal)}</span></p>
                                <p class="text-[11px] text-green-400 flex items-center justify-center gap-1">${lucideIcon('tag', 'w-3 h-3')} Descuento aplicado: -${formatPrice(discount)}</p>
                            </div>
                        ` : ''}
                        ${isPaidInFull ? lucideIcon('circle-check', 'w-5 h-5 text-green-400 mt-0.5 inline-block') : ''}
                    </div>`
                },
                {
                    opc: "div",
                    id: "cardMethodPay",
                    class: "col-12 mb-2",
                    lbl: "Método de pago",
                    html: methodPayCardHtml
                },
                {
                    opc: "div",
                    id: "origenPedido",
                    lbl: "Origen del pedido",
                    class: "col-12 mb-2",
                    html: `<div class="flex items-center gap-2.5 bg-[#1E293B] border border-slate-700 rounded-lg px-2.5 py-1.5">
                        <div class="flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 text-gray-300 shrink-0">
                            ${lucideIcon('house', 'w-4 h-4')}
                        </div>
                        <div class="flex flex-col leading-tight min-w-0">
                            <span class="text-sm text-white font-semibold truncate">${origenNombre}</span>
                            <span class="text-[11px] text-gray-400">Sucursal donde se generó la venta</span>
                        </div>
                    </div>`
                },
                {
                    opc: "div",
                    id: "cobroWrapper",
                    lbl: "Sucursal que cobrará",
                    // mb-2 como el resto: el mb-3 abria un hueco mayor justo antes de Importe.
                    class: "col-12 mb-2",
                    html: `<div class="relative">
                        <div id="cobroCard" class="flex items-center gap-2.5 bg-[#1E293B] border ${cobroEsMismaSuc ? 'border-slate-700' : 'border-amber-500/60'} rounded-lg px-2.5 py-1.5 pointer-events-none">
                            <div id="cobroCardIcon" class="flex items-center justify-center w-7 h-7 rounded-lg bg-slate-700/60 ${cobroEsMismaSuc ? 'text-blue-400' : 'text-amber-400'} shrink-0">
                                ${lucideIcon('landmark', 'w-4 h-4')}
                            </div>
                            <div class="flex flex-col leading-tight flex-1 min-w-0">
                                <span id="cobroCardName" class="text-sm text-white font-semibold truncate">${cobroNombre}</span>
                                <span id="cobroCardSub" class="text-[11px] text-gray-400">${cobroSubtitulo}</span>
                            </div>
                            ${lucideIcon('chevron-down', 'w-4 h-4 text-gray-400 shrink-0')}
                        </div>
                        <select id="payment_subsidiaries_id" name="payment_subsidiaries_id" data-origen="${origenSubId}" required
                            class="absolute inset-0 w-full h-full opacity-0 ${isPaidInFull ? 'cursor-not-allowed' : 'cursor-pointer'}"
                            ${isPaidInFull ? 'disabled' : ''} onchange="app.onCobroChange(this)">
                            ${cobroOptionsHtml}
                        </select>
                    </div>
                    <div id="cobroShiftAlert" class="hidden mt-1.5"></div>`
                },
                {
                    opc: "input",
                    type: "number",
                    id: "advanced_pay",
                    lbl: "Importe",
                    class: "col-12 mb-2",
                    placeholder: "0.00",
                    required: true,
                    min: 0,
                    onkeyup: "app.updateTotal()",
                    disabled: isPaidInFull
                },
                {
                    opc: "textarea",
                    id: "description",
                    lbl: "Observación",
                    class: "col-12 mb-2",
                    disabled: isPaidInFull
                }
                // Sin btn-submit: el boton de registrar es el del footer del modal
                // (.cf-confirm), que dispara el submit de este formulario.
            ],
            success: async (response) => {
                if (response.status === 200) {

                    const data = response.data;

                    // ✅ Alert con cierre automático
                    alert({
                        icon: "success",
                        text: "Pago registrado correctamente ✅",
                        timer: 1000
                    });

                    // Refrescar pagos y vista general. Aqui no hay tabla de pedidos que
                    // recargar (el ls() de pedidos): lo que se actualiza es la ficha del
                    // pedido abierta detras del modal.
                    this.lsPay(id);
                    this.refreshOrderDetails(id);
                    this.renderResumenPagos(data.details);

                    // Recalcular saldo restante sin redibujar
                    const order = data.order;
                    const discount = order.discount ?? 0;
                    const restante2 = order.total_pay - discount - order.total_paid;
                    this.totalPay = order.total_pay;
                    this.totalPaid = order.total_paid;
                    this.discount = discount;

                    // Verificar si se pagó completamente
                    if (restante2 <= 0) {
                        // Recargar el formulario para mostrar estado pagado
                        this.addPayment(order, id);
                    } else {
                        $("#SaldoEvent").text(formatPrice(restante2));
                        $("#advanced_pay").val("");
                        $("#description").val("");
                        app.updateTotal();
                    }

                } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }

            }
        });

        // ── Interacción de los dropdowns (abrir/cerrar, seleccionar) ───────────
        const $payRoot = $('#container-payment');
        $payRoot.off('click.dd');

        // Abrir / cerrar al pulsar el trigger.
        $payRoot.on('click.dd', '.js-dd-trigger:not([disabled])', function (e) {
            e.stopPropagation();
            const $menu = $(this).siblings('.js-dd-menu');
            const willOpen = $menu.hasClass('hidden');
            // Cerrar cualquier otro menú abierto.
            $payRoot.find('.js-dd-menu').addClass('hidden');
            $payRoot.find('.js-dd-chevron').removeClass('rotate-180');
            if (willOpen) {
                $menu.removeClass('hidden');
                $(this).find('.js-dd-chevron').addClass('rotate-180');
            }
        });

        // Seleccionar una opción: actualiza hidden + trigger + check y cierra.
        $payRoot.on('click.dd', '.js-dd-option', function (e) {
            e.stopPropagation();
            const $opt = $(this);
            const $dd = $opt.closest('.js-dd');
            const value = $opt.attr('data-value');
            const label = $opt.attr('data-label');
            const sub = $opt.attr('data-sub') || '';
            const icon = $opt.attr('data-icon');

            // Valor real (id) para el envío del formulario.
            $dd.prevAll('input[type="hidden"]').first().val(value);

            // Reflejar la selección en el trigger.
            const $trigger = $dd.find('.js-dd-trigger');
            $trigger.find('.js-dd-trigger-icon').html(window.lucideIcon(icon, 'w-4 h-4'));
            $trigger.find('.js-dd-trigger-label').text(label);
            $trigger.find('.js-dd-trigger-sub').text(sub);

            // Mover el check a la opción elegida.
            $dd.find('.js-dd-check').addClass('opacity-0');
            $opt.find('.js-dd-check').removeClass('opacity-0');

            // Cerrar.
            $dd.find('.js-dd-menu').addClass('hidden');
            $trigger.find('.js-dd-chevron').removeClass('rotate-180');
        });

        // Cerrar al hacer click fuera de cualquier dropdown.
        $(document).off('click.payDD').on('click.payDD', function () {
            $('#container-payment .js-dd-menu').addClass('hidden');
            $('#container-payment .js-dd-chevron').removeClass('rotate-180');
        });

        // Confirmación antes de registrar el pago. Se intercepta el submit en fase
        // de captura (antes de validation_form): si no está confirmado, se bloquea,
        // se valida el importe y se pregunta; al confirmar se reenvía con bandera
        // para que el flujo normal (validación + AJAX) continúe.
        const formEl = document.getElementById('form-payment');
        if (formEl) {
            formEl.addEventListener('submit', async (e) => {
                if (formEl.dataset.payConfirmed === '1') {
                    formEl.dataset.payConfirmed = '';
                    return; // ya confirmado: dejar pasar a validation_form
                }
                e.preventDefault();
                e.stopImmediatePropagation();

                // Sin turno abierto en la sucursal que cobra el dinero no entra a
                // ningun corte: se bloquea aqui y tambien en el backend.
                if (!this.requireCobroShift()) return;

                const importe = parseFloat($('#advanced_pay').val()) || 0;
                if (importe <= 0) {
                    alert({ icon: 'error', text: 'Ingresa un importe válido para registrar el pago.', btn1: true, btn1Text: 'Ok' });
                    return;
                }

                // Datos legibles para que el usuario entienda cómo se registrará el pago.
                const metodos = { '1': 'Efectivo', '2': 'Tarjeta', '3': 'Transferencia' };
                const metodoTxt = metodos[String($('#method_pay_id').val())] || '—';
                const subCobroId = String($('#payment_subsidiaries_id').val() || '');
                const subCobroObj = (this.subsidiariesCobro || []).find(s => String(s.id) === subCobroId);
                const subCobroNombre = subCobroObj ? subCobroObj.valor : origenNombre;
                // Cobro cruzado: la sucursal que cobra es distinta a la de origen del pedido.
                const esCruzado = subCobroId !== '' && String(order.subsidiaries_id ?? '') !== subCobroId;

                const row = (lbl, val, color = '#fff') => `
                    <div style="display:flex;justify-content:space-between;gap:16px;padding:3px 0;">
                        <span style="color:#9ca3af;">${lbl}</span><b style="color:${color};">${val}</b>
                    </div>`;

                const htmlConfirm = `
                    <div style="text-align:left;font-size:14px;line-height:1.5;">
                        ${row('Importe', formatPrice(importe))}
                        ${row('Método de pago', metodoTxt)}
                        ${row('Sucursal que cobra', subCobroNombre, '#A78BFA')}
                        ${esCruzado ? `
                        <div style="margin-top:10px;padding:8px 10px;border-radius:8px;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.4);color:#fcd34d;font-size:12.5px;line-height:1.45;">
                            Cobro cruzado: el pedido es de <b>${origenNombre}</b>, pero el cobro se registrará en <b>${subCobroNombre}</b>.
                        </div>` : ''}
                    </div>`;

                const res = await alert({
                    icon: 'question',
                    title: '¿Registrar pago?',
                    html: htmlConfirm,
                    btn1Text: 'Sí, registrar',
                    btn2Text: 'Cancelar'
                });

                if (res && res.isConfirmed) {
                    formEl.dataset.payConfirmed = '1';
                    formEl.requestSubmit();
                }
            }, true);
        }

        // Aplicar estilos disabled si está pagado
        if (isPaidInFull) {
            setTimeout(() => {
                $("#advanced_pay, #description, #btnSuccess").prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
                $('.cf-confirm').prop('disabled', true).addClass('opacity-50 cursor-not-allowed').text('Pedido Pagado');
            }, 100);
        }

        // Estado inicial del candado de turno. Va despues del bloque de "pagado" para
        // no pelearse con el, y con retraso porque el boton vive en el footer del modal.
        setTimeout(() => this.applyCobroShiftLock(), 120);
    }

    // Snapshot fresco de las sucursales de cobro con su shift_opened_at. Sale por el
    // ctrl de pedidos porque el init del calendario entrega la lista sin el turno.
    async refreshSubsidiariesCobro() {
        const res = await useFetch({ url: this._pedidosLink, data: { opc: 'getSubsidiariesShift' } });
        if (res && Array.isArray(res.data) && res.data.length) this.subsidiariesCobro = res.data;
    }

    // Estado de turno de una sucursal a partir del snapshot (sub.shift_opened_at):
    // sin turno, turno abierto hoy o turno de otro dia sin cerrar.
    subsidiaryShift(sub) {
        const opened = sub && sub.shift_opened_at;
        if (!opened) return { status: 'none', canSell: false };
        if (moment(opened).isSame(moment(), 'day')) return { status: 'open', canSell: true };
        return { status: 'old', canSell: false };
    }

    // Turno de la sucursal que cobra: sin turno abierto de hoy el pago no puede
    // registrarse (el dinero no caeria en ningun corte). Pinta el aviso bajo el
    // selector y bloquea importe, observacion y el boton de registrar.
    applyCobroShiftLock() {
        const sub = (this.subsidiariesCobro || []).find(s => String(s.id) === String($('#payment_subsidiaries_id').val() || ''));
        const st  = this.subsidiaryShift(sub);

        const $alert = $('#cobroShiftAlert');

        if (st.canSell) {
            $alert.addClass('hidden').empty();
        } else {
            const nombre  = sub ? sub.valor : 'seleccionada';
            const titulo  = st.status === 'old' ? 'Turno sin cerrar' : 'Sucursal sin turno abierto';
            const detalle = st.status === 'old'
                ? `La sucursal <b class="text-gray-300">${nombre}</b> tiene un turno de otro día sin cerrar; no se puede registrar este pago.`
                : `La sucursal <b class="text-gray-300">${nombre}</b> debe abrir su turno para poder registrar este pago.`;

            $alert.removeClass('hidden').html(`
                <div class="flex items-start gap-2 bg-amber-500/10 rounded-lg px-2.5 py-1.5">
                    <span class="text-amber-400 shrink-0 mt-0.5">${lucideIcon('circle-alert', 'w-4 h-4')}</span>
                    <div class="flex flex-col leading-tight min-w-0">
                        <span class="text-[12px] font-semibold text-amber-300">${titulo}</span>
                        <span class="text-[11px] text-gray-400">${detalle}</span>
                    </div>
                </div>`);
        }

        if (this.payIsPaidInFull) return st;

        const locked = !st.canSell;
        $('#advanced_pay, #description').prop('disabled', locked).toggleClass('opacity-50 cursor-not-allowed', locked);
        $('.cf-confirm').prop('disabled', locked).toggleClass('opacity-50 cursor-not-allowed', locked);

        return st;
    }

    requireCobroShift() {
        const st = this.applyCobroShiftLock();
        if (st.canSell) return true;

        const sub    = (this.subsidiariesCobro || []).find(s => String(s.id) === String($('#payment_subsidiaries_id').val() || ''));
        const nombre = sub ? sub.valor : 'seleccionada';

        alert({
            icon: 'warning',
            title: st.status === 'old' ? 'Turno sin cerrar' : 'Sucursal sin turno abierto',
            text: st.status === 'old'
                ? `La sucursal ${nombre} tiene un turno de otro día sin cerrar. Debe cerrarlo y abrir el turno de hoy para registrar este pago.`
                : `La sucursal ${nombre} debe abrir su turno de caja para poder registrar este pago.`,
            btn1: true,
            btn1Text: 'Entendido'
        });

        return false;
    }

    onCobroChange(sel) {
        const $sel   = $(sel);
        const id     = String($sel.val() || '');
        const nombre = $sel.find('option:selected').text().trim();
        const origen = String($sel.data('origen') || '');
        const same   = id === origen;

        $('#cobroCardName').text(nombre);
        $('#cobroCardSub').text(same ? 'Misma sucursal de origen' : 'Cobro en otra sucursal');
        $('#cobroCard')
            .toggleClass('border-slate-700', same)
            .toggleClass('border-amber-500/60', !same);
        $('#cobroCardIcon')
            .toggleClass('text-blue-400', same)
            .toggleClass('text-amber-400', !same);

        this.applyCobroShiftLock();
    }

    deletePay(id, idFolio, requiereClave = 0) {
        const row = event.target.closest("tr");
        const raw = row.cells[2].textContent;
        const clean = raw.replace(/[^\d.-]/g, "");
        const amount = parseFloat(clean);

        this._switchToPedidos();

        // Pedido liquidado: el controlador exige la contraseña del usuario en
        // sesión, así que se confirma con ella en vez del sí/no de siempre.
        if (requiereClave == 1) {
            this.deletePayWithKey(id, idFolio, amount);
            return;
        }

        this.swalQuestion({
            opts: {
                title: "¿Confirmar eliminación?",
                text: `Se eliminará el pago de ${formatPrice(amount)} de forma permanente.`,
                icon: "warning"
            },
            data: { opc: "deletePay", id: idFolio, amount: amount, idPay: id },
            methods: {
                success: (res) => {
                    if (res.status === 200) {
                        this.afterDeletePay(res, idFolio);
                    } else {
                        this._restoreLink();
                        alert({ icon: "error", text: res.message });
                    }
                }
            }
        });
    }

    // Borrado autorizado: el saldo del pedido ya es cero, por lo que eliminar un
    // abono reabre un pedido cerrado. Este modal solo recolecta la contraseña;
    // quien la valida es deletePay() del controlador.
    deletePayWithKey(id, idFolio, amount) {
        this.alertBox({
            theme:       'dark',
            type:        'cancel',
            icon:        'lock',
            title:       'Pedido liquidado',
            detailHtml:  `Ingresa tu contraseña para eliminar el pago de <b class="text-gray-200">${formatPrice(amount)}</b>.`,
            input:       'password',
            inputLabel:  'Contraseña',
            inputPlaceholder: '••••••••',
            inputRequired: true,
            inputError:  'Ingresa tu contraseña',
            okLabel:     'Eliminar pago',
            okBg:        'bg-[#E02424] hover:bg-[#C81E1E]',
            cancelLabel: 'Cancelar',
            onCancel:    () => this._restoreLink(),
            onOk: async (password) => {
                const res = await useFetch({
                    url: this._pedidosLink,
                    data: { opc: 'deletePay', id: idFolio, amount: amount, idPay: id, password: password }
                });

                if (res.status !== 200) {
                    // Contraseña rechazada: se avisa y se vuelve a abrir el dialogo,
                    // porque alertBox ya se cerro al confirmar.
                    this._restoreLink();
                    this.alertBox({
                        theme:      'dark',
                        type:       'error',
                        title:      'No se eliminó el pago',
                        detailHtml: res.message || 'Contraseña incorrecta.',
                        okLabel:    'Reintentar',
                        onOk:       () => this.deletePayWithKey(id, idFolio, amount)
                    });
                    return;
                }

                this.afterDeletePay(res, idFolio);
            }
        });
    }

    // Refresco comun tras eliminar un pago (con o sin contraseña).
    afterDeletePay(res, idFolio) {
        const data = res.initHistoryPay;

        this.renderResumenPagos(data.details);
        this.lsPay(idFolio);

        const order = data.order;
        this.totalPay = order.total_pay;
        this.totalPaid = order.total_paid;
        this.addPayment(order, idFolio);

        // Refrescar detalles del pedido en el modal
        this.refreshOrderDetails(idFolio);

        alert({
            icon: "success",
            text: res.message || "Pago eliminado correctamente. Saldo actualizado.",
            timer: 2000
        });
    }

    async lsPay(id) {
        this._switchToPedidos();
        const response = await useFetch({
            url: this._pedidosLink,
            data: { opc: 'listPayment', id: id }
        });

        if (!response.row || response.row.length === 0) {
            $("#container-methodPay").html(`
                <div class="flex flex-col items-center justify-center py-12 text-center bg-[#1E293B] border border-slate-700 rounded-xl">
                    <div class="w-16 h-16 rounded-2xl bg-slate-700/60 flex items-center justify-center mb-4">
                        ${lucideIcon('history', 'w-7 h-7 text-gray-400')}
                    </div>
                    <p class="text-gray-300 text-base font-semibold mb-1">Aún no se ha realizado ningún abono</p>
                    <p class="text-gray-500 text-sm">Los pagos registrados aparecerán aquí</p>
                </div>
            `);
            return;
        }

        this.createTable({
            parent: "container-methodPay",
            idFilterBar: "filterBarEventos",
            data: { opc: 'listPayment', id: id },
            conf: { datatable: false, pag: 8 },
            coffeesoft: true,
            attr: {
                id: "tableOrder",
                theme: 'dark',
                center: [1, , 3, 6, 7],
                right: [4],
                f_size: 11,
                extends: true,
            },
        });
    }

    renderResumenPagos(totales) {
        const totalPagado = totales?.pagado ?? 0;
        const discount = totales?.discount ?? 0;
        const totalEvento = totales?.total ?? 0;

        const totalConDescuento = totalEvento - discount;
        const restante = totalConDescuento - totalPagado;

        const fmt = (n) => n.toLocaleString('es-MX', {
            style: 'currency',
            currency: 'MXN',
            minimumFractionDigits: 2
        });

        // Liquidado: el restante deja de ser una alerta y se pinta en verde como el
        // total pagado, para que la tarjeta no siga en rojo con saldo cero.
        const liquidado = restante <= 0;

        let originalHTML = `<p class="text-lg font-bold text-blue-400 mt-1" id="totalEvento">${formatPrice(totalEvento)}</p>`;

        if (discount > 0) {
            originalHTML = `
            <p class="text-lg font-bold text-blue-400 mt-1" id="totalEvento">${fmt(totalConDescuento)}</p>
            <p class="text-xs text-gray-500 line-through">${fmt(totalEvento)}</p>
            <p class="text-xs text-emerald-400 mt-1 flex items-center justify-center gap-1">
                ${lucideIcon('tag', 'w-3 h-3')} Descuento:
                <span class="font-semibold">${fmt(discount)}</span>
            </p>
        `;
        }

        $('#container-info-payment').html(`
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div class="bg-emerald-500/10 rounded-xl p-3 text-center">
                <p class="text-xs text-emerald-400/80 flex items-center justify-center gap-1.5">
                    ${lucideIcon('circle-check', 'w-3.5 h-3.5')} Total pagado
                </p>
                <p class="text-lg font-bold text-emerald-400 mt-1" id="totalPagado">${fmt(totalPagado)}</p>
            </div>
            <div class="bg-blue-500/10 rounded-xl p-3 text-center">
                <p class="text-xs text-blue-400/80 flex items-center justify-center gap-1.5">
                    ${lucideIcon('wallet', 'w-3.5 h-3.5')} Total
                </p>
                ${originalHTML}
            </div>
            <div class="${liquidado ? 'bg-emerald-500/10' : 'bg-red-500/10'} rounded-xl p-3 text-center">
                <p class="text-xs ${liquidado ? 'text-emerald-400/80' : 'text-red-400/80'} flex items-center justify-center gap-1.5">
                    ${lucideIcon(liquidado ? 'circle-check' : 'clock', 'w-3.5 h-3.5')} Restante
                </p>
                <p class="text-lg font-bold ${liquidado ? 'text-emerald-400' : 'text-red-400'} mt-1" id="totalRestante">${fmt(restante)}</p>
            </div>
        </div>
    `);
    }

    updateTotal(total, totalPaid) {
        const val = parseFloat($("#advanced_pay").val()) || 0;
        const t = typeof total === 'number' ? total : (this.totalPay || 0);
        const tp = typeof totalPaid === 'number' ? totalPaid : (this.totalPaid || 0);
        const d = this.discount || 0;
        const restante = (t - d - (tp || 0)) - val;
        // .cf-confirm: en Gestion de Pagos el boton de registrar vive en el footer del
        // modal, no dentro del formulario.
        const btn = $("#btnSuccess").add('.cf-confirm');
        const display = $("#SaldoEvent");
        if (display && display.length) {
            display.text(formatPrice(restante < 0 ? 0 : restante));
        }
        // Sin turno en la sucursal que cobra el boton se queda bloqueado: este metodo
        // corre en cada tecla y despues de cada pago, y sin esto reabriria el candado.
        const shiftLocked = $('#cobroShiftAlert').length && !$('#cobroShiftAlert').hasClass('hidden');

        if (restante < 0 || shiftLocked) {
            btn.prop("disabled", true).addClass("opacity-50 cursor-not-allowed");
        } else {
            btn.prop("disabled", false).removeClass("opacity-50 cursor-not-allowed");
        }
    }

    previewImage(imageUrl, imageName = 'Imagen') {
        const modal = $(`
            <div id="imagePreviewModal" class="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80" onclick="if(event.target === this) $(this).remove()">
                <div class="relative max-w-4xl max-h-[90vh] p-2">
                    <button onclick="$('#imagePreviewModal').remove()"
                            class="absolute -top-2 -right-2 w-10 h-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-xl font-bold z-10 shadow-lg">
                        ×
                    </button>
                    <img src="${imageUrl}" alt="${imageName}"
                         class="max-w-full max-h-[85vh] rounded-lg shadow-2xl object-contain">
                    <p class="text-white text-center mt-3 text-sm">${imageName}</p>
                </div>
            </div>
        `);

        $('body').append(modal);

        $(document).on('keydown.imagePreview', function (e) {
            if (e.key === 'Escape') {
                $('#imagePreviewModal').remove();
                $(document).off('keydown.imagePreview');
            }
        });
    }



}
