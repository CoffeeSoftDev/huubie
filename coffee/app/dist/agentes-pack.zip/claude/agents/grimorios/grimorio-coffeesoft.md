---
name: grimorio-coffeesoft
description: Grimorio del sistema de diseno CoffeeSoft. Paleta "Arcilla Invernal" con acento terracota #C05A40, soporte light + dark, basado en el modulo inventory (operacion/almacen). Distinto a Huubie UI (azul #1C64F2, dark unico). Fuente de verdad de tokens en inventory/src/css/colors.css, dark-mode.css y tailwind-theme.js.
type: reference
spell: coffeesoft
domain: coffeesoft
---

# Grimorio UI-Kit: CoffeeSoft (Arcilla Invernal)

> **Uso:** Referencia oficial del sistema de diseno **CoffeeSoft** para el agente CoffeeMagic. Cuando el usuario pida un template "estilo CoffeeSoft", "arcilla invernal", "terracota", "tema inventory" o "tema almacen", carga este grimorio.
>
> **IMPORTANTE — diferencia con Huubie UI:**
> - **Huubie UI** ([[grimorio-huubie-ui]]) es **dark unico**, acento azul `#1C64F2`, clases `.cs-*` cerradas sobre `coffee/ui/css/ui-kit.css`.
> - **CoffeeSoft** soporta **light + dark** (toggle `body.dark-mode`), acento **terracota `#C05A40`** ("Arcilla Invernal"), construido sobre Tailwind (Play CDN) + Bootstrap 5 grid + variables CSS `--primary`, `--secondary`, etc. Vive en el modulo `inventory/operacion/almacen`.
> - Ambos comparten los chromes `#111928` / `#1F2A37` / `#141d2b` en dark, pero **el acento cambia** (azul vs terracota) y **el comportamiento de tema cambia** (dark-only vs light+dark).

---

## 1. Filosofia del Sistema

- **Doble tema:** Claro (default) y Oscuro (`body.dark-mode`). El toggle vive en el navbar. A diferencia de Huubie UI, CoffeeSoft **si tiene modo claro** y es el predeterminado.
- **Acento unico:** Terracota `#C05A40` — paleta "Arcilla Invernal" heredada del Visor. Reemplaza al azul institucional en toda la rampa.
- **Tecnologia:** HTML + Tailwind CSS v3 (Play CDN) con la escala `blue` remapeada a terracota (`tailwind-theme.js`) + Bootstrap 5 (solo grid/utilidades) + variables CSS custom (`--primary`, `--secondary`...).
- **Fuente:** Inter (Google Fonts).
- **Iconografia:** Fontello (clases `icon-*`) + SVG inline estilo Heroicons.
- **Remapeo clave:** toda clase Tailwind `blue-*` (`bg-blue-600`, `text-blue-400`, `ring-blue-500`, `border-blue-...`) **rinde terracota** sin editar componente por componente — gracias a `tailwind-theme.js` cargado justo despues del CDN.

---

## 2. Tokens de Color

Fuente de verdad: [inventory/src/css/colors.css](../../../../wamp64/www/huubie/inventory/src/css/colors.css), [dark-mode.css](../../../../wamp64/www/huubie/inventory/src/css/dark-mode.css), [tailwind-theme.js](../../../../wamp64/www/huubie/inventory/src/js/tailwind-theme.js).

### 2.1 Acento Principal — Terracota (`--primary`)

| Token CSS | Hex | Uso |
|-----------|-----|-----|
| `--primary` | `#C05A40` | Acento principal: botones, tabs activos, focus, badges, links |
| `--primary-hover` | `#A84A33` | Hover de primario |
| `--primary-light` | `#E8A68F` | Salmon — acento suave, fondos tenues |
| `--primary-dark` | `#8F3D2A` | Texto/acento profundo, gradientes |
| `--primary1` … `--primary9` | `rgba(192,90,64,.1)` … `.9` | Escala de opacidad (chips, overlays, focus ring) |

### 2.2 Rampa Terracota Tailwind (remapeo de `blue`)

`tailwind-theme.js` reescribe la escala `blue` de Tailwind. Usar `bg-blue-600`, `text-blue-400`, etc., rinde terracota:

| Paso | Hex | Nota |
|------|-----|------|
| `blue-50` | `#FBF3EF` | fondo muy tenue |
| `blue-100` | `#F7E3DC` | |
| `blue-200` | `#EFC9BC` | |
| `blue-300` | `#E8A68F` | salmon |
| `blue-400` | `#D9826A` | |
| `blue-500` | `#C8694C` | |
| `blue-600` | `#C05A40` | **acento (terracota)** |
| `blue-700` | `#A84A33` | **hover** |
| `blue-800` | `#8F3D2A` | |
| `blue-900` | `#6E2F20` | |
| `blue-950` | `#4A1F16` | |

### 2.3 Secundario — Dark Slate (`--secondary`)

| Token CSS | Hex | Uso |
|-----------|-----|-----|
| `--secondary` | `#0F172A` | Botones secundarios, texto oscuro, base slate |
| `--secondary-hover` | `#1E293B` | Hover de secundario |
| `--secondary-light` | `#334155` | Variante clara |
| `--secondary-lighter` | `#475569` | Variante mas clara |
| `--secondary1` … `--secondary9` | `rgba(15,23,42,.1)` … `.9` | Escala de opacidad |

### 2.4 Estados Semanticos

| Token CSS | Hex | Hover | Light | Dark | Uso |
|-----------|-----|-------|-------|------|-----|
| `--success` | `#22C55E` | `#16A34A` | `#4ADE80` | `#15803D` | Exito, activo, aprobado |
| `--danger` | `#9D3434` | `#832B2B` | `#B85454` | `#6E2424` | Rojo vino (Arcilla Invernal): error, eliminar, inactivo |
| `--warning` | `#F69F00` | — | — | — | Advertencia, pendiente |
| `--info` | `#C05A40` | — | `#F7E3DC` | — | Alias del terracota (compatibilidad) |
| `--disabled` | `#494C50` | — | — | — | Deshabilitado |

> Nota: cada estado tiene su escala de opacidad `--success1..9`, `--danger1..9`, `--warning5..9`, `--disabled1..9`.

### 2.5 Fondos (Backgrounds)

**Tema claro (default):**

| Token | Hex | Uso |
|-------|-----|-----|
| `--default` | `#F2F5F9` | Fondo de pagina base |
| `--aliceblue` | `#FAFCFF` | Fondo de cards/superficies |
| `--crema` | `#F7F0EB` | Fondo tenue / badges (Arcilla Invernal) |
| `.navbar-main` | `#FAFCFF` | Navbar claro |

**Tema oscuro (`body.dark-mode`):**

| Elemento | Hex | Uso |
|----------|-----|-----|
| body / main / `#root` | `#111928` | Fondo de pagina |
| card / modal / contenedor | `#1F2A37` | Cards, paneles, modales, header de tabla |
| input / select / textarea | `#1F2A37` | Campos de formulario |
| input :focus | `#1F2937` | Campo enfocado |
| fila alterna (even) | `#1A2332` | Tabla striped |
| fila :hover | `#1F2937` | Hover de fila |
| navbar / sidebar | `#141D2B` | Chrome navy (`--navbar`) |
| tooltip | `#1A2332` | Tooltip inner |

### 2.6 Texto

| Contexto | Claro | Oscuro | Uso |
|----------|-------|--------|-----|
| Principal | `#1A1A1A` | `#F5F5F5` | Titulos, texto base |
| Secundario / muted | `#6B7280` | `#9CA3AF` | Labels, metadatos, subtitulos |
| Atenuado / placeholder | `#9CA3AF` | `#6B7280` | Placeholders, deshabilitado |
| `.text-dark` (dark-mode) | — | `#E5E5E5` | Texto sobre superficies oscuras |

### 2.7 Bordes

| Token | Valor | Uso |
|-------|-------|-----|
| Borde general (dark) | `#374151` | Inputs, cards, tablas, separadores |
| Borde hover (dark) | `#4B5563` | Hover de cards/botones |
| Borde focus | `#C05A40` | Input enfocado (terracota) |
| Focus ring | `rgba(192,90,64,.2)` / `.25` | Sombra de focus en inputs |

### 2.8 Tokens base "Arcilla Invernal"

Los crudos de los que deriva toda la paleta:

| Token CSS | Hex | Rol |
|-----------|-----|-----|
| `--terracota` | `#C05A40` | Acento principal |
| `--salmon` | `#E8A68F` | Acento suave / hover |
| `--crema` | `#F7F0EB` | Fondo light / badges |
| `--acero` | `#8FA3B7` | Muted / secundario |
| `--navy` | `#1E2730` | Texto / acento profundo |
| `--terracota-tint` | `rgba(192,90,64,.18)` | Chips, focus ring |

---

## 3. Tipografia

*(Pendiente — proxima seccion a conjurar.)*

## 4. Layout Canonico

*(Pendiente — proxima seccion a conjurar.)*

## 5. Componentes

*(Pendiente — proxima seccion a conjurar.)*

---

## Archivos fuente de verdad (modulo inventory)

| Archivo | Contenido |
|---------|-----------|
| `inventory/src/css/colors.css` | Variables `--primary`, `--secondary`, estados, neutrales, tokens Arcilla Invernal |
| `inventory/src/css/color-palette.css` | Clases de utilidad (`.bg-primary`, `.btn-*`, `.badge-*`, `.alert-*`, gradientes) |
| `inventory/src/css/dark-mode.css` | Tema oscuro completo (`body.dark-mode`) |
| `inventory/src/js/tailwind-theme.js` | Remapeo de la escala `blue` de Tailwind a terracota |
| `inventory/operacion/almacen/uikit/sidebar-uikit.html` | UI kit local del rail re-tematizado |

> Si cambia un hex en esos archivos, actualizar este grimorio. Las demas secciones (tipografia, layout, componentes) se conjuraran en iteraciones siguientes.