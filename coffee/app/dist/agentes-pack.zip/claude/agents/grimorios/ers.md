# ERS — Especificación de Requisitos del Software (formato de la casa)

El ERS es el documento con el que arranca un proyecto: dice **qué se va a construir,
para quién y cuándo se considera terminado**. De él salen después las historias de
usuario (ver `historias-de-usuario.md`, §10).

Fuente: `ERS - SISTEMA DE FACTURACIÓN` (visor, CoffeeSoft/Facturacion/ERS.md).

---

## 1) Estructura del documento

Markdown, con frontmatter y **estas ocho secciones, en este orden y en MAYÚSCULAS**.
No se inventan secciones nuevas ni se renombran.

```markdown
---
name: ERS
description:
date: 2026-08-05
---

ERS - SISTEMA DE <NOMBRE>

## DESCRIPCIÓN BREVE DEL PROYECTO

## OBJETIVO DEL PROYECTO

## SECCIONES DEL PROYECTO

## USUARIOS QUE UTILIZARÁN EL PROYECTO

## ¿EL ÉXITO DEL PROYECTO SE DA CUÁNDO?

## ACCIONES A REALIZAR

## EXCEPCIONES

## OBSERVACIONES
```

### Qué lleva cada sección

| Sección | Contenido |
|---|---|
| **DESCRIPCIÓN BREVE DEL PROYECTO** | Dos o tres párrafos: de qué se encarga el sistema y qué produce. Lenguaje de negocio, sin tecnicismos. |
| **OBJETIVO DEL PROYECTO** | Para qué existe, en términos del negocio (control, ahorro, cumplimiento, visibilidad). Si hay metas numéricas, van aquí. |
| **SECCIONES DEL PROYECTO** | El corazón. Un bloque por **módulo**: nombre (`Módulo de …`, con la pestaña entre corchetes si aplica), una línea de qué hace y **la lista de campos / columnas / apartados**, uno por línea. Es lo que después se convierte en criterios de aceptación. |
| **USUARIOS QUE UTILIZARÁN EL PROYECTO** | Los puestos reales, en MAYÚSCULAS: `ADMINISTRADOR DEL POS`, `CONTABILIDAD`, `GERENTE Y AUXILIAR`, `DEVELOPER`. Uno por línea. |
| **¿EL ÉXITO DEL PROYECTO SE DA CUÁNDO?** | Los escenarios que demuestran que funciona, redactados como capacidades: *"Consultar tickets por fecha: selecciona una fecha y ve…"*. Con números y ejemplos concretos cuando existan. |
| **ACCIONES A REALIZAR** | El plan por fases (`FASE 1: ANÁLISIS`, `FASE 2: ADMINISTRADOR`, `FASE 3: …`), con viñetas de entregables. La fase 1 suele ser base de datos, diagrama ER y templates. |
| **EXCEPCIONES** | Lo que el sistema **no** hace o los casos que quedan fuera del alcance. Puede quedar vacía. |
| **OBSERVACIONES** | Reglas sueltas del negocio que no encajan en un módulo (consecutivos, qué no se muestra, bloqueos por fecha). |

---

## 2) Levantar un ERS desde una carpeta de proyecto

Cuando el usuario conecta una carpeta y pide el ERS, **el documento se levanta de lo
que hay en el disco, no de la imaginación**.

Las herramientas cambian de nombre según dónde estés; usa las que tengas:

| Para | Visor / CoffeeIA | Avatars |
|---|---|---|
| Listar carpeta | `list_dir` | `list_project_files` |
| Leer archivo | `read_file` | `read_project_file` |
| Buscar texto | `grep_files` | *(no hay: se suple leyendo los archivos clave)* |

Procedimiento:

1. **Mapa general** — lista la raíz y las carpetas de trabajo. Interesan:
   `app/`, `src/js/`, `ctrl/`, `mdl/`, `templates/`, `docs/`.
2. **Detectar módulos.** En el framework CoffeeSoft cada módulo deja huella triple:

   | Señal | Qué indica |
   |---|---|
   | `ctrl/ctrl-<modulo>.php` | Un módulo y sus operaciones (los `case` del switch = acciones) |
   | `mdl/mdl-<modulo>.php` | Sus tablas y consultas |
   | `src/js/<modulo>.js` | Sus pantallas: `tabLayout` = pestañas, `createTable` = listados, `createModalForm` = altas |
   | `index.php` / `*.php` de vista | La entrada del módulo |

3. **Sacar los campos reales.** De `createTable` salen las columnas; de
   `createModalForm` los campos del alta; de `createfilterBar` los filtros. Si tienes
   búsqueda de texto, `createTable` / `createModalForm` / `filterBar` / `case '` acortan
   el camino; si no, lee directo el JS de cada módulo.
4. **Detectar los usuarios.** Buscar `ROLID`, `rol`, `perfil`, `subsidiaries_id` para
   saber qué perfiles existen y si el alcance es por unidad de negocio.
5. **Redactar** el ERS con la estructura de §1, un bloque de `SECCIONES DEL PROYECTO`
   por módulo detectado.

### Honestidad del levantamiento

- **Solo se escribe lo que se leyó.** Un módulo que no está en el disco no va en el ERS.
- Lo que no se pudo determinar se dice en `OBSERVACIONES` como pregunta abierta:
  *"No se detectó el perfil que usa el módulo de cortes: confirmar."*
- Si la carpeta trae un módulo a medias (controlador sin JS, o tabs vacíos), se anota
  en `EXCEPCIONES` en vez de completarlo por cuenta propia.
- Al final del documento se listan **los archivos que se leyeron** para levantarlo. Es
  la trazabilidad de dónde salió cada sección.

---

## 3) Cómo se entrega — bloque ` ```ers `

Dentro del **visor / chat de agentes / playground / sandbox** el ERS no se escribe como
prosa: se entrega un **bloque de datos** y la interfaz lo pinta como documento (tema
GitHub: cabecera de archivo, módulos plegables, avisos y tabla de archivos leídos), con
botones para copiar el markdown, descargarlo, guardarlo en el proyecto e imprimirlo.

Es el mismo mecanismo del bloque ` ```stories ` (ver `historias-de-usuario.md` §8).

````
```ers
sistema:   Sistema de Facturación
resumen:   Control de tickets y de los medios de pago asociados a cada transacción.
fecha:     "2026-08-06"
proyecto:  CoffeeSoft / Facturacion
descripcion: |
  Es un sistema que se encarga del control de tickets y sus diferentes medios de
  pago. Su objetivo principal es generar un concentrado ordenado de tickets.
objetivo: |
  Permitir controlar un monto correcto de venta aplicando cálculo de porcentaje.
modulos:
  - nombre:      Módulo de carga de tickets del POS
    pestana:     Pestaña detallado
    descripcion: Sube los tickets seleccionando mes y año.
    campos:
      - Día
      - Fecha de operación
      - Subtotal
usuarios:
  - ADMINISTRADOR DEL POS
exito:
  - titulo: Consultar tickets por fecha
    texto:  Selecciona un día y ve todos los tickets ordenados cronológicamente.
fases:
  - nombre: FASE 1 · ANÁLISIS
    items:
      - Crear la base de datos con los campos requeridos y su diagrama ER
      - Definir las tablas principales que no se modificarán
excepciones:
  - El sistema no timbra facturas: solo concentra y marca los tickets facturados
observaciones:
  - Las notas del día llevan consecutivo y se reinician al día siguiente
archivos:
  - ruta:   ctrl/ctrl-facturacion.php
    lineas: 412
    aporte: Operaciones del módulo
```
````

| Campo | Qué lleva | Sección del §1 |
|---|---|---|
| `sistema` | Nombre del sistema. Encabeza el documento | Título |
| `resumen` | Una línea: de qué va. Va bajo el título | — |
| `fecha` · `proyecto` | Metadatos de la cabecera | Frontmatter |
| `descripcion` | Párrafos. Con `\|` para texto de varias líneas | DESCRIPCIÓN BREVE |
| `objetivo` | Idem | OBJETIVO |
| `modulos[]` | `nombre`, `pestana` (opcional), `descripcion` (opcional) y `campos` | SECCIONES DEL PROYECTO |
| `usuarios[]` | Los puestos, en MAYÚSCULAS | USUARIOS |
| `exito[]` | `titulo` + `texto` por escenario | ¿EL ÉXITO…? |
| `fases[]` | `nombre` + `items` | ACCIONES A REALIZAR |
| `excepciones[]` | Una línea por excepción | EXCEPCIONES |
| `observaciones[]` | Una línea por observación | OBSERVACIONES |
| `archivos[]` | `ruta`, `lineas`, `aporte` — la trazabilidad del §2 | (pie del documento) |

Cuidados:

- Si un valor lleva `:` dentro, **va entre comillas**; para varios párrafos, `|`.
- `fecha` es **la de hoy**, no una inventada. Si no la sabes, deja el campo vacío.
- Un solo bloque por respuesta, y **nada de ` ```stories ` en el mismo mensaje**: el ERS
  y las historias son dos entregables y dos momentos (§4).
- Fuera del visor (documentos, correo, terminal) sigue mandando el markdown de §1.
  La tarjeta ya trae el botón para copiarlo en ese formato.
- Alrededor del bloque, solo una línea de contexto y —si aplica— los supuestos y las
  preguntas abiertas.

---

## 4) Lo que NO se hace

- No se mezcla el ERS con las historias de usuario en la misma respuesta: son dos
  entregables y dos momentos.
- No se describe arquitectura ni nombres de tablas salvo en `ACCIONES A REALIZAR`
  (fase de análisis) — el ERS lo lee el cliente, no solo el desarrollador.
- No se inflan las secciones: si `EXCEPCIONES` no tiene contenido, se deja vacía.
- No se cambia el orden ni el nombre de las ocho secciones.
