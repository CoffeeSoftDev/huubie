# Grimorio de Fuentes (Pivotes de Transmutacion)

Compendio de **pivotes canonicos** que el spell `transmute` de CoffeeMagic reutiliza como base para convertir un HTML aprobado en modulo JS `coffeeSoft`.

> **Tema agnostico:** los pivotes definen **arquitectura JS y formato de data**, NO estilo visual. El tema (huubie / varoch / dark base) lo aporta el HTML fuente.

---

## Como usar este grimorio

El spell `transmute` debe:

1. **Leer este grimorio completo** antes de generar archivos.
2. **Reemplazar placeholders** con los valores reales del modulo:
   - `{modulo}`     → nombre kebab-case (ej. `admin-inventarios`)
   - `{Entidad}`    → PascalCase singular (ej. `AdminItems`)
   - `{entidad}`    → camelCase singular (ej. `adminItems`)
   - `{ENTIDAD}`    → SCREAMING_SNAKE para SAMPLEs (ej. `PRODUCTOS`)
   - `{Project}`    → `PROJECT_NAME` PascalCase (ej. `AdminInventarios`)
   - `{dir}`        → directorio del modulo (ej. `app/inventarios`)
   - `{seccion}`    → titulo legible (ej. `Administrador de Inventarios`)
3. **Verificar con `Grep`** si los componentes locales (`viewHeader`, `viewFooter`, `tabsBar`, `kpisRow`) viven en `app/src/js/coffeeSoft.js`. Si NO, portar 1:1 desde este grimorio. **NUNCA asumir herencia.**

## Origen de los pivotes

| Pivote | Archivo real |
|---|---|
| Modulo tripartita | `app/inventarios/src/js/pos-entradas.js` |
| Sample data | `app/inventarios/src/js/sample_entradas.js` |
| Entry-point | `app/inventarios/pos-entradas.php` |

---

# Pivote 1 — Modulo tripartita `{modulo}.js`

## 1.1 Bootstrap (top del archivo)

```js
let api = 'ctrl/ctrl-{modulo}.php';
let app, {entidad}, {entidad}View;

let turno, subsidiaries_id;

window.updateSession = () => { };


$(async () => {
    {entidad}View = new {Entidad}View(api, 'root');
    {entidad}     = new {Entidad}(api, 'root');
    app           = new App(api, 'root');
    await app.init();
});
```

Reglas:
- 3 variables globales: `app`, `{entidad}`, `{entidad}View` (en ese orden de instanciacion: View → Data → App).
- `App` se instancia ULTIMO porque su `init()` orquesta a los otros dos.
- `await app.init()` en el bootstrap, NO en el constructor.

## 1.2 `class App extends Templates` — orquestador

```js
class App extends Templates {

    // -- Bootstrap --

    constructor(link, divModule) {
        super(link, divModule);
        this.PROJECT_NAME = '{Project}';
        this.subId        = null;
        this.selectedId   = null;
    }

    async init() {
        // MODO FAKE: si hubiera backend -> useFetch({ url:this._link, data:{ opc:'init' } })
        this.dataInit = {
            subsidiaries_id: '',
            sucursales:      SAMPLE_{ENTIDAD}_SUCURSALES,
            // ... otros catalogos
        };
        this.subId      = this.dataInit.subsidiaries_id;
        subsidiaries_id = this.subId;

        this.render();
    }

    render() {
        this.layout();
        this.filterBar();
        {entidad}View.renderHeader(SAMPLE_VIEW_HEADER_{ENTIDAD});
        {entidad}View.renderFooter(SAMPLE_VIEW_FOOTER_{ENTIDAD});
        {entidad}View.renderDetail(null);  // si hay panel detalle
        {entidad}.lsRecords();
        {entidad}.lsKpis();                // si hay KPIs
    }

    // -- Layout --

    layout() {
        const mainPanel = {
            type:  'div',
            id:    'mainPanel',
            class: 'flex-1 flex flex-col overflow-hidden min-w-0 w-full',
            children: [
                { id: 'viewHeader', text: '#viewHeader', class: 'flex items-center justify-between px-4 py-3 bg-[#0E1521] border-b border-[#374151] flex-shrink-0' },
                { id: 'kpisRow',                         class: 'px-3 py-3 bg-[#0E1521] border-b border-[#374151] flex-shrink-0' },
                { id: 'filterBar',                       class: 'px-4 py-3 bg-[#141d2b] border-b border-[#374151] flex-shrink-0' },
                { id: 'tableWrap',  text: '#tableWrap',  class: 'p-3 flex-1' },
                { id: 'viewFooter', text: '#viewFooter', class: 'px-4 py-2 bg-[#141d2b] border-t border-[#374151] flex items-center justify-between flex-shrink-0' }
            ]
        };

        // Panel lateral solo si hay vista detalle
        const detailPanel = {
            type:  'aside',
            id:    'detailPanel',
            class: 'w-full md:w-[420px] flex-shrink-0 bg-[#141d2b] border-t md:border-t-0 md:border-l border-[#374151] flex flex-col overflow-hidden',
            children: [
                { id: 'emptyDetail',   text: '#emptyDetail',   class: 'flex-1 flex flex-col items-center justify-center text-center px-6' },
                { id: 'detailContent', text: '#detailContent', class: 'hidden flex-1 flex flex-col overflow-hidden' }
            ]
        };

        this.createLayout({
            parent: 'root',
            design: false,
            data: {
                id:        this.PROJECT_NAME,
                class:     'mt-16 h-[calc(100vh-4rem)] flex flex-col md:flex-row overflow-hidden overflow-y-auto md:overflow-hidden',
                container: [mainPanel, detailPanel]   // sin detailPanel si no aplica
            }
        });
    }

    // -- Filter bar --

    filterBar() {
        const filters = [
            {
                opc:      'select',
                id:       'fEstado',
                lbl:      'Estado:',
                class:    'col-12 col-md-3 col-lg-2',
                onchange: 'app.onChangeFilters()',
                value:    '',
                data:     SAMPLE_{ENTIDAD}_ESTADOS
            },
            {
                opc:         'input',
                id:          'qBuscar',
                lbl:         'Buscar:',
                class:       'col-12 col-md-3 col-lg-3',
                placeholder: 'Folio, registrado, nota...',
                onkeyup:     'app.onChangeFilters()'
            },
            {
                opc:       'button',
                id:        'btnNuevo',
                text:      'Nuevo registro',
                color_btn: ' bg-purple-600 text-white hover:bg-purple-800',
                class:     'col-12 col-md-3 col-lg-2',
                onClick:   () => {entidad}View.openForm()
            }
        ];

        this.createfilterBar({
            parent: 'filterBar',
            data:   filters
        });
    }

    getFilters() {
        return {
            subsidiaries_id: $('#subsidiaries_id').val() || this.subId || '',
            estado:          $('#fEstado').val()        || '',
            q:               $('#qBuscar').val()        || ''
        };
    }

    // -- Event handlers --

    async onChangeFilters() {
        {entidad}.lsRecords();
        await {entidad}.lsKpis();

        if (this.selectedId && !this.isVisibleAfterFilters(this.selectedId)) {
            this.selectRecord(null);
        }
    }

    updateFooterInfo(text) {
        $('#viewFooter_info').text(text);
    }

    // -- Facade --

    selectRecord(id) {
        this.selectedId = id;
        $(`#tb${this.PROJECT_NAME} tbody tr`).removeClass('row-active');
        if (id) {
            const $row = $(`#tb${this.PROJECT_NAME} tbody tr`).filter(function () {
                return $(this).text().includes(id);
            });
            $row.addClass('row-active');
        }
        {entidad}View.renderDetail(id ? SAMPLE_{ENTIDAD}_DB[id] : null);
    }

    editRecord(id) {
        this.selectRecord(id);
    }
}
```

## 1.3 `class {Entidad} extends Templates` — data layer

```js
class {Entidad} extends Templates {

    // -- Bootstrap --

    constructor(link, divModule) {
        super(link, divModule);
        this.PROJECT_NAME = '{Project}';
    }

    // -- Data --

    lsRecords() {
        // MODO FAKE: si hubiera backend -> useFetch({ data:Object.assign({ opc:'lsRecords' }, app.getFilters()) })
        const f = app.getFilters();
        const filteredRows = (SAMPLE_{ENTIDAD}_TABLE.row || []).filter(r => {
            const e = SAMPLE_{ENTIDAD}_DB[r.id];
            if (!e) return true;
            // logica de filtro segun campos del DB
            const est = !f.estado || e.estado === f.estado;
            const q   = !f.q || (e.folio + ' ' + e.registrado + ' ' + (e.nota || ''))
                                    .toLowerCase()
                                    .includes(f.q.toLowerCase());
            return est && q;
        });

        const data = { row: filteredRows };

        this.createCoffeeTable3({
            parent:       'tableWrap',
            id:           `tb${this.PROJECT_NAME}`,
            theme:        'dark',
            title:        '',
            subtitle:     '',
            center:       [2, 3, 7],
            right:        [4],
            extends:      true,
            scrollable:   false,
            f_size:       12,
            emptyMessage: 'No se encontraron registros con los filtros aplicados',
            emptyIcon:    'icon-arrow-down-to-line',
            data:         data
        });

        if (window.lucide) lucide.createIcons();

        const total = filteredRows.length;
        app.updateFooterInfo(`Mostrando ${total} registro${total !== 1 ? 's' : ''}`);
    }

    async lsKpis() {
        // MODO FAKE: si hubiera backend -> useFetch({ data:Object.assign({ opc:'showKpis' }, app.getFilters()) })
        const f = app.getFilters();
        const visible = Object.values(SAMPLE_{ENTIDAD}_DB).filter(/* filtros */);

        const kpis = [
            { id: 'kpi1', label: 'Total',  value: visible.length, tone: 'success' },
            { id: 'kpi2', label: 'Mes',    value: '$' + 0,        tone: 'default' },
            { id: 'kpi3', label: 'Semana', value: visible.length, tone: 'purple'  },
            { id: 'kpi4', label: 'Princ.', value: '-',            tone: 'info'    }
        ];
        {entidad}View.renderInfoCards(kpis);
    }

    // -- Actions --

    saveRecord(payload) {
        // MODO FAKE: si hubiera backend -> useFetch({ url:this._link, data:{ opc:'saveRecord', ...payload } })
        // logica de save (update si id, insert si no)
        this.lsRecords();
    }

    toggleRecord(id) {
        const e = SAMPLE_{ENTIDAD}_DB[id];
        if (!e) return;
        e.active = e.active ? 0 : 1;
        this.lsRecords();
    }
}
```

## 1.4 `class {Entidad}View extends Templates` — vistas + componentes locales

```js
class {Entidad}View extends Templates {

    // -- Bootstrap --

    constructor(link, divModule) {
        super(link, divModule);
        this.PROJECT_NAME = '{Project}';
    }

    // -- Render helpers --

    renderHeader(data) {
        this.viewHeader({
            parent:   'viewHeader',
            json:     data,
            onToggle: (key, value) => console.log('[viewHeader] toggle', key, '->', value)
        });
    }

    renderFooter(data) {
        this.viewFooter({
            parent: 'viewFooter',
            json:   data
        });
    }

    renderInfoCards(rows) {
        this.kpisRow({
            parent:  'kpisRow',
            json:    rows,
            onClick: (kpi) => console.log('[kpisRow] click', kpi.id)
        });
    }

    renderTabs(activeId) {
        this.tabsBar({
            parent: 'tabsRow',
            json:   SAMPLE_{ENTIDAD}_TABS.map(t => Object.assign({}, t, { active: t.id === activeId })),
            onChange: (tab) => app.onChangeTab(tab.id)
        });
    }

    renderDetail({entidad}) {
        // implementacion segun pivote (panel lateral con datos del registro)
    }

    openForm() {
        if (!this.formApi) this.renderForm();
        this.formApi.open();
    }

    // -- Components (PORTADOS 1:1 — viven aqui porque NO estan en Templates) --

    // ver seccion siguiente para los 4 componentes locales canonicos
}
```

## 1.5 Componentes locales canonicos (portar 1:1 a `{Entidad}View`)

> **Critico:** estos 4 metodos NO viven en `Templates` (`coffeeSoft.js`). Viven dentro de la clase `{Entidad}View`. El spell `transmute` debe portarlos 1:1 sin modificar.

### viewHeader

```js
    viewHeader(options) {
        const defaults = {
            parent: 'root',
            id:     'viewHeader',
            class:  'flex items-center justify-between w-full',
            json:   { title: '', subtitle: '', toggles: [], back: null },
            classes: {
                title:    'text-base font-bold text-white',
                subtitle: 'text-[10px] text-[var(--cs-text-secondary,#D1D5DB)]',
                groupLbl: 'text-[9px] text-[var(--cs-text-muted,#9CA3AF)] uppercase tracking-wider font-bold',
                btn:      'demo-toggle px-2.5 py-1 rounded text-[11px] border border-[var(--cs-border,#374151)] text-[var(--cs-text-secondary,#D1D5DB)] hover:bg-[var(--cs-bg-input,#1F2937)] transition-colors',
                btnActive:'demo-toggle active px-2.5 py-1 rounded text-[11px] border border-[var(--cs-accent-purple,#7C3AED)] bg-[var(--cs-accent-purple,#7C3AED)]/15 text-white',
                sep:      'text-[var(--cs-border,#374151)]',
                backBtn:  'w-8 h-8 rounded-full bg-[var(--cs-bg-input,#1F2937)] hover:bg-[var(--cs-accent-purple,#7C3AED)]/15 border border-[var(--cs-border,#374151)] hover:border-[var(--cs-accent-purple,#7C3AED)] flex items-center justify-center text-[var(--cs-text-secondary,#D1D5DB)] hover:text-white transition-colors flex-shrink-0'
            },
            onToggle: () => { },
            onBack:   null
        };

        const o    = options || {};
        const opts = Object.assign({}, defaults, o);
        opts.json    = Object.assign({}, defaults.json,    o.json    || {});
        opts.classes = Object.assign({}, defaults.classes, o.classes || {});

        const state = {};
        (opts.json.toggles || []).forEach(g => { state[g.key] = g.value; });

        const esc = (str) => String(str == null ? '' : str).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));

        const toggleGroup = (g) => {
            const buttons = (g.options || []).map(op => {
                const active = state[g.key] === op.value;
                return `<button type="button"
                                data-toggle-key="${esc(g.key)}"
                                data-toggle-value="${esc(op.value)}"
                                class="${active ? opts.classes.btnActive : opts.classes.btn}">${esc(op.label)}</button>`;
            }).join('');
            return `
                <div class="flex items-center gap-2">
                    <span class="${opts.classes.groupLbl}">${esc(g.label)}</span>
                    ${buttons}
                </div>
            `;
        };

        const backCfg   = opts.json.back;
        const backHref  = typeof backCfg === 'string' ? backCfg : (backCfg && backCfg.href) || '';
        const backTitle = (backCfg && backCfg.title) || 'Regresar';
        const backHtml  = backCfg ? `
            <button type="button" id="${opts.id}_back" class="${opts.classes.backBtn}" title="${esc(backTitle)}">
                <i data-lucide="chevron-left" class="w-4 h-4"></i>
            </button>
        ` : '';

        const wrap = $('<div>', { id: opts.id, class: opts.class });
        const togglesHtml = (opts.json.toggles || [])
            .map((g, i, arr) => toggleGroup(g) + (i < arr.length - 1 ? `<span class="${opts.classes.sep}">|</span>` : ''))
            .join('');

        wrap.html(`
            <div class="flex items-center gap-3">
                ${backHtml}
                <div>
                    <h1 class="${opts.classes.title}">${esc(opts.json.title)}</h1>
                    ${opts.json.subtitle ? `<p class="${opts.classes.subtitle}">${esc(opts.json.subtitle)}</p>` : ''}
                </div>
            </div>
            <div class="flex items-center gap-4">
                ${togglesHtml}
            </div>
        `);

        $(`#${opts.parent}`).html(wrap);
        if (window.lucide) lucide.createIcons();

        wrap.on('click', '[data-toggle-key]', (e) => {
            const $btn = $(e.currentTarget);
            const key  = $btn.attr('data-toggle-key');
            const val  = $btn.attr('data-toggle-value');
            state[key] = val;

            $btn.siblings('[data-toggle-key="' + key + '"]').addBack().each(function () {
                const isActive  = $(this).attr('data-toggle-value') === val;
                this.className  = isActive ? opts.classes.btnActive : opts.classes.btn;
            });

            opts.onToggle(key, val, Object.assign({}, state));
        });

        if (backCfg) {
            $(`#${opts.id}_back`).on('click', () => {
                if (typeof opts.onBack === 'function') return opts.onBack();
                if (backHref) window.location.href = backHref;
            });
        }
    }
```

### viewFooter

```js
    viewFooter(options) {
        const defaults = {
            parent: 'root',
            id:     'viewFooter',
            class:  'flex items-center justify-between w-full',
            json:   { info: '', legends: [] },
            tones: {
                default: '#9CA3AF',
                success: 'var(--cs-success,#3FC189)',
                warning: 'var(--cs-warning,#FBBF24)',
                danger:  'var(--cs-danger,#E02424)',
                info:    'var(--cs-info,#1C64F2)',
                purple:  'var(--cs-accent-purple,#7C3AED)'
            },
            classes: {
                info:   'text-[10px] text-[var(--cs-text-muted,#9CA3AF)]',
                legend: 'flex items-center gap-3 text-[10px] text-[var(--cs-text-muted,#9CA3AF)]',
                item:   'flex items-center gap-1'
            }
        };

        const o    = options || {};
        const opts = Object.assign({}, defaults, o);
        opts.json    = Object.assign({}, defaults.json,    o.json    || {});
        opts.tones   = Object.assign({}, defaults.tones,   o.tones   || {});
        opts.classes = Object.assign({}, defaults.classes, o.classes || {});

        const esc = (str) => String(str == null ? '' : str).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));

        const toneColor  = (tone) => opts.tones[tone] || opts.tones.default;
        const legendItem = (lg) => `
            <span class="${opts.classes.item}">
                <span class="w-2 h-2 rounded-full" style="background:${toneColor(lg.tone)};"></span>
                ${esc(lg.label)}
            </span>
        `;

        const wrap = $('<div>', { id: opts.id, class: opts.class });
        const legendsHtml = (opts.json.legends || []).map(legendItem).join('');

        wrap.html(`
            <p id="${opts.id}_info" class="${opts.classes.info}">${esc(opts.json.info)}</p>
            <div class="${opts.classes.legend}">${legendsHtml}</div>
        `);

        $(`#${opts.parent}`).html(wrap);
    }
```

### tabsBar

```js
    tabsBar(options) {
        const defaults = {
            parent: 'root',
            id:     'tabsBar',
            class:  'flex items-center gap-1 border-b border-transparent',
            json:   [],
            classes: {
                tab:       'px-3 py-2 text-[11px] font-medium text-[var(--cs-text-muted,#9CA3AF)] border-b-2 border-transparent hover:text-white transition-colors cursor-pointer',
                tabActive: 'px-3 py-2 text-[11px] font-bold text-[var(--cs-accent-purple,#A78BFA)] border-b-2 border-[var(--cs-accent-purple,#7C3AED)] cursor-pointer'
            },
            onChange: () => { }
        };

        const o    = options || {};
        const opts = Object.assign({}, defaults, o);
        opts.classes = Object.assign({}, defaults.classes, o.classes || {});

        const esc = (str) => String(str == null ? '' : str).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));

        const wrap = $('<div>', { id: opts.id, class: opts.class });
        wrap.html((opts.json || []).map(tab => `
            <button type="button"
                    data-tab-id="${esc(tab.id)}"
                    class="${tab.active ? opts.classes.tabActive : opts.classes.tab}">
                ${esc(tab.label)}
            </button>
        `).join(''));

        $(`#${opts.parent}`).html(wrap);

        wrap.on('click', '[data-tab-id]', (e) => {
            const id = $(e.currentTarget).attr('data-tab-id');
            wrap.find('[data-tab-id]').each(function () {
                const isActive = $(this).attr('data-tab-id') === id;
                this.className = isActive ? opts.classes.tabActive : opts.classes.tab;
            });
            const tab = (opts.json || []).find(t => t.id === id);
            opts.onChange(tab || { id });
        });
    }
```

### kpisRow

```js
    kpisRow(options) {
        const defaults = {
            parent: 'root',
            id:     'kpisRow',
            class:  'grid grid-cols-2 md:grid-cols-4 gap-3',
            json:   [],
            labels: { empty: 'Sin indicadores' },
            tones: {
                default: 'text-white',
                success: 'cs-text-success text-[var(--cs-success,#3FC189)]',
                warning: 'cs-text-warning text-[var(--cs-warning,#FBBF24)]',
                danger:  'cs-text-danger  text-[var(--cs-danger,#E02424)]',
                info:    'cs-text-info    text-[var(--cs-info,#1C64F2)]',
                purple:  'cs-text-purple  text-[var(--cs-accent-purple,#7C3AED)]'
            },
            cardClass:  'cs-kpi-card bg-[var(--cs-bg-input,#1F2937)] rounded-lg px-3 py-3 cursor-pointer hover:bg-[var(--cs-bg-header,#141d2b)] transition-colors',
            labelClass: 'cs-kpi-label text-[10px] uppercase tracking-wider font-bold text-[var(--cs-text-muted,#9CA3AF)]',
            valueClass: 'cs-kpi-value text-sm font-bold',
            onClick:    () => { }
        };

        const o    = options || {};
        const opts = Object.assign({}, defaults, o);
        opts.labels = Object.assign({}, defaults.labels, o.labels || {});
        opts.tones  = Object.assign({}, defaults.tones,  o.tones  || {});

        const esc = (str) => String(str == null ? '' : str).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));

        const toneClass = (tone) => opts.tones[tone] || opts.tones.default;

        const kpiCard = (kpi, idx) => {
            const cardId = kpi.id || `${opts.id}_${idx}`;
            return `
                <div id="${cardId}" data-kpi-idx="${idx}" class="${opts.cardClass}">
                    <p class="${opts.labelClass}">${esc(kpi.label)}</p>
                    <p class="${opts.valueClass} ${toneClass(kpi.tone)}" id="${cardId}_value">${esc(kpi.value)}</p>
                </div>
            `;
        };

        const grid = $('<div>', { id: opts.id, class: opts.class });

        if (!opts.json || opts.json.length === 0) {
            grid.html(`
                <p class="col-span-full text-[10px] text-[var(--cs-text-muted,#9CA3AF)] italic text-center py-2">
                    ${esc(opts.labels.empty)}
                </p>
            `);
            $(`#${opts.parent}`).html(grid);
            return;
        }

        grid.html(opts.json.map((kpi, idx) => kpiCard(kpi, idx)).join(''));
        $(`#${opts.parent}`).html(grid);

        grid.find('[data-kpi-idx]').on('click', (e) => {
            const idx = parseInt($(e.currentTarget).attr('data-kpi-idx'), 10);
            const kpi = opts.json[idx];
            opts.onClick(kpi, idx);
        });
    }
```

---

# Pivote 2 — `sample_{modulo}.js`

## 2.1 Headers y footers

```js
const SAMPLE_VIEW_HEADER_{ENTIDAD} = {
    title:    '{Seccion}',
    subtitle: 'Descripcion corta del modulo',
    back:     { href: '/{dir}/index.php', title: 'Regresar al inicio' }
};

const SAMPLE_VIEW_FOOTER_{ENTIDAD} = {
    info: 'Mostrando 3 de 3 registros',
    legends: [
        { tone: 'purple',  label: 'Tipo A' },
        { tone: 'warning', label: 'Tipo B' },
        { tone: 'info',    label: 'Tipo C' },
        { tone: 'danger',  label: 'Tipo D' }
    ]
};
```

## 2.2 Helpers de badges y formato

> Funciones MODULO (prefijo `_`). NO son metodos de clase. Viven al top del sample.

```js
const _badgeTipo = (tipo) => {
    const map = {
        'TipoA': { bg: 'rgba(124,58,237,0.15)', fg: '#A78BFA' },
        'TipoB': { bg: 'rgba(251,191,36,0.15)', fg: '#FBBF24' }
    };
    const c = map[tipo] || { bg: 'rgba(156,163,175,0.18)', fg: '#9CA3AF' };
    return `<span class="px-2 py-0.5 rounded text-[10px] font-bold" style="background:${c.bg};color:${c.fg};">${tipo}</span>`;
};

const _badgeEstado = (estado) => {
    const map = {
        'Activo':   { bg: 'rgba(63,193,137,0.15)', fg: '#3FC189' },
        'Inactivo': { bg: 'rgba(244,63,94,0.15)',  fg: '#F43F5E' }
    };
    const c = map[estado] || { bg: 'rgba(156,163,175,0.18)', fg: '#9CA3AF' };
    return `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold" style="background:${c.bg};color:${c.fg};">${estado.toUpperCase()}</span>`;
};

const _fmtMoneyShort = (n) => '$' + Number(n).toLocaleString('en-US');
const _fmtMoney      = (n) => '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const _DOW_ES = ['Dom','Lun','Mar','Mie','Jue','Vie','Sab'];
const _MON_ES = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const _fmtFechaCorta = (iso) => {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    const dow = _DOW_ES[d.getDay()];
    const day = String(d.getDate()).padStart(2, '0');
    const mon = _MON_ES[d.getMonth()];
    let h     = d.getHours();
    const m   = String(d.getMinutes()).padStart(2, '0');
    const ampm = h >= 12 ? 'pm' : 'am';
    h = h % 12 || 12;
    return `${dow} ${day} ${mon} ${String(h).padStart(2, '0')}:${m} ${ampm}`;
};
```

## 2.3 `SAMPLE_{ENTIDAD}_DB` (objeto indexado)

> Indexar por **folio/sku/id natural** (string preferible si la entidad tiene folio).

```js
const SAMPLE_{ENTIDAD}_DB = {
    'REG-001': {
        folio:       'REG-001',
        tipo:        'TipoA',
        sucursal:    'Sucursal 1',
        sucursalId:  'suc1',
        registrado:  'Admin',
        fechaIso:    '2026-04-04T08:30:00',
        estado:      'Activo',
        nota:        'Texto descriptivo',
        items: [
            { nombre: 'Item 1', sku: 'SKU-001', cant: 24, costo: 22 },
            { nombre: 'Item 2', sku: 'SKU-002', cant: 10, costo: 280 }
        ]
    }
    // ... 2-6 registros mas
};

const _totalsOf = (e) => {
    const uds   = (e.items || []).reduce((s, p) => s + Number(p.cant  || 0), 0);
    const costo = (e.items || []).reduce((s, p) => s + Number(p.cant  || 0) * Number(p.costo || 0), 0);
    return { uds, costo };
};
```

## 2.4 `_{entidad}Row` + `SAMPLE_{ENTIDAD}_TABLE`

```js
const _{entidad}Row = (e) => {
    const { uds, costo } = _totalsOf(e);
    return {
        id:          e.folio,
        Folio:       `<span class="text-xs font-bold text-green-400">${e.folio}</span>`,
        Tipo:        _badgeTipo(e.tipo),
        Items:       `<span class="text-xs font-bold">${e.items.length}</span>`,
        'Total Uds': `<span class="text-xs font-bold">${uds}</span>`,
        'Costo':     `<span class="text-xs font-bold">${_fmtMoneyShort(costo)}</span>`,
        Registrado:  `<span class="text-[10px] text-gray-400">${e.registrado}</span>`,
        Fecha:       `<span class="text-[10px] text-gray-500 whitespace-nowrap">${_fmtFechaCorta(e.fechaIso)}</span>`,
        Estado:      _badgeEstado(e.estado),
        a: [
            { class: 'inline-flex items-center justify-center w-7 h-7 rounded text-[12px] transition-colors me-1 bg-slate-600 hover:bg-slate-500 text-white', html: '<i class="icon-eye"></i>',    onclick: `app.selectRecord('${e.folio}')` },
            { class: 'inline-flex items-center justify-center w-7 h-7 rounded text-[12px] transition-colors me-1 bg-red-600 hover:bg-red-500 text-white',     html: '<i class="icon-pencil"></i>', onclick: `app.editRecord('${e.folio}')` }
        ]
    };
};

const SAMPLE_{ENTIDAD}_TABLE = {
    row: Object.values(SAMPLE_{ENTIDAD}_DB).map(_{entidad}Row)
};
```

## 2.5 `SAMPLE_{ENTIDAD}_COUNTS` (opcional, para KPIs)

```js
const SAMPLE_{ENTIDAD}_COUNTS = (() => {
    const all      = Object.values(SAMPLE_{ENTIDAD}_DB);
    const totals   = all.map(_totalsOf);
    const costoTot = totals.reduce((s, t) => s + t.costo, 0);
    const tipoCount = {};
    all.forEach(e => { tipoCount[e.tipo] = (tipoCount[e.tipo] || 0) + 1; });
    const principal = Object.keys(tipoCount).reduce(
        (a, b) => (tipoCount[a] > tipoCount[b] ? a : b),
        Object.keys(tipoCount)[0] || '-'
    );
    return {
        total:        all.length,
        total_costo:  costoTot,
        total_semana: all.length,
        principal:    principal
    };
})();
```

## 2.6 Catalogos (`{ id, valor }`)

```js
const SAMPLE_{ENTIDAD}_SUCURSALES = [
    { id: '',     valor: 'Todas las sucursales' },
    { id: 'suc1', valor: 'Sucursal 1'           },
    { id: 'suc2', valor: 'Sucursal 2'           }
];

const SAMPLE_{ENTIDAD}_TIPOS = [
    { id: '',      valor: 'Todos los tipos' },
    { id: 'TipoA', valor: 'TipoA'           },
    { id: 'TipoB', valor: 'TipoB'           }
];

const SAMPLE_{ENTIDAD}_ESTADOS = [
    { id: '',         valor: 'Todos los estados' },
    { id: 'Activo',   valor: 'Activo'            },
    { id: 'Inactivo', valor: 'Inactivo'          }
];

const SAMPLE_{ENTIDAD}_TABS = [
    { id: 'tab1', label: 'Tab 1', active: true  },
    { id: 'tab2', label: 'Tab 2', active: false }
];
```

---

# Pivote 3 — `{modulo}.php` entry-point

```php
<?php require_once("../conf/_Rutes.php"); ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/svg+xml" href="/app/src/img/logo/logo.ico" />
    <title>{Seccion}</title>

    <?php require_once(__DIR__ . '/../layout/head.php'); ?>
    <?php require_once(__DIR__ . '/../layout/core-libraries.php'); ?>
</head>

<body class="bg-[#111928] text-white" data-bs-theme="dark">
    <div id="menu-navbar"></div>
    <div id="menu-sidebar"></div>

    <div id="mainContainer" class="w-full h-full transition-all duration-500 bg-[#111928] text-white mt-16">
        <div class="bg-[#111928]" id="root"></div>
    </div>

    <script src="/{dir}/src/js/sample_{modulo}.js?t=<?php echo time(); ?>"></script>
    <script src="/{dir}/src/js/{modulo}.js?t=<?php echo time(); ?>"></script>
</body>

</html>
```

**Reglas:**
- 1 sola linea de `<?php require_once("../conf/_Rutes.php"); ?>` al top.
- `head.php` y `core-libraries.php` siempre incluidos via `__DIR__`.
- Scripts en orden estricto: `sample_{modulo}.js` **PRIMERO**, `{modulo}.js` **DESPUES**.
- Cache busting `?t=<?php echo time(); ?>` en ambos scripts.
- `data-bs-theme="dark"` en el body para integrarse con el navbar/sidebar.

---

# Reglas criticas del spell `transmute`

1. **Lee el grimorio completo** antes de generar archivos — no inventes la arquitectura.
2. **Verifica con `Grep`** que cada componente local (`viewHeader`, `viewFooter`, `tabsBar`, `kpisRow`) NO viva ya en `Templates`. Si no esta, portarlo 1:1 desde la seccion 1.5.
3. **Sin banners decorativos** `// ════════` ni descriptores de clase `// Clase: X hace Y` (ver feedback `feedback_no_class_banner_comments`).
4. **Sin tildes/caracteres especiales** en strings — usa "Devolucion" no "Devolución".
5. **`SAMPLE_*` al top** del archivo sample, NUNCA en el modulo principal (ver feedback `feedback_sample_pattern`).
6. **`.php` carga sample ANTES** del modulo principal.
7. **`node --check`** debe pasar en ambos JS sin errores antes de cerrar el conjuro.
8. **Componentes con `json`/arrays** → `Object.assign` para merge, NUNCA `this.ObjectMerge` (rompe arrays).
9. **NUNCA prefijo `_`** en metodos de clase. Los `_helpers` del sample SON funciones modulo, no metodos.
10. **Tema visual heredado** del HTML fuente — el spell NO cambia colores ni clases CSS, solo extrae estructura.