---
name: grimorio-coffee-varoch
description: Grimorio AUTOCONTENIDO del sistema de diseno Coffee-Varoch (Grupo Varoch). Paleta institucional #003360 + clases .cv-* + light/dark + estructura header-azul/sidebar-blanco. Incluye CSS completo embebido + snippets HTML por componente. Portable entre proyectos.
type: reference
spell: coffee-varoch
domain: varoch
---

# Grimorio: Coffee-Varoch (Sistema Institucional Grupo Varoch)

> **Grimorio AUTOCONTENIDO** — contiene todo el CSS y los snippets HTML necesarios para generar templates Coffee-Varoch en CUALQUIER proyecto sin dependencias externas.
>
> **Diferencia con otros grimorios:**
> - `grimorio-finanzas` / `grimorio-rrhh` — dominios de NEGOCIO especificos del ERP.
> - `grimorio-huubie-ui` — sistema de diseno **dark unico** con clases `.cs-*` para el producto Huubie.
> - **`grimorio-coffee-varoch`** — sistema de diseno **institucional Grupo Varoch** con clases `.cv-*`, soporte light+dark, header azul + sidebar blanco. CSS embebido + snippets HTML autocontenidos.

---

## 1. Filosofia del Sistema

- **Doble tema:** Light (default) + Dark. Toggle automatico con `data-theme="dark"` sobre `<body class="coffee-varoch">`.
- **Tecnologia:** HTML estatico con Tailwind CSS v3 (CDN) + clases utilitarias CSS custom (prefijo `.cv-*`) embebidas en `<style>`.
- **Fuente:** Inter (Google Fonts).
- **Iconografia:** SVG inline estilo Lucide/Heroicons. Coexiste con Fontello (clases `icon-*`) cuando el usuario ya tiene esa fuente cargada — pero el grimorio NO depende de Fontello.
- **Identidad visual:** Header **AZUL** institucional + Sidebar **BLANCO**. Nunca invertir.
- **CSS maestro:** embebido en la seccion 3 (copy-paste). No requiere archivo externo.

### Triggers de activacion del grimorio

CoffeeMagic carga este grimorio cuando el usuario menciona:
- `"varoch"`, `"coffee-varoch"`, `"paleta varoch"`, `"tema varoch"`
- `"estilo varoch"`, `"institucional varoch"`, `"grupo varoch"`
- Clases `.cv-*` (cv-card, cv-btn, cv-header-primary, etc.)

---

## 2. Paleta Institucional REAL

### Colores Principales

| Variable CSS | Hex | Uso |
|---|---|---|
| `--cv-primary` | **`#003360`** | Azul institucional Grupo Varoch — header, badges primary, titulos |
| `--cv-secondary` | **`#F24444`** | Rojo Varoch — acentos, alertas suaves |
| `--cv-info` | `#0078D7` | Estados de proceso, enlaces, badges info |
| `--cv-success` | **`#7AAB20`** | Verde oliva — exito, confirmaciones, badges success |
| `--cv-danger` | **`#9E1B32`** | Rojo oscuro — alertas criticas, eliminar |
| `--cv-warning` | `#FFC107` | Advertencias, pendientes |
| `--cv-disabled` | `#494C50` | Elementos deshabilitados |
| `--cv-middle` | `#AAD3EB` | Azul claro institucional |
| `--cv-aliceblue` | `#FAFCFF` | Fondo super claro |
| `--cv-default-bg` | `#F2F5F9` | Gris fondo modulos |

### Colores Action (variantes interactivas modernas)

| Variable | Hex | Uso |
|---|---|---|
| `--cv-action` | `#2563EB` | Links, botones de accion, iconos interactivos |
| `--cv-action-hover` | `#1D4ED8` | Hover de action |
| `--cv-accent` | `#60A5FA` | Acentos en hover/active |
| `--cv-soft` | `#FE9834` | Avisos suaves |

### Light Theme (default)

| Variable | Hex |
|---|---|
| `--cv-bg` | `#F2F5F9` |
| `--cv-card` | `#FFFFFF` |
| `--cv-border` | `#E2E8F0` |
| `--cv-text` | `#0F172A` |
| `--cv-muted` | `#64748B` |
| `--cv-label` | `#475569` |
| `--cv-input-bg` | `#F8FAFC` |
| `--cv-input-border` | `#CBD5E1` |
| `--cv-sidebar` | `#FFFFFF` |
| `--cv-header` | `#FFFFFF` |
| `--cv-hover` | `rgba(37, 99, 235, .08)` |

### Dark Theme (`[data-theme="dark"]`)

| Variable | Hex |
|---|---|
| `--cv-bg` | `#111928` |
| `--cv-card` | `#1F2A37` |
| `--cv-border` | `#374151` |
| `--cv-text` | `#F8FAFC` |
| `--cv-muted` | `#94A3B8` |
| `--cv-label` | `#CBD5E1` |
| `--cv-input-bg` | `#1A2332` |
| `--cv-input-border` | `#374151` |
| `--cv-sidebar` | `#E9ECF1` (sidebar sigue claro en dark) |
| `--cv-header` | `#00264A` (azul mas profundo) |

---

## 3. CSS Maestro Completo (EMBEBIDO)

Copia este bloque integro dentro de `<style>` en el `<head>` del template. NO requiere archivos externos.

```css
/* ════════════════════════════════════════════════════════════════════
   Coffee-Varoch — Sistema de diseno institucional Grupo Varoch
   Paleta institucional · Clases prefijadas .cv-*
   ════════════════════════════════════════════════════════════════════ */

/* === VARIABLES BASE === */
.coffee-varoch {
    /* Paleta institucional real */
    --cv-primary:        #003360;     /* AZUL Varoch real */
    --cv-secondary:      #F24444;     /* ROJO Varoch real */
    --cv-info:           #0078D7;
    --cv-success:        #7AAB20;     /* verde oliva real */
    --cv-danger:         #9E1B32;     /* rojo oscuro real */
    --cv-warning:        #FFC107;
    --cv-disabled:       #494C50;
    --cv-middle:         #AAD3EB;     /* azul claro */
    --cv-aliceblue:      #FAFCFF;     /* fondo super claro */
    --cv-default-bg:     #F2F5F9;     /* gris fondo modulos */

    /* Action (links/botones interactivos) — variante moderna del primary */
    --cv-action:         #2563EB;
    --cv-action-hover:   #1D4ED8;
    --cv-accent:         #60A5FA;
    --cv-soft:           #FE9834;

    /* Light (default) */
    --cv-bg:             var(--cv-default-bg);
    --cv-card:           #FFFFFF;
    --cv-border:         #E2E8F0;
    --cv-text:           #0F172A;
    --cv-muted:          #64748B;
    --cv-label:          #475569;
    --cv-input-bg:       #F8FAFC;
    --cv-input-border:   #CBD5E1;
    --cv-sidebar:        #FFFFFF;
    --cv-header:         #FFFFFF;
    --cv-hover:          rgba(37, 99, 235, .08);
    --cv-shadow:         0 2px 8px rgba(15, 23, 42, .06);
}

/* === DARK MODE === */
.coffee-varoch[data-theme="dark"],
body.coffee-varoch[data-theme="dark"] {
    --cv-bg:             #111928;
    --cv-card:           #1F2A37;
    --cv-border:         #374151;
    --cv-text:           #F8FAFC;
    --cv-muted:          #94A3B8;
    --cv-label:          #CBD5E1;
    --cv-input-bg:       #1A2332;
    --cv-input-border:   #374151;
    --cv-sidebar:        #E9ECF1;
    --cv-header:         #00264A;
    --cv-hover:          rgba(96, 165, 250, .1);
    --cv-shadow:         0 2px 12px rgba(0, 0, 0, .35);
}

/* === RESET / LAYOUT === */
.cv-page {
    background: var(--cv-bg);
    color: var(--cv-text);
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    min-height: 100vh;
    transition: background .2s ease, color .2s ease;
}

/* === SCROLLBAR === */
.cv-scroll::-webkit-scrollbar       { width: 6px; height: 6px; }
.cv-scroll::-webkit-scrollbar-track { background: transparent; }
.cv-scroll::-webkit-scrollbar-thumb { background: var(--cv-border); border-radius: 6px; }
.cv-scroll::-webkit-scrollbar-thumb:hover { background: var(--cv-action); }

/* === TIPOGRAFIA === */
.cv-title  { color: var(--cv-primary); font-weight: 700; }
.cv-text   { color: var(--cv-text); }
.cv-muted  { color: var(--cv-muted); }
.cv-label  { color: var(--cv-label); font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .03em; }

.coffee-varoch[data-theme="dark"] .cv-title { color: var(--cv-accent); }

/* ════════════════════════════════════════════════════════════════════
   SIDEBAR — Varoch usa SIDEBAR BLANCO con shadow azulada
   ════════════════════════════════════════════════════════════════════ */
.cv-sidebar {
    background: var(--cv-sidebar);
    box-shadow: -5px 0 20px rgba(0, 51, 96, .5);
    transition: width .5s ease, background .2s ease;
    overflow: hidden;
}
.cv-sidebar.collapsed { width: 0 !important; }

.cv-nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 9px 14px;
    border-radius: 6px;
    color: var(--cv-text);
    font-size: 12.5px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: .15s;
    position: relative;
}
.cv-nav-item:hover {
    background: var(--cv-primary);
    color: #fff;
}
.cv-nav-item:hover svg { color: #fff; }
.cv-nav-item.active {
    background: var(--cv-primary);
    color: #fff;
    box-shadow: 0 2px 8px rgba(0, 51, 96, .25);
}
.cv-nav-item.active svg { color: #fff; }

/* Dark: el sidebar mantiene fondo claro pero un poco mas tenue */
.coffee-varoch[data-theme="dark"] .cv-sidebar {
    background: #E9ECF1;
    box-shadow: -5px 0 20px rgba(0, 0, 0, .55);
}
.coffee-varoch[data-theme="dark"] .cv-sidebar .cv-nav-item { color: #1F2937; }
.coffee-varoch[data-theme="dark"] .cv-sidebar .cv-text { color: #1F2937; }
.coffee-varoch[data-theme="dark"] .cv-sidebar .cv-muted { color: #6B7280; }

/* ════════════════════════════════════════════════════════════════════
   HEADER — Varoch usa HEADER AZUL INSTITUCIONAL (top bar 50px)
   .cv-header  → neutro (kit, login, paginas sin chrome)
   .cv-header-primary → variante institucional azul (POR DEFECTO en modulos)
   ════════════════════════════════════════════════════════════════════ */
.cv-header {
    background: var(--cv-header);
    border-bottom: 1px solid var(--cv-border);
    transition: background .2s ease, border-color .2s ease;
}

.cv-header-primary {
    background: var(--cv-primary);
    border-bottom: 1px solid rgba(0, 0, 0, .25);
    color: #fff;
    height: 50px;
    display: flex;
    align-items: center;
}
.cv-header-primary .cv-title,
.cv-header-primary .cv-text { color: #fff; }
.cv-header-primary .cv-muted { color: rgba(255, 255, 255, .65); }
.cv-header-primary .cv-breadcrumb a { color: rgba(255, 255, 255, .75); }
.cv-header-primary .cv-breadcrumb a:hover { color: #fff; }
.cv-header-primary .cv-breadcrumb-sep { color: rgba(255, 255, 255, .35); }
.cv-header-primary .cv-btn-ghost {
    color: rgba(255, 255, 255, .85);
    background: rgba(255, 255, 255, .08);
    border: 1px solid rgba(255, 255, 255, .12);
}
.cv-header-primary .cv-btn-ghost:hover { background: rgba(255, 255, 255, .18); color: #fff; }

/* Boton hamburguesa del header (toggle sidebar) */
.cv-header-toggle {
    background: none;
    border: none;
    color: rgba(255, 255, 255, .9);
    cursor: pointer;
    width: 38px; height: 38px;
    display: flex; align-items: center; justify-content: center;
    border-radius: 6px;
    transition: .15s;
    flex-shrink: 0;
}
.cv-header-toggle:hover { background: rgba(255, 255, 255, .12); color: #fff; }

/* Logo blanco en el header */
.cv-header-logo {
    height: 28px; max-height: 80%;
    display: block;
    cursor: pointer;
}

/* Dark: header azul mas profundo */
.coffee-varoch[data-theme="dark"] .cv-header-primary {
    background: #00264A;
    border-bottom-color: rgba(0, 0, 0, .4);
}

/* User menu dentro del header */
.cv-header-user {
    display: flex; align-items: center; gap: 10px;
    padding: 4px 10px;
    border-radius: 8px;
    cursor: pointer;
    color: #fff;
    transition: .15s;
}
.cv-header-user:hover { background: rgba(255, 255, 255, .1); }
.cv-header-user .cv-header-avatar {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: rgba(255, 255, 255, .15);
    display: flex; align-items: center; justify-content: center;
    color: #fff;
    flex-shrink: 0;
}
.cv-header-user .cv-header-username { font-size: 12.5px; color: #fff; font-weight: 500; }

/* Iconos navbar (notificaciones, mail, etc.) */
.cv-header-icon {
    width: 36px; height: 36px;
    display: flex; align-items: center; justify-content: center;
    border-radius: 8px;
    color: rgba(255, 255, 255, .8);
    cursor: pointer;
    transition: .15s;
    position: relative;
}
.cv-header-icon:hover { background: rgba(255, 255, 255, .1); color: #fff; }
.cv-header-icon-badge {
    position: absolute;
    top: 2px; right: 4px;
    width: 8px; height: 8px;
    background: #f43f5e;
    border-radius: 50%;
    border: 2px solid var(--cv-primary);
}

/* ════════════════════════════════════════════════════════════════════
   BREADCRUMB del modulo (debajo del header, dentro de #main__content)
   ════════════════════════════════════════════════════════════════════ */
.cv-module-breadcrumb {
    padding: 12px 20px 6px;
    background: transparent;
    margin: 0;
    list-style: none;
    display: flex; align-items: center; gap: 6px;
    font-size: 12px;
}
.cv-module-breadcrumb-item {
    display: inline-flex; align-items: center;
}
.cv-module-breadcrumb-item.text-uppercase { text-transform: uppercase; letter-spacing: .04em; }
.cv-module-breadcrumb-item.text-muted { color: var(--cv-muted); }
.cv-module-breadcrumb-item.active {
    color: var(--cv-primary);
    font-weight: 700;
}
.coffee-varoch[data-theme="dark"] .cv-module-breadcrumb-item.active { color: var(--cv-accent); }
.cv-module-breadcrumb-item + .cv-module-breadcrumb-item::before {
    content: "/";
    color: var(--cv-muted);
    opacity: .5;
    margin: 0 8px;
}

/* ════════════════════════════════════════════════════════════════════
   MAIN CONTAINER — fondo blanco con border-radius
   ════════════════════════════════════════════════════════════════════ */
.cv-main-container {
    background: var(--cv-card);
    border-radius: 10px;
    padding: 16px;
    margin: 6px 14px 14px;
    box-shadow: var(--cv-shadow);
    transition: background .2s ease;
}

/* === CARDS === */
.cv-card {
    background: var(--cv-card);
    border: 1px solid var(--cv-border);
    border-radius: 12px;
    box-shadow: var(--cv-shadow);
    transition: .2s ease;
}
.cv-card.cv-card-hover:hover {
    border-color: var(--cv-action);
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(37, 99, 235, .15);
}

/* === INPUTS === */
.cv-input,
.cv-select,
.cv-textarea {
    width: 100%;
    background: var(--cv-input-bg);
    border: 1px solid var(--cv-input-border);
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 12.5px;
    color: var(--cv-text);
    transition: .15s;
    font-family: inherit;
}
.cv-input:focus,
.cv-select:focus,
.cv-textarea:focus {
    outline: none;
    border-color: var(--cv-action);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .15);
}
.cv-input::placeholder { color: var(--cv-muted); opacity: .7; }
.cv-textarea { resize: vertical; min-height: 80px; }

/* === BOTONES === */
.cv-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 6px;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 12.5px;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid transparent;
    transition: .15s;
    text-decoration: none;
    white-space: nowrap;
}
.cv-btn-primary { background: var(--cv-primary); color: #fff; }
.cv-btn-primary:hover { background: #00264a; transform: translateY(-1px); }

.cv-btn-action { background: var(--cv-action); color: #fff; }
.cv-btn-action:hover { background: var(--cv-action-hover); transform: translateY(-1px); }

.cv-btn-success { background: var(--cv-success); color: #fff; }
.cv-btn-success:hover { background: #62881a; }

.cv-btn-danger { background: var(--cv-danger); color: #fff; }
.cv-btn-danger:hover { background: #7d1527; }

.cv-btn-outline-action { background: transparent; color: var(--cv-action); border-color: var(--cv-action); }
.cv-btn-outline-action:hover { background: var(--cv-action); color: #fff; }

.cv-btn-ghost { background: transparent; color: var(--cv-muted); }
.cv-btn-ghost:hover { background: var(--cv-hover); color: var(--cv-action); }

.cv-btn-sm { padding: 5px 10px; font-size: 11.5px; }
.cv-btn-lg { padding: 11px 22px; font-size: 14px; }

/* === BADGES === */
.cv-badge {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 3px 10px;
    border-radius: 9999px;
    font-size: 10.5px;
    font-weight: 600;
    border: 1px solid;
    line-height: 1;
}
.cv-badge-success {
    background: rgba(122, 171, 32, .15);
    color: var(--cv-success);
    border-color: rgba(122, 171, 32, .35);
}
.cv-badge-warning {
    background: rgba(255, 193, 7, .15);
    color: #b45309;
    border-color: rgba(255, 193, 7, .4);
}
.cv-badge-danger {
    background: rgba(158, 27, 50, .15);
    color: var(--cv-danger);
    border-color: rgba(158, 27, 50, .35);
}
.cv-badge-info {
    background: rgba(0, 120, 215, .12);
    color: var(--cv-info);
    border-color: rgba(0, 120, 215, .35);
}
.cv-badge-neutral {
    background: rgba(100, 116, 139, .15);
    color: var(--cv-muted);
    border-color: rgba(100, 116, 139, .3);
}
.cv-badge-primary {
    background: rgba(0, 51, 96, .12);
    color: var(--cv-primary);
    border-color: rgba(0, 51, 96, .35);
}
.cv-badge-action {
    background: rgba(37, 99, 235, .12);
    color: var(--cv-action);
    border-color: rgba(37, 99, 235, .35);
}

.coffee-varoch[data-theme="dark"] .cv-badge-warning { color: #fbbf24; }
.coffee-varoch[data-theme="dark"] .cv-badge-primary { color: var(--cv-accent); }

/* === TABLAS ===
   Las tablas Varoch NO usan clase .cv-table. Se renderizan con puro Tailwind
   identico al output del createCoffeTable3 de CoffeeSoft.
   Solo se conserva el helper .ct3-hoverable para replicar hover:bg-blue-500/8. */
.ct3-hoverable:hover { background-color: rgba(59, 130, 246, .08); }

/* === CHIPS === */
.cv-chip {
    display: inline-flex; align-items: center; gap: 4px;
    background: var(--cv-input-bg);
    border: 1px solid var(--cv-border);
    color: var(--cv-text);
    font-size: 11px;
    font-weight: 500;
    padding: 3px 10px;
    border-radius: 9999px;
}
.cv-chip-action {
    background: rgba(37, 99, 235, .1);
    color: var(--cv-action);
    border-color: rgba(37, 99, 235, .3);
}
.cv-chip-x { cursor: pointer; opacity: .6; }
.cv-chip-x:hover { opacity: 1; color: var(--cv-danger); }

/* === MODAL === */
.cv-modal-overlay {
    position: fixed; inset: 0;
    background: rgba(15, 23, 42, .55);
    backdrop-filter: blur(3px);
    display: flex; align-items: center; justify-content: center;
    z-index: 100;
    padding: 16px;
}
.cv-modal {
    background: var(--cv-card);
    border: 1px solid var(--cv-border);
    border-radius: 14px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, .25);
    width: 100%;
    max-height: 92vh;
    overflow: hidden;
    display: flex; flex-direction: column;
}
.cv-modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--cv-border);
    display: flex; align-items: center; justify-content: space-between;
}
.cv-modal-body { padding: 18px 20px; overflow-y: auto; flex: 1; }
.cv-modal-footer {
    padding: 14px 20px;
    border-top: 1px solid var(--cv-border);
    display: flex; gap: 8px; justify-content: flex-end;
    background: var(--cv-input-bg);
}

/* === PROGRESS BAR === */
.cv-progress {
    width: 100%;
    height: 6px;
    background: var(--cv-input-bg);
    border-radius: 9999px;
    overflow: hidden;
    border: 1px solid var(--cv-border);
}
.cv-progress-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--cv-action), var(--cv-info));
    border-radius: 9999px;
    transition: width .3s ease;
}
.cv-progress-bar.cv-progress-success {
    background: linear-gradient(90deg, var(--cv-success), #5d8418);
}
.cv-progress-bar.cv-progress-warning {
    background: linear-gradient(90deg, var(--cv-warning), var(--cv-soft));
}

/* === KPI CARD === */
.cv-kpi {
    background: var(--cv-card);
    border: 1px solid var(--cv-border);
    border-radius: 12px;
    padding: 16px;
    display: flex; flex-direction: column; gap: 6px;
    transition: .2s;
}
.cv-kpi:hover { border-color: var(--cv-action); transform: translateY(-2px); }
.cv-kpi-label { font-size: 11px; color: var(--cv-muted); font-weight: 600; text-transform: uppercase; letter-spacing: .04em; }
.cv-kpi-value { font-size: 24px; color: var(--cv-primary); font-weight: 800; line-height: 1.1; }
.coffee-varoch[data-theme="dark"] .cv-kpi-value { color: var(--cv-accent); }
.cv-kpi-foot  { font-size: 11px; color: var(--cv-muted); }

/* === TOGGLE THEME BUTTON === */
.cv-theme-toggle {
    display: inline-flex;
    background: var(--cv-input-bg);
    border: 1px solid var(--cv-border);
    border-radius: 8px;
    padding: 3px;
}
.cv-theme-btn {
    padding: 4px 12px;
    font-size: 11px;
    border-radius: 5px;
    color: var(--cv-muted);
    cursor: pointer;
    border: none;
    background: transparent;
    transition: .15s;
}
.cv-theme-btn.active {
    background: var(--cv-action);
    color: #fff;
}

/* === RADIO / CHECKBOX VISUAL === */
.cv-radio-card {
    border: 1.5px solid var(--cv-border);
    border-radius: 10px;
    padding: 12px 14px;
    cursor: pointer;
    transition: .15s;
    background: var(--cv-card);
}
.cv-radio-card:hover { border-color: var(--cv-action); background: var(--cv-hover); }
.cv-radio-card.active {
    border-color: var(--cv-action);
    background: rgba(37, 99, 235, .08);
}

/* === BREADCRUMB === */
.cv-breadcrumb {
    display: flex; align-items: center; gap: 6px;
    font-size: 12px;
    color: var(--cv-muted);
}
.cv-breadcrumb a {
    color: var(--cv-action);
    text-decoration: none;
    cursor: pointer;
}
.cv-breadcrumb a:hover { text-decoration: underline; }
.cv-breadcrumb-sep { color: var(--cv-border); }

/* === ESTADO PREGUNTAS (CALIDAD) === */
.cv-question {
    border: 1.5px solid var(--cv-border);
    border-radius: 10px;
    padding: 14px 16px;
    background: var(--cv-card);
    transition: .2s;
}
.cv-question.answered {
    border-color: rgba(122, 171, 32, .4);
    background: rgba(122, 171, 32, .08);
}
.coffee-varoch[data-theme="dark"] .cv-question.answered {
    background: rgba(122, 171, 32, .06);
    border-color: rgba(122, 171, 32, .35);
}

.cv-q-btn {
    width: 72px;
    padding: 9px 12px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    border: 1.5px solid;
    transition: .15s;
    background: var(--cv-card);
}
.cv-q-yes { color: var(--cv-success); border-color: rgba(122, 171, 32, .4); }
.cv-q-yes:hover, .cv-q-yes.active { background: var(--cv-success); color: #fff; border-color: var(--cv-success); }
.cv-q-no  { color: var(--cv-danger);  border-color: rgba(158, 27, 50, .4); }
.cv-q-no:hover, .cv-q-no.active { background: var(--cv-danger); color: #fff; border-color: var(--cv-danger); }

/* === GROUP CARDS (3 NIVELES) === */
.cv-group-card {
    border: 1.5px solid var(--cv-border);
    border-radius: 12px;
    padding: 16px;
    cursor: pointer;
    background: var(--cv-card);
    transition: .2s;
    display: flex; flex-direction: column; gap: 8px;
}
.cv-group-card:hover {
    border-color: var(--cv-action);
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(37, 99, 235, .12);
}
.cv-group-card.complete {
    border-color: var(--cv-success);
    background: rgba(122, 171, 32, .08);
}
.cv-group-card.direct {
    background: rgba(254, 152, 52, .08);
    border-color: rgba(254, 152, 52, .35);
}
.coffee-varoch[data-theme="dark"] .cv-group-card.direct {
    background: rgba(254, 152, 52, .08);
}

/* === EMPTY STATE === */
.cv-empty {
    text-align: center;
    padding: 48px 24px;
    color: var(--cv-muted);
}
.cv-empty-icon {
    width: 56px; height: 56px;
    margin: 0 auto 12px;
    border-radius: 50%;
    background: var(--cv-input-bg);
    display: flex; align-items: center; justify-content: center;
    color: var(--cv-muted);
}

/* === STICKY FOOTER === */
.cv-sticky-footer {
    position: sticky; bottom: 0;
    background: var(--cv-card);
    border-top: 1px solid var(--cv-border);
    padding: 12px 20px;
    display: flex; justify-content: space-between; align-items: center;
    z-index: 10;
}

/* === FILTER BAR STICKY === */
.cv-filter-bar {
    position: sticky; top: 0;
    background: var(--cv-card);
    border-bottom: 1px solid var(--cv-border);
    padding: 12px 16px;
    z-index: 8;
}

/* === HUB CARD (NAVEGACION) === */
.cv-hub-card {
    background: var(--cv-card);
    border: 1px solid var(--cv-border);
    border-radius: 12px;
    padding: 22px;
    transition: .2s;
    text-decoration: none;
    display: block;
    color: var(--cv-text);
}
.cv-hub-card:hover {
    border-color: var(--cv-action);
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(37, 99, 235, .15);
}

/* === RESPONSIVE === */
@media (max-width: 768px) {
    .cv-modal { max-width: 95vw !important; }
    .cv-kpi-value   { font-size: 20px; }
}
```

---

## 4. Estructura Canonica HTML (OBLIGATORIA)

Patron base de **CUALQUIER** template Coffee-Varoch — header AZUL arriba, sidebar BLANCO lateral, breadcrumb debajo del header, container blanco con border-radius.

```html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modulo · Coffee-Varoch</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* >>>>>>> Aqui pega el bloque CSS completo de la seccion 3 <<<<<<< */
        body { font-family: 'Inter', system-ui, sans-serif; }
    </style>
</head>
<body class="coffee-varoch cv-page">

<div class="flex flex-col h-screen overflow-hidden">

    <!-- HEADER (top bar AZUL, 50px) -->
    <header class="cv-header-primary w-full px-3 flex items-center justify-between shrink-0">
        <section class="flex items-center gap-3" style="width: 250px;">
            <button id="btnSidebar" class="cv-header-toggle" aria-label="Toggle sidebar">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div class="flex items-center gap-2 text-white">
                <div class="w-7 h-7 rounded-md flex items-center justify-center font-bold text-xs"
                     style="background: rgba(255,255,255,.95); color: var(--cv-primary);">CV</div>
                <span class="font-bold text-sm tracking-tight">Grupo Varoch</span>
            </div>
        </section>
        <nav class="flex items-center gap-1 pr-2">
            <span class="cv-header-icon" title="Notificaciones">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                <span class="cv-header-icon-badge"></span>
            </span>
            <div class="cv-header-user">
                <div class="cv-header-avatar">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </div>
                <span class="cv-header-username">Rosita</span>
            </div>
        </nav>
    </header>

    <!-- MAIN -->
    <main class="flex flex-1 overflow-hidden">

        <!-- SIDEBAR (BLANCO, lateral) -->
        <section id="sidebar" class="cv-sidebar cv-scroll overflow-y-auto" style="width: 250px;">
            <ul class="p-3 space-y-1">
                <li><div class="cv-nav-item active">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l9-9 9 9v9a2 2 0 01-2 2h-3v-7H8v7H5a2 2 0 01-2-2v-9z"/></svg>
                    <span class="flex-1">Inicio</span>
                </div></li>
            </ul>
        </section>

        <!-- #main__content -->
        <div id="main__content" class="flex-1 overflow-y-auto cv-scroll" style="background: var(--cv-bg);">

            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb">
                <ol class="cv-module-breadcrumb">
                    <li class="cv-module-breadcrumb-item text-uppercase text-muted">Finanzas</li>
                    <li class="cv-module-breadcrumb-item active">Tesoreria</li>
                </ol>
            </nav>

            <!-- main-container (donde monta el modulo) -->
            <div class="cv-main-container" id="root">
                <!-- AQUI VA EL CONTENIDO DEL MODULO -->
            </div>

        </div>
    </main>
</div>

<script>
    // Theme toggle persistente
    const root = document.body;
    const saved = localStorage.getItem('cv-theme') || 'light';
    if (saved === 'dark') root.setAttribute('data-theme', 'dark');

    // Toggle sidebar (replica #btnSidebar del ERP real)
    const btnSidebar = document.getElementById('btnSidebar');
    const sidebar = document.getElementById('sidebar');
    if (btnSidebar && sidebar) {
        btnSidebar.addEventListener('click', () => {
            sidebar.style.width = sidebar.style.width === '0px' ? '250px' : '0px';
        });
    }
</script>
</body>
</html>
```

### Reglas estructurales criticas

1. **Header SIEMPRE azul** (`cv-header-primary`) con `var(--cv-primary)` (#003360) — NO blanco.
2. **Sidebar SIEMPRE blanco** (`cv-sidebar`) con sombra azulada `rgba(0, 51, 96, .5)` — NO azul.
3. **Breadcrumb DEBAJO del header**, dentro de `#main__content`, ANTES del container.
4. **`cv-main-container` SIEMPRE existe** (con `id="root"`) — es donde la app monta su contenido. Padding 16px, border-radius 10px, fondo blanco.
5. **NO invertir** la jerarquia (sidebar azul / header blanco rompe la identidad Varoch).

---

## 5. Spells por Componente

### 5.1 conjure header-varoch

Header AZUL institucional top bar 50px con logo, hamburguesa, iconos y user menu.

```html
<header class="cv-header-primary w-full px-3 flex items-center justify-between shrink-0">
    <section class="flex items-center gap-3" style="width: 250px;">
        <button id="btnSidebar" class="cv-header-toggle" aria-label="Toggle sidebar">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <div class="flex items-center gap-2 text-white">
            <div class="w-7 h-7 rounded-md flex items-center justify-center font-bold text-xs"
                 style="background: rgba(255,255,255,.95); color: var(--cv-primary);">CV</div>
            <span class="font-bold text-sm tracking-tight">Grupo Varoch</span>
        </div>
    </section>
    <nav class="flex items-center gap-1 pr-2">
        <span class="cv-header-icon" title="Mensajes">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
        </span>
        <span class="cv-header-icon" title="Notificaciones">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
            <span class="cv-header-icon-badge"></span>
        </span>
        <div class="cv-header-user">
            <div class="cv-header-avatar">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            </div>
            <span class="cv-header-username">Rosita</span>
            <svg class="w-3 h-3 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
        </div>
    </nav>
</header>
```

### 5.2 conjure sidebar-varoch

Sidebar BLANCO lateral toggleable con items de navegacion.

```html
<section id="sidebar" class="cv-sidebar cv-scroll overflow-y-auto" style="width: 250px;">
    <ul class="p-3 space-y-1">
        <li>
            <div class="cv-nav-item active">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l9-9 9 9v9a2 2 0 01-2 2h-3v-7H8v7H5a2 2 0 01-2-2v-9z"/></svg>
                <span class="flex-1">Inicio</span>
            </div>
        </li>
        <li>
            <div class="cv-nav-item">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-8a2 2 0 00-2-2H9a2 2 0 00-2 2v8a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                <span class="flex-1">Finanzas</span>
                <svg class="w-3 h-3 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
            </div>
        </li>
        <li>
            <div class="cv-nav-item">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857"/></svg>
                <span class="flex-1">Recursos Humanos</span>
            </div>
        </li>
        <li class="pt-2 mt-2 border-t" style="border-color: var(--cv-border);">
            <div class="cv-nav-item">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <span class="flex-1">Configuracion</span>
            </div>
        </li>
    </ul>
</section>
```

### 5.3 conjure breadcrumb-varoch

Breadcrumb DEBAJO del header, dentro de `#main__content`.

```html
<nav aria-label="breadcrumb">
    <ol class="cv-module-breadcrumb">
        <li class="cv-module-breadcrumb-item text-uppercase text-muted">Finanzas</li>
        <li class="cv-module-breadcrumb-item">Tesoreria</li>
        <li class="cv-module-breadcrumb-item active">Folio #519</li>
    </ol>
</nav>
```

### 5.4 conjure main-container

Container blanco con border-radius donde monta TODO el contenido del modulo.

```html
<div class="cv-main-container" id="root">
    <!-- contenido del modulo aqui -->
</div>
```

### 5.5 conjure button

6 variantes + tamanos (sm, default, lg).

```html
<!-- Solidos -->
<button class="cv-btn cv-btn-primary">Primary</button>
<button class="cv-btn cv-btn-action">Action</button>
<button class="cv-btn cv-btn-success">Success</button>
<button class="cv-btn cv-btn-danger">Danger</button>

<!-- Outline y ghost -->
<button class="cv-btn cv-btn-outline-action">Outline Action</button>
<button class="cv-btn cv-btn-ghost">Ghost</button>

<!-- Tamanos -->
<button class="cv-btn cv-btn-action cv-btn-sm">Small</button>
<button class="cv-btn cv-btn-action">Default</button>
<button class="cv-btn cv-btn-action cv-btn-lg">Large</button>

<!-- Con icono -->
<button class="cv-btn cv-btn-action">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
    Nuevo registro
</button>

<!-- Cargando -->
<button class="cv-btn cv-btn-action">
    <svg class="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
    Cargando
</button>
```

### 5.6 conjure badge

7 variantes semanticas.

```html
<span class="cv-badge cv-badge-success">Aprobado</span>
<span class="cv-badge cv-badge-warning">Pendiente</span>
<span class="cv-badge cv-badge-danger">Rechazado</span>
<span class="cv-badge cv-badge-info">En proceso</span>
<span class="cv-badge cv-badge-neutral">Sin estatus</span>
<span class="cv-badge cv-badge-primary">Institucional</span>
<span class="cv-badge cv-badge-action">Activo</span>

<!-- Con dot -->
<span class="cv-badge cv-badge-success">
    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cv-success);"></span>
    Conectado
</span>
```

### 5.7 conjure chip

Tag base + chip de filtro removible.

```html
<span class="cv-chip">Neutral</span>
<span class="cv-chip cv-chip-action">Action</span>

<!-- Removible -->
<span class="cv-chip cv-chip-action">
    Filtro: UDN 1
    <span class="cv-chip-x" title="Quitar">&times;</span>
</span>

<!-- Barra de filtros activos -->
<div class="cv-filter-bar flex items-center gap-2 flex-wrap rounded-xl border" style="border-color: var(--cv-border);">
    <span class="cv-muted text-xs mr-2">Filtros activos:</span>
    <span class="cv-chip cv-chip-action">UDN 1 <span class="cv-chip-x">&times;</span></span>
    <span class="cv-chip cv-chip-action">Mayo 2026 <span class="cv-chip-x">&times;</span></span>
    <button class="cv-btn cv-btn-ghost cv-btn-sm ml-auto">Limpiar todo</button>
</div>
```

### 5.8 conjure input

Inputs, selects, textarea, label y radio-card.

```html
<label class="cv-label block mb-1.5">Nombre completo</label>
<input type="text" class="cv-input" placeholder="Ej. Rosita Martinez">

<label class="cv-label block mb-1.5">UDN</label>
<select class="cv-select">
    <option>UDN 1 — Matriz CDMX</option>
    <option>UDN 2 — Sucursal Norte</option>
</select>

<label class="cv-label block mb-1.5">Observaciones</label>
<textarea class="cv-textarea" placeholder="Escribe aqui..."></textarea>

<!-- Radio cards (seleccion exclusiva) -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-3" id="radioGroup">
    <div class="cv-radio-card active">
        <div class="flex items-center gap-2 mb-1">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" style="color: var(--cv-action);"><path stroke-linecap="round" stroke-linejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-8a2 2 0 00-2-2H9a2 2 0 00-2 2v8a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            <span class="cv-text font-semibold text-sm">Efectivo</span>
        </div>
        <span class="cv-muted text-xs">Pago en caja inmediato</span>
    </div>
    <div class="cv-radio-card">
        <div class="flex items-center gap-2 mb-1">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" style="color: var(--cv-muted);"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
            <span class="cv-text font-semibold text-sm">Tarjeta</span>
        </div>
        <span class="cv-muted text-xs">Credito o debito</span>
    </div>
</div>
```

### 5.9 conjure card

Card base, con hover, hub-card y group-card.

```html
<!-- Card simple -->
<div class="cv-card p-5">
    <h3 class="cv-title text-base mb-1">Card simple</h3>
    <p class="cv-muted text-sm">Contenedor base con borde, sombra suave y padding.</p>
</div>

<!-- Card con hover -->
<div class="cv-card cv-card-hover p-5">...</div>

<!-- Card con header y badge -->
<div class="cv-card p-5">
    <div class="flex items-center justify-between mb-2">
        <h3 class="cv-title text-base">Modulo</h3>
        <span class="cv-badge cv-badge-action">Activo</span>
    </div>
    <p class="cv-muted text-sm">Combinable con titulos, badges y footer.</p>
</div>

<!-- Hub card (navegacion) -->
<a class="cv-hub-card">
    <div class="flex items-start gap-3">
        <div class="w-11 h-11 rounded-xl flex items-center justify-center" style="background: rgba(37,99,235,.12); color: var(--cv-action);">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18M3 12h18M3 18h18"/></svg>
        </div>
        <div class="flex-1">
            <div class="flex items-center justify-between">
                <h3 class="cv-title text-base">Ingresos</h3>
                <span class="cv-badge cv-badge-success">Activo</span>
            </div>
            <p class="cv-muted text-xs mt-1">Cobros y registros de caja</p>
        </div>
    </div>
</a>

<!-- Group card (3 estados: default, complete, direct) -->
<div class="cv-group-card complete">
    <span class="cv-label" style="color: var(--cv-success);">Completo</span>
    <h3 class="cv-title text-base">Cierre Mensual</h3>
    <p class="cv-muted text-xs">Todas las secciones aprobadas</p>
</div>
```

### 5.10 conjure kpi

KPI card con label, value y foot.

```html
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
    <div class="cv-kpi">
        <span class="cv-kpi-label">Saldo inicial</span>
        <span class="cv-kpi-value">$18,500.00</span>
        <span class="cv-kpi-foot">Fondo de caja del dia</span>
    </div>
    <div class="cv-kpi">
        <span class="cv-kpi-label">Egresos</span>
        <span class="cv-kpi-value">$4,320.50</span>
        <span class="cv-kpi-foot">Pagos y retiros</span>
    </div>
    <div class="cv-kpi">
        <span class="cv-kpi-label">Ingresos</span>
        <span class="cv-kpi-value">$28,140.00</span>
        <span class="cv-kpi-foot">Cobros del dia</span>
    </div>
    <div class="cv-kpi">
        <span class="cv-kpi-label">Saldo final</span>
        <span class="cv-kpi-value">$42,319.50</span>
        <span class="cv-kpi-foot">Disponible en caja</span>
    </div>
</div>

<!-- KPI con icono y bandera superior -->
<div class="cv-card overflow-hidden">
    <div class="h-1 w-full" style="background: var(--cv-action);"></div>
    <div class="p-4">
        <div class="flex items-start justify-between gap-3">
            <div class="min-w-0">
                <p class="cv-text text-sm font-semibold">Saldo inicial</p>
                <p class="cv-muted text-xs mt-0.5">Fondo de caja</p>
            </div>
            <div class="w-11 h-11 rounded-xl flex items-center justify-center" style="background: rgba(37,99,235,.12); color: var(--cv-action);">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 9m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3"/></svg>
            </div>
        </div>
        <p class="mt-3 text-2xl font-extrabold tracking-tight text-end" style="color: var(--cv-action);">$18,500.00</p>
    </div>
</div>
```

### 5.11 conjure tabLayout (Tailwind puro — 4 variantes)

Replica fiel de `tabLayout()` de CoffeeSoft — 4 variantes: `large`, `short`, `button`, `dark`.

**Variante `type: "large"` (la mas usada):**

```html
<div id="tabComponent" class="bg-gray-200 text-black rounded-lg flex gap-1 px-1 py-1 w-full text-sm overflow-x-auto"
     data-theme="light" data-type="large" data-target="content-tabComponent">
    <button data-state="active" data-tab-id="general"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 bg-white text-black">
        General
    </button>
    <button data-state="inactive" data-tab-id="fiscal"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-white">
        Datos fiscales
    </button>
    <button data-state="inactive" data-tab-id="contactos"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-white">
        Contactos
    </button>
</div>

<div id="content-tabComponent" class="mt-2">
    <div id="container-general" class="border p-3 rounded-lg">Contenido General</div>
    <div id="container-fiscal" class="hidden border p-3 rounded-lg">Contenido Fiscal</div>
    <div id="container-contactos" class="hidden border p-3 rounded-lg">Contenido Contactos</div>
</div>
```

**Variante `type: "short"` (sin `w-full`, ancho contenido):**

```html
<div id="tabComponent-short" class="bg-gray-200 text-black rounded-lg flex gap-1 px-1 py-1 text-sm overflow-x-auto"
     data-theme="light" data-type="short" data-target="content-tabComponent-short">
    <button data-state="active" data-tab-id="resumen"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 bg-white text-black">
        Resumen
    </button>
    <button data-state="inactive" data-tab-id="detalle"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-white">
        Detalle
    </button>
</div>
```

**Variante `type: "button"` (pildoras tipo segmented control):**

```html
<div id="tabComponent-button" class="bg-gray-100 p-1 rounded-lg inline-flex shadow-blue-500/50 gap-1 overflow-x-auto flex-nowrap"
     data-theme="light" data-type="button" data-target="content-tabComponent-button">
    <button data-state="active" data-tab-id="dia"
            class="transition-all duration-200 text-sm font-medium rounded-md px-4 py-2.5 whitespace-nowrap flex-shrink-0 bg-blue-600 text-white">
        Dia
    </button>
    <button data-state="inactive" data-tab-id="semana"
            class="transition-all duration-200 text-sm font-medium rounded-md px-4 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-gray-50">
        Semana
    </button>
    <button data-state="inactive" data-tab-id="mes"
            class="transition-all duration-200 text-sm font-medium rounded-md px-4 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-gray-50">
        Mes
    </button>
</div>
```

**Variante `theme: "dark"` (independiente del theme global):**

```html
<div id="tabComponent-dark" class="bg-gray-900 text-white rounded-lg flex gap-1 px-1 py-1 w-full text-sm overflow-x-auto"
     data-theme="dark" data-type="large" data-target="content-tabComponent-dark">
    <button data-state="active" data-tab-id="dashboard"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 bg-blue-600 text-white">
        Dashboard
    </button>
    <button data-state="inactive" data-tab-id="analytics"
            class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-300 hover:bg-gray-700">
        Analytics
    </button>
</div>
```

**JS vanilla del toggle (replica del handler de tabLayout):**

```html
<script>
const THEMES = {
    dark:   { base: 'bg-gray-900 text-white',                                       active: 'bg-blue-600 text-white', inactive: 'text-gray-300 hover:bg-gray-700', iconActive: 'text-white' },
    light:  { base: 'bg-gray-200 text-black',                                       active: 'bg-white text-black',    inactive: 'text-gray-600 hover:bg-white',     iconActive: 'text-blue-600' },
    button: { base: 'bg-gray-100 p-1 rounded-lg inline-flex shadow-blue-500/50',   active: 'bg-blue-600 text-white', inactive: 'text-gray-600 hover:bg-gray-50',   iconActive: 'text-white' }
};

function bindTabs(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const type  = container.dataset.type;
    const theme = container.dataset.theme;
    const contentId = container.dataset.target;
    const style = THEMES[type] || THEMES[theme];

    container.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
            container.querySelectorAll('button').forEach(b => {
                b.setAttribute('data-state', 'inactive');
                style.active.split(/\s+/).forEach(cls => b.classList.remove(cls));
                style.inactive.split(/\s+/).forEach(cls => b.classList.add(cls));
            });
            btn.setAttribute('data-state', 'active');
            style.inactive.split(/\s+/).forEach(cls => btn.classList.remove(cls));
            style.active.split(/\s+/).forEach(cls => btn.classList.add(cls));

            const content = document.getElementById(contentId);
            if (content) {
                content.querySelectorAll(':scope > div').forEach(p => p.classList.add('hidden'));
                const panel = document.getElementById('container-' + btn.dataset.tabId);
                if (panel) panel.classList.remove('hidden');
            }
        });
    });
}

bindTabs('tabComponent');
</script>
```

### 5.12 conjure table (Tailwind puro — 5 temas)

Las tablas Varoch usan puro Tailwind (sin `.cv-table`) replica del `createCoffeTable3` de CoffeeSoft. **SIEMPRE** envolver en wrapper `overflow-hidden rounded-lg` para que el border-radius funcione con `border-separate`.

**Tema 1 — `default` (azul Varoch #003360 + texto gray-100):**

```html
<div class="overflow-hidden rounded-lg border border-gray-200">
    <table class="border-separate border-spacing-0 w-full table-auto text-sm text-gray-800">
        <thead>
            <tr>
                <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">ID</th>
                <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Folio</th>
                <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Cliente</th>
                <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Monto</th>
                <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Estado</th>
            </tr>
        </thead>
        <tbody>
            <tr class="ct3-hoverable">
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">1</td>
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">F-001</td>
                <td class="border-b border-gray-200 px-2 py-2" style="font-size:12px">ACME Corp</td>
                <td class="text-right border-b border-gray-200 px-2 py-2 font-semibold" style="font-size:12px">$12,500.00</td>
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px"><span class="cv-badge cv-badge-success">Pagado</span></td>
            </tr>
            <tr class="ct3-hoverable">
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">2</td>
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">F-002</td>
                <td class="border-b border-gray-200 px-2 py-2" style="font-size:12px">Cafeteria del Norte</td>
                <td class="text-right border-b border-gray-200 px-2 py-2 font-semibold" style="font-size:12px">$8,920.50</td>
                <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px"><span class="cv-badge cv-badge-warning">Pendiente</span></td>
            </tr>
        </tbody>
    </table>
</div>
```

**Tema 2 — `light` (gris claro + texto gray-600):**

```html
<th class="text-center px-3 py-2 bg-gray-200 text-gray-600 capitalize font-semibold" style="font-size:12px">Col</th>
```

**Tema 3 — `corporativo` (azul Varoch + texto blanco):**

```html
<th class="text-center px-3 py-2 bg-[#003360] text-white capitalize font-semibold" style="font-size:12px">Col</th>
```

**Tema 4 — `dark` (toda oscura, filas alternadas):**

```html
<div class="overflow-hidden rounded-lg border border-gray-700">
    <table class="border-separate border-spacing-0 w-full table-auto text-sm text-gray-300">
        <thead>
            <tr>
                <th class="text-center px-3 py-2 bg-[#374151] text-gray-300 capitalize font-semibold" style="font-size:12px">ID</th>
                <th class="text-center px-3 py-2 bg-[#374151] text-gray-300 capitalize font-semibold" style="font-size:12px">Folio</th>
            </tr>
        </thead>
        <tbody>
            <tr class="ct3-hoverable">
                <td class="text-center border-t border-gray-700 px-2 py-2 bg-[#283341]" style="font-size:12px">1</td>
                <td class="text-center border-t border-gray-700 px-2 py-2 bg-[#283341]" style="font-size:12px">TX-9001</td>
            </tr>
            <tr class="ct3-hoverable">
                <td class="text-center border-t border-gray-700 px-2 py-2 bg-[#111827]" style="font-size:12px">2</td>
                <td class="text-center border-t border-gray-700 px-2 py-2 bg-[#111827]" style="font-size:12px">TX-9002</td>
            </tr>
        </tbody>
    </table>
</div>
```

**Tema 5 — `slate`:**

```html
<th class="text-center px-3 py-2 bg-slate-700 text-slate-100 capitalize font-semibold" style="font-size:12px">Col</th>
```

**Extra — `striped: true` (alterna gris claro):**

```html
<tr class="ct3-hoverable">
    <td class="text-center border-b border-gray-200 px-2 py-2 bg-gray-50" style="font-size:12px">1</td>
    <!-- ... -->
</tr>
<tr class="ct3-hoverable">
    <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">2</td>
    <!-- ... -->
</tr>
```

**Extra — colgroup row (encabezado horizontal):**

```html
<tbody>
    <tr>
        <td colspan="4" class="px-3 py-2 font-semibold capitalize border-b border-gray-200 bg-gray-200" style="font-size:12px">Bebidas calientes</td>
    </tr>
    <tr class="ct3-hoverable">
        <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px">B-001</td>
        <!-- ... -->
    </tr>
</tbody>
```

**Extra — empty state:**

```html
<div class="flex flex-col items-center justify-center py-12 px-4 rounded-lg">
    <svg class="w-12 h-12 text-gray-400 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
    <p class="text-base font-medium text-gray-500">No se encontraron registros</p>
    <p class="text-sm text-gray-400 mt-1">Intenta ajustar los filtros de busqueda</p>
</div>
```

### 5.13 conjure modal

Overlay + card centrada con anchos: 400px (confirmacion), 460px (info), 520px (form), 600px (selector).

```html
<!-- Overlay base -->
<div class="cv-modal-overlay">
    <div class="cv-modal" style="max-width: 520px;">
        <div class="cv-modal-header">
            <div>
                <h3 class="cv-title text-base">Titulo</h3>
                <p class="cv-muted text-xs">Subtitulo o descripcion</p>
            </div>
            <button class="cv-btn cv-btn-ghost cv-btn-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="cv-modal-body space-y-3">
            <!-- Contenido del modal -->
        </div>
        <div class="cv-modal-footer">
            <button class="cv-btn cv-btn-ghost">Cancelar</button>
            <button class="cv-btn cv-btn-action">Aceptar</button>
        </div>
    </div>
</div>
```

**Modal de confirmacion (400px, sustituto Varoch de swalQuestion):**

```html
<div class="cv-modal-overlay">
    <div class="cv-modal" style="max-width: 400px;">
        <div class="cv-modal-body text-center py-8">
            <div class="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center"
                 style="background: rgba(220,38,38,.12); color: var(--cv-danger);">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>
            </div>
            <h3 class="cv-title text-lg mb-2">Eliminar registro</h3>
            <p class="cv-muted text-sm">Esta accion no se puede deshacer.</p>
        </div>
        <div class="cv-modal-footer justify-center">
            <button class="cv-btn cv-btn-ghost">Cancelar</button>
            <button class="cv-btn cv-btn-danger">Si, eliminar</button>
        </div>
    </div>
</div>
```

**Modal selector grid (600px):**

```html
<div class="cv-modal-overlay">
    <div class="cv-modal" style="max-width: 600px;">
        <div class="cv-modal-header">
            <div>
                <h3 class="cv-title text-base">Tipo de operacion</h3>
                <p class="cv-muted text-xs">Selecciona como quieres registrar</p>
            </div>
            <button class="cv-btn cv-btn-ghost cv-btn-sm">X</button>
        </div>
        <div class="cv-modal-body">
            <div class="grid grid-cols-2 gap-3">
                <div class="cv-radio-card active">
                    <span class="cv-text font-semibold text-sm">Efectivo</span>
                    <span class="cv-muted text-xs">Pago inmediato</span>
                </div>
                <div class="cv-radio-card">
                    <span class="cv-text font-semibold text-sm">Tarjeta</span>
                    <span class="cv-muted text-xs">Credito o debito</span>
                </div>
                <div class="cv-radio-card">
                    <span class="cv-text font-semibold text-sm">Transferencia</span>
                    <span class="cv-muted text-xs">SPEI bancario</span>
                </div>
                <div class="cv-radio-card">
                    <span class="cv-text font-semibold text-sm">Cheque</span>
                    <span class="cv-muted text-xs">Cobro por documento</span>
                </div>
            </div>
        </div>
        <div class="cv-modal-footer">
            <button class="cv-btn cv-btn-ghost">Cancelar</button>
            <button class="cv-btn cv-btn-action">Continuar</button>
        </div>
    </div>
</div>
```

### 5.14 conjure form

Form centrado (createForm) + Form con header y secciones (createModalForm).

```html
<!-- Form centrado -->
<div class="cv-card max-w-2xl mx-auto p-7">
    <header class="mb-5">
        <h2 class="cv-title text-xl">Registrar nuevo empleado</h2>
        <p class="cv-muted text-sm mt-1">Completa los datos. Los campos con * son obligatorios.</p>
    </header>

    <form class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="cv-label block mb-1.5">Nombre *</label>
            <input type="text" class="cv-input" placeholder="Nombre">
        </div>
        <div>
            <label class="cv-label block mb-1.5">Apellido paterno *</label>
            <input type="text" class="cv-input" placeholder="Apellido">
        </div>
        <div>
            <label class="cv-label block mb-1.5">Correo *</label>
            <input type="email" class="cv-input" placeholder="correo@ejemplo.mx">
        </div>
        <div>
            <label class="cv-label block mb-1.5">Telefono</label>
            <input type="tel" class="cv-input" placeholder="55 1234 5678">
        </div>
        <div>
            <label class="cv-label block mb-1.5">Puesto</label>
            <select class="cv-select">
                <option>Selecciona puesto</option>
                <option>Cajero</option>
                <option>Barista</option>
            </select>
        </div>
        <div>
            <label class="cv-label block mb-1.5">Fecha de ingreso</label>
            <input type="date" class="cv-input">
        </div>
        <div class="md:col-span-2">
            <label class="cv-label block mb-1.5">Notas</label>
            <textarea class="cv-textarea" placeholder="Observaciones..."></textarea>
        </div>

        <div class="md:col-span-2 flex justify-end gap-2 mt-2">
            <button type="button" class="cv-btn cv-btn-ghost">Cancelar</button>
            <button type="submit" class="cv-btn cv-btn-action">Guardar empleado</button>
        </div>
    </form>
</div>

<!-- Form con header y secciones -->
<div class="cv-card max-w-3xl mx-auto overflow-hidden">
    <div class="px-6 py-4 flex items-center justify-between" style="border-bottom: 1px solid var(--cv-border);">
        <div>
            <h3 class="cv-title text-base">Registro de compra</h3>
            <p class="cv-muted text-xs">Folio nuevo · UDN 1</p>
        </div>
        <span class="cv-badge cv-badge-action">Borrador</span>
    </div>
    <form class="p-6 space-y-5">
        <div>
            <h4 class="cv-label mb-3">Datos del proveedor</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="cv-label block mb-1.5">Proveedor *</label>
                    <select class="cv-select"><option>Selecciona</option></select>
                </div>
                <div>
                    <label class="cv-label block mb-1.5">Factura</label>
                    <input type="text" class="cv-input" placeholder="F-00000">
                </div>
            </div>
        </div>
        <div class="flex justify-end gap-2 pt-3" style="border-top:1px solid var(--cv-border);">
            <button type="button" class="cv-btn cv-btn-ghost">Cancelar</button>
            <button type="button" class="cv-btn cv-btn-outline-action">Guardar borrador</button>
            <button type="submit" class="cv-btn cv-btn-action">Enviar</button>
        </div>
    </form>
</div>
```

### 5.15 conjure progress

Barras de progreso con variantes default (action), success y warning.

```html
<!-- Default (action gradient) -->
<div>
    <div class="flex justify-between mb-1">
        <span class="cv-text text-sm">Carga de archivos</span>
        <span class="cv-muted text-xs">35%</span>
    </div>
    <div class="cv-progress">
        <div class="cv-progress-bar" style="width: 35%;"></div>
    </div>
</div>

<!-- Success -->
<div class="cv-progress">
    <div class="cv-progress-bar cv-progress-success" style="width: 100%;"></div>
</div>

<!-- Warning -->
<div class="cv-progress">
    <div class="cv-progress-bar cv-progress-warning" style="width: 22%;"></div>
</div>

<!-- En contexto: card de modulo -->
<div class="cv-card p-5">
    <div class="flex items-center justify-between mb-3">
        <h3 class="cv-title text-base">Modulo Finanzas</h3>
        <span class="cv-badge cv-badge-success">Activo</span>
    </div>
    <div class="cv-progress mb-2">
        <div class="cv-progress-bar cv-progress-success" style="width: 92%;"></div>
    </div>
    <span class="cv-muted text-xs">92% de cobertura del modulo</span>
</div>
```

### 5.16 conjure breadcrumb (generico vs modulo)

**Diferencia clave:**
- `.cv-breadcrumb` — breadcrumb generico para cualquier card o header sin chrome.
- `.cv-module-breadcrumb` — breadcrumb especifico para modulos, va DEBAJO del header dentro de `#main__content`.

```html
<!-- Generico -->
<nav class="cv-breadcrumb">
    <a>Inicio</a>
    <span class="cv-breadcrumb-sep">/</span>
    <a>Finanzas</a>
    <span class="cv-breadcrumb-sep">/</span>
    <span class="cv-text">Tesoreria</span>
</nav>

<!-- Con iconos -->
<nav class="cv-breadcrumb">
    <a class="flex items-center gap-1">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3"/></svg>
        Inicio
    </a>
    <span class="cv-breadcrumb-sep">›</span>
    <a>Recursos Humanos</a>
    <span class="cv-breadcrumb-sep">›</span>
    <span class="cv-text">Empleados</span>
</nav>

<!-- De modulo (debajo del header) -->
<nav aria-label="breadcrumb">
    <ol class="cv-module-breadcrumb">
        <li class="cv-module-breadcrumb-item text-uppercase text-muted">Finanzas</li>
        <li class="cv-module-breadcrumb-item">Tesoreria</li>
        <li class="cv-module-breadcrumb-item active">Folio #519</li>
    </ol>
</nav>
```

### 5.17 conjure empty-state

Estado vacio para tablas, busquedas sin resultados o modulos recien instalados.

```html
<!-- Sin resultados -->
<div class="cv-card">
    <div class="cv-empty">
        <div class="cv-empty-icon">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </div>
        <h3 class="cv-title text-base mb-1">Sin resultados</h3>
        <p class="cv-muted text-sm mb-4">No encontramos registros que coincidan con tu busqueda.</p>
        <button class="cv-btn cv-btn-outline-action cv-btn-sm">Limpiar filtros</button>
    </div>
</div>

<!-- Tabla vacia con CTA -->
<div class="cv-card">
    <div class="cv-empty">
        <div class="cv-empty-icon">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
        </div>
        <h3 class="cv-title text-base mb-1">Aun no hay registros</h3>
        <p class="cv-muted text-sm mb-4">Comienza creando tu primer cliente para verlo aqui.</p>
        <button class="cv-btn cv-btn-action cv-btn-sm">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
            Nuevo cliente
        </button>
    </div>
</div>

<!-- Error / Sin conexion -->
<div class="cv-card">
    <div class="cv-empty">
        <div class="cv-empty-icon" style="background: rgba(220,38,38,.1); color: var(--cv-danger);">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>
        </div>
        <h3 class="cv-title text-base mb-1">No pudimos conectar</h3>
        <p class="cv-muted text-sm mb-4">Revisa tu conexion o intenta de nuevo en unos minutos.</p>
        <button class="cv-btn cv-btn-danger cv-btn-sm">Reintentar</button>
    </div>
</div>
```

### 5.18 conjure theme-toggle

Toggle light/dark con localStorage persistente.

```html
<!-- HTML del componente -->
<div class="cv-theme-toggle" role="group" aria-label="Tema">
    <button class="cv-theme-btn active" data-theme-set="light">Light</button>
    <button class="cv-theme-btn" data-theme-set="dark">Dark</button>
</div>

<!-- JS del toggle (al final del body) -->
<script>
const root = document.body;
const saved = localStorage.getItem('cv-theme') || 'light';
if (saved === 'dark') root.setAttribute('data-theme', 'dark');

document.querySelectorAll('.cv-theme-btn').forEach(btn => {
    if (btn.dataset.themeSet === saved) btn.classList.add('active');
    else btn.classList.remove('active');

    btn.addEventListener('click', () => {
        const t = btn.dataset.themeSet;
        if (t === 'dark') root.setAttribute('data-theme', 'dark');
        else root.removeAttribute('data-theme');
        localStorage.setItem('cv-theme', t);
        document.querySelectorAll('.cv-theme-btn').forEach(b =>
            b.classList.toggle('active', b.dataset.themeSet === t)
        );
    });
});
</script>
```

### 5.19 conjure question (modulo calidad)

Pregunta tipo Si/No con estado contestado.

```html
<div class="cv-question">
    <div class="flex items-start justify-between gap-4">
        <div class="flex-1">
            <p class="cv-text font-semibold text-sm">El area cumple con los lineamientos de orden y limpieza?</p>
            <p class="cv-muted text-xs mt-1">Verifica que no haya residuos, herramientas fuera de lugar.</p>
        </div>
        <div class="flex gap-2">
            <button class="cv-q-btn cv-q-yes">Si</button>
            <button class="cv-q-btn cv-q-no">No</button>
        </div>
    </div>
</div>

<!-- Pregunta contestada -->
<div class="cv-question answered">
    <div class="flex items-start justify-between gap-4">
        <div class="flex-1">
            <p class="cv-text font-semibold text-sm">Se sigue el procedimiento de seguridad establecido?</p>
        </div>
        <div class="flex gap-2">
            <button class="cv-q-btn cv-q-yes active">Si</button>
            <button class="cv-q-btn cv-q-no">No</button>
        </div>
    </div>
</div>
```

### 5.20 conjure sticky-footer y filter-bar

Footer pegado abajo + Barra de filtros sticky.

```html
<!-- Sticky footer -->
<div class="cv-sticky-footer">
    <button class="cv-btn cv-btn-ghost cv-btn-sm">Cancelar</button>
    <button class="cv-btn cv-btn-action cv-btn-sm">Guardar cambios</button>
</div>

<!-- Filter bar sticky -->
<div class="cv-filter-bar flex items-center gap-2 flex-wrap">
    <div class="relative">
        <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" style="color: var(--cv-muted);"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" class="cv-input pl-9" placeholder="Buscar..." style="width: 240px;">
    </div>
    <select class="cv-select" style="width: 160px;">
        <option>Todos los status</option>
        <option>Aprobado</option>
        <option>Pendiente</option>
    </select>
    <select class="cv-select" style="width: 160px;">
        <option>Todas las UDN</option>
    </select>
</div>
```

---

## 6. Layouts Canonicos

### 6.1 Primary Layout (sidebar + content)

Layout base de modulo: header azul + sidebar blanco + breadcrumb + container con dashboard.

```html
<div class="flex flex-col h-screen overflow-hidden">

    <!-- HEADER AZUL -->
    <header class="cv-header-primary w-full px-3 flex items-center justify-between shrink-0">
        <section class="flex items-center gap-3" style="width: 250px;">
            <button id="btnSidebar" class="cv-header-toggle">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div class="flex items-center gap-2 text-white">
                <div class="w-7 h-7 rounded-md flex items-center justify-center font-bold text-xs"
                     style="background: rgba(255,255,255,.95); color: var(--cv-primary);">CV</div>
                <span class="font-bold text-sm tracking-tight">Grupo Varoch</span>
            </div>
        </section>
        <nav class="flex items-center gap-1 pr-2">
            <span class="cv-header-icon">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                <span class="cv-header-icon-badge"></span>
            </span>
            <div class="cv-header-user">
                <div class="cv-header-avatar">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </div>
                <span class="cv-header-username">Rosita</span>
            </div>
        </nav>
    </header>

    <main class="flex flex-1 overflow-hidden">
        <!-- SIDEBAR BLANCO -->
        <section id="sidebar" class="cv-sidebar cv-scroll overflow-y-auto" style="width: 250px;">
            <ul class="p-3 space-y-1">
                <li><div class="cv-nav-item active">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 12l9-9 9 9v9a2 2 0 01-2 2h-3v-7H8v7H5a2 2 0 01-2-2v-9z"/></svg>
                    <span class="flex-1">Tesoreria</span>
                </div></li>
                <li><div class="cv-nav-item">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2"/></svg>
                    <span class="flex-1">Ingresos</span>
                </div></li>
                <li><div class="cv-nav-item">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <span class="flex-1">Egresos</span>
                </div></li>
            </ul>
        </section>

        <!-- #main__content -->
        <div id="main__content" class="flex-1 overflow-y-auto cv-scroll" style="background: var(--cv-bg);">
            <nav aria-label="breadcrumb">
                <ol class="cv-module-breadcrumb">
                    <li class="cv-module-breadcrumb-item text-uppercase text-muted">Finanzas</li>
                    <li class="cv-module-breadcrumb-item active">Tesoreria</li>
                </ol>
            </nav>

            <div class="cv-main-container" id="root">
                <!-- Subheader del modulo -->
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h1 class="cv-title text-lg">Dashboard de Tesoreria</h1>
                        <p class="cv-muted text-xs">Resumen del flujo de caja del dia</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <button class="cv-btn cv-btn-outline-action cv-btn-sm">Exportar</button>
                        <button class="cv-btn cv-btn-action cv-btn-sm">+ Nuevo movimiento</button>
                    </div>
                </div>

                <!-- KPI bar -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
                    <div class="cv-kpi"><span class="cv-kpi-label">Saldo inicial</span><span class="cv-kpi-value">$18,500</span><span class="cv-kpi-foot">Fondo de caja</span></div>
                    <div class="cv-kpi"><span class="cv-kpi-label">Ingresos</span><span class="cv-kpi-value">$28,140</span><span class="cv-kpi-foot">Hoy</span></div>
                    <div class="cv-kpi"><span class="cv-kpi-label">Egresos</span><span class="cv-kpi-value">$4,320</span><span class="cv-kpi-foot">Hoy</span></div>
                    <div class="cv-kpi"><span class="cv-kpi-label">Saldo final</span><span class="cv-kpi-value">$42,320</span><span class="cv-kpi-foot">Disponible</span></div>
                </div>
            </div>
        </div>
    </main>
</div>
```

### 6.2 Secondary Layout (master + detail split)

Layout split: lista de items (master) + panel lateral de edicion (detail w-[420px]).

```html
<div class="flex flex-col h-screen overflow-hidden">

    <header class="cv-header-primary w-full px-3 flex items-center justify-between shrink-0">
        <!-- Mismo header que primary layout -->
    </header>

    <main class="flex flex-1 overflow-hidden">
        <section id="sidebar" class="cv-sidebar cv-scroll overflow-y-auto" style="width: 250px;">
            <!-- Mismo sidebar que primary layout -->
        </section>

        <div id="main__content" class="flex-1 overflow-hidden flex flex-col" style="background: var(--cv-bg);">
            <nav aria-label="breadcrumb">
                <ol class="cv-module-breadcrumb">
                    <li class="cv-module-breadcrumb-item text-uppercase text-muted">Recursos Humanos</li>
                    <li class="cv-module-breadcrumb-item active">Empleados</li>
                </ol>
            </nav>

            <!-- main-container con split master/detail -->
            <div class="cv-main-container flex-1 flex flex-col overflow-hidden" id="root" style="padding: 0;">

                <!-- Subheader del modulo -->
                <div class="flex items-center justify-between px-4 py-3 border-b" style="border-color: var(--cv-border);">
                    <div>
                        <h1 class="cv-title text-lg">Empleados</h1>
                        <p class="cv-muted text-xs">Selecciona un empleado para editar su detalle</p>
                    </div>
                    <button class="cv-btn cv-btn-action cv-btn-sm">+ Nuevo empleado</button>
                </div>

                <!-- Split: master (lista) + detail (formulario) -->
                <div class="flex flex-1 overflow-hidden">

                    <!-- Master -->
                    <section class="flex-1 flex flex-col overflow-hidden" style="border-right: 1px solid var(--cv-border);">
                        <div class="cv-filter-bar flex items-center gap-2">
                            <div class="relative flex-1">
                                <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2" style="color: var(--cv-muted);"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                                <input type="text" class="cv-input pl-9" placeholder="Buscar empleado...">
                            </div>
                            <select class="cv-select" style="width: 140px;">
                                <option>Todos</option>
                                <option>Activos</option>
                            </select>
                        </div>
                        <div class="flex-1 overflow-y-auto cv-scroll">
                            <div class="overflow-hidden rounded-lg border border-gray-200 m-2">
                                <table class="border-separate border-spacing-0 w-full text-sm">
                                    <thead>
                                        <tr>
                                            <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Empleado</th>
                                            <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Puesto</th>
                                            <th class="text-center px-3 py-2 bg-[#003360] text-gray-100 capitalize font-semibold" style="font-size:12px">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="ct3-hoverable" style="background: var(--cv-hover);">
                                            <td class="border-b border-gray-200 px-2 py-2 font-semibold" style="font-size:12px">Rosita Martinez</td>
                                            <td class="border-b border-gray-200 px-2 py-2" style="font-size:12px">Administrador</td>
                                            <td class="text-center border-b border-gray-200 px-2 py-2" style="font-size:12px"><span class="cv-badge cv-badge-success">Activo</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>

                    <!-- Detail (w-[420px]) -->
                    <aside class="w-[420px] flex flex-col overflow-hidden shrink-0">
                        <div class="px-4 py-3 flex items-center justify-between border-b" style="border-color: var(--cv-border);">
                            <h2 class="cv-title text-base">Detalle de empleado</h2>
                            <span class="cv-badge cv-badge-action">Editando</span>
                        </div>
                        <div class="flex-1 overflow-y-auto cv-scroll p-4 space-y-3">
                            <div class="flex items-center gap-3 pb-4 border-b" style="border-color: var(--cv-border);">
                                <div class="w-14 h-14 rounded-full flex items-center justify-center text-white text-lg font-bold"
                                     style="background: linear-gradient(135deg, var(--cv-primary), var(--cv-action));">RM</div>
                                <div>
                                    <p class="cv-text font-bold text-base">Rosita Martinez</p>
                                    <p class="cv-muted text-xs">Administrador &middot; #EMP-001</p>
                                </div>
                            </div>
                            <div>
                                <label class="cv-label block mb-1.5">Correo</label>
                                <input type="email" class="cv-input" value="rosita@ejemplo.mx">
                            </div>
                            <div>
                                <label class="cv-label block mb-1.5">Telefono</label>
                                <input type="tel" class="cv-input" value="55 1234 5678">
                            </div>
                            <div>
                                <label class="cv-label block mb-1.5">Status</label>
                                <select class="cv-select">
                                    <option>Activo</option>
                                    <option>Vacaciones</option>
                                    <option>Baja</option>
                                </select>
                            </div>
                        </div>
                        <div class="cv-sticky-footer">
                            <button class="cv-btn cv-btn-ghost cv-btn-sm">Cancelar</button>
                            <button class="cv-btn cv-btn-action cv-btn-sm">Guardar cambios</button>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </main>
</div>
```

### 6.3 Tab Layout

Layout con tabs dentro del `cv-main-container`.

```html
<div class="cv-main-container" id="root">
    <div class="flex items-center justify-between mb-5">
        <div>
            <h1 class="cv-title text-lg">Cliente: Cafeteria del Norte</h1>
            <p class="cv-muted text-xs">Datos generales, fiscales y de contacto</p>
        </div>
        <span class="cv-chip cv-chip-action">3 tabs</span>
    </div>

    <!-- Tab nav large -->
    <div id="tabComponent" class="bg-gray-200 text-black rounded-lg flex gap-1 px-1 py-1 w-full text-sm overflow-x-auto"
         data-theme="light" data-type="large" data-target="content-tabComponent">
        <button data-state="active" data-tab-id="general"
                class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 bg-white text-black">General</button>
        <button data-state="inactive" data-tab-id="fiscal"
                class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-white">Datos fiscales</button>
        <button data-state="inactive" data-tab-id="contactos"
                class="transition text-sm font-medium rounded px-3 py-2.5 whitespace-nowrap flex-shrink-0 text-gray-600 hover:bg-white">Contactos</button>
    </div>

    <!-- Contenido de tabs -->
    <div id="content-tabComponent" class="mt-2">
        <div id="container-general" class="border p-3 rounded-lg">
            <h3 class="cv-title text-base mb-3">Informacion general</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label class="cv-label block mb-1.5">Razon social</label><input class="cv-input" type="text" value="Cafeteria del Norte SA"></div>
                <div><label class="cv-label block mb-1.5">Telefono</label><input class="cv-input" type="tel" value="55 1234 5678"></div>
            </div>
        </div>
        <div id="container-fiscal" class="hidden border p-3 rounded-lg">
            <h3 class="cv-title text-base mb-3">Datos fiscales</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label class="cv-label block mb-1.5">RFC</label><input class="cv-input" type="text" value="CDN240315ABC"></div>
                <div><label class="cv-label block mb-1.5">Regimen fiscal</label><select class="cv-select"><option>601 General de Ley</option></select></div>
            </div>
        </div>
        <div id="container-contactos" class="hidden border p-3 rounded-lg">
            <h3 class="cv-title text-base mb-3">Contactos</h3>
            <p class="cv-muted text-sm">Lista de contactos del cliente.</p>
        </div>
    </div>
</div>

<script>
// JS del bindTabs (ver seccion 5.11)
</script>
```

---

## 7. Hub Navegacion (index)

Pagina indice con grid de cards navegables agrupadas por categoria.

```html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hub Modulo · Coffee-Varoch</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* >>>>>>> CSS de la seccion 3 <<<<<<< */
        body { font-family: 'Inter', system-ui, sans-serif; }
        .hero-grad {
            background:
              radial-gradient(1200px 400px at 0% -20%, rgba(37,99,235,.12), transparent 60%),
              radial-gradient(900px 380px at 100% 0%, rgba(140,198,63,.12), transparent 60%);
        }
        .ico-wrap {
            width: 44px; height: 44px; border-radius: 12px;
            display:flex; align-items:center; justify-content:center;
            background: rgba(37,99,235,.12); color: var(--cv-action);
        }
    </style>
</head>
<body class="coffee-varoch cv-page">

<header class="hero-grad border-b" style="border-color: var(--cv-border);">
    <div class="max-w-7xl mx-auto px-6 py-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl font-bold"
                 style="background: linear-gradient(135deg, var(--cv-primary), var(--cv-action));">CV</div>
            <div>
                <h1 class="cv-title text-3xl tracking-tight">Modulo · Coffee-Varoch</h1>
                <p class="cv-muted text-sm mt-1">Selecciona una opcion · Paleta institucional Grupo Varoch · Light + Dark</p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <span class="cv-chip cv-chip-action">v1.0 · Estable</span>
            <div class="cv-theme-toggle">
                <button class="cv-theme-btn active" data-theme-set="light">Light</button>
                <button class="cv-theme-btn" data-theme-set="dark">Dark</button>
            </div>
        </div>
    </div>
</header>

<main class="max-w-7xl mx-auto px-6 py-10">

    <!-- KPI bar -->
    <section class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <div class="cv-kpi">
            <span class="cv-kpi-label">Modulos</span>
            <span class="cv-kpi-value">8</span>
            <span class="cv-kpi-foot">Disponibles</span>
        </div>
        <div class="cv-kpi">
            <span class="cv-kpi-label">Activos</span>
            <span class="cv-kpi-value">6</span>
            <span class="cv-kpi-foot">En operacion</span>
        </div>
        <div class="cv-kpi">
            <span class="cv-kpi-label">Usuarios</span>
            <span class="cv-kpi-value">24</span>
            <span class="cv-kpi-foot">Conectados</span>
        </div>
        <div class="cv-kpi">
            <span class="cv-kpi-label">Reportes</span>
            <span class="cv-kpi-value">12</span>
            <span class="cv-kpi-foot">Disponibles</span>
        </div>
    </section>

    <!-- Grupo: Operacion -->
    <div class="flex items-center justify-between mb-4">
        <h2 class="cv-label">Operacion</h2>
        <span class="cv-muted text-xs">4 modulos</span>
    </div>
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">

        <a class="cv-hub-card">
            <div class="flex items-start gap-3">
                <div class="ico-wrap">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18M3 12h18M3 18h18"/></svg>
                </div>
                <div class="flex-1">
                    <div class="flex items-center justify-between">
                        <h3 class="cv-title text-base">Ingresos</h3>
                        <span class="cv-badge cv-badge-success">Activo</span>
                    </div>
                    <p class="cv-muted text-xs mt-1">Cobros y registros de caja</p>
                </div>
            </div>
        </a>

        <a class="cv-hub-card">
            <div class="flex items-start gap-3">
                <div class="ico-wrap" style="background: rgba(255,193,7,.15); color: #b45309;">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                </div>
                <div class="flex-1">
                    <div class="flex items-center justify-between">
                        <h3 class="cv-title text-base">Egresos</h3>
                        <span class="cv-badge cv-badge-warning">Pendiente</span>
                    </div>
                    <p class="cv-muted text-xs mt-1">Pagos a proveedores y retiros</p>
                </div>
            </div>
        </a>

        <a class="cv-hub-card">
            <div class="flex items-start gap-3">
                <div class="ico-wrap" style="background: rgba(140,198,63,.15); color: var(--cv-success);">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                </div>
                <div class="flex-1">
                    <div class="flex items-center justify-between">
                        <h3 class="cv-title text-base">Reportes</h3>
                        <span class="cv-badge cv-badge-info">3 nuevos</span>
                    </div>
                    <p class="cv-muted text-xs mt-1">Exportaciones y resumen mensual</p>
                </div>
            </div>
        </a>

    </section>

    <!-- Grupo: Administracion -->
    <div class="flex items-center justify-between mb-4">
        <h2 class="cv-label">Administracion</h2>
        <span class="cv-muted text-xs">3 modulos</span>
    </div>
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
        <a class="cv-hub-card">
            <h3 class="cv-title text-base">Empleados</h3>
            <p class="cv-muted text-xs mt-1">Gestion de personal y nomina</p>
        </a>
    </section>

</main>

<footer class="border-t mt-10" style="border-color: var(--cv-border);">
    <div class="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
        <span class="cv-muted text-xs">Coffee-Varoch · CoffeeMagic</span>
        <span class="cv-muted text-xs">Hecho con cuidado</span>
    </div>
</footer>

<script>
// Toggle tema (ver seccion 5.18)
</script>

</body>
</html>
```

---

## 8. Reglas Criticas

1. **Header SIEMPRE azul** (`cv-header-primary` con `var(--cv-primary)` #003360). Nunca blanco para modulos.
2. **Sidebar SIEMPRE blanco** (`cv-sidebar` con sombra azulada). Nunca azul. En dark se mantiene claro `#E9ECF1` para legibilidad.
3. **Breadcrumb va DEBAJO del header**, dentro de `#main__content`, ANTES del container — NO dentro del header azul.
4. **`cv-main-container` SIEMPRE existe** con `id="root"`. Padding 16px, border-radius 10px, fondo blanco. Es donde se monta TODO el contenido del modulo.
5. **`--cv-secondary` es ROJO** `#F24444` (no verde). El verde institucional es `--cv-success` `#7AAB20`.
6. **Tablas NO usan clase `.cv-table`** — usan Tailwind puro identico a `createCoffeTable3` de CoffeeSoft. Wrapper obligatorio: `<div class="overflow-hidden rounded-lg border border-gray-200">`.
7. **Tabs NO usan clases `.cv-tab*`** — usan Tailwind puro identico al `tabLayout` de CoffeeSoft. 4 variantes: large, short, button, dark.
8. **Tablas y celdas usan `font-size: 12px` INLINE** (no Tailwind) — replica exacta del original.
9. **El thead default es `bg-[#003360] text-gray-100`** (azul Varoch oscuro con texto claro). No gradientes.
10. **CSS embebido obligatorio** — el grimorio es autocontenido, NO requiere archivos externos. Copia el bloque CSS de la seccion 3 dentro de `<style>` en cada template generado.

---

## 9. Triggers de Activacion

CoffeeMagic carga este grimorio cuando el usuario menciona:

- `"varoch"`, `"coffee-varoch"`, `"paleta varoch"`, `"tema varoch"`
- `"estilo varoch"`, `"institucional varoch"`, `"grupo varoch"`
- Clases prefijadas: `cv-card`, `cv-btn`, `cv-header-primary`, `cv-main-container`, `cv-module-breadcrumb`, etc.
- Referencias a la paleta institucional `#003360` o el azul Varoch.

**Decision de tema:**
- Si menciona "varoch" sin especificar → genera AMBOS (light + dark) con toggle.
- Si menciona "varoch light" → solo modo claro.
- Si menciona "varoch dark" → solo modo oscuro.

---

## 10. Snippets Rapidos Copiables

### Header azul minimo
```html
<header class="cv-header-primary w-full px-3 flex items-center justify-between" style="height:50px;">
    <section style="width:250px;" class="flex items-center gap-3">
        <button class="cv-header-toggle">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <span class="text-white font-bold text-sm">Grupo Varoch</span>
    </section>
    <div class="cv-header-user">
        <div class="cv-header-avatar">R</div>
        <p class="cv-header-username">Rosita</p>
    </div>
</header>
```

### Sidebar minimo
```html
<section class="cv-sidebar" style="width:250px;">
    <ul class="p-3 space-y-1">
        <li><div class="cv-nav-item active"><span class="flex-1">Inicio</span></div></li>
        <li><div class="cv-nav-item"><span class="flex-1">Finanzas</span></div></li>
    </ul>
</section>
```

### Tabla minima (tema default)
```html
<div class="overflow-hidden rounded-lg border border-gray-200">
    <table class="w-full border-separate border-spacing-0 text-sm text-gray-800">
        <thead>
            <tr>
                <th class="bg-[#003360] text-gray-100 px-3 py-2 capitalize font-semibold" style="font-size:12px">Col</th>
            </tr>
        </thead>
        <tbody>
            <tr class="ct3-hoverable">
                <td class="border-b border-gray-200 px-2 py-2" style="font-size:12px">Dato</td>
            </tr>
        </tbody>
    </table>
</div>
```

### Badge success
```html
<span class="cv-badge cv-badge-success">Activo</span>
```

### KPI card
```html
<div class="cv-kpi">
    <span class="cv-kpi-label">Ventas Hoy</span>
    <span class="cv-kpi-value">$12,500</span>
    <span class="cv-kpi-foot">+12% vs ayer</span>
</div>
```

### Boton primary
```html
<button class="cv-btn cv-btn-action">+ Nuevo registro</button>
```

### Modal de confirmacion
```html
<div class="cv-modal-overlay">
    <div class="cv-modal" style="max-width: 400px;">
        <div class="cv-modal-body text-center py-8">
            <h3 class="cv-title text-lg mb-2">Eliminar registro?</h3>
            <p class="cv-muted text-sm">Esta accion no se puede deshacer.</p>
        </div>
        <div class="cv-modal-footer justify-center">
            <button class="cv-btn cv-btn-ghost">Cancelar</button>
            <button class="cv-btn cv-btn-danger">Si, eliminar</button>
        </div>
    </div>
</div>
```

### Input con label
```html
<div>
    <label class="cv-label block mb-1.5">Nombre completo</label>
    <input type="text" class="cv-input" placeholder="Rosita Martinez">
</div>
```

### Theme toggle completo (HTML + JS)
```html
<div class="cv-theme-toggle">
    <button class="cv-theme-btn active" data-theme-set="light">Light</button>
    <button class="cv-theme-btn" data-theme-set="dark">Dark</button>
</div>

<script>
const root = document.body;
const saved = localStorage.getItem('cv-theme') || 'light';
if (saved === 'dark') root.setAttribute('data-theme', 'dark');
document.querySelectorAll('.cv-theme-btn').forEach(btn => {
    if (btn.dataset.themeSet === saved) btn.classList.add('active');
    btn.addEventListener('click', () => {
        const t = btn.dataset.themeSet;
        if (t === 'dark') root.setAttribute('data-theme', 'dark');
        else root.removeAttribute('data-theme');
        localStorage.setItem('cv-theme', t);
        document.querySelectorAll('.cv-theme-btn').forEach(b => b.classList.toggle('active', b.dataset.themeSet === t));
    });
});
</script>
```
