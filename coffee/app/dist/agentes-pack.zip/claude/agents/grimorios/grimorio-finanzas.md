---
grimorio: finanzas
modulo: CoffeeSoft Finanzas
spells: [table, detail, cards, form, hub, modal, selector]
referencia_original: alpha/finanzas/templates/
---

# Grimorio de Finanzas ☕

Patrones UI extraidos del modulo **CoffeeSoft Finanzas** — referencia autoritativa para CoffeeMagic.

> **Decision de tema (heredado de CoffeeMagic.md):**
> - Sin mencion de tema → genera **AMBOS** (light + dark) con toggle.
> - `"tema light"` o `"tema dark"` → genera **SOLO uno** (sin toggle).
> - Default del modo light → **`coffee-varoch`** (no la paleta clasica).
> - Tablas en tema light → SIEMPRE fondo blanco (`#ffffff`).

## Estructura de archivos original

```
alpha/finanzas/templates/
├── finanzas-index-navegacion.html      (hub)
├── finanzas-ingresos.html              (tabla)
├── finanzas-ingresos-detalle.html      (KPI cards + grafico)
├── finanzas-ingresos-efectivo.html     (formulario centrado)
├── finanzas-ingresos-deposito.html     (formulario centrado)
├── finanzas-ingresos-corte-form.html   (formulario grande)
├── finanzas-egresos.html               (tabla)
├── finanzas-egresos-detalle.html       (panel lateral detalle)
├── finanzas-compras.html               (tabla)
├── finanzas-compras-detalle.html       (panel lateral detalle)
└── modals/
    ├── modal-seleccionar-ingreso.html
    ├── modal-seleccionar-orden-compra.html
    ├── modal-confirmacion-datos.html
    ├── modal-nueva-orden-compra.html
    ├── modal-nuevo-proveedor.html
    └── modal-nuevo-egreso.html
```

---

## BASE COMUN (todos los templates)

### HTML shell + CSS reutilizable

```html
<!DOCTYPE html>
<html lang="es" class="bg-[#111928]">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoffeeSoft [Modulo] — [Seccion]</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:#111928; font-family:'Inter',system-ui,sans-serif; color:#fff; height:100vh; overflow:hidden; }
        .scrollbar-thin::-webkit-scrollbar { width:4px; height:4px; }
        .scrollbar-thin::-webkit-scrollbar-track { background:transparent; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background:#374151; border-radius:4px; }

        /* BADGES */
        .badge-base        { display:inline-flex; align-items:center; padding:2px 10px; border-radius:9999px; font-size:10px; font-weight:700; border:1px solid; }
        .badge-aprobado    { background:rgba(63,193,137,.15); color:#3fc189; border-color:rgba(63,193,137,.3); }
        .badge-pagado-blue { background:rgba(28,100,242,.18); color:#76a9fa; border-color:rgba(28,100,242,.35); }
        .badge-pendiente   { background:rgba(251,191,36,.15); color:#fbbf24; border-color:rgba(251,191,36,.3); }
        .badge-rechazado   { background:rgba(234,2,52,.15); color:#ea0234; border-color:rgba(234,2,52,.35); }

        /* BASE */
        .card-base   { background:#1F2A37; border:1px solid rgba(55,65,81,.6); border-radius:12px; }
        .input-base  { background:#1a2332; border:1px solid #374151; border-radius:8px; padding:6px 12px; font-size:12px; color:#d1d5db; }
        .input-base:focus { outline:none; border-color:#7c3aed; }

        /* SIDEBAR */
        .sidebar-item       { display:flex; align-items:center; gap:10px; padding:7px 12px; border-radius:8px; font-size:12px; color:#9ca3af; cursor:pointer; text-decoration:none; }
        .sidebar-item:hover { background:rgba(124,58,237,.08); color:#d1d5db; }
        .sidebar-item.active{ color:#c4b5fd; background:rgba(124,58,237,.15); }
        .sidebar-sub        { padding-left:32px; font-size:11px; }
        .sidebar-sub.active { color:#c4b5fd; background:rgba(124,58,237,.12); border-left:2px solid #7c3aed; }

        /* DETALLE (panel lateral) */
        .detail-label { font-size:10px; color:#6b7280; font-weight:600; text-transform:uppercase; letter-spacing:.03em; margin-bottom:2px; }
        .detail-value { font-size:12px; color:#d1d5db; line-height:1.4; }

        /* BADGE FECHA (subheader) */
        .badge-fecha { display:inline-flex; align-items:center; gap:6px; background:#7c3aed; color:#fff; padding:6px 16px; border-radius:8px; font-size:13px; font-weight:600; }

        /* LIGHT THEME OVERRIDES */
        body[data-theme="light"] { background:#f3f4f6; color:#111928; }
        body[data-theme="light"] aside.bg-\[\#0f172a\] { background:#ffffff !important; }
        body[data-theme="light"] .bg-\[\#111928\] { background:#f9fafb !important; }
        body[data-theme="light"] .bg-\[\#141d2b\] { background:#ffffff !important; }
        body[data-theme="light"] .bg-\[\#1a2332\] { background:#f3f4f6 !important; }
        body[data-theme="light"] .bg-\[\#1F2A37\] { background:#ffffff !important; }
        body[data-theme="light"] .border-gray-800 { border-color:#e5e7eb !important; }
        body[data-theme="light"] .border-gray-700 { border-color:#d1d5db !important; }
        body[data-theme="light"] .text-white { color:#111928 !important; }
        body[data-theme="light"] .text-gray-300 { color:#374151 !important; }
        body[data-theme="light"] .text-gray-400 { color:#4b5563 !important; }
        body[data-theme="light"] .text-gray-500 { color:#6b7280 !important; }
        body[data-theme="light"] .text-gray-600 { color:#9ca3af !important; }
        body[data-theme="light"] .sidebar-item { color:#6b7280 !important; }
        body[data-theme="light"] .sidebar-item:hover { background:rgba(124,58,237,.08) !important; color:#111928 !important; }
        body[data-theme="light"] .sidebar-item.active { color:#7c3aed !important; background:rgba(124,58,237,.12) !important; }
        body[data-theme="light"] .hover\:bg-\[\#1a2332\]:hover { background:#f3f4f6 !important; }
        body[data-theme="light"] thead { background:#f9fafb !important; }
        body[data-theme="light"] .divide-gray-800\/50 > * + * { border-color:#e5e7eb !important; }
        body[data-theme="light"] .card-base { background:#ffffff !important; border-color:#e5e7eb !important; }
        body[data-theme="light"] .input-base { background:#f9fafb !important; border-color:#e5e7eb !important; color:#111928 !important; }
        body[data-theme="light"] input::placeholder { color:#9ca3af !important; }
        body[data-theme="light"] .detail-label { color:#9ca3af !important; }
        body[data-theme="light"] .detail-value { color:#374151 !important; }

        /* LIGHT THEME — botones de color SIEMPRE conservan texto blanco */
        body[data-theme="light"] [class*="bg-blue-6"].text-white,
        body[data-theme="light"] [class*="bg-blue-7"].text-white,
        body[data-theme="light"] [class*="bg-purple-6"].text-white,
        body[data-theme="light"] [class*="bg-purple-7"].text-white,
        body[data-theme="light"] [class*="bg-green-6"].text-white,
        body[data-theme="light"] [class*="bg-green-7"].text-white,
        body[data-theme="light"] [class*="bg-red-6"].text-white,
        body[data-theme="light"] [class*="bg-red-7"].text-white,
        body[data-theme="light"] [class*="bg-orange-6"].text-white,
        body[data-theme="light"] [class*="bg-pink-6"].text-white,
        body[data-theme="light"] [class*="bg-emerald-6"].text-white,
        body[data-theme="light"] [class*="bg-yellow-6"].text-white,
        body[data-theme="light"] [class*="bg-indigo-6"].text-white,
        body[data-theme="light"] .badge-fecha,
        body[data-theme="light"] .toggle-pill.active,
        body[data-theme="light"] button[class*="bg-blue-"]:not([class*="bg-blue-50"]):not([class*="bg-blue-100"]):not([class*="bg-blue-500/15"]),
        body[data-theme="light"] button[class*="bg-purple-"]:not([class*="bg-purple-50"]):not([class*="bg-purple-100"]):not([class*="bg-purple-500/15"]) { color:#ffffff !important; }

        /* LIGHT THEME — badges con mayor contraste (estatus + categoria) */
        body[data-theme="light"] .bg-green-500\/15   { background:#dcfce7 !important; }
        body[data-theme="light"] .text-green-400     { color:#166534 !important; }
        body[data-theme="light"] .border-green-500\/30 { border-color:#86efac !important; }

        body[data-theme="light"] .bg-yellow-500\/15  { background:#fef3c7 !important; }
        body[data-theme="light"] .text-yellow-400    { color:#92400e !important; }
        body[data-theme="light"] .border-yellow-500\/30 { border-color:#fcd34d !important; }

        body[data-theme="light"] .bg-red-500\/15     { background:#fee2e2 !important; }
        body[data-theme="light"] .text-red-400       { color:#991b1b !important; }
        body[data-theme="light"] .border-red-500\/30 { border-color:#fca5a5 !important; }

        body[data-theme="light"] .bg-blue-500\/15    { background:#dbeafe !important; }
        body[data-theme="light"] .text-blue-400      { color:#1e40af !important; }
        body[data-theme="light"] .border-blue-500\/30 { border-color:#93c5fd !important; }

        body[data-theme="light"] .bg-purple-500\/15  { background:#ede9fe !important; }
        body[data-theme="light"] .text-purple-400    { color:#5b21b6 !important; }
        body[data-theme="light"] .border-purple-500\/30 { border-color:#c4b5fd !important; }

        body[data-theme="light"] .bg-orange-500\/15  { background:#ffedd5 !important; }
        body[data-theme="light"] .text-orange-400    { color:#9a3412 !important; }
        body[data-theme="light"] .border-orange-500\/30 { border-color:#fdba74 !important; }

        body[data-theme="light"] .bg-pink-500\/15    { background:#fce7f3 !important; }
        body[data-theme="light"] .text-pink-400      { color:#9d174d !important; }
        body[data-theme="light"] .border-pink-500\/30 { border-color:#f9a8d4 !important; }

        body[data-theme="light"] .bg-emerald-500\/15 { background:#d1fae5 !important; }
        body[data-theme="light"] .text-emerald-400   { color:#065f46 !important; }
        body[data-theme="light"] .border-emerald-500\/30 { border-color:#6ee7b7 !important; }

        body[data-theme="light"] .bg-gray-500\/15    { background:#e5e7eb !important; }
        body[data-theme="light"] .border-gray-500\/30 { border-color:#9ca3af !important; }

        [data-theme-btn] { transition:.15s; }
        [data-theme-btn].theme-active { background:rgba(124,58,237,.8); color:#fff !important; border-radius:4px; }
    </style>
</head>
<body class="flex">
    <!-- Contenido -->
    <script>
        (function(){const t=localStorage.getItem('huubie-theme')||'dark';document.body.setAttribute('data-theme',t)})();
        function setTheme(theme){document.body.setAttribute('data-theme',theme);localStorage.setItem('huubie-theme',theme);document.querySelectorAll('[data-theme-btn]').forEach(b=>{b.classList.toggle('theme-active',b.dataset.themeBtn===theme)})}
        window.addEventListener('DOMContentLoaded',()=>{const t=document.body.getAttribute('data-theme');document.querySelectorAll('[data-theme-btn]').forEach(b=>{b.classList.toggle('theme-active',b.dataset.themeBtn===t)})});
    </script>
</body>
</html>
```

### Sidebar estandar Finanzas

```html
<aside class="w-56 bg-[#0f172a] border-r border-gray-800 flex flex-col flex-shrink-0 h-screen">
    <div class="px-4 py-4 border-b border-gray-800 flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center font-bold text-xs">hb</div>
        <span class="font-bold text-sm">CoffeeSoft</span>
    </div>
    <nav class="flex-1 overflow-y-auto scrollbar-thin py-3 px-2">
        <a href="#" class="sidebar-item"><svg class="w-4 h-4" ...>...</svg>Inicio</a>
        <div class="sidebar-item">RRHH</div>
        <div class="sidebar-item">Mkt y Clientes</div>
        <div class="sidebar-item">Calidad</div>
        <div class="sidebar-item active">
            <svg class="w-4 h-4" ...>...</svg>
            Finanzas
            <svg class="w-3 h-3 ml-auto">...</svg>
        </div>
        <div class="mt-1 space-y-0.5">
            <a href="finanzas-ingresos.html" class="sidebar-item sidebar-sub active">Ingresos</a>
            <a href="finanzas-egresos.html" class="sidebar-item sidebar-sub">Egresos</a>
            <a href="finanzas-compras.html" class="sidebar-item sidebar-sub">Compras</a>
            <div class="sidebar-item sidebar-sub opacity-60">Bancos</div>
            <div class="sidebar-item sidebar-sub opacity-60">Finanzas</div>
            <div class="sidebar-item sidebar-sub opacity-60">CxC y CxP</div>
            <div class="sidebar-item sidebar-sub opacity-60">Presupuestos</div>
            <div class="sidebar-item sidebar-sub opacity-60">Cuentas</div>
        </div>
    </nav>
    <div class="px-2 py-3 border-t border-gray-800 space-y-0.5">
        <div class="sidebar-item">Settings</div>
        <div class="sidebar-item">Logout</div>
    </div>
    <div class="px-4 py-3 border-t border-gray-800">
        <div class="text-[10px] text-gray-600"><span class="font-bold text-purple-400">huubie</span></div>
    </div>
</aside>
```

### Header estandar (search + theme toggle + avatar)

```html
<header class="flex items-center justify-between px-6 py-3 bg-[#141d2b] border-b border-gray-800 flex-shrink-0">
    <div class="flex items-center gap-3 flex-1 max-w-md">
        <svg class="w-4 h-4 text-gray-500" ...>...</svg>
        <input type="text" placeholder="Search" class="bg-transparent text-sm text-gray-300 w-full focus:outline-none">
    </div>
    <div class="flex items-center gap-3">
        <div class="flex bg-[#1a2332] border border-gray-700 rounded-lg p-0.5">
            <button data-theme-btn="light" onclick="setTheme('light')" class="px-3 py-1 text-[11px] text-gray-500 rounded">○ Claro</button>
            <button data-theme-btn="dark" onclick="setTheme('dark')" class="px-3 py-1 text-[11px] text-gray-500 rounded">○ Oscuro</button>
        </div>
        <span class="text-[11px] text-gray-500">English</span>
        <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-[10px] font-bold">JM</div>
            <div class="text-right">
                <p class="text-xs font-medium">Juan Marichal</p>
                <p class="text-[10px] text-gray-500">Admin</p>
            </div>
        </div>
    </div>
</header>
```

### Subheader estandar (titulo + badge fecha)

```html
<div class="px-6 py-4 bg-[#141d2b] border-b border-gray-800 flex items-center justify-between flex-shrink-0">
    <div class="flex items-center gap-3">
        <h1 class="text-lg font-bold">[Titulo Seccion]</h1>
        <div class="badge-fecha">
            <svg class="w-4 h-4" ...>...</svg>
            Fecha
        </div>
    </div>
</div>
```

### Barra de filtros

```html
<div class="flex items-center gap-3 px-6 py-3 bg-[#141d2b] border-b border-gray-800 flex-shrink-0">
    <div class="flex items-center gap-2 text-xs text-gray-400">
        <svg class="w-4 h-4" ...>...</svg>
        <span class="font-semibold">Filter By</span>
    </div>
    <select class="input-base"><option>Campo 1</option></select>
    <input type="text" class="input-base w-36">
    <select class="input-base"><option>Status</option></select>
    <button class="text-xs text-red-400 font-semibold hover:text-red-300 flex items-center gap-1">
        <svg class="w-3 h-3" ...>...</svg>
        Reset Filter
    </button>
    <div class="flex-1"></div>
    <button class="px-4 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold flex items-center gap-2 hover:bg-blue-500">
        [Accion Primaria]
        <svg class="w-3.5 h-3.5" ...>...</svg>
    </button>
</div>
```

### Paginacion

```html
<div class="px-6 py-3 bg-[#141d2b] border-t border-gray-800 flex items-center justify-between text-[11px] text-gray-500 flex-shrink-0">
    <span>Showing 1-09 of 78</span>
    <div class="flex items-center gap-1">
        <button class="w-7 h-7 rounded border border-gray-700 flex items-center justify-center text-gray-400 hover:bg-[#1a2332]">←</button>
        <button class="w-7 h-7 rounded border border-gray-700 flex items-center justify-center text-gray-400 hover:bg-[#1a2332]">→</button>
    </div>
</div>
```

---

## SPELL 1: `conjure table` — Tabla con filtros y paginacion

**Referencia:** `finanzas-ingresos.html`, `finanzas-compras.html`, `finanzas-egresos.html`

**Layout:** Sidebar + (Header → Subheader → Filtros → Tabla scroll → Paginacion)

### Tabla base

```html
<div class="flex-1 overflow-y-auto scrollbar-thin">
    <table class="w-full">
        <thead class="bg-[#141d2b] sticky top-0">
            <tr class="border-b border-gray-800">
                <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium px-6 py-3">ID</th>
                <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium px-3 py-3">Fecha</th>
                <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium px-3 py-3">Encargado</th>
                <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium px-3 py-3">Tipo</th>
                <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium px-3 py-3">Importe</th>
                <th class="text-center text-[10px] text-gray-500 uppercase tracking-wider font-medium px-3 py-3">Ver</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-800/50">
            <tr class="hover:bg-[#1a2332] transition-colors">
                <td class="px-6 py-3 text-xs text-gray-300">00001</td>
                <td class="px-3 py-3 text-xs text-gray-300">1 Ene 2024</td>
                <td class="px-3 py-3 text-xs text-gray-300">Juan Marichal</td>
                <td class="px-3 py-3 text-xs text-gray-300">Corte X</td>
                <td class="px-3 py-3 text-xs font-semibold text-white">2,300</td>
                <td class="px-3 py-3 text-center">
                    <a href="#" class="text-gray-400 hover:text-purple-400">
                        <svg class="w-4 h-4 mx-auto" ...>...</svg>
                    </a>
                </td>
            </tr>
        </tbody>
    </table>
</div>
```

### Reglas criticas tabla
- `thead` con `sticky top-0 bg-[#141d2b]` (se queda fijo al scroll).
- `tbody` con `divide-y divide-gray-800/50` para separadores sutiles.
- Filas con `hover:bg-[#1a2332] transition-colors`.
- Celdas monetarias con `font-semibold text-white`.
- Fila "seleccionada" (cuando hay panel lateral abierto): `bg-[#1a2332]/40`.
- Iconos accion: `text-gray-400 hover:text-purple-400` (ver detalle) o `hover:text-blue-400` (comprobante).

---

## SPELL 2: `conjure detail` — Vista detalle con panel lateral

**Referencia:** `finanzas-compras-detalle.html`, `finanzas-egresos-detalle.html`

**Layout:** Sidebar + [Area principal (tabla simplificada) | Panel lateral 420px (detalle)]

### Estructura split

```html
<div class="flex-1 flex min-w-0 h-screen">
    <!-- AREA PRINCIPAL (tabla resumen) -->
    <div class="flex-1 flex flex-col min-w-0">
        <!-- header + subheader + filtros + tabla + paginacion -->
    </div>

    <!-- PANEL LATERAL DERECHO -->
    <aside class="w-[420px] bg-[#1F2A37] border-l border-gray-800 flex flex-col h-screen flex-shrink-0 overflow-y-auto scrollbar-thin">
        <!-- panel header + body + footer -->
    </aside>
</div>
```

### Panel header (titulo + badges + navegacion)

```html
<div class="px-5 pt-5 pb-3 border-b border-gray-800">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-white">ID OC01</h2>
        <div class="flex items-center gap-1">
            <button class="w-7 h-7 rounded border border-gray-700 flex items-center justify-center text-gray-400 hover:bg-[#1a2332] hover:text-white">←</button>
            <button class="w-7 h-7 rounded border border-gray-700 flex items-center justify-center text-gray-400 hover:bg-[#1a2332] hover:text-white">→</button>
        </div>
    </div>
    <div class="flex items-start gap-3 flex-wrap">
        <div class="flex flex-col items-start gap-1">
            <span class="badge-base badge-aprobado">APROBADO</span>
            <span class="text-[10px] text-gray-500">31 ene 2024 2:00pm</span>
        </div>
        <div class="flex flex-col items-start gap-1">
            <span class="badge-base badge-pagado-blue">PAGADO</span>
            <span class="text-[10px] text-gray-500">31 ene 2024 5:00pm</span>
        </div>
    </div>
</div>
```

### Panel body (grid clave-valor)

```html
<div class="flex-1 px-5 py-4 space-y-4">
    <div class="grid grid-cols-2 gap-4">
        <div>
            <p class="detail-label">Cuenta</p>
            <p class="detail-value">Mantenimiento</p>
        </div>
        <div>
            <p class="detail-label">Pago</p>
            <p class="detail-value">Aprovisionado</p>
        </div>
    </div>

    <div class="border-t border-gray-800"></div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <p class="detail-label">Cotizacion</p>
            <div class="flex items-center gap-2 mt-1">
                <svg class="w-4 h-4 text-red-400 flex-shrink-0" ...>...</svg>
                <span class="detail-value text-blue-400 cursor-pointer hover:underline">Cotizacion.PDF</span>
            </div>
        </div>
    </div>

    <!-- Monto desglosado -->
    <div>
        <p class="detail-label">Monto</p>
        <p class="detail-value text-[11px]">Sub Total: <span class="text-white font-medium">2,300</span></p>
        <p class="detail-value text-[11px]">Impuestos: <span class="text-white font-medium">0</span></p>
        <p class="detail-value text-[11px]">Total: <span class="text-white font-semibold">2,300</span></p>
    </div>
</div>
```

### Panel footer (botones de accion)

```html
<div class="px-5 py-4 border-t border-gray-800">
    <div class="mb-4">
        <p class="text-xs font-semibold text-gray-300">Realizado</p>
        <p class="text-[11px] text-gray-500">31 ene 2024 12:00 pm</p>
    </div>
    <div class="flex items-center gap-3">
        <button class="flex-1 px-4 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300 hover:bg-[#1a2332] transition">Cambiar Estatus</button>
        <button class="flex-1 px-4 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300 hover:bg-[#1a2332] transition">Cerrar</button>
    </div>
</div>
```

### Reglas criticas detail
- Panel lateral SIEMPRE `w-[420px]` (fijo).
- Usar `.detail-label` / `.detail-value` para consistencia.
- Divisores `<div class="border-t border-gray-800"></div>` entre secciones.
- Grid `grid-cols-2 gap-4` para pares de campos.
- Archivos adjuntos en azul `text-blue-400 cursor-pointer hover:underline`.
- Totales con `text-white font-semibold`.

---

## SPELL 3: `conjure cards` — Dashboard con KPI cards

**Referencia:** `finanzas-ingresos-detalle.html`

### KPI card base

```html
<div class="card-base p-4">
    <div class="flex items-start justify-between mb-1">
        <p class="text-3xl font-bold text-white">5</p>
        <div class="w-8 h-8 rounded-lg bg-green-500/20 text-green-400 flex items-center justify-center">
            <svg class="w-4 h-4" ...>+</svg>
        </div>
    </div>
    <p class="text-xs font-semibold text-white">Altas</p>
    <p class="text-[10px] text-gray-500">del 15 al 30 agosto 2024</p>
</div>
```

### Grid de KPIs

```html
<div class="grid grid-cols-5 gap-4 mb-6">
    <!-- 4 cards KPI -->
    <!-- + 1 card vacia tipo "Agregar" con borde dashed -->
    <button class="rounded-xl border-2 border-dashed border-purple-500/40 flex items-center justify-center text-purple-400 hover:bg-purple-500/5 transition">
        <svg class="w-8 h-8" ...>+</svg>
    </button>
</div>
```

### KPI con tendencia

```html
<div class="card-base p-4">
    <p class="text-[10px] text-gray-500 uppercase tracking-wider">Total Efectivo</p>
    <p class="text-2xl font-bold text-white mt-1">$768.89</p>
    <p class="text-[10px] text-green-400 mt-1">↑ 12% vs mes anterior</p>
</div>
```

### Reglas cards
- Valor numerico grande: `text-3xl font-bold text-white` o `text-2xl`.
- Label: `text-[10px] text-gray-500 uppercase tracking-wider`.
- Icono en esquina: `w-8 h-8 rounded-lg bg-[color]-500/20 text-[color]-400`.
- Tendencia positiva: `text-green-400 ↑`. Negativa: `text-red-400 ↓`.
- Colores por tipo: altas→green, bajas→red, info→blue, staff→purple.

---

## SPELL 4: `conjure form` — Formulario centrado

**Referencia:** `finanzas-ingresos-efectivo.html`, `finanzas-ingresos-deposito.html`, `finanzas-ingresos-corte-form.html`

### Card centrada con formulario

```html
<div class="flex-1 flex items-center justify-center p-6">
    <div class="card-base p-6 w-full max-w-md">
        <h2 class="text-base font-bold mb-5">[Titulo Form]</h2>

        <div class="space-y-4">
            <div>
                <label class="block text-[11px] text-gray-500 mb-1">Monto</label>
                <input type="text" class="input-base w-full">
            </div>
            <div>
                <label class="block text-[11px] text-gray-500 mb-1">Cuenta</label>
                <select class="input-base w-full"><option>Seleccionar</option></select>
            </div>
            <div>
                <label class="block text-[11px] text-gray-500 mb-1">Observaciones</label>
                <textarea class="input-base w-full" rows="3"></textarea>
            </div>
        </div>

        <div class="flex items-center gap-3 mt-6 justify-center">
            <button class="px-6 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300 hover:bg-[#1a2332]">Cancelar</button>
            <button class="px-6 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold hover:bg-blue-500">Enviar</button>
        </div>
    </div>
</div>
```

### Formulario grid 2-3 columnas (para forms complejos)

```html
<div class="card-base p-6 w-full max-w-3xl">
    <h2 class="text-base font-bold mb-5">Nueva Orden de Compra</h2>

    <div class="grid grid-cols-2 gap-4">
        <div><label class="block text-[11px] text-gray-500 mb-1">Cuenta</label><select class="input-base w-full"><option>...</option></select></div>
        <div><label class="block text-[11px] text-gray-500 mb-1">Detalle</label><input class="input-base w-full"></div>
        <div><label class="block text-[11px] text-gray-500 mb-1">Monto</label><input class="input-base w-full"></div>
        <div><label class="block text-[11px] text-gray-500 mb-1">Tipo de pago</label><select class="input-base w-full"><option>...</option></select></div>
    </div>

    <!-- Upload zona drag-drop -->
    <div class="mt-4">
        <label class="block text-[11px] text-gray-500 mb-1">Cotizacion</label>
        <div class="border-2 border-dashed border-gray-700 rounded-lg p-4 text-center hover:border-purple-500/50 transition">
            <p class="text-xs text-gray-400">Arrastra archivo o <span class="text-purple-400 cursor-pointer">selecciona</span></p>
            <p class="text-[10px] text-gray-500 mt-1">PDF, XLS, JPG · Max 5MB</p>
        </div>
    </div>

    <div class="flex items-center gap-3 mt-6 justify-end">
        <button class="px-6 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300">Cancelar</button>
        <button class="px-6 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold">Guardar</button>
    </div>
</div>
```

### Reglas form
- Label SIEMPRE `text-[11px] text-gray-500 mb-1`.
- Input SIEMPRE `.input-base w-full`.
- Botones accion centrados (form simple) o a la derecha (form complejo).
- Boton primario `bg-[#1c64f2]`. Secundario `border-gray-600`.
- Anchos: `max-w-md` (simple), `max-w-2xl` (medio), `max-w-3xl` (complejo).

---

## SPELL 5: `conjure hub` — Pagina indice de navegacion

**Referencia:** `finanzas-index-navegacion.html`

### Shell hub (SIN sidebar)

```html
<body class="p-8">
    <div class="max-w-6xl mx-auto">
        <header class="mb-8">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-purple-600 flex items-center justify-center font-bold text-sm">hb</div>
                    <div>
                        <h1 class="text-2xl font-bold">CoffeeSoft — Modulo [Nombre]</h1>
                        <p class="text-[12px] text-gray-500">Demos estaticas · Fase 1 · Plantillas HTML navegables</p>
                    </div>
                </div>
                <!-- theme toggle -->
            </div>
            <p class="text-sm text-gray-400 mt-4 max-w-2xl">Descripcion del hub...</p>
        </header>

        <!-- Seccion -->
        <h2 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Nombre Seccion</h2>
        <div class="grid grid-cols-3 gap-4 mb-8">
            <a href="template.html" class="card-demo">
                <div class="w-10 h-10 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center mb-3">
                    <svg class="w-5 h-5" ...>...</svg>
                </div>
                <h3 class="text-sm font-bold mb-1">Titulo Card</h3>
                <p class="text-[11px] text-gray-500">Descripcion del template</p>
                <p class="text-[10px] text-purple-400 mt-3">referencia.png →</p>
            </a>
        </div>

        <footer class="text-center text-[11px] text-gray-600 pt-8 border-t border-gray-800">
            <p>© 2026 CoffeeSoft, LLC. · Modulo [Nombre] Fase 1</p>
        </footer>
    </div>
</body>
```

### Regla clase card-demo especifica del hub

```css
.card-demo { background:#1F2A37; border:1px solid rgba(55,65,81,.6); border-radius:12px; padding:1.5rem; transition:.15s; text-decoration:none; display:block; }
.card-demo:hover { border-color:#7c3aed; transform:translateY(-2px); box-shadow:0 10px 30px rgba(0,0,0,.3); }
```

### Reglas hub
- Body con `p-8` y contenedor `max-w-6xl mx-auto` (NO sidebar).
- Grid `grid-cols-3 gap-4` para cards.
- H2 de seccion: `text-sm font-bold text-gray-400 uppercase tracking-wider mb-3`.
- Icono en cuadrado redondeado con color contextual `bg-[color]-500/20 text-[color]-400`.
- Al final de cada card: `text-[10px] text-purple-400 mt-3` con nombre de mockup.

---

## SPELL 6: `conjure modal` — Modal reutilizable

**Referencia:** `modals/modal-confirmacion-datos.html`, `modals/modal-nueva-orden-compra.html`

### Estructura base modal

```html
<div id="modalId" class="hidden fixed inset-0 bg-black/60 z-40 items-center justify-center">
    <div class="bg-[#1F2A37] rounded-2xl p-6 border border-gray-700 w-[480px] relative">
        <button onclick="document.getElementById('modalId').classList.add('hidden');document.getElementById('modalId').classList.remove('flex')" class="absolute top-3 right-3 text-gray-400 hover:text-white">
            <svg class="w-4 h-4" ...><!-- X --></svg>
        </button>

        <h3 class="text-base font-bold mb-4">Titulo Modal</h3>

        <!-- Contenido -->

        <div class="flex justify-center gap-3 mt-5">
            <button class="px-6 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300">Cancelar</button>
            <button class="px-6 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold">Aceptar</button>
        </div>
    </div>
</div>
```

### Anchos estandar modal
| Proposito | Ancho |
|-----------|-------|
| Confirmacion Si/No | `w-[400px]` |
| Selector tipo grid | `w-[480px]` a `w-[520px]` |
| Formulario medio | `w-[600px]` |
| Formulario complejo | `w-[720px]` |

### Toggle del modal
```html
<!-- Abrir -->
<button onclick="document.getElementById('modalId').classList.remove('hidden');document.getElementById('modalId').classList.add('flex')">Abrir</button>
<!-- Cerrar (dentro del modal) -->
<button onclick="document.getElementById('modalId').classList.add('hidden');document.getElementById('modalId').classList.remove('flex')">×</button>
```

---

## SPELL 7: `conjure selector` — Modal de seleccion tipo grid

**Referencia:** `modals/modal-seleccionar-ingreso.html`, `modals/modal-seleccionar-orden-compra.html`

### Grid de opciones 2 columnas

```html
<div id="modalSelIngreso" class="hidden fixed inset-0 bg-black/60 z-40 items-center justify-center">
    <div class="bg-[#1F2A37] rounded-2xl p-6 border border-gray-700 w-[480px] relative">
        <button class="absolute top-3 right-3 text-gray-400 hover:text-white">×</button>
        <h3 class="text-base font-bold mb-4">Seleccionar Ingreso :</h3>

        <div class="grid grid-cols-2 gap-3 mb-3">
            <button class="p-3 rounded-xl border border-gray-700 text-left text-xs text-gray-300 hover:border-purple-500 hover:bg-purple-500/5 transition">Corte X</button>
            <button class="p-3 rounded-xl border border-gray-700 text-left text-xs text-gray-300 hover:border-purple-500 hover:bg-purple-500/5 transition">Corte Y</button>
        </div>

        <p class="text-[10px] text-gray-500 mb-3">*Archivos: XLS, CSV, PDF</p>

        <div class="grid grid-cols-2 gap-3 mb-3">
            <button class="p-3 rounded-xl border border-gray-700 text-left text-xs text-gray-300 hover:border-purple-500 hover:bg-purple-500/5 transition">Manual Corte X</button>
            <button class="p-3 rounded-xl border border-gray-700 text-left text-xs text-gray-300 hover:border-purple-500 hover:bg-purple-500/5 transition">Manual Corte Y</button>
        </div>

        <div class="flex justify-center">
            <button class="px-8 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold hover:bg-blue-500">Aceptar</button>
        </div>
    </div>
</div>
```

### Reglas selector
- Botones de opcion: `p-3 rounded-xl border border-gray-700 hover:border-purple-500 hover:bg-purple-500/5`.
- Grid `grid-cols-2 gap-3`.
- Texto alineado a la izquierda.
- Seleccionado: `border-purple-500 bg-purple-500/10`.
- Boton Aceptar centrado al final: `bg-[#1c64f2]`.

---

## Paleta especifica Finanzas

| Token | Valor | Uso |
|-------|-------|-----|
| bg body | `#111928` | Fondo principal |
| bg sidebar | `#0f172a` | Sidebar |
| bg header/subheader | `#141d2b` | Headers |
| bg input/hover | `#1a2332` | Inputs y hover |
| bg card/panel | `#1F2A37` | Cards y paneles |
| border | `border-gray-800` | Bordes principales |
| accent | `#7c3aed` | Purple (hovers, active) |
| primary btn | `#1c64f2` | Botones accion principal |
| status aprobado | `#3fc189` | Green-400 |
| status pagado | `#76a9fa` | Blue-400 |
| status pendiente | `#fbbf24` | Yellow-400 |
| status rechazado | `#ea0234` | Red-400 |

## Reglas globales Finanzas

1. SIEMPRE Tailwind CDN + Inter Google Fonts
2. Tema por defecto segun peticion del usuario (ver "Decision de tema" arriba) — sin mencion → ambos con toggle
3. SIEMPRE estilos base en `<style>` inline (no CSS externo)
4. SIEMPRE `body class="flex"` para layout sidebar + contenido
5. SIEMPRE `h-screen overflow-hidden` en body (scroll interno en areas especificas)
6. Scrollbars finos con clase `.scrollbar-thin`
7. Iconos SVG inline (stroke, no fill) — no Font Awesome
8. Theme toggle con `localStorage` key `huubie-theme`
9. **Tablas en tema light** SIEMPRE con fondo blanco (`#ffffff`), no `#f3f4f6`
10. **Default del modo light** → `coffee-varoch` (importar `../utils/coffee-varoch.css` + `<body class="coffee-varoch">`). La paleta light clasica solo si el usuario pide "coffee clasico"
