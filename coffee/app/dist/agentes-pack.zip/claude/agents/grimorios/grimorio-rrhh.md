---
grimorio: rrhh
modulo: CoffeeSoft Recursos Humanos
spells: [table, cards, grid, recibo, form, modal]
referencia_original: alpha/rrhh/templates/
---

# Grimorio de RRHH ☕

Patrones UI extraidos del modulo **CoffeeSoft Recursos Humanos** — referencia autoritativa para CoffeeMagic.

> **Decision de tema (heredado de CoffeeMagic.md):**
> - Sin mencion de tema → genera **AMBOS** (light + dark) con toggle.
> - `"tema light"` o `"tema dark"` → genera **SOLO uno** (sin toggle).
> - Default del modo light → **`coffee-varoch`** (no la paleta clasica).
> - Tablas en tema light → SIEMPRE fondo blanco (`#ffffff`).

## Estructura de archivos original

```
alpha/rrhh/templates/
├── rrhh-index-navegacion.html          (hub)
├── rrhh-resumen.html                   (dashboard KPI + chart + tabla)
├── rrhh-personal.html                  (tabla empleados con avatar)
├── rrhh-incidencia-diario.html         (grid asistencia diario)
├── rrhh-incidencia-personalizado.html  (grid calendario 7 dias)
├── rrhh-nomina.html                    (tabla nomina)
├── rrhh-nomina-recibo.html             (vista recibo + panel lateral)
├── rrhh-permisos.html                  (tabla permisos)
└── modals/
    ├── modal-autorizacion.html         (modal confirmacion con avatar)
    ├── modal-permiso-form.html         (modal formulario)
    └── modal-upload.html               (modal upload drag-drop)
```

---

## BASE COMUN (todos los templates)

### HTML shell + CSS base (igual al de finanzas, con badges adicionales)

```css
/* BADGES DE ESTATUS */
.badge-base        { display:inline-flex; align-items:center; padding:2px 10px; border-radius:9999px; font-size:10px; font-weight:700; border:1px solid; }
.badge-aprobado    { background:rgba(63,193,137,.15); color:#3fc189; border-color:rgba(63,193,137,.3); }
.badge-rechazado   { background:rgba(234,2,52,.15); color:#ea0234; border-color:rgba(234,2,52,.35); }
.badge-pendiente   { background:rgba(251,191,36,.15); color:#fbbf24; border-color:rgba(251,191,36,.3); }
.badge-sin-estatus { background:rgba(156,163,175,.15); color:#9ca3af; border-color:rgba(156,163,175,.3); }
.badge-incapacidad { background:rgba(244,114,182,.15); color:#f472b6; border-color:rgba(244,114,182,.3); }
.badge-vacaciones  { background:rgba(124,58,237,.18); color:#c4b5fd; border-color:rgba(124,58,237,.35); }
.badge-permiso     { background:rgba(249,115,22,.15); color:#fb923c; border-color:rgba(249,115,22,.3); }

/* BADGES DE PUESTO */
.badge-puesto-admin  { background:rgba(124,58,237,.18); color:#c4b5fd; border-color:rgba(124,58,237,.35); }
.badge-puesto-cocina { background:rgba(124,58,237,.18); color:#c4b5fd; border-color:rgba(124,58,237,.35); }
.badge-puesto-piso   { background:rgba(28,100,242,.18); color:#76a9fa; border-color:rgba(28,100,242,.35); }

/* BASE */
.card-base   { background:#1F2A37; border:1px solid rgba(55,65,81,.6); border-radius:12px; }
.input-base  { background:#1a2332; border:1px solid #374151; border-radius:8px; padding:6px 12px; font-size:12px; color:#d1d5db; }

/* SIDEBAR (idem finanzas) */
.sidebar-item       { display:flex; align-items:center; gap:10px; padding:7px 12px; border-radius:8px; font-size:12px; color:#9ca3af; cursor:pointer; text-decoration:none; }
.sidebar-item:hover { background:rgba(124,58,237,.08); color:#d1d5db; }
.sidebar-item.active{ color:#c4b5fd; background:rgba(124,58,237,.15); }
.sidebar-sub        { padding-left:32px; font-size:11px; }
.sidebar-sub.active { color:#c4b5fd; background:rgba(124,58,237,.12); border-left:2px solid #7c3aed; }

/* TABS (resumen) */
.tab-btn.active { color:#7c3aed; border-bottom:2px solid #7c3aed; }

/* TOGGLE PILLS (incidencia) */
.toggle-pill          { padding:6px 18px; border-radius:8px; font-size:12px; font-weight:600; cursor:pointer; text-decoration:none; display:inline-block; }
.toggle-pill.active   { background:#7c3aed; color:#fff; }
.toggle-pill.inactive { background:transparent; color:#9ca3af; }

/* DOTS DE ESTATUS (grid asistencia) */
.dot                { display:inline-block; width:6px; height:6px; border-radius:9999px; margin-right:6px; }
.dot-asistencia     { background:#3fc189; }
.dot-falta          { background:#ea0234; }
.dot-vacaciones     { background:#fbbf24; }
.dot-incidencia     { background:#fb923c; }
.dot-reconocimiento { background:#c4b5fd; }

/* CELDAS CLICKEABLES GRID */
.cell-btn         { display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:6px; font-size:11px; color:#d1d5db; cursor:pointer; border:1px solid transparent; }
.cell-btn:hover   { background:rgba(124,58,237,.1); border-color:rgba(124,58,237,.3); }
.cell-btn.open    { background:rgba(124,58,237,.18); border-color:rgba(124,58,237,.5); }

/* DROPDOWN CONTEXTUAL */
.dropdown-menu { position:fixed; background:#1F2A37; border:1px solid #374151; border-radius:8px; padding:4px; min-width:170px; z-index:50; box-shadow:0 10px 30px rgba(0,0,0,.5); }
.dropdown-item { display:flex; align-items:center; gap:8px; padding:7px 12px; border-radius:6px; font-size:11px; color:#d1d5db; cursor:pointer; }
.dropdown-item:hover { background:rgba(124,58,237,.15); }

/* LIGHT THEME OVERRIDES — badges custom RRHH (mayor contraste) */
body[data-theme="light"] .badge-aprobado    { background:#dcfce7 !important; color:#166534 !important; border-color:#86efac !important; }
body[data-theme="light"] .badge-rechazado   { background:#fee2e2 !important; color:#991b1b !important; border-color:#fca5a5 !important; }
body[data-theme="light"] .badge-pendiente   { background:#fef3c7 !important; color:#92400e !important; border-color:#fcd34d !important; }
body[data-theme="light"] .badge-sin-estatus { background:#e5e7eb !important; color:#374151 !important; border-color:#9ca3af !important; }
body[data-theme="light"] .badge-incapacidad { background:#fce7f3 !important; color:#9d174d !important; border-color:#f9a8d4 !important; }
body[data-theme="light"] .badge-vacaciones  { background:#ede9fe !important; color:#5b21b6 !important; border-color:#c4b5fd !important; }
body[data-theme="light"] .badge-permiso     { background:#ffedd5 !important; color:#9a3412 !important; border-color:#fdba74 !important; }

/* LIGHT THEME OVERRIDES — badges de puesto (mayor contraste) */
body[data-theme="light"] .badge-puesto-admin  { background:#ede9fe !important; color:#5b21b6 !important; border-color:#c4b5fd !important; }
body[data-theme="light"] .badge-puesto-cocina { background:#ede9fe !important; color:#5b21b6 !important; border-color:#c4b5fd !important; }
body[data-theme="light"] .badge-puesto-piso   { background:#dbeafe !important; color:#1e40af !important; border-color:#93c5fd !important; }

/* LIGHT THEME — toggle pill activa mantiene texto blanco */
body[data-theme="light"] .toggle-pill.active { background:#7c3aed !important; color:#ffffff !important; }

/* LIGHT THEME — card y input base */
body[data-theme="light"] .card-base   { background:#ffffff !important; border-color:#e5e7eb !important; }
body[data-theme="light"] .input-base  { background:#f9fafb !important; border-color:#e5e7eb !important; color:#111928 !important; }
```

### Sidebar estandar RRHH

```html
<aside class="w-56 bg-[#0f172a] border-r border-gray-800 flex flex-col flex-shrink-0 h-screen">
    <div class="px-4 py-4 border-b border-gray-800 flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center font-bold text-xs">hb</div>
        <span class="font-bold text-sm">CoffeeSoft</span>
    </div>
    <nav class="flex-1 overflow-y-auto scrollbar-thin py-3 px-2">
        <a href="rrhh-resumen.html" class="sidebar-item"><svg class="w-4 h-4">...</svg>Resumen</a>
        <div class="sidebar-item">Finanzas</div>
        <div class="sidebar-item active">Recursos Humanos</div>
        <div class="mt-1 space-y-0.5">
            <a href="rrhh-personal.html" class="sidebar-item sidebar-sub">Personal</a>
            <a href="rrhh-incidencia-diario.html" class="sidebar-item sidebar-sub">Incidencia</a>
            <a href="rrhh-nomina.html" class="sidebar-item sidebar-sub">Nómina</a>
            <a href="rrhh-permisos.html" class="sidebar-item sidebar-sub">Permisos</a>
            <div class="sidebar-item sidebar-sub opacity-60">Desempeño</div>
            <div class="sidebar-item sidebar-sub opacity-60">Reclutamiento</div>
            <div class="sidebar-item sidebar-sub opacity-60">Cursos</div>
            <div class="sidebar-item sidebar-sub opacity-60">Actas</div>
            <div class="sidebar-item sidebar-sub opacity-60">Reconocimientos</div>
            <div class="sidebar-item sidebar-sub opacity-60">Configuración</div>
        </div>
        <div class="sidebar-item mt-1">Operaciones</div>
        <div class="sidebar-item">Mkt y clientes</div>
        <div class="sidebar-item">Ventas</div>
    </nav>
    <div class="px-2 py-3 border-t border-gray-800 space-y-0.5">
        <div class="sidebar-item">Asistencia</div>
        <div class="sidebar-item">Documentos</div>
        <div class="sidebar-item">Ayuda</div>
    </div>
</aside>
```

### Header y theme toggle (identicos a finanzas)

Ver `grimorio-finanzas.md` → sección "Header estandar".

### Subheader RRHH (con fecha y selector)

```html
<div class="flex items-center justify-between px-6 py-4 bg-[#141d2b] border-b border-gray-800 flex-shrink-0">
    <h1 class="text-lg font-bold">Stats</h1>
    <div class="flex items-center gap-3">
        <span class="text-[11px] text-gray-500">9 de agosto del 2024 · 12:32 pm</span>
        <select class="bg-[#1a2332] border border-gray-700 rounded-lg px-3 py-1 text-[11px] text-gray-300"><option>Sucursal</option></select>
    </div>
</div>
```

---

## SPELL 1: `conjure cards` — Dashboard KPI con grafico

**Referencia:** `rrhh-resumen.html`

**Layout:** Sidebar + Header + Subheader + (Scroll: Stats cards + Chart card + Tabla + KPIs nómina)

### Grid KPI cards (5 columnas con "Agregar")

```html
<div class="grid grid-cols-5 gap-4 mb-6">
    <!-- KPI Card -->
    <div class="card-base p-4">
        <div class="flex items-start justify-between mb-1">
            <p class="text-3xl font-bold text-white">5</p>
            <div class="w-8 h-8 rounded-lg bg-green-500/20 text-green-400 flex items-center justify-center">
                <svg class="w-4 h-4" ...>+</svg>
            </div>
        </div>
        <p class="text-xs font-semibold text-white">Altas</p>
        <p class="text-[10px] text-gray-500">del 15 al 30 agosto 2024</p>
    </div>

    <!-- Card tipo "Agregar" (dashed) -->
    <button class="rounded-xl border-2 border-dashed border-purple-500/40 flex items-center justify-center text-purple-400 hover:bg-purple-500/5 transition">
        <svg class="w-8 h-8" ...>+</svg>
    </button>
</div>
```

### Chart card (Chart.js)

```html
<div class="card-base p-5 mb-6">
    <div class="flex items-start justify-between mb-4">
        <div>
            <p class="text-xs text-gray-500 uppercase tracking-wider">Área</p>
            <div class="flex items-baseline gap-2">
                <h2 class="text-2xl font-bold text-white">156</h2>
                <p class="text-[11px] text-gray-500">Número de empleados</p>
            </div>
        </div>
        <div class="flex bg-[#1a2332] border border-gray-700 rounded-lg p-0.5 text-[10px]">
            <button class="px-2 py-1 text-purple-400">Sucursal 1</button>
            <button class="px-2 py-1 text-gray-500">Sucursal 2</button>
        </div>
    </div>

    <!-- Tabs -->
    <div class="flex gap-1 border-b border-gray-800 mb-4 text-[11px]">
        <button class="tab-btn active px-3 py-2 font-semibold">Alta</button>
        <button class="tab-btn px-3 py-2 text-gray-500 border-b-2 border-transparent">Bajas</button>
        <button class="tab-btn px-3 py-2 text-gray-500 border-b-2 border-transparent">Activos</button>
    </div>

    <div class="h-[260px]">
        <canvas id="chartEmpleados"></canvas>
    </div>

    <div class="flex items-center gap-4 mt-3 text-[10px] text-gray-400">
        <div class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-[#7c3aed]"></span>Sucursal 1</div>
        <div class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-[#06b6d4]"></span>Sucursal 2</div>
    </div>
</div>
```

### Chart.js config estandar

```html
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Mar', 'May', 'Jul'],
            datasets: [{
                label: 'Sucursal 1',
                data: [8, 12, 22, 14],
                borderColor: '#7c3aed',
                backgroundColor: 'rgba(124,58,237,.15)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#7c3aed',
                pointRadius: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(55,65,81,.3)' }, ticks: { color: '#6b7280', font: { size: 10 } } },
                y: { beginAtZero: true, grid: { color: 'rgba(55,65,81,.3)' }, ticks: { color: '#6b7280', font: { size: 10 } } }
            }
        }
    });
</script>
```

### KPI simple con tendencia (Grid 3 columnas)

```html
<div class="grid grid-cols-3 gap-4">
    <div class="card-base p-4">
        <p class="text-[10px] text-gray-500 uppercase tracking-wider">Total Efectivo</p>
        <p class="text-2xl font-bold text-white mt-1">$768.89</p>
        <p class="text-[10px] text-green-400 mt-1">↑ 12% vs mes anterior</p>
    </div>
</div>
```

### Reglas cards RRHH
- Grid de 5 con "Agregar" terminal: `grid-cols-5 gap-4`.
- Valor grande: `text-3xl font-bold text-white` (KPI principal) o `text-2xl` (KPI secundario).
- Icono color contextual: altas→green, bajas→red, docs→blue, staff→purple.
- Chart colors: primario `#7c3aed`, secundario `#06b6d4`.
- Tabs con `.tab-btn` — activo subrayado purple.

---

## SPELL 2: `conjure table` — Tabla empleados con avatar y badges

**Referencia:** `rrhh-personal.html`, `rrhh-permisos.html`, `rrhh-resumen.html` (tabla permisos)

**Diferencia vs tabla Finanzas:** Las tablas RRHH tienen avatars circulares + badges de puesto/estatus.

### Tabla con avatar + badges

```html
<table class="w-full">
    <thead>
        <tr class="text-[10px] text-gray-500 uppercase tracking-wider border-b border-gray-800">
            <th class="text-left py-2.5 px-5 font-medium">Colaborador</th>
            <th class="text-left py-2.5 px-3 font-medium">Puesto</th>
            <th class="text-left py-2.5 px-3 font-medium">Turno</th>
            <th class="text-left py-2.5 px-3 font-medium">Permiso</th>
            <th class="text-left py-2.5 px-3 font-medium">Estatus</th>
            <th class="text-center py-2.5 px-3 font-medium">Solicitud</th>
            <th class="text-center py-2.5 px-5 font-medium">Comprobante</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-800/50">
        <tr class="hover:bg-[#1a2332]">
            <!-- Avatar + Nombre -->
            <td class="py-2.5 px-5">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-[9px] font-bold">JL</div>
                    <p class="text-xs font-medium">Jese Leos</p>
                </div>
            </td>
            <td class="py-2.5 px-3"><span class="badge-base badge-puesto-admin">Admin</span></td>
            <td class="py-2.5 px-3 text-[11px] text-gray-400">Matutino</td>
            <td class="py-2.5 px-3"><span class="badge-base badge-incapacidad">Incapacidad</span></td>
            <td class="py-2.5 px-3"><span class="badge-base badge-aprobado">Aprobado</span></td>
            <td class="py-2.5 px-3 text-center"><svg class="w-4 h-4 text-gray-500 mx-auto" ...>...</svg></td>
            <td class="py-2.5 px-5 text-center"><svg class="w-4 h-4 text-gray-500 mx-auto" ...>...</svg></td>
        </tr>
    </tbody>
</table>
```

### Avatares con gradientes

Los avatares son `w-7 h-7` o `w-8 h-8` rounded-full con gradiente `bg-gradient-to-br` + iniciales:

| Persona | Gradiente |
|---------|-----------|
| JL (Jese Leos) | `from-purple-500 to-pink-500` |
| BG (Bonnie Green) | `from-green-500 to-teal-500` |
| LL (Leslie Livingston) | `from-blue-500 to-purple-500` |
| MG (Micheal Gough) | `from-orange-500 to-red-500` |
| JM (Joseph McFall) | `from-pink-500 to-purple-500` |
| RB (Robert Brown) | `from-teal-500 to-blue-500` |
| KN (Karen Nelson) | `from-yellow-500 to-orange-500` |
| HE (Helene Engels) | `from-red-500 to-pink-500` |
| LB (Lana Byrd) | `from-indigo-500 to-purple-500` |
| NS (Neil Sims) | `from-green-500 to-blue-500` |

### Reglas tabla RRHH
- Avatar + nombre en primera celda.
- Badges de puesto y estatus (ver catalogo en CSS base).
- Filas `hover:bg-[#1a2332]` sin `transition-colors` (mas sutil).
- Iconos accion al final: `text-gray-500 mx-auto`.
- Padding celda: `py-2.5 px-3` (mas compacta que finanzas).

---

## SPELL 3: `conjure grid` — Grid calendario interactivo (asistencia)

**Referencia:** `rrhh-incidencia-personalizado.html`, `rrhh-incidencia-diario.html`

**Layout:** Sidebar + Header + Subheader + (Filtros + Toggle) + Grid-tabla con columnas-fecha

### Toggle Diario/Personalizado (pills)

```html
<div class="ml-auto flex bg-[#1a2332] border border-gray-700 rounded-lg p-1 gap-1">
    <a href="rrhh-incidencia-diario.html" class="toggle-pill inactive">Diario</a>
    <button class="toggle-pill active">Personalizado</button>
</div>
```

### Subheader con filtros

```html
<div class="flex items-center gap-2 px-6 py-3 bg-[#141d2b] border-b border-gray-800 flex-shrink-0">
    <div class="flex items-center gap-2 bg-[#1a2332] border border-gray-700 rounded-lg px-3 py-1.5 flex-1 max-w-xs">
        <svg class="w-3.5 h-3.5 text-gray-500" ...>🔍</svg>
        <input type="text" placeholder="Colaborador" class="bg-transparent text-xs text-gray-300 w-full focus:outline-none">
    </div>
    <select class="input-base"><option>Sucursal</option></select>
    <select class="input-base"><option>Turno</option></select>
    <select class="input-base"><option>Estatus</option></select>
    <div class="ml-auto flex bg-[#1a2332] border border-gray-700 rounded-lg p-1 gap-1">
        <a href="rrhh-incidencia-diario.html" class="toggle-pill inactive">Diario</a>
        <button class="toggle-pill active">Personalizado</button>
    </div>
</div>
```

### Grid tabla con columnas-fecha

```html
<div class="flex-1 overflow-auto scrollbar-thin">
    <table class="w-full min-w-[1200px]">
        <thead class="sticky top-0 bg-[#111928] z-10">
            <tr class="text-[10px] text-gray-500 uppercase tracking-wider border-b border-gray-800">
                <th class="text-left py-3 px-6 font-medium">Colaborador</th>
                <th class="text-left py-3 px-3 font-medium">Puesto</th>
                <th class="text-left py-3 px-3 font-medium">Turno</th>
                <th class="text-center py-3 px-2 font-medium">Lunes<br><span class="text-[8px] text-gray-600">22/07/2024</span></th>
                <th class="text-center py-3 px-2 font-medium">Martes<br><span class="text-[8px] text-gray-600">23/07/2024</span></th>
                <!-- ... hasta Domingo -->
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-800/50">
            <tr class="hover:bg-[#1a2332]">
                <td class="py-3 px-6">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-[10px] font-bold">JL</div>
                        <p class="text-xs font-medium">Jese Leos</p>
                    </div>
                </td>
                <td class="py-3 px-3"><span class="badge-base badge-puesto-admin">Admin</span></td>
                <td class="py-3 px-3 text-[11px] text-gray-400">Matutino</td>
                <!-- Celdas por fecha con dots -->
                <td class="py-3 px-2 text-center">
                    <button class="cell-btn"><span class="dot dot-asistencia"></span>Asistencia</button>
                </td>
                <td class="py-3 px-2 text-center">
                    <button class="cell-btn"><span class="dot dot-falta"></span>Falta</button>
                </td>
                <td class="py-3 px-2 text-center">
                    <button class="cell-btn"><span class="dot dot-vacaciones"></span>Vacaciones</button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
```

### Dropdown contextual (cambio de estatus)

```html
<div id="ctxMenu" class="dropdown-menu hidden">
    <div class="dropdown-item" data-status="incidencia"><span class="dot dot-incidencia"></span>Incidencia</div>
    <div class="dropdown-item" data-status="falta"><span class="dot dot-falta"></span>Falta</div>
    <div class="dropdown-item" data-status="asistencia"><span class="dot dot-asistencia"></span>Asistencia</div>
    <div class="dropdown-item" data-status="vacaciones"><span class="dot dot-vacaciones"></span>Vacaciones</div>
    <div class="dropdown-item" data-status="reconocimiento"><span class="dot dot-reconocimiento"></span>Reconocimiento</div>
</div>
```

### Reglas grid calendario
- Tabla con `min-w-[1200px]` (scroll horizontal si no cabe).
- Thead sticky con `z-10`.
- Cada columna de fecha `px-2 text-center` (compacta).
- Header fecha: titulo + `<br>` + subtitulo pequeño con fecha.
- Celda clickeable: `.cell-btn` con `.dot` de color + texto.
- Dropdown fijo: `.dropdown-menu position:fixed` — se abre al click de celda.
- Estados de celda: asistencia (verde), falta (rojo), vacaciones (amarillo), incidencia (naranja), reconocimiento (purple).

---

## SPELL 4: `conjure recibo` — Vista documento/recibo

**Referencia:** `rrhh-nomina-recibo.html`

**Layout:** Sidebar + Header + Subheader + [Card recibo centrada | Panel lateral colaboradores 340px]

### Subheader con accion descarga

```html
<div class="flex items-center justify-between px-6 py-4 bg-[#141d2b] border-b border-gray-800 flex-shrink-0">
    <h1 class="text-lg font-bold">Nómina <span class="text-gray-400 font-normal">— Recibos de Nómina</span></h1>
    <div class="flex items-center gap-3">
        <div class="text-[11px] text-gray-500">27 de marzo del 2024 · 12:32 pm</div>
        <button class="px-3 py-1.5 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold flex items-center gap-1.5">
            <svg class="w-3.5 h-3.5" ...>↓</svg>
            Download Full
            <span class="bg-white/20 px-1.5 py-0.5 rounded text-[9px]">1867</span>
        </button>
    </div>
</div>
```

### Card recibo centrada

```html
<div class="flex-1 flex overflow-hidden">
    <div class="flex-1 overflow-y-auto scrollbar-thin p-6">
        <div class="max-w-3xl mx-auto bg-[#1F2A37] rounded-2xl border border-gray-800 p-6">

            <!-- Header recibo: logo + titulo + numero -->
            <div class="flex items-start justify-between mb-6">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-[#1c64f2]/20 flex items-center justify-center">
                        <svg class="w-5 h-5 text-blue-400" ...>🏢</svg>
                    </div>
                    <div>
                        <h2 class="text-base font-bold">Tu empresa</h2>
                        <p class="text-[11px] text-gray-500">Pago correspondiente a la nomina de fecha a fecha</p>
                    </div>
                </div>
                <div class="text-right">
                    <p class="text-[11px] text-gray-500">Recibo</p>
                    <p class="text-sm font-bold text-white">#1</p>
                </div>
            </div>

            <div class="mb-4">
                <p class="text-[11px] text-gray-500">Fecha: <span class="text-gray-300">05/07/2023</span></p>
            </div>

            <!-- Grid 2 cols: empresa / colaborador -->
            <div class="grid grid-cols-2 gap-6 mb-6">
                <div>
                    <p class="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Empresa</p>
                    <p class="text-xs font-medium text-white">Tu empresa</p>
                    <p class="text-[11px] text-gray-400">Dirección de la empresa</p>
                    <p class="text-[11px] text-gray-400">Datos generales</p>
                </div>
                <div>
                    <p class="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Recibo de nómina</p>
                    <p class="text-xs font-medium text-white">Nombre del colaborador</p>
                    <p class="text-[11px] text-gray-400">email@example.com</p>
                </div>
            </div>

            <!-- Tabla desglose -->
            <table class="w-full mb-4">
                <thead>
                    <tr class="border-y border-gray-700">
                        <th class="text-left text-[10px] text-gray-500 uppercase tracking-wider font-medium py-2">Pago desglosado</th>
                        <th class="text-right text-[10px] text-gray-500 uppercase tracking-wider font-medium py-2">Total Price</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-800/50">
                    <tr>
                        <td class="py-3 text-xs text-gray-300">Salario Total</td>
                        <td class="py-3 text-right text-xs font-bold text-white">$269</td>
                    </tr>
                    <tr>
                        <td class="py-3">
                            <p class="text-xs text-gray-300">Extras</p>
                            <p class="text-[10px] text-gray-500">Prima Vacacional, Horas extras, etc.</p>
                        </td>
                        <td class="py-3 text-right text-xs font-bold text-white">$1598</td>
                    </tr>
                </tbody>
            </table>

            <!-- Resumen alineado derecha -->
            <div class="flex justify-end">
                <div class="w-64 space-y-2 pt-4 border-t border-gray-700">
                    <p class="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Resumen</p>
                    <div class="flex justify-between text-[11px]">
                        <span class="text-gray-400">Efectivo</span>
                        <span class="text-white font-medium">$2513</span>
                    </div>
                    <div class="flex justify-between text-[11px]">
                        <span class="text-gray-400">Bancos</span>
                        <span class="text-white font-medium">$477</span>
                    </div>
                    <div class="flex justify-between pt-2 border-t border-gray-700">
                        <span class="text-sm font-bold text-white">Salario Total</span>
                        <span class="text-sm font-bold text-white">$2990</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Panel lateral: lista de colaboradores -->
    <aside class="w-[340px] bg-[#141d2b] border-l border-gray-800 flex flex-col flex-shrink-0">
        <div class="px-4 py-3 border-b border-gray-800">
            <h3 class="text-sm font-bold mb-2">Colaboradores</h3>
            <select class="w-full bg-[#1a2332] border border-gray-700 rounded-lg px-3 py-1.5 text-xs text-gray-300">
                <option>Colaborador</option>
            </select>
        </div>
        <div class="flex-1 overflow-y-auto scrollbar-thin p-2 space-y-1">
            <!-- Item colaborador (activo) -->
            <div class="flex items-center gap-2 p-2 rounded-lg bg-[#1a2332] cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-[10px] font-bold">LB</div>
                <div class="flex-1 min-w-0">
                    <p class="text-xs font-medium truncate">Lana Byrd</p>
                    <p class="text-[10px] text-gray-500 truncate">email@example.com</p>
                </div>
                <span class="badge-base badge-puesto-admin">Admin</span>
            </div>
            <!-- Item inactivo -->
            <div class="flex items-center gap-2 p-2 rounded-lg hover:bg-[#1a2332] cursor-pointer">
                <div class="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center text-[10px] font-bold">NS</div>
                <div class="flex-1 min-w-0">
                    <p class="text-xs font-medium truncate">Neil Sims</p>
                    <p class="text-[10px] text-gray-500 truncate">email@example.com</p>
                </div>
                <span class="badge-base badge-puesto-admin">Admin</span>
            </div>
        </div>
    </aside>
</div>
```

### Reglas recibo
- Area principal con `max-w-3xl mx-auto` (recibo centrado).
- Recibo en `bg-[#1F2A37] rounded-2xl border border-gray-800 p-6`.
- Logo/icono inicial: circulo `w-10 h-10 rounded-full bg-[color]/20`.
- Grid 2-col para datos empresa/colaborador.
- Tabla de desglose con `border-y` en thead.
- Resumen alineado a derecha: `flex justify-end` + card `w-64`.
- Panel lateral: ancho fijo `w-[340px]` con lista scrolleable.
- Item activo: `bg-[#1a2332]` (sin hover). Item inactivo: `hover:bg-[#1a2332]`.
- Colaborador item con avatar + nombre + email (truncate) + badge puesto.

---

## SPELL 5: `conjure modal` — Modal reutilizable (variantes RRHH)

**Referencia:** `modals/modal-autorizacion.html`, `modals/modal-permiso-form.html`, `modals/modal-upload.html`

### Modal autorizacion (con avatar y detalles)

```html
<div id="modalAuth" class="hidden fixed inset-0 bg-black/60 z-40 items-center justify-center">
    <div class="bg-[#1F2A37] rounded-2xl p-6 border border-gray-700 w-[480px] relative">
        <button class="absolute top-3 right-3 text-gray-400 hover:text-white">×</button>

        <div class="flex items-center gap-3 mb-4">
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-xs font-bold">JL</div>
            <div>
                <h3 class="text-sm font-bold">Jese Leos</h3>
                <p class="text-[11px] text-gray-500">Solicita: Vacaciones</p>
            </div>
        </div>

        <div class="space-y-3 mb-5 text-xs text-gray-300">
            <div class="flex justify-between"><span class="text-gray-500">Fecha inicio:</span><span>22/07/2024</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Fecha fin:</span><span>29/07/2024</span></div>
            <div class="flex justify-between"><span class="text-gray-500">Dias:</span><span>7</span></div>
        </div>

        <div class="flex justify-center gap-3">
            <button class="px-6 py-2 rounded-lg border border-red-500/40 text-red-400 text-xs font-semibold hover:bg-red-500/10">Rechazar</button>
            <button class="px-6 py-2 rounded-lg bg-green-500 text-white text-xs font-semibold hover:bg-green-600">Aprobar</button>
        </div>
    </div>
</div>
```

### Modal upload drag-drop

```html
<div id="modalUpload" class="hidden fixed inset-0 bg-black/60 z-40 items-center justify-center">
    <div class="bg-[#1F2A37] rounded-2xl p-6 border border-gray-700 w-[520px] relative">
        <button class="absolute top-3 right-3 text-gray-400 hover:text-white">×</button>
        <h3 class="text-base font-bold mb-4">Subir comprobante</h3>

        <div class="border-2 border-dashed border-gray-700 rounded-xl p-8 text-center hover:border-purple-500/50 transition cursor-pointer">
            <svg class="w-10 h-10 text-gray-500 mx-auto mb-3" ...>☁↑</svg>
            <p class="text-sm font-semibold text-gray-300 mb-1">Arrastra archivos aqui</p>
            <p class="text-[11px] text-gray-500">o <span class="text-purple-400 cursor-pointer">selecciona manualmente</span></p>
            <p class="text-[10px] text-gray-600 mt-3">PDF, JPG, PNG · Max 5MB</p>
        </div>

        <div class="flex justify-center gap-3 mt-5">
            <button class="px-6 py-2 rounded-lg border border-gray-600 text-xs font-semibold text-gray-300">Cancelar</button>
            <button class="px-6 py-2 rounded-lg bg-[#1c64f2] text-white text-xs font-semibold">Subir</button>
        </div>
    </div>
</div>
```

### Anchos modal RRHH
| Proposito | Ancho |
|-----------|-------|
| Autorizacion simple | `w-[400px]` |
| Autorizacion con detalles | `w-[480px]` |
| Upload drag-drop | `w-[520px]` |
| Formulario permiso | `w-[600px]` |

---

## Paleta especifica RRHH

Identica a Finanzas + badges de puesto/estatus especificos.

### Badges de estatus
| Estatus | Color |
|---------|-------|
| Aprobado/Asistencia | `#3fc189` (green-400) |
| Pendiente/Calculada | `#fbbf24` (yellow-400) |
| Rechazado/Falta | `#ea0234` (red-400) |
| Sin Estatus | `#9ca3af` (gray-400) |
| Incapacidad | `#f472b6` (pink-400) |
| Vacaciones | `#c4b5fd` (purple-300) |
| Permiso | `#fb923c` (orange-400) |
| Reconocimiento | `#c4b5fd` (purple-300) |

### Badges de puesto
| Puesto | Background | Color |
|--------|------------|-------|
| Admin | `rgba(124,58,237,.18)` | `#c4b5fd` |
| Cocina | `rgba(124,58,237,.18)` | `#c4b5fd` |
| Piso | `rgba(28,100,242,.18)` | `#76a9fa` |

## Reglas globales RRHH

1. SIEMPRE Tailwind CDN + Inter Google Fonts
2. Chart.js v4.4.0 CDN si hay graficos: `chart.js@4.4.0/dist/chart.umd.min.js`
3. SIEMPRE avatar `rounded-full bg-gradient-to-br from-[c1] to-[c2]` con iniciales de 2 letras
4. SIEMPRE badge puesto junto al nombre del colaborador
5. Fechas en formato `22/07/2024` o `31 ene 2024`
6. Para multi-fecha usa grid calendario tipo incidencia con `.cell-btn` + `.dot`
7. Formularios con `label text-[11px] text-gray-500` + `.input-base`
8. Theme toggle igual a finanzas (localStorage key `huubie-theme`)
9. **Tablas en tema light** SIEMPRE con fondo blanco (`#ffffff`), no `#f3f4f6`
10. **Default del modo light** → `coffee-varoch` (importar `../utils/coffee-varoch.css` + `<body class="coffee-varoch">`). La paleta light clasica solo si el usuario pide "coffee clasico"
