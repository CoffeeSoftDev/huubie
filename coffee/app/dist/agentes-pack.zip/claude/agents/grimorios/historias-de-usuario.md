# Historias de usuario — formato Varoch

Cómo se escriben las historias de usuario en este equipo. No es Scrum de manual
ni Gherkin: es una **tabla de especificación** donde la historia dice QUÉ pantalla
se construye y los criterios de aceptación dicen QUÉ LLEVA esa pantalla, campo por
campo, hasta el color de un número negativo.

Fuente: `Historia de usuario evaluacion.xlsx` (3 hojas, módulo de evaluación de
calidad) y `historias de usuario contabilida.xlsx` (7 sprints, ERP contable).

---

## 1) La tabla

Toda entrega es una tabla. Hay dos variantes y se elige por el tamaño del trabajo:

**Variante corta** — un módulo, sin planeación de sprints:

| Yo ( Usuario) | Quiero (funcionalidad) | Beneficio(para que ) | criterios de aceptación |
|---|---|---|---|

**Variante sprint** — proyecto largo, se planea por quincenas:

| Yo ( Usuario) | En el apartado | Quiero (funcionalidad) | Beneficio (para qué) | Criterios de aceptación | Sprint | Points | Fecha |
|---|---|---|---|---|---|---|---|

Reglas de la tabla:

- Los encabezados se escriben tal cual, con esas etiquetas entre paréntesis.
- **Filas banner**: antes de un grupo de historias va una fila con el nombre del
  módulo en MAYÚSCULAS y el resto de columnas vacías — `VENTAS`, `CLIENTES`,
  `MODULO HOME`, `ADMINISTRACIÓN`, `DIAGRAMA ENTIDAD RELACIÓN`. Ordena la lectura.
- Una hoja por sprint (`SPRINT 1`… `SPRINT 7`) o, si no hay sprints, una hoja por
  gran bloque funcional (`Administrador`, `Encuesta`, `reportes`).
- `Sprint` se numera con decimal: `1.0`, `3.0`, `5.0`.
- `Fecha` es el rango de la quincena: `18 nov - 01 dic`, `13 ene- 26 ene`.
- `Points` casi siempre va vacío: no se estima con puntos, se estima con quincena.

---

## 2) Columna por columna

### Yo ( Usuario)

El **puesto real** que va a usar la pantalla, no un "usuario" genérico:
`Admin`, `Direccion operativa`, `D.O`, `GERENTE Y AUXILIAR`, `CONTABILIDAD`,
`DEVELOPER`, `CONTABILIDAD Y DEVELOPER`, `CONTABILIDAD / DEVELOPER`.

Cuando dos perfiles ven la misma pantalla con distinto alcance de datos, se
escriben **historias separadas**, una por perfil (ver §4).

### En el apartado

El nombre de la pantalla dentro del módulo, en MAYÚSCULAS: `INTERFAZ INICIAL`,
`CONCENTRADO DE VENTAS`, `MOVIMIENTOS DIARIOS DE CLIENTES`, `FORMAS DE PAGO`,
`BASE DE DATOS`. Es la columna que permite buscar la historia después.

### Quiero (funcionalidad)

Qué hace la pantalla, en infinitivo y sin la fórmula "Como… quiero… para…"
(la fórmula ya está repartida en las columnas). Va del verbo al detalle:

> Visualizar el concentrado de ventas desglosado por los conceptos de: ventas sin
> impuestos, descuentos y cortesías, impuestos, total de venta y formas de pago,
> filtrado por el periodo de consulta seleccionado y la unidad de negocio a la que
> pertenece el perfil.

> Ver, registrar, editar y eliminar movimientos de clientes a crédito.

> Crear apartado de grupos de formato para separar en categorias las preguntas

Se admite enumerar los CRUD en una sola historia (`Ver, registrar, editar y
eliminar`) cuando comparten pantalla.

### Beneficio (para qué)

Empieza con **"Para…"** y dice el beneficio de negocio, no el técnico. Una o dos
líneas:

> Para acceso rápido a los módulos y consultar la información inicial por periodo de fechas

> Para gestionar los movimientos de los clientes a crédito de la unidad de negocio del perfil.

> Para monitorear el desempeño del equipo y detectar áreas de oportunidad

### Criterios de aceptación

Es el 80% del valor de la historia. **No son Gherkin ni checklist de QA: son la
especificación de la interfaz.** Ver §3.

---

## 3) Anatomía de los criterios de aceptación

Se escriben como lista jerárquica con guiones e indentación, en este orden:

1. **Frase de apertura** que declara qué se construye:
   `El apartado debe contener los siguientes elementos:` ·
   `Crear una interfaz que tenga las siguientes caracteristicas:` ·
   `El apartado esta conformado por:`
2. **FilterBar** y sus filtros, uno por línea (selectores, rangos de fecha,
   botones primarios). Siempre se nombra `filterBar` / `barra de filtros`.
3. **Cards / showCards** de consulta: cuántas y qué dato lleva cada una.
4. **Tabla**: TODAS las columnas, una por línea, y al final los botones de acción
   (`ver`, `editar`, `eliminar`, `activar/desactivar`).
5. **Modales y formularios**: se abren describiendo el disparador —
   `Al precionar el boton de nueva pregunta se abrira un apartado con los
   siguientes campos:` — y luego los campos, uno por línea.
6. **Variantes condicionales**, cuando el formulario cambia según un selector:
   `* En caso de seleccionar el tipo de compra corporativo los valores cambian:` /
   `* En caso de ser credito se oculta metodo de pago`.
7. **Reglas y validaciones sueltas**, marcadas con `*` (una) o `** IMPORTANTE **`
   (bloque) al final del criterio.

Lo que SIEMPRE se especifica cuando aplica:

| Tema | Cómo se escribe |
|---|---|
| Alcance de datos | `Se debe vincular la unidad de negocio a la que pertenece el perfil` |
| Auditoría | `Se debe guardar quién capturó por usuario` · `registra la operación en la bitácora` |
| Borrado | `soft delete` o físico, y siempre `solicita confirmación explícita (modal de advertencia)` |
| Estados | Con su semántica de color: `[ Blanco : por contestar, verde: contestada ]` |
| Color condicional | `Si el número es negativo, se pintará de color rojo` |
| Tablas anchas | `La tabla debe ser capaz de scrollear de forma horizontal` · `La primera y segunda columna deben estar fijas` |
| Exportar | `FilterBar con boton de exportar a excel` |
| Defaults | `Se selecciona por defecto año y mes actual` · `Seleccionada al dia de hoy por defecto` |
| Origen del dato | `Reviso ( se obtiene de la sesion iniciada )` |
| Responsive | `* Debe adaptar a movil/tablet/PC` |
| Bloqueo de captura | `Bloqueo por fecha y hora` |
| Validaciones | `* validar que la pregunta no este repetida` · `Fecha no puede ser futura` |

Ejemplo completo de criterio (historia real, módulo de evaluación):

```
El apartado debe contener los siguientes elementos:
filterbar:
selector de unidades de negocio
selector de tipo de formato [ camarista,general]
botón para agregar nuevo formato

Tabla:
Titulo del formato
Subtitulo
Unidad de negocio
Tipo
Código
Ref.
Rev.
botones de accion
Editar , baja
```

---

## 4) Una historia por perfil

Cuando la misma pantalla la usan varios puestos, **no** se escribe "según el rol":
se repite la historia cambiando el alcance. El patrón es siempre el mismo:

- **GERENTE Y AUXILIAR** → solo su unidad de negocio; el criterio dice
  `filtrado por … la unidad de negocio a la que pertenece el perfil`.
- **CONTABILIDAD / DEVELOPER** → todas las unidades; el criterio suma
  `- Select de unidad de negocio.` en el filterBar y en el modal de alta.
- El **DEVELOPER** suele llevar además los toggles y accesos que los operativos
  no ven (`En el filterBar un boton toggle para pasar a registro diario capturado`).

---

## 5) Historias técnicas

El trabajo de infraestructura también es historia, con `DEVELOPER` como usuario y
`BASE DE DATOS` como apartado:

> **Yo:** DEVELOPER · **En el apartado:** BASE DE DATOS ·
> **Quiero:** Realizar un diagrama Entidad-Relación. ·
> **Beneficio:** Para visualizar el esquema de las relaciones de las tablas de la
> base de datos, así como el funcionamiento y las dependencias entre sí. ·
> **Criterios:** `- Crear diagrama en excalidraw.` `- Seguir la nomenclatura de
> colores y diseños.` `- Realizar diagrama de los siguientes modulos: …`

Van al inicio del Sprint 1, antes de las historias de pantalla.

---

## 6) Vocabulario obligatorio

Se usa el léxico del ERP y de CoffeeSoft, no términos genéricos de UX:

`filterBar` · `showCards` / `cards de consulta` · `tabla dinámica` · `modal` ·
`tabs` · `select` / `selector` · `botón toggle` · `badge` · `CRUD` ·
`botones de acción (ver, editar, eliminar)` · `unidad de negocio (UDN)` ·
`periodo de consulta` / `rango de fechas` · `data range` · `concentrado` ·
`exportar a excel` · `columnas fijas` · `bloqueo por fecha y hora` ·
`soft delete` · `puesto de trabajo`.

Redacción: español directo, sin adjetivos de venta, sin "el sistema deberá
proporcionar la capacidad de". Frases cortas. Se tutea a la interfaz
("al precionar el botón se abre un modal").

---

## 7) Lo que NO se hace

- **No** Gherkin (`Dado / Cuando / Entonces`) en los criterios.
- **No** criterios vagos: `- La interfaz debe ser intuitiva`, `- Buen rendimiento`.
  Si no nombra un campo, un filtro, una columna o una regla, no es criterio.
- **No** historias épicas sin desglose: si la pantalla tiene alta + edición +
  consulta + reporte, son historias distintas del mismo apartado.
- **No** mezclar dos perfiles en una historia con "dependiendo del rol".
- **No** inventar `Points` ni fechas: si no se conocen, la celda va vacía.
- **No** describir implementación (nombres de tablas, endpoints, framework) en la
  columna Quiero; eso vive en los criterios solo si es una historia técnica.

---

## 8) Formato de salida en el visor — bloque ` ```stories `

Cuando trabajas dentro del **visor / chat de agentes / playground**, la tabla no se
escribe a mano: se entrega un bloque de datos y la interfaz la dibuja (fichas por
historia, tabla del Excel, exportar a `.xlsx`). Es el mismo mecanismo de los bloques
` ```mermaid ` o ` ```chart `.

**La plantilla del visor son cinco columnas:** `Yo ( Usuario)` · `En el apartado` ·
`Quiero (funcionalidad)` · `Beneficio (para qué)` · `Criterios de aceptación`.
**No lleva `Sprint`, `Points` ni `Fecha`** — la planeación no se pinta aquí. Si los
mandas, se ignoran.

Entrega **un solo bloque** ` ```stories ` con esta estructura. La indentación es
significativa (2 espacios por nivel):

````
```stories
proyecto: Admin de documentos
historias:
  - banner: Admin de documentos
  - usuario:   ADMIN
    apartado:  EXPLORADOR DE PROYECTOS
    quiero:    Visualizar los documentos de un proyecto en un árbol de carpetas.
    beneficio: Para localizar rápido el documento sin recorrer el disco del servidor.
    criterios:
      intro: El apartado debe contener los siguientes elementos
      bloques:
        - tipo: filterBar
          items:
            - Buscador de proyecto ( placeholder "Buscar proyecto..." )
            - Botón de subir archivo ( primary )
        - tipo: tabla
          titulo: Listado de documentos
          items:
            - Nombre del documento
            - Extensión ( badge )
            - item: Botones de acción
              sub: [ ver, renombrar, eliminar ]
      reglas:
        - nivel: nota
          texto: Solo se listan las rutas dentro de la raíz configurada del proyecto
        - nivel: importante
          texto: "Guardar sobreescribe el archivo en disco: se pide confirmación"
```
````

Reglas del bloque:

| Campo | Qué lleva |
|---|---|
| `proyecto` | Nombre del módulo. Encabeza la tarjeta. |
| `- banner: TEXTO` | Fila banner de módulo (§1). Va como item suelto de `historias`. |
| `usuario` · `apartado` · `quiero` · `beneficio` | Las cuatro primeras columnas, redactadas igual que en §2. |
| `criterios.intro` | La frase de apertura (§3.1). |
| `criterios.bloques[].tipo` | **Vocabulario cerrado:** `filterBar` · `cards` · `tabla` · `modal` · `tabs` · `header` · `footer` · `nota`. Define el color y el icono del bloque. |
| `criterios.bloques[].titulo` | Opcional; si falta se usa el nombre del tipo. |
| `items` | Una línea por campo/columna/filtro. Para sub-items: `- item: Botones de acción` + `sub: [ ver, editar ]`. |
| `reglas[].nivel` | `nota` (equivale a `*`) o `importante` (equivale a `** IMPORTANTE **`). |

Cuidados:

- Si un valor lleva `:` dentro (`"Vista: el markdown renderizado"`), **va entre comillas**.
- Un bloque por respuesta. Si el trabajo abarca varios módulos, sepáralos con
  `- banner: NOMBRE DEL MODULO` dentro del mismo bloque.
- Nada de `sprint:`, `points:` ni `fecha:`: esa planeación va en la tabla del Excel,
  no en la tarjeta del visor.
- **Fuera del visor** (Excel, documentos, terminal) sigue mandando la tabla markdown
  de §1: el bloque es solo el formato de intercambio con la interfaz. La propia
  tarjeta tiene el botón "copiar tabla markdown" para volver al formato del equipo.
- El resto de la respuesta va como siempre: una línea de contexto antes y, al final,
  supuestos y preguntas abiertas. **Nunca** repitas las historias en prosa fuera del bloque.

---

## 9) De un ERS a las historias

El camino normal del trabajo es **carpeta → ERS → historias**. Cuando ya existe un
ERS (ver `ers.md`), las historias **no se inventan: se derivan de él**, sección por
sección:

| Del ERS | Va a la historia |
|---|---|
| `SECCIONES DEL PROYECTO` → cada módulo | Una o varias historias. El nombre del módulo, en MAYÚSCULAS, es **En el apartado** |
| Las operaciones de ese módulo (subir, consultar, imprimir, dar de baja) | **Una historia por operación** — no una épica por módulo |
| La lista de campos del módulo | Los **criterios**: filterBar, columnas de la tabla, campos del modal |
| `USUARIOS QUE UTILIZARÁN EL PROYECTO` | La columna **Yo ( Usuario)**. Si un módulo lo usan dos perfiles con distinto alcance, son dos historias (§4) |
| `OBJETIVO DEL PROYECTO` y `¿EL ÉXITO…?` | El **Beneficio** ("Para…") de cada historia |
| `¿EL ÉXITO DEL PROYECTO SE DA CUÁNDO?` | Además, escenarios concretos que se vuelven criterios o reglas |
| `OBSERVACIONES` | Reglas con `nivel: nota` |
| `EXCEPCIONES` | Reglas con `nivel: importante`, o huecos que se señalan al final |
| `ACCIONES A REALIZAR` (fase 1) | Historias técnicas del `DEVELOPER` con apartado `BASE DE DATOS` (§5) |

Reglas de la derivación:

- **Cobertura completa:** cada módulo del ERS tiene al menos una historia. Si alguno
  se queda fuera a propósito, se dice al final y por qué.
- **Nada nuevo:** no se agregan módulos, campos ni perfiles que el ERS no menciona. Si
  hace falta algo obvio (un buscador, un estatus), se propone como pregunta abierta,
  no se cuela en los criterios.
- **Lo que el ERS no dice, se pregunta.** Un ERS parco da criterios parcos: antes de
  rellenar con supuestos, se listan las dudas al final de la entrega.
- Si el ERS está abierto en el visor ya viene en el contexto; si no, se lee de la
  carpeta conectada con `read_file` antes de escribir la primera historia.

---

## 10) Checklist antes de entregar

1. ¿Cada fila tiene usuario real, apartado, funcionalidad y un "Para…"?
2. ¿Los criterios nombran filterBar, cards, columnas de tabla y campos de modal?
3. ¿Están las reglas de negocio marcadas con `*` o `** IMPORTANTE **`?
4. ¿Se dijo el alcance por unidad de negocio y quién captura?
5. ¿Las pantallas con varios perfiles están duplicadas, una por perfil?
6. ¿Hay filas banner en MAYÚSCULAS separando módulos?
7. ¿Sprint y rango de fechas puestos (o vacíos a propósito)?
8. ¿Se especificó qué pasa al eliminar (confirmación + soft delete/bitácora)?
9. Si la entrega es en el visor, ¿va en un bloque ` ```stories ` de cinco columnas
   (sin sprint/points/fecha), con los `tipo` del vocabulario cerrado y sin repetir
   las historias en prosa? (§8)
10. Si hay ERS, ¿está cubierto módulo por módulo, sin agregar nada que no diga? (§9)
