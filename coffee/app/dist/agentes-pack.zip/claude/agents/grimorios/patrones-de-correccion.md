# Patrones de correccion

Como se lee el cajon de TODOs para saber **que se esta corrigiendo una y otra vez**, y
cuando una correccion repetida deja de ser tarea y pasa a ser regla.

Esta regla la comparten CoffeeClown (que levanta el analisis) y CoffeePlanner (que al
planear un sprint no deberia volver a especificar lo que siempre termina corrigiendose).

---

## 1. De donde salen los numeros

De `todo_stats`. **Nunca de una estimacion del modelo.** La herramienta devuelve:

| Campo | Que es |
|---|---|
| `total` / `hechas` / `pendientes` | Tareas contadas en todas las listas visibles |
| `listas` | Cuantas listas se leyeron |
| `verbos` | Con que verbo empieza cada tarea, de mas a menos frecuente |
| `cruzados` | Terminos que aparecen en **dos o mas listas distintas**, con `tareas`, `listas` y `donde` |
| `sin_fecha` | Tareas sin sello de alta ni de cierre |

`cruzados` ya viene ordenado por `listas` (cuantos proyectos alcanza) y, a igualdad,
por `tareas`.

---

## 2. La taxonomia

Siete categorias, sacadas de las tareas reales del equipo. Cada tarea recibe una
principal; si aplica, una secundaria.

| Categoria | Que la delata | Ejemplo real |
|---|---|---|
| **Sobra** | quitar, eliminar, solo dejar | "Quitar el border que tiene la filterBar" |
| **Tema y color** | tono, dark, paleta, borde | "En tema dark el color de la scrollbar debe ser acorde al tema" |
| **Acomodo** | centrar, alinear, tamano, contenedor | "Alinear la filterbar del selector para que no de un salto" |
| **Formato de dato** | moneda, fecha, digitos | "Deben tener formato 02/agosto/2026" |
| **No funciona** | no se ve, revisar porque, no renderiza | "El datatable solo renderiza los iconos de la primera pagina" |
| **Falta** | agregar, nuevo, habilitar | "Agregar un resumen de facturacion con kpis cards" |
| **Backend** | validar, prepare/bind, permisos | "Validar el parametro 'opc' contra una whitelist" |

Las categorias **se solapan a proposito**: "quitar el border de la filterBar" cuenta en
tres. Los porcentajes no suman 100 y no hay que forzarlos.

---

## 3. Que convierte una correccion en regla

Tres condiciones. Si no se cumplen las tres, es una tarea y se queda como tarea:

1. **Cruza proyectos.** Aparece en **tres listas o mas**. Repetir dentro de un mismo
   modulo es normal; repetir en tres proyectos significa que la decision no esta
   escrita en ningun sitio.
2. **Es una decision, no un bug.** "El switch no funciona" se arregla; "el borde de la
   filterBar sobra" es una decision de diseno que alguien vuelve a tomar mal cada vez.
3. **Se puede enunciar en una frase imperativa.** Si hace falta un parrafo con
   excepciones, todavia no esta madura.

El ratio **quitar / agregar** de `verbos` es el termometro del conjunto: cuando
"quitar" encabeza, se esta generando de mas, y la regla que falta casi siempre es una
de omision ("no pintes X salvo que se pida").

---

## 4. Como se redacta el borrador de regla

Cuando un patron cumple las tres condiciones, se redacta asi:

```
[Componente] — [que se hace] / [que NO se hace]
Motivo: aparece en N tareas de M proyectos (lista los proyectos).
Archivo sugerido: ~/.claude/steering/<archivo>.md, seccion "<seccion>"
```

Ejemplo:

```
filterBar — sin borde propio; hereda el del contenedor.
No se le anaden inputs de busqueda salvo que la pantalla los pida explicitamente.
Motivo: 8 tareas en 4 proyectos (Huubie, Facturador, ERP, Encuestas).
Archivo sugerido: ~/.claude/steering/FRONT-JS.md, seccion "filterBar"
```

**El borrador no se escribe en disco.** `~/.claude/steering/` gobierna a todos los
agentes del ecosistema: el texto se le entrega al usuario y el commit lo hace el.

---

## 5. Lo que hoy no se puede responder

Las tareas **no guardan fecha** (`sin_fecha` lo confirma). Mientras siga asi:

- No hay antiguedad de lo pendiente ni tiempo de cierre.
- No hay "que corregi este mes" ni tendencia.

Si preguntan por eso, se dice en una frase y se ofrece el corte que si existe (por
lista, por categoria, por verbo). **Nunca se estima una fecha.**
