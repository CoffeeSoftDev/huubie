# Documentación CoffeeSoft Framework

## Descripción General
CoffeeSoft es un framework JavaScript basado en jQuery que proporciona componentes reutilizables, utilidades y patrones para el desarrollo de aplicaciones web empresariales.

## Arquitectura de Clases

### Jerarquía de Herencia
```
Complements
    └── Components
            └── Templates
```

### Constructor Base
```javascript
constructor(link, div_modulo) {
    this._link = link;           // URL del controlador PHP
    this._div_modulo = div_modulo; // ID del contenedor raíz
}
```

---

## Clase: Complements

Clase base que proporciona utilidades fundamentales.

### Métodos Principales

#### `ObjectMerge(target, source)`
Combina dos objetos recursivamente.
```javascript
this.ObjectMerge(defaults, options);
```

#### `closedModal(data)`
Cierra un modal de bootbox si la operación fue exitosa.

#### `dropdown(options)`
Genera un menú dropdown HTML.
```javascript
dropdown([
    { icon: "icon-pencil", text: "Editar", onClick: "edit()" },
    { icon: "icon-trash", text: "Eliminar", onClick: "delete()" }
])
```

#### `useFetch(options)`
Realiza peticiones AJAX usando Fetch API.
```javascript
this.useFetch({
    url: api,
    data: { opc: 'ls' },
    success: (data) => console.log(data)
});
```

---

## Clase: Components

Extiende `Complements` y proporciona componentes visuales reutilizables.

### Componentes de Visualización

#### `detailCard(options)`
Muestra información en formato de tarjeta con campos clave-valor.
```javascript
this.detailCard({
    parent: "container",
    title: "Detalles",
    class: "cols-2",
    data: [
        { text: "Nombre", value: "Juan", icon: "icon-user" },
        { type: "status", text: "Estado", value: "Activo", color: "bg-green-500" },
        { type: "observacion", text: "Notas", value: "Comentarios..." }
    ]
});
```

#### `createItemCard(options)`
Crea tarjetas de navegación tipo grid.
```javascript
this.createItemCard({
    parent: 'cardGrid',
    title: 'Módulos',
    json: [
        {
            titulo: "Ventas",
            descripcion: "Gestión de ventas",
            imagen: "/img/ventas.svg",
            enlace: "/ventas/",
            onClick: () => {}
        }
    ]
});
```

### Componentes de Formularios

#### `coffeeForm(options)` *(Tailwind Native)*
Genera formularios dinámicos usando exclusivamente TailwindCSS. Vive dentro de la clase `Components` (no es un plugin jQuery).

**Diferencia con createForm:** `coffeeForm` NO depende del plugin `content_json_form` ni de Bootstrap. Renderiza los campos directamente con clases Tailwind (dark theme por defecto).

**Opciones disponibles en `data[]`:** input, input-group, textarea, select, radio, checkbox, input-file, input-file-btn, input-calendar, btn, btn-submit, button, btn-select, label, code, list-group.

```javascript
this.coffeeForm({
    parent: 'formContainer',
    id: 'myForm',
    class: 'flex flex-wrap items-end gap-y-2',
    data: [
        { opc: "label", id: "lblSection", text: "Datos del usuario", class: "w-full px-2" },
        { opc: "input", id: "name", lbl: "Nombre", tipo: "texto", class: "w-full sm:w-1/2 px-2 mt-1" },
        { opc: "input", id: "email", lbl: "Email", type: "email", class: "w-full sm:w-1/2 px-2 mt-1" },
        { opc: "select", id: "role", lbl: "Rol", class: "w-full sm:w-1/3 px-2 mt-1", data: [
            { id: "admin", valor: "Admin" },
            { id: "user", valor: "Usuario" }
        ]},
        { opc: "textarea", id: "notes", lbl: "Notas", rows: 3, class: "w-full px-2 mt-1", required: false },
        { opc: "checkbox", id: "active", text: "Activo", class: "w-full sm:w-1/3 px-2 mt-1" }
    ]
});
```

**Clases Tailwind para columnas (reemplazo de Bootstrap grid):**
- `w-full` = col-12
- `sm:w-1/2` = col-sm-6
- `sm:w-1/3` = col-sm-4
- `sm:w-1/4` = col-sm-3
- `lg:w-1/4` = col-lg-3

#### `createForm(options)`
Genera formularios dinámicos con validación automática.

**IMPORTANTE:** Por defecto `createForm` usa `type: 'div'`, lo que significa que **NO genera botón de submit automáticamente**. No incluir `opc: "btn-submit"` en el `json` a menos que el diseño lo requiera explícitamente. El `validation_form` maneja el submit internamente.

```javascript
this.createForm({
    parent: 'formContainer',
    id: 'myForm',
    data: { opc: 'add' },
    autofill: { name: "Juan", email: "juan@mail.com" },
    json: [
        { opc: "input", id: "name", lbl: "Nombre", class: "col-12" },
        { opc: "select", id: "category", lbl: "Categoría", data: categories }
    ],
    success: (response) => {
        if (response.status === 200) {
            alert({ icon: "success", text: response.message });
        }
    }
});
```

#### `createModalForm(options)`
Crea un formulario dentro de un modal de bootbox.
```javascript
this.createModalForm({
    id: 'formModal',
    bootbox: {
        title: 'Agregar Registro',
        closeButton: true
    },
    data: { opc: 'add' },
    autofill: false,
    json: [
        { opc: "input", id: "name", lbl: "Nombre", class: "col-12" },
        { opc: "textarea", id: "description", lbl: "Descripción", class: "col-12" }
    ],
    success: (response) => {
        console.log(response);
    }
});
```

#### `form(options)`
Genera formularios sin contenedor automático.
```javascript
this.form({
    parent: "container",
    id: "myForm",
    class: "row",
    json: [
        { opc: "input", id: "name", lbl: "Nombre", class: "col-6" },
        { opc: "select", id: "type", lbl: "Tipo", data: types, class: "col-6" }
    ]
});
```

### Componentes de Tablas

#### `createTable(options)`
Genera tablas dinámicas con datos del backend.
```javascript
this.createTable({
    parent: 'tableContainer',
    idFilterBar: 'filterBar',
    data: { opc: 'ls', fi: '2024-01-01', ff: '2024-12-31' },
    coffeesoft: true,
    conf: { datatable: true, pag: 15 },
    attr: {
        id: 'tbProducts',
        theme: 'corporativo',
        title: 'Lista de Productos',
        subtitle: 'Productos registrados',
        center: [1, 2],
        right: [4]
    },
    success: (data) => console.log(data)
});
```

**`conf` — defaults ya incluidos:** `datatable: true`, `fn_datatable: 'simple_data_table'`,
`beforeSend: true`, `pag: 15`. Declarar solo lo que cambia (normalmente `pag`). **NO** crear funciones
wrapper locales que solo reenvíen a `simple_data_table` — ver FRONT-JS.md, "`conf` de createTable —
usar los defaults, NO envolverlos".

#### `createCoffeTable(options)`
Tabla estilizada con TailwindCSS.
**Theme por defecto:** `'corporativo'`. NO usar otros themes salvo solicitud explícita del usuario.
```javascript
this.createCoffeTable({
    parent: "container",
    id: "myTable",
    theme: 'corporativo', // DEFAULT. Otros disponibles: 'light' | 'dark' | 'shadcdn' (NO usar sin solicitud explícita)
    title: "Lista de Registros",
    subtitle: "Registros del sistema",
    data: {
        thead: ["ID", "Nombre", "Estado", "Acciones"],
        row: [
            {
                id: 1,
                Nombre: "Juan",
                Estado: "Activo",
                dropdown: [
                    { icon: "icon-pencil", text: "Editar", onclick: "edit(1)" },
                    { icon: "icon-trash", text: "Eliminar", onclick: "delete(1)" }
                ]
            }
        ]
    },
    center: [0, 2],
    right: [3]
});
```

### Componentes de Navegación

#### `tabLayout(options)`
Crea pestañas de navegación.
```javascript
this.tabLayout({
    parent: "container",
    id: "myTabs",
    type: "short", // 'short' | 'large'
    theme: "light", // 'light' | 'dark'
    renderContainer: true,
    json: [
        {
            id: "tab1",
            tab: "Dashboard",
            icon: "icon-home",
            active: true,
            onClick: () => console.log("Tab 1")
        },
        {
            id: "tab2",
            tab: "Reportes",
            icon: "icon-chart",
            onClick: () => console.log("Tab 2")
        }
    ]
});
```

#### `navBar(options)`
Barra de navegación superior.
```javascript
this.navBar({
    theme: "dark", // 'light' | 'dark'
    logoFull: "/img/logo.png",
    logoMini: "/img/icon.png",
    user: {
        name: "Usuario",
        photo: "/img/user.png",
        onProfile: () => redireccion('perfil/'),
        onLogout: () => cerrar_sesion()
    },
    apps: [
        { icon: "icon-cart", name: "Ventas", color: "text-green-600" }
    ]
});
```

#### `sideBar(options)`
Menú lateral colapsable.
```javascript
this.sideBar({
    parent: "body",
    id: "sidebar",
    theme: "light",
    groups: [
        {
            name: "Administración",
            icon: "icon-cog",
            items: [
                { name: "Usuarios", icon: "icon-user", onClick: () => {} }
            ]
        }
    ]
});
```

### Componentes de KPI / Info Cards

#### `infoCard(options)`
Muestra tarjetas de resumen con indicadores clave (KPIs). Usa estilo `file` para tarjetas con fondo de color, borde y valor destacado.

**Opciones principales:**

| Propiedad | Tipo | Default | Descripcion |
|---|---|---|---|
| `parent` | `string` | `"root"` | ID del contenedor padre |
| `id` | `string` | `"infoCardKPI"` | ID del contenedor grid |
| `theme` | `string` | `"light"` | Tema visual |
| `style` | `string` | `"default"` | Estilo de renderizado (`"file"` para tarjetas KPI) |
| `cols` | `number` | `4` | Columnas del grid (4, 5 o 6) |
| `class` | `string` | `""` | Clases adicionales al grid |
| `json` | `array` | `[]` | Array de tarjetas |

**Propiedades de cada tarjeta (`json[]`):**

| Propiedad | Tipo | Descripcion |
|---|---|---|
| `id` | `string` | ID del elemento valor (para actualizar dinamicamente) |
| `title` | `string` | Titulo de la tarjeta |
| `subtitle` | `string` | Subtitulo opcional |
| `bgColor` | `string` | Clase Tailwind de fondo (ej: `"bg-blue-100"`) |
| `borderColor` | `string` | Clase Tailwind de borde (ej: `"border-blue-300"`) |
| `data.value` | `string` | Valor a mostrar |
| `data.color` | `string` | Clase Tailwind del color del valor (ej: `"text-blue-700"`) |
| `onClick` | `function` | Callback al hacer click (opcional) |

**Ejemplo - KPIs de modulo:**
```javascript
renderInfoCards(counts) {
    this.infoCard({
        parent: `cards${this.PROJECT_NAME}`,
        theme: "light",
        style: "file",
        class: "pt-2 pb-3",
        json: [
            {
                id: "kpiTotal",
                title: "Total de compras",
                bgColor: "bg-yellow-100",
                borderColor: "border-yellow-300",
                data: { value: formatPrice(counts.total || 0), color: "text-yellow-700" }
            },
            {
                id: "kpiCredito",
                title: "Compras a Credito",
                bgColor: "bg-red-100",
                borderColor: "border-red-300",
                data: { value: formatPrice(counts.credito || 0), color: "text-red-700" }
            }
        ]
    });
}
```

**Ejemplo - KPIs con colores condicionales:**
```javascript
renderInfoComparativa(resumen) {
    const isPositive = resumen.diferencia >= 0;

    this.infoCard({
        parent: `info${this.PROJECT_NAME}`,
        theme: "light",
        style: "file",
        class: "pt-2 pb-3",
        json: [
            {
                id: "kpiActual",
                title: `Periodo ${resumen.yearActual}`,
                bgColor: "bg-blue-100",
                borderColor: "border-blue-300",
                data: { value: `${total} kg`, color: "text-blue-700" }
            },
            {
                id: "kpiDiferencia",
                title: "Diferencia",
                bgColor: isPositive ? "bg-emerald-100" : "bg-red-100",
                borderColor: isPositive ? "border-emerald-300" : "border-red-300",
                data: { value: `${diff} kg`, color: isPositive ? "text-green-700" : "text-red-700" }
            }
        ]
    });
}
```

**IMPORTANTE:** NO armar tarjetas de KPI con HTML manual (divs con grid-cols). Siempre usar `this.infoCard()` con `style: "file"`.

---

#### `inlineCards(options)`
Cards horizontales compactas con icono + label + valor. Usadas en barras superiores junto a filtros para mostrar metricas en tira inline (no grid como `infoCard`).

**Opciones:**

| Propiedad | Tipo | Default | Descripcion |
|---|---|---|---|
| `parent` | `string` | `"root"` | ID del contenedor padre |
| `id` | `string` | `"inlineCards"` | ID base del componente |
| `width` | `number` | `150` | Ancho fijo de cada card en px |
| `class` | `string` | `""` | Clases extra aplicadas a cada card |
| `json` | `array` | `[]` | Array de cards |

**Propiedades de cada card (`json[]`):**

| Propiedad | Tipo | Descripcion |
|---|---|---|
| `label` | `string` | Texto pequeno (titulo) |
| `value` | `string` | Valor destacado |
| `icon` | `string` | Nombre lucide (ej: `"wallet"`, `"arrow-up-circle"`) |
| `tone` | `string` | Paleta: `blue` `teal` `gray` `green` `amber` `red` `purple` `indigo` |

**Ejemplo - Saldos del fondo de caja:**
```javascript
renderInfoCards(summary) {
    this.inlineCards({
        parent: 'infoCardsBadge',
        width: 150,
        json: [
            { label: 'Saldo inicial', value: summary.saldoInicial, icon: 'wallet',            tone: 'blue' },
            { label: 'Ingresos',      value: summary.ingresos,     icon: 'arrow-up-circle',   tone: 'teal' },
            { label: 'Egresos',       value: summary.egresos,      icon: 'arrow-down-circle', tone: 'gray' },
            { label: 'Saldo final',   value: summary.saldoFinal,   icon: 'badge-check',       tone: 'blue' }
        ]
    });
}
```

**Diferencia con `infoCard()`:** `infoCard` renderiza grid de tarjetas grandes (landing/dashboards), `inlineCards` es un strip horizontal compacto (`px-2 py-1`) pensado para barras de filtros.

---

### Componentes de Interaccion

#### `swalQuestion(options)`
Muestra un diálogo de confirmación con SweetAlert2.
```javascript
this.swalQuestion({
    opts: {
        title: "¿Confirmar acción?",
        text: "Esta acción no se puede deshacer",
        icon: "warning"
    },
    data: { opc: "delete", id: 123 },
    methods: {
        send: (response) => {
            if (response.status === 200) {
                alert({ icon: "success", text: "Eliminado" });
            }
        }
    }
});
```

#### `createfilterBar(options)`
Barra de filtros para búsquedas.
```javascript
this.createfilterBar({
    parent: 'filterBar',
    data: [
        {
            opc: "select",
            id: "category",
            lbl: "Categoría",
            class: "col-3",
            data: categories,
            onchange: "app.search()"
        },
        {
            opc: "input-calendar",
            id: "dateRange",
            lbl: "Fecha",
            class: "col-4"
        },
        {
            opc: "btn",
            text: "Buscar",
            fn: "app.search()",
            class: "col-2"
        }
    ]
});
```

### Componentes Especializados

#### `createTableForm(options)`
Tabla con formulario lateral integrado.
```javascript
this.createTableForm({
    parent: 'container',
    id: 'tableForm',
    title: 'Gestión de Productos',
    table: {
        data: { opc: "ls" },
        conf: { datatable: true, pag: 10 }
    },
    form: {
        json: [
            { opc: "input", id: "name", lbl: "Nombre", class: "col-12" }
        ],
        success: (data) => console.log(data)
    }
});
```

---

## Clase: Templates

Extiende `Components` y proporciona layouts predefinidos.

### Layouts Disponibles

#### `primaryLayout(options)`
Layout principal con filterBar y container.
```javascript
this.primaryLayout({
    parent: 'root',
    id: this.PROJECT_NAME,
    class: 'p-2',
    card: {
        filterBar: { class: 'w-full my-3 p-3 border rounded-lg', id: `filterBar${this.PROJECT_NAME}` },
        container: { class: 'w-full my-3 h-full ', id: `container${this.PROJECT_NAME}` }
    }
});
```

#### `splitLayout(options)`
Layout dividido en dos columnas.
```javascript
this.splitLayout({
    parent: 'root',
    id: 'split',
    container: {
        children: [
            { class: 'w-1/2', id: 'left' },
            { class: 'w-1/2', id: 'right' }
        ]
    }
});
```

#### `verticalLinearLayout(options)`
Layout vertical con filterBar, container y footer.
```javascript
this.verticalLinearLayout({
    parent: 'root',
    id: 'vertical',
    card: {
        filterBar: { className: 'w-full', id: 'filterBar' },
        container: { className: 'w-full', id: 'container' },
        footer: { className: 'w-full', id: 'footer' }
    }
});
```

#### `createLayout(options)`
Layout personalizado con estructura libre (sidebar, multi-panel, expedientes).

**Ejemplo 1 — Sidebar + contenido:**
```javascript
this.createLayout({
    parent: 'root',
    design: false,
    data: {
        id: this.PROJECT_NAME,
        class: "flex gap-5 px-2 py-2",
        container: [
            { type: 'div', id: 'sidebar', class: 'w-64 flex-shrink-0' },
            { type: 'div', id: `main${this.PROJECT_NAME}`, class: 'flex-1 min-w-0',
                children: [
                    { id: 'tabContent', class: 'bg-white border rounded-lg p-5' }
                ]
            }
        ]
    }
});
```

**Ejemplo 2 — Container con titulo + tabs (children):**
```javascript
this.createLayout({
    parent: 'root',
    design: false,
    data: {
        id: this.PROJECT_NAME,
        class: 'w-full min-h-screen p-4',
        container: [
            {
                type: 'div',
                id: `container${this.PROJECT_NAME}`,
                class: 'w-full bg-[#1F2A37] rounded-lg p-3 min-h-screen',
                children: [
                    {
                        id: 'titleAdmin',
                        class: 'px-4 pt-3 pb-3'
                    },
                    {
                        id: `tabs${this.PROJECT_NAME}`,
                        class: 'w-full p-3'
                    }
                ]
            }
        ]
    }
});

// El titulo se pinta con el componente, NO con $().html() y HTML a mano:
// FRONT-JS.md "PROHIBIDO: HTML crudo en metodos JS" solo tolera wrappers vacios.
$("#titleAdmin").html(this.createTitleModal({
    lucideIcon: 'package',
    title:      'Titulo del modulo',
    subtitle:   'Descripcion del modulo.'
}));
```
> Usa `children` para crear sub-contenedores dentro de un div. Ideal cuando se necesita un titulo fijo antes de tabs sin usar `primaryLayout`.

> Usar para layouts que no encajan en `primaryLayout` / `secondaryLayout`.

#### `secondaryLayout(options)`
Layout con tabla y formulario lateral.
```javascript
this.secondaryLayout({
    parent: 'root',
    id: 'secondary',
    cardtable: {
        className: 'col-7',
        filterBar: { id: 'filterTable' },
        container: { id: 'listTable' }
    },
    cardform: {
        className: 'col-5',
        id: 'containerForm'
    }
});
```

---

## Plugins jQuery (plugins.js)

### `$.fn.content_json_form(options)`
Genera formularios desde JSON.
```javascript
$('#container').content_json_form({
    data: [
        { opc: "input", id: "name", lbl: "Nombre", class: "col-12" },
        { opc: "select", id: "type", lbl: "Tipo", data: types }
    ]
});
```

### `$.fn.validation_form(options, callback)`
Valida formularios automáticamente.
```javascript
$('#myForm').validation_form(
    { opc: 'add', tipo: 'text' },
    (formData) => {
        console.log(formData);
    }
);
```

### `$.fn.validar_contenedor(options, callback)`
Valida campos dentro de un contenedor.
```javascript
$('#container').validar_contenedor(
    { tipo: 'text', opc: 'save' },
    (data) => {
        console.log(data);
    }
);
```

### `$.fn.option_select(options)`
Llena un select con datos.
```javascript
$('#mySelect').option_select({
    data: [
        { id: 1, valor: "Opción 1" },
        { id: 2, valor: "Opción 2" }
    ],
    placeholder: "Seleccionar",
    select2: true
});
```

### `$.fn.rpt_json_table2(options)`
Genera tablas desde JSON.
```javascript
$('#container').rpt_json_table2({
    data: {
        thead: ["ID", "Nombre"],
        row: [
            { id: 1, Nombre: "Juan", a: [...] }
        ]
    },
    id: 'myTable',
    center: [0],
    right: [2]
});
```

---

## Funciones Auxiliares

### `useFetch(options)`
Función global para peticiones AJAX.
```javascript
const data = await useFetch({
    url: 'ctrl/ctrl-products.php',
    data: { opc: 'ls' },
    success: (response) => console.log(response)
});
```

### `dataPicker(options)`
Inicializa un selector de fechas.
```javascript
dataPicker({
    parent: 'dateInput',
    type: 'all', // 'all' | 'simple'
    onSelect: (start, end) => {
        console.log(start.format('YYYY-MM-DD'));
    }
});
```

### `getDataRangePicker(idInput)`
Obtiene el rango de fechas seleccionado.
```javascript
const { fi, ff } = getDataRangePicker('dateInput');
```

### `simple_data_table(table, rows)`
Inicializa DataTables.
```javascript
simple_data_table('#myTable', 15);
```

### `fn_ajax(data, url, div)`
Petición AJAX con jQuery.
```javascript
fn_ajax({ opc: 'ls' }, 'ctrl/ctrl.php', '#container')
    .then(data => console.log(data));
```

### `formatPrice(amount, locale, currency)`
Formatea números como moneda.
```javascript
formatPrice(1500); // "$1,500.00"
formatPrice(1500, 'en-US', 'USD'); // "$1,500.00"
```

### `formDataToJson(formData)`
Convierte un objeto `FormData` (multipart) en un JSON plano. Útil al subir archivos junto con campos.
```javascript
const fd = new FormData(document.getElementById('myForm'));
const json = formDataToJson(fd);
```

---

## Tipos de Input Soportados

### Formularios JSON
```javascript
json: [
    { opc: "input", tipo: "texto" },
    { opc: "input", tipo: "numero" },
    { opc: "input", tipo: "cifra" },
    { opc: "input", tipo: "email" },
    { opc: "input", type: "date" },
    { opc: "input", type: "time" },
    { opc: "textarea" },
    { opc: "select", data: [] },
    { opc: "radio" },
    { opc: "checkbox" },
    { opc: "input-calendar" },
    { opc: "input-file" },
    { opc: "btn" },
    { opc: "btn-submit" },
    { opc: "button" },
    { opc: "dropdown" },
    { opc: "label" }
]
```

---

## Temas Disponibles

### Tablas
- `light` - Fondo blanco, texto oscuro
- `dark` - Fondo oscuro (#1F2A37), texto blanco
- `corporativo` - Azul corporativo (#003360)
- `shadcdn` - Estilo moderno (#111827)

### Navegación
- `light` - Fondo claro
- `dark` - Estilo Huubie (#1F2A37)

---

## Integración con Proyectos

### Archivos Obligatorios
```html
<!-- En index.php -->
<script src="src/js/coffeSoft.js"></script>
<script src="src/js/plugins.js"></script>
```

### Estructura de Proyecto
```
proyecto/
├── index.php
├── ctrl/
│   └── ctrl-proyecto.php
├── mdl/
│   └── mdl-proyecto.php
├── js/
│   └── proyecto.js
└── src/
    ├── js/
    │   ├── coffeSoft.js
    │   └── plugins.js
    └── components/
        └── [componentes-personalizados].js
```

### Inicialización Básica
```javascript
let api = 'ctrl/ctrl-proyecto.php';
let app;

$(async () => {
    app = new App(api, "root");
    app.render();
});

class App extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "proyecto";
    }
}
```

---

## Soporte y Recursos

- **Documentación CoffeeSoft**: este archivo (DOC-COFFEESOFT.md).
- **Steering relacionados**: `CTRL.md`, `MDL.md`, `FRONT-JS.md`, `new-component.md`, `PIVOTE-INDEX.md`.
- **Pivote local del framework**: `src/js/coffeSoft.js` (NO usar el CDN antiguo `CoffeSoft.js`).

---

## Notas Importantes

1. **Herencia**: Siempre extender de `Templates` para acceder a todos los componentes
2. **Constructor**: Pasar `link` (API) y `div_modulo` (contenedor raíz)
3. **Validación**: Los formularios validan automáticamente campos con `required`
4. **Responsive**: Todos los componentes usan TailwindCSS y son responsive
5. **Eventos**: Usar `onClick`, `onchange`, `fn` según el componente
6. **Async**: Usar `async/await` con `useFetch()` para peticiones

---

## Ejemplo Completo

```javascript
class App extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "products";
    }

    render() {
        this.layout();
        this.filterBar();
        this.ls();
    }

    layout() {
        this.primaryLayout({
            parent: 'root',
            id: this.PROJECT_NAME,
            class: 'p-2',
            card: {
                filterBar: { class: 'w-full my-3 p-3 border rounded-lg', id: `filterBar${this.PROJECT_NAME}` },
                container: { class: 'w-full my-3 h-full ', id: `container${this.PROJECT_NAME}` }
            }
        });
    }

    filterBar() {
        this.createfilterBar({
            parent: 'filterBar',
            data: [
                {
                    opc: "select",
                    id: "category",
                    lbl: "Categoría",
                    data: categories,
                    onchange: "app.ls()"
                }
            ]
        });
    }

    ls() {
        this.createTable({
            parent: 'container',
            idFilterBar: 'filterBar',
            data: { opc: 'ls' },
            coffeesoft: true,
            conf: { datatable: true, pag: 15 },
            attr: {
                id: 'tbProducts',
                theme: 'corporativo'
            }
        });
    }
}
```
