# Indice de Steering Files - Global (~/.claude/steering)

> Mapa de secciones para Read(file, offset, limit). Generado por regenerar_indice.py

**Generado:** 2026-08-02
**Ubicacion:** `C:\Users\CoffeSoft\.claude\steering`
**Archivos indexados:** 11

---

## Reglas de uso

1. NUNCA leas un archivo completo. Usa `Read(file, offset, limit)` con la seccion especifica.
2. Si tu pedido toca varias secciones, lee 2-3 en paralelo (un mensaje, multiples tool calls).
3. Si necesitas algo no listado, lee el archivo completo SOLO esa vez.
4. Si un offset parece desactualizado, regenera el indice con `/actualiza`.

---

## COFFEE-MAGIC.md (128 lineas)

`C:/Users/CoffeSoft/.claude/steering/COFFEE-MAGIC.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | COFFEE-MAGIC — Router de Steering para el agente CoffeeMagic | 1 | 7 |
| 2 | 1. Cuando invocar a CoffeeMagic | 8 | 30 |
| 3 | 2. Mapeo dominio → grimorio | 38 | 11 |
| 4 | 3. Rutas de resolucion de grimorios (orden) | 49 | 15 |
| 5 | 4. Catalogo de spells | 64 | 19 |
| 6 | 5. Reglas de tema (resumen) | 83 | 13 |
| 7 | 6. Estructura de salida estandar | 96 | 16 |
| 8 | 7. Integracion con CoffeeIA | 112 | 12 |
| 9 | 8. Mantenimiento | 124 | 5 |

## CoffeeIA.md (575 lineas)

`C:/Users/CoffeSoft/.claude/steering/CoffeeIA.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | Prompt Estructurado para Generar Código con CoffeeSoft (PRINCIPIO R.O.S.Y) | 1 | 4 |
| 2 | 0. Flujo de Trabajo Obligatorio | 5 | 38 |
| 3 | 1. Rol del Asistente (R) | 43 | 40 |
| 4 | 2. Objetivo (O) | 83 | 6 |
| 5 | 3. Secuencia de Acción-WORKFLOW (S) | 89 | 322 |
| 6 | 4. Yield / Definiciones Técnicas (Y) | 411 | 52 |
| 7 | Control de errores | 463 | 64 |
| 8 | Reglas de Comentarios | 527 | 49 |

## CTRL.md (974 lineas)

`C:/Users/CoffeSoft/.claude/steering/CTRL.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | Objetivo | 1 | 194 |
| 2 | Notas Adicionales de Métodos | 195 | 174 |
| 3 | 9. uploadFile() | 369 | 83 |
| 4 | 9.1 uploadSingleFile() — Archivo único | 452 | 56 |
| 5 | 10. Funciones Auxiliares (Complements) | 508 | 317 |
| 6 | Variables en foreach | 825 | 22 |
| 7 | Multiline Arrays | 847 | 21 |
| 8 | Ruta de coffeSoft.php según profundidad | 868 | 10 |
| 9 | Helpers de render fuera de la clase | 878 | 97 |

## DOC-COFFEESOFT.md (947 lineas)

`C:/Users/CoffeSoft/.claude/steering/DOC-COFFEESOFT.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | Documentación CoffeeSoft Framework | 1 | 2 |
| 2 | Descripción General | 3 | 3 |
| 3 | Arquitectura de Clases | 6 | 19 |
| 4 | Clase: Complements | 25 | 36 |
| 5 | Clase: Components | 61 | 466 |
| 6 | Clase: Templates | 527 | 132 |
| 7 | Plugins jQuery (plugins.js) | 659 | 66 |
| 8 | Funciones Auxiliares | 725 | 59 |
| 9 | Tipos de Input Soportados | 784 | 27 |
| 10 | Temas Disponibles | 811 | 14 |
| 11 | Integración con Proyectos | 825 | 47 |
| 12 | Soporte y Recursos | 872 | 8 |
| 13 | Notas Importantes | 880 | 11 |
| 14 | Ejemplo Completo | 891 | 57 |

## FRONT-JS.md (1011 lineas)

`C:/Users/CoffeSoft/.claude/steering/FRONT-JS.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | Objetivo General | 1 | 74 |
| 2 | Rules | 75 | 131 |
| 3 | Análisis previo de layout (OBLIGATORIO) | 206 | 36 |
| 4 | La clase debe implementar los siguientes métodos: | 242 | 770 |

## MDL.md (465 lineas)

`C:/Users/CoffeSoft/.claude/steering/MDL.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | 1.Estructura Base del Modelo | 6 | 63 |
| 2 | Nomenclatura Permitida para Modelos (MDL) | 69 | 17 |
| 3 | 3. Uso de Métodos CRUD Heredados | 86 | 87 |
| 4 | 4. Estructura para Consultas con _Read | 173 | 120 |
| 5 | 5. Separación de Consultas Complejas | 293 | 173 |

## new-component.md (247 lineas)

`C:/Users/CoffeSoft/.claude/steering/new-component.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | Prompt para construir un componente jQuery con Tailwind | 1 | 2 |
| 2 | 0. Flujo de creación de componentes | 3 | 26 |
| 3 | 1. Contexto claro: | 29 | 4 |
| 4 | 2. Reglas o condiciones: | 33 | 56 |
| 5 | 3. Inputs esperados | 89 | 16 |
| 6 | 4. Formato de salida esperado (ejemplo base): | 105 | 90 |
| 7 | 5. Datos SAMPLE para desarrollo UI-first | 195 | 53 |

## PIVOTE-INDEX.md (577 lineas)

`C:/Users/CoffeSoft/.claude/steering/PIVOTE-INDEX.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | PIVOTE INDEX - Estructura Estándar para Archivos index.php | 4 | 2 |
| 2 | Descripción | 6 | 3 |
| 3 | Objetivo | 9 | 8 |
| 4 | Aclaraciones Importantes | 17 | 38 |
| 5 | Estructura Base | 55 | 57 |
| 6 | Componentes del Pivote | 112 | 77 |
| 7 | Ejemplos de Uso | 189 | 166 |
| 8 | Reglas de Implementación | 355 | 32 |
| 9 | Variaciones Permitidas | 387 | 51 |
| 10 | Archivos de Layout Requeridos | 438 | 90 |
| 11 | Integración con CoffeeSoft | 528 | 7 |
| 12 | Notas Importantes | 535 | 12 |
| 13 | Checklist de Implementación | 547 | 18 |
| 14 | Mantenimiento | 565 | 13 |

## TESTING.backup-2026-07-31.md (388 lineas)

`C:/Users/CoffeSoft/.claude/steering/TESTING.backup-2026-07-31.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | TESTING - Reglas de Validacion CoffeeSoft | 1 | 2 |
| 2 | Objetivo General | 3 | 3 |
| 3 | Severidades | 6 | 8 |
| 4 | Tipos de Verificacion | 14 | 10 |
| 5 | 1. Validaciones de Controlador (CTRL) - 14 puntos | 24 | 128 |
| 6 | 2. Validaciones de Modelo (MDL) - 12 puntos | 152 | 65 |
| 7 | 3. Validaciones de Frontend JavaScript (JS) - 13 puntos | 217 | 80 |
| 8 | 4. Validaciones de Index.php (IDX) - 8 puntos | 297 | 59 |
| 9 | Formato de Reporte | 356 | 5 |
| 10 | Reporte de Validacion - [nombre-modulo] | 361 | 3 |
| 11 | Resumen | 364 | 4 |
| 12 | Resultado: XX/47 validaciones pasadas | 368 | 2 |
| 13 | Fallos Detectados | 370 | 10 |
| 14 | Reglas CRITICAS | 380 | 9 |

## TESTING.md (459 lineas)

`C:/Users/CoffeSoft/.claude/steering/TESTING.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | TESTING - Reglas de Validacion CoffeeSoft | 1 | 2 |
| 2 | Objetivo General | 3 | 6 |
| 3 | Severidades | 9 | 8 |
| 4 | Tipos de Verificacion | 17 | 10 |
| 5 | 1. Validaciones de Controlador (CTRL) - 14 puntos | 27 | 128 |
| 6 | 2. Validaciones de Modelo (MDL) - 12 puntos | 155 | 65 |
| 7 | 3. Validaciones de Frontend JavaScript (JS) - 13 puntos | 220 | 80 |
| 8 | 4. Validaciones de Index.php (IDX) - 8 puntos | 300 | 59 |
| 9 | 5. Validaciones de Transmutacion (TRM) - 17 puntos | 359 | 61 |
| 10 | Formato de Reporte | 420 | 5 |
| 11 | Reporte de Validacion - [nombre-modulo] | 425 | 3 |
| 12 | Resumen | 428 | 4 |
| 13 | Resultado: XX/47 validaciones base (+ XX/17 TRM si es transmutacion) | 432 | 2 |
| 14 | Fallos Detectados | 434 | 10 |
| 15 | Reglas CRITICAS | 444 | 16 |

## WORKFLOW.md (316 lineas)

`C:/Users/CoffeSoft/.claude/steering/WORKFLOW.md`

| # | Seccion | offset | limit |
|---|---|---|---|
| 1 | WORKFLOW — Flujo de Trabajo Obligatorio de CoffeeIA | 4 | 4 |
| 2 | Principio rector | 8 | 6 |
| 3 | Fase 0 — Comprensión (bloqueante, antes de tocar código) | 14 | 80 |
| 4 | Fase 1 — Diseño con aprobación (bloqueante) | 94 | 48 |
| 5 | Diseño propuesto — [Nombre del módulo] | 142 | 38 |
| 6 | Fase 2 — Construcción con checkpoints | 180 | 56 |
| 7 | Fase 3 — Validación final (bloqueante) | 236 | 31 |
| 8 | ❌ Anti-patrones prohibidos | 267 | 15 |
| 9 | 🚨 Señales de que estás saltando el flujo | 282 | 17 |
| 10 | Excepciones legítimas (cuándo SÍ puedes saltar fases) | 299 | 18 |

---

**Total: 11 archivos, 109 secciones indexadas.**
