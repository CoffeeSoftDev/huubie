---
inclusion: always
---
# PIVOTE INDEX - Estructura Estándar para Archivos index.php

## Descripción
Este pivote define la estructura estándar para todos los archivos `index.php` del sistema ERP. Proporciona una base consistente con validación de sesión, integración de layouts, y carga de módulos siguiendo las mejores prácticas del framework CoffeeSoft.

## Objetivo
Establecer un patrón uniforme para los puntos de entrada de todos los módulos del sistema, asegurando:
- Validación de sesión consistente
- Carga ordenada de recursos
- Integración con el sistema de navegación
- Estructura HTML semántica
- Compatibilidad con CoffeeSoft Framework

## Aclaraciones Importantes

### Nombre del archivo del framework
- El nombre correcto es `coffeeSoft.js` (c minúscula, S mayúscula)
- **NO** usar `CoffeSoft.js` ni `coffeesoft.js`

### core-libraries.php (antes script.php)
- Los proyectos **nuevos** usan `layout/core-libraries.php`
- Reemplaza al antiguo `layout/script.php`
- Contiene las mismas librerías pero con nombre estandarizado

### Rutas relativas según profundidad
- **ANTES** de crear rutas, examinar el nivel de profundidad del proyecto respecto a `src/`
- Módulo nivel 1 (`ERP3/coffee/`): usar `../src/js/coffeeSoft.js`, `../layout/navbar.php`
- Módulo nivel 2 (`ERP3/finanzas/administracion/`): usar `../../src/js/coffeeSoft.js`, `../../layout/navbar.php`
- **SIEMPRE** ajustar según la profundidad real del módulo

### plugins.js
- Es un archivo **nuevo** que reemplaza a `plugin-forms.js` y `plugin-table.js`
- Se carga desde ruta local: `[profundidad]/src/js/plugins.js`

### complementos.js
- Se carga desde CDN: `https://www.plugins.erp-varoch.com/ERP/JS/complementos.js`
- **NO** usar la versión local

### TailwindCSS CDN
- Requisito **nuevo** para todos los proyectos
- Se incluye en `layout/core-libraries.php`

### Chart.js
- Solo incluir en `core-libraries.php` cuando el módulo use gráficas
- **NO** incluir por defecto en todos los módulos

### Separación de responsabilidades en layouts
- `index.php` → DOCTYPE, `<html>`, `<head>`, meta tags, favicon, title. Incluye head.php y core-libraries.php. Carga CoffeeSoft Framework, cierra `</head>` y abre `<body>`
- `head.php` → **Solo estilos CSS** (links a hojas de estilo y fuentes)
- `core-libraries.php` → **Solo scripts JS** de plugins, librerías y TailwindCSS CDN

## Estructura Base

```php
<?php
session_start();

// Validar sesión de usuario
if (empty($_COOKIE["IDU"])) {
    require_once('[profundidad]/acceso/ctrl/ctrl-logout.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="[profundidad]/src/img/logos/logo_icon.png" type="image/x-icon">
    <title>15-92</title>

    <?php require_once('layout/head.php'); ?>
    <?php require_once('layout/core-libraries.php'); ?>

    <!-- CoffeeSoft Framework -->
    <script src="[profundidad]/src/js/coffeeSoft.js"></script>
    <script src="[profundidad]/src/js/plugins.js"></script>
    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
</head>

<body>
    <?php require_once('[profundidad]/layout/navbar.php'); ?>

    <main>
        <section id="sidebar"></section>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">[MÓDULO_PADRE]</li>
                    <li class="breadcrumb-item fw-bold active">[MÓDULO_ACTUAL]</li>
                </ol>
            </nav>

            <!-- Main Container -->
            <div class="main-container" id="root"></div>

            <!-- Módulo Scripts -->
            <script src="js/[nombre-modulo].js?t=<?php echo time(); ?>"></script>
        </div>
    </main>
</body>
</html>
```

**Nota:** `[profundidad]` se reemplaza por `..` o `../..` según el nivel del módulo respecto a la raíz del ERP.

## Componentes del Pivote

### 1. Validación de Sesión
```php
session_start();

// Validar sesión de usuario
if (empty($_COOKIE["IDU"])) {
    require_once('[profundidad]/acceso/ctrl/ctrl-logout.php');
    exit();
}
```

**Reglas:**
- SIEMPRE iniciar con `session_start()`
- Validar cookie `IDU` para verificar sesión activa
- Redirigir a logout si no hay sesión válida
- Usar `exit()` después de la redirección

### 2. Carga de Layouts
```php
require_once('layout/head.php');
require_once('layout/core-libraries.php');
```

**Reglas:**
- Cargar `head.php` primero (solo CSS y estilos)
- Cargar `core-libraries.php` segundo (solo JS de plugins y librerías)
- Usar rutas relativas al módulo actual

### 3. CoffeeSoft Framework
```php
<!-- CoffeeSoft Framework -->
<script src="[profundidad]/src/js/coffeeSoft.js"></script>
<script src="[profundidad]/src/js/plugins.js"></script>
<script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
```

**Reglas:**
- SIEMPRE cargar en este orden: coffeeSoft.js → plugins.js → complementos.js
- Usar comentario descriptivo `<!-- CoffeeSoft Framework -->`
- Mantener las rutas exactas del pivote

### 4. Estructura HTML
```php
<body>
    <?php require_once('[profundidad]/layout/navbar.php'); ?>

    <main>
        <section id="sidebar"></section>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">[MÓDULO_PADRE]</li>
                    <li class="breadcrumb-item fw-bold active">[MÓDULO_ACTUAL]</li>
                </ol>
            </nav>

            <!-- Main Container -->
            <div class="main-container" id="root"></div>

            <!-- Módulo Scripts -->
            <script src="js/[nombre-modulo].js?t=<?php echo time(); ?>"></script>
        </div>
    </main>
</body>
```

**Reglas:**
- Incluir navbar del sistema 
- Mantener estructura: `<main>` → `<section id="sidebar">` → `<div id="main__content">`
- Breadcrumb con comentario descriptivo
- Container principal con `id="root"`
- Scripts del módulo al final con cache busting `?t=<?php echo time(); ?>`

## Ejemplos de Uso

### Ejemplo 1: Módulo Nivel 1 (ERP3/almacen/)
Profundidad: `..` (un nivel desde la raíz del ERP)
```php
<?php
session_start();

if (empty($_COOKIE["IDU"])) {
    require_once('../acceso/ctrl/ctrl-logout.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../src/img/logos/logo_icon.png" type="image/x-icon">
    <title>15-92</title>

    <?php require_once('layout/head.php'); ?>
    <?php require_once('layout/core-libraries.php'); ?>

    <!-- CoffeeSoft Framework -->
    <script src="../src/js/coffeeSoft.js"></script>
    <script src="../src/js/plugins.js"></script>
    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
</head>

<body>
    <?php require_once('../layout/navbar.php'); ?>

    <main>
        <section id="sidebar"></section>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">Operación</li>
                    <li class="breadcrumb-item fw-bold active">Almacén</li>
                </ol>
            </nav>

            <!-- Main Container -->
            <div class="main-container" id="root"></div>

            <!-- Módulo de Almacén -->
            <script src="js/almacen.js?t=<?php echo time(); ?>"></script>
        </div>
    </main>
</body>
</html>
```

### Ejemplo 2: Módulo Nivel 2 (ERP3/finanzas/administracion/)
Profundidad: `../..` (dos niveles desde la raíz del ERP)
```php
<?php
session_start();

if (empty($_COOKIE["IDU"])) {
    require_once('../../acceso/ctrl/ctrl-logout.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../src/img/logos/logo_icon.png" type="image/x-icon">
    <title>15-92</title>

    <?php require_once('layout/head.php'); ?>
    <?php require_once('layout/core-libraries.php'); ?>

    <!-- CoffeeSoft Framework -->
    <script src="../../src/js/coffeeSoft.js"></script>
    <script src="../../src/js/plugins.js"></script>
    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
</head>

<body>
    <?php require_once('../../layout/navbar.php'); ?>

    <main>
        <section id="sidebar"></section>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">Contabilidad</li>
                    <li class="breadcrumb-item fw-bold active">Administrador</li>
                </ol>
            </nav>

            <!-- Main Container -->
            <div class="main-container" id="root"></div>

            <!-- Módulos del Sistema -->
            <script src="js/admin.js?t=<?php echo time(); ?>"></script>
            <script src="js/cuenta-venta.js?t=<?php echo time(); ?>"></script>
            <script src="js/efectivo.js?t=<?php echo time(); ?>"></script>
        </div>
    </main>
</body>
</html>
```

### Ejemplo 3: Módulo Nivel 1 Simple (ERP3/dashboard/)
Profundidad: `..` (un nivel, sin submódulos)
```php
<?php
session_start();

if (empty($_COOKIE["IDU"])) {
    require_once('../acceso/ctrl/ctrl-logout.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../src/img/logos/logo_icon.png" type="image/x-icon">
    <title>15-92</title>

    <?php require_once('layout/head.php'); ?>
    <?php require_once('layout/core-libraries.php'); ?>

    <!-- CoffeeSoft Framework -->
    <script src="../src/js/coffeeSoft.js"></script>
    <script src="../src/js/plugins.js"></script>
    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
</head>

<body>
    <?php require_once('../layout/navbar.php'); ?>

    <main>
        <section id="sidebar"></section>

        <div id="main__content">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase text-muted">Reportes</li>
                    <li class="breadcrumb-item fw-bold active">Dashboard</li>
                </ol>
            </nav>

            <!-- Main Container -->
            <div class="main-container" id="root"></div>

            <!-- Módulo de Dashboard -->
            <script src="js/dashboard.js?t=<?php echo time(); ?>"></script>
        </div>
    </main>
</body>
</html>
```

## Reglas de Implementación

### ✅ OBLIGATORIO

1. **Validación de Sesión:**
   - SIEMPRE validar session `IDU`
   - SIEMPRE redirigir a logout si no hay sesión
   - SIEMPRE usar `exit()` después de redirección

2. **Orden de Carga:**
   - session_start() → validación → DOCTYPE/html/head/meta → head.php (CSS) → core-libraries.php (JS) → CoffeeSoft Framework → </head> → body

3. **Estructura HTML:**
   - Mantener jerarquía: main → sidebar → main__content
   - SIEMPRE incluir breadcrumb con comentario
   - SIEMPRE usar `id="root"` en el container principal

4. **Scripts:**
   - SIEMPRE agregar cache busting `?t=<?php echo time(); ?>` en scripts del **módulo** (`src/js/[modulo].js`)
   - **NO** agregar cache busting a `coffeeSoft.js` ni `plugins.js` — son librerías del framework y no deben forzar recarga
   - Cargar scripts del módulo al final del main__content
   - **Ruta del módulo:** `src/js/[nombre-modulo].js` (NUNCA `js/[nombre-modulo].js` en raíz del módulo)

### ❌ PROHIBIDO

1. **NO** omitir la validación de sesión
2. **NO** cambiar el orden de carga de CoffeeSoft
3. **NO** modificar los IDs estándar (sidebar, main__content, root)
4. **NO** usar rutas absolutas para recursos internos
5. **NO** usar cache busting (`?t=`) en `coffeeSoft.js` ni `plugins.js`
6. **NO** colocar scripts del módulo en `js/` a nivel raíz del módulo — siempre usar `src/js/`

## Variaciones Permitidas

### Múltiples Scripts
Si el módulo tiene varios submódulos, cargar todos los scripts necesarios:

```php
<!-- Módulos del Sistema -->
<script src="src/js/modulo1.js?t=<?php echo time(); ?>"></script>
<script src="src/js/modulo2.js?t=<?php echo time(); ?>"></script>
<script src="src/js/modulo3.js?t=<?php echo time(); ?>"></script>
```

### Breadcrumb con Más Niveles
Para módulos con jerarquía profunda:

```php
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item text-uppercase text-muted">Nivel 1</li>
        <li class="breadcrumb-item text-uppercase text-muted">Nivel 2</li>
        <li class="breadcrumb-item fw-bold active">Nivel 3</li>
    </ol>
</nav>
```

### Sin Validación de Sesión (Solo para páginas públicas)
**USAR CON PRECAUCIÓN - Solo para login, registro, etc.**

```php
<?php
session_start();
// Sin validación de cookie para páginas públicas
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="[profundidad]/src/img/logos/logo_icon.png" type="image/x-icon">
    <title>15-92</title>

    <?php require_once('layout/head.php'); ?>
    <?php require_once('layout/core-libraries.php'); ?>

    <!-- CoffeeSoft Framework -->
    <script src="[profundidad]/src/js/coffeeSoft.js"></script>
    <script src="[profundidad]/src/js/plugins.js"></script>
    <script src="https://www.plugins.erp-varoch.com/ERP/JS/complementos.js"></script>
</head>
```

## Archivos de Layout Requeridos

### layout/head.php (Solo CSS)
Contiene **únicamente** hojas de estilo `<link>` y fuentes. No incluye ningún `<script>`, DOCTYPE, meta tags ni favicon (esos van en `index.php`).
- CSS: Fontello, Bootstrap, SweetAlert, DataTables, Select2, DateRangePicker
- Fuente Poppins
- CSS personalizados (navbar.css)

**Ejemplo de head.php:**
```php
    <!-- FONTELLO -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/fontello/css/fontello.css">
    <link rel="stylesheet" href="[profundidad]/src/plugin/fontello/css/animation.css">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/bootstrap-5/css/bootstrap.min.css">

    <!-- SWEETALERT -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/sweetalert2/sweetalert2.min.css">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/datatables/dataTables.responsive.min.css">
    <link rel="stylesheet" href="[profundidad]/src/plugin/datatables/1.13.6/css/dataTables.bootstrap5.min.css">

    <!-- DATERANGEPICKER -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/daterangepicker/daterangepicker.css">

    <!-- SELECT2 -->
    <link rel="stylesheet" href="[profundidad]/src/plugin/select2/bootstrap/select2.min.css">
    <link rel="stylesheet" href="[profundidad]/src/plugin/select2/bootstrap/select2-bootstrap-5-theme.min.css">

    <!-- PERSONALIZADO -->
    <link rel="stylesheet" href="[profundidad]/src/css/navbar.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
```

**Nota:** `[profundidad]` = `..` o `../..` según nivel del módulo.

### layout/core-libraries.php (Solo JS)
Contiene **únicamente** scripts `<script>`. No incluye ningún `<link>` CSS.
- TailwindCSS CDN
- Lucide Icons CDN (solo si el módulo usa iconos Lucide)
- jQuery, Bootstrap JS, Bootbox, SweetAlert2
- Select2, Moment.js, DateRangePicker
- DataTables
- Chart.js **solo si el módulo usa gráficas**
- navbar.js y sidebar.js

**Ejemplo de core-libraries.php:**
```php
<!-- CDN TAILWIND -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Lucide Icons (solo si el módulo usa iconos Lucide) -->
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>

<!-- Core Libraries -->
<script src="[profundidad]/src/plugin/jquery/jquery-3.7.0.min.js"></script>

<!-- Bootstrap -->
<script src="[profundidad]/src/plugin/bootstrap-5/js/bootstrap.min.js"></script>
<script src="[profundidad]/src/plugin/bootstrap-5/js/bootstrap.bundle.js"></script>

<!-- UI Plugins -->
<script src="[profundidad]/src/plugin/select2/bootstrap/select2.min.js"></script>
<script src="[profundidad]/src/plugin/bootbox.min.js"></script>
<script src="[profundidad]/src/plugin/sweetalert2/sweetalert2.all.min.js"></script>

<!-- Date & Time -->
<script src="[profundidad]/src/plugin/daterangepicker/moment.min.js"></script>
<script src="[profundidad]/src/plugin/daterangepicker/daterangepicker.js"></script>

<!-- DataTables -->
<script src="[profundidad]/src/plugin/datatables/datatables.min.js"></script>
<script src="[profundidad]/src/plugin/datatables/dataTables.responsive.min.js"></script>
<script src="[profundidad]/src/plugin/datatables/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- Charts (solo si el módulo usa gráficas) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>

<!-- Layout Components -->
<script src="[profundidad]/src/js/navbar.js"></script>
<script src="[profundidad]/src/js/sidebar.js"></script>
```

**Nota:** `[profundidad]` = `..` o `../..` según nivel del módulo. Charts solo si el módulo requiere gráficas.

## Integración con CoffeeSoft

El pivote está diseñado para trabajar perfectamente con:
- **Templates**: Layouts predefinidos (primaryLayout, splitLayout, etc.)
- **Components**: Tablas, formularios, filtros, modales
- **Complements**: Utilidades y helpers

## Notas Importantes

1. **Rutas Relativas:** Ajustar según la profundidad del módulo
   - Módulo raíz: `../src/js/coffeeSoft.js`
   - Submódulo: `../../src/js/coffeeSoft.js`

2. **Cache Busting:** El `?t=<?php echo time(); ?>` previene problemas de caché en desarrollo

3. **Comentarios:** Mantener comentarios descriptivos para claridad

4. **Consistencia:** Seguir EXACTAMENTE este pivote para todos los módulos nuevos

## Checklist de Implementación

Antes de considerar completo un index.php, verificar:

- [ ] ✅ session_start() al inicio
- [ ] ✅ Validación de session IDU
- [ ] ✅ Redirección a logout si no hay sesión
- [ ] ✅ Carga de layout/head.php
- [ ] ✅ Carga de layout/core-libraries.php
- [ ] ✅ CoffeeSoft Framework en orden correcto
- [ ] ✅ Navbar incluido
- [ ] ✅ Estructura main → sidebar → main__content
- [ ] ✅ Breadcrumb con comentario
- [ ] ✅ Container con id="root"
- [ ] ✅ Scripts con cache busting
- [ ] ✅ Comentarios descriptivos
- [ ] ✅ HTML válido y bien formateado

## Mantenimiento

Este pivote es **INMUTABLE**. Cualquier cambio debe:
1. Ser discutido con el equipo
2. Actualizarse en TODOS los módulos existentes
3. Documentarse en este archivo

---

**Versión:** 1.0  
**Última actualización:** 2026-03-20  
**Autor:** CoffeeIA ☕  
**Estado:** Aprobado para producción
