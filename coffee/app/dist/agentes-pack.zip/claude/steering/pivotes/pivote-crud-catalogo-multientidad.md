---
inclusion: manual
---
# PIVOTE — CRUD Catálogo Multi-Entidad (`ctrl` + `mdl` + `js`)

## Qué es

Patrón completo para un **módulo de administración que gestiona varias entidades CRUD homogéneas** bajo una sola pantalla, navegadas por tabs. Una clase `App` orquestadora + N clases CRUD idénticas en estructura. Probado en producción en el módulo de administración de inventario Huubie (`app/inventarios/admin-productos.*`): productos, categorías, almacenes, áreas, unidades, proveedores, orígenes, mermas, ajustes y estados de traspaso.

## Cuándo usar

- El módulo administra **3+ catálogos/entidades** con operaciones CRUD simples y homogéneas (alta, edición, listado, cambio de estado).
- Cada entidad es una tabla independiente con su propio filtro de estado y botón "Nuevo".
- Se quiere una sola pantalla con tabs, no N pantallas separadas.

Si es **una sola** entidad → usar el pivote de módulo simple (`primaryLayout`), no este.

## Capas incluidas

| Capa | Incluida | Archivo de referencia |
|---|---|---|
| `js` (FRONT) | ✅ | `app/inventarios/src/js/admin-productos.js` |
| `ctrl` (controlador) | ✅ | `app/inventarios/ctrl/ctrl-admin-productos.php` |
| `mdl` (modelo) | ✅ | `app/inventarios/mdl/mdl-admin-productos.php` |
| `index.php` | ❌ **NO** | usar [PIVOTE-INDEX](../PIVOTE-INDEX.md) |

> Este pivote **no** cubre el `index.php`. Para el punto de entrada usar siempre `PIVOTE-INDEX`.

---

## ⚠️ Regla de THEME (crítica)

- **Por defecto se genera en `light`.** Si el usuario no indica theme → `light`.
- **`dark` solo si el proyecto es Huubie** (o el usuario lo pide). El código de referencia abajo está en **dark Huubie** (`theme: "dark"`, paleta `#1F2A37`). Al portar a otro proyecto, intercambiar los **tokens de theme**:

| Token | `light` (default) | `dark` (Huubie) |
|---|---|---|
| `createTable` → `attr.theme` | `"corporativo"` | `"dark"` |
| `tabLayout` → `theme` | `"light"` | `"dark"` |
| `createModalForm` → `theme` | `"light"` | `"dark"` |
| Contenedor principal | `bg-white border` | `bg-[#1F2A37]` |
| Título / texto fuerte | `text-gray-900` | `text-white` |
| Texto secundario | `text-gray-500` | `text-gray-400` |
| Caja de detalle (preview) | `bg-gray-50` | `bg-[#1E293B]` |

> Cuando el destino es light, NO arrastrar clases `bg-[#...]` hardcodeadas del ejemplo dark; sustituir por los tokens light.

---

## Arquitectura tripartita

```
admin-[modulo].js   →  App (orquesta tabs) + N clases CRUD (extends Templates) + helpers globales
ctrl-admin-[modulo].php  →  class ctrl extends mdl: init() + ls/get/add/edit/status por entidad + complements (render cells)
mdl-admin-[modulo].php   →  class mdl extends CRUD: *Select() para catálogos + list/getById/create/update/updateStatus por entidad
```

Nomenclatura encadenada entre capas (OBLIGATORIO):

| Front (JS) | Controlador (ctrl) | Modelo (mdl) |
|---|---|---|
| `ls()` | `ls[Entidad]()` | `list[Entidad]()` |
| `edit(id)` → `getProduct` | `get[Entidad]()` | `get[Entidad]ById()` |
| `add()` → `add[Entidad]` | `add[Entidad]()` | `create[Entidad]()` |
| (submit edit) | `edit[Entidad]()` | `update[Entidad]()` |
| `status(id,active)` | `status[Entidad]()` | `update[Entidad]Status()` |

---

## Capa 1 — JS (FRONT)

### App orquestadora (lazy render)

```js
let api = '/app/[modulo]/ctrl/ctrl-admin-[modulo].php';
let cat = {};
let app, productos, categorias /*, ...resto de entidades */;

$(async () => {
    const data = await useFetch({ url: api, data: { opc: "init" } });

    cat = {
        categorias: (data && data.categorias) || SAMPLE_CATALOGOS.categorias,
        areas:      (data && data.areas)      || SAMPLE_CATALOGOS.areas
        // ...catálogos compartidos por los formularios
    };

    app        = new App(api, "root");
    productos  = new Productos(api, "root");
    categorias = new Categorias(api, "root");
    // ...instanciar todas las entidades

    app.render();
});

// -- Clase principal --

class App extends Templates {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "AdminModulo";
    }

    render() {
        this.layout();
        this.renderTabs();
        this.renderActiveTab();
    }

    layout() {
        this.createLayout({
            parent: "root",
            design: false,
            data: {
                id: this.PROJECT_NAME,
                class: "flex flex-col w-full p-3 flex-1",
                container: [
                    {
                        type: "div",
                        id: `container${this.PROJECT_NAME}`,
                        class: "w-full flex-1 bg-[#1F2A37] rounded-lg p-3 overflow-auto", // DARK token
                        children: [
                            { id: "titleAdmin", class: "px-2 pt-2 pb-3" },
                            { id: `tabs${this.PROJECT_NAME}`, class: "w-full" }
                        ]
                    }
                ]
            }
        });
        this.renderTitle();
    }

    renderTitle() {
        this.infoTitle({
            parent: "titleAdmin",
            title: "Productos",
            subtitle: "Administra el catálogo de productos del inventario."
        });
    }

    renderTabs() {
        this.tabLayout({
            parent: `tabs${this.PROJECT_NAME}`,
            id: `tabs${this.PROJECT_NAME}`,
            theme: "dark",          // THEME token → "light" por defecto
            type: "short",
            showBorder: false,
            json: [
                {
                    id: "productos",
                    tab: "Productos",
                    lucideIcon: "package",
                    active: true,
                    onClick: () => productos.render()
                },
                {
                    id: "categorias",
                    tab: "Categorias",
                    lucideIcon: "tag",
                    onClick: () => categorias.render()
                }
                // ...un tab por entidad, cada uno con lucideIcon DISTINTO
            ]
        });

        if (window.lucide) lucide.createIcons();
    }

    renderActiveTab() {
        productos.render();   // SOLO el tab activo en el arranque; el resto se pinta en su onClick (lazy)
    }
}
```

> **Render perezoso (OBLIGATORIO):** `renderActiveTab()` pinta solo el tab activo. NUNCA llamar a `productos.render(); categorias.render(); ...` todos de golpe — cada uno dispara un `createTable`/`useFetch` y se hacen N peticiones innecesarias.

> **`titleAdmin`:** NO usar `$("#titleAdmin").html("<h2>...</h2><p>...</p>")` (HTML con contenido real viola FRONT-JS). Usar un componente de título (`infoTitle`/`infoCard`) o, si no existe, crearlo según `new-component.md`.

### Clase CRUD por entidad (esqueleto homogéneo)

```js
// -- Productos --

class Productos extends Templates {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Productos";
    }

    render() {
        this.filterBar();
        this.ls();
    }

    filterBar() {
        $("#container-productos").html(`
            <div id="filterbar-productos" class="mb-2"></div>
            <div id="tabla-productos" class="w-full"></div>
        `);

        this.createfilterBar({
            parent: "filterbar-productos",
            data: [
                {
                    opc: "select",
                    id: "estadoProductos",
                    class: "col-12 col-md-2",
                    data: statusFilter(),
                    onchange: "productos.ls()"
                },
                {
                    opc: "button",
                    id: "btnNuevoProducto",
                    class: "col-12 col-md-3",
                    text: "Nuevo Producto",
                    onClick: () => this.add()
                }
            ]
        });
    }

    ls() {
        this.createTable({
            parent: "tabla-productos",
            idFilterBar: "filterbar-productos",
            data: {
                opc: "lsProducts",
                active: $("#estadoProductos").val()
            },
            coffeesoft: true,
            conf: { datatable: true, pag: 10 },
            attr: {
                id: "tbProductos",
                theme: "dark",      // THEME token → "corporativo" por defecto
                striped: true,
                center: [1, 5, 6, 7]
            }
        });
    }

    add() {
        this.createModalForm({
            id: "formProductoAdd",
            data: { opc: "addProduct" },
            theme: "dark",          // THEME token → "light" por defecto
            bootbox: { title: "Nuevo Producto", size: "default" },
            json: this.json(),
            success: (response) => afterSave(response, () => this.ls())
        });
    }

    async edit(id) {
        const request = await useFetch({ url: this._link, data: { opc: "getProduct", id: id } });

        this.createModalForm({
            id: "formProductoEdit",
            data: { opc: "editProduct", id: id },
            theme: "dark",
            bootbox: { title: "Editar Producto", size: "large" },
            autofill: request.data,
            json: this.json(),
            success: (response) => afterSave(response, () => this.ls())
        });
    }

    status(id, active) {
        this.swalQuestion({
            opts: {
                title: "Cambiar estado del producto",
                text: "Esta accion ocultara o reactivara el producto.",
                icon: "warning"
            },
            data: { opc: "statusProduct", active: active, id: id },
            methods: { send: () => this.ls() }
        });
    }

    json() {
        return [
            {
                opc: "input",
                id: "name",
                lbl: "Nombre del producto",
                class: "col-12 mb-3"
            }
            // ...campos en formato vertical expandido (una prop por línea)
        ];
    }
}
```

### Helpers globales (anti-duplicación)

```js
// -- Helpers --

function statusFilter() {
    return [
        { id: "1", valor: "Activos" },
        { id: "0", valor: "Inactivos" },
        { id: "",  valor: "Todos" }
    ];
}

function afterSave(response, reload) {
    if (response.status == 200) {
        alert({ icon: "success", text: response.message });
        if (typeof reload === "function") reload();
    } else {
        alert({ icon: "info", title: "Oops!...", text: response.message, btn1: true, btn1Text: "Ok" });
    }
}
```

> Una sola fuente de verdad: NO definir `statusOptions()` ni `afterSave()` propio por clase. Todas las entidades reutilizan `statusFilter()` y `afterSave(response, () => this.ls())`.

### Reglas JS

- Submódulos extienden `Templates` directo (la `App` solo orquesta → no hay nada que heredar).
- Variable global por entidad en minúsculas == `PROJECT_NAME`.
- `SAMPLE_CATALOGOS` declarado en `sample_admin-[modulo].js` (dev UI-first sin backend).
- Imágenes de producto: prefijo fijo `https://huubie.com.mx/` (patrón de la casa).
- Los `#container-[entidad]` los genera `tabLayout` a partir del `id` del tab.

---

## Capa 2 — CTRL (controlador)

`class ctrl extends mdl`. Recibe `opc` por POST, resuelve compañía/sucursal/usuario desde sesión, y expone `ls/get/add/edit/status` por entidad. Las celdas con formato (badges, swatches, miniaturas, botones) se construyen con **funciones complemento** al pie del archivo.

```php
<?php
session_start();
if (empty($_POST['opc'])) exit(0);

require_once '../mdl/mdl-admin-[modulo].php';

class ctrl extends mdl {

    public $companiesId;
    public $subsidiariesId;
    public $userId;

    public function __construct() {
        parent::__construct();
        $this->companiesId    = (int) ($_SESSION['COM'] ?? $_POST['companies_id']    ?? 4);
        $this->subsidiariesId = (int) ($_SESSION['SUB'] ?? $_POST['subsidiaries_id'] ?? 0);
        $this->userId         = (int) ($_SESSION['USR'] ?? $_POST['user_id']         ?? 1);
    }

    function init() {
        return [
            'status'     => 200,
            'categorias' => $this->lsCategoriesSelect(),
            'areas'      => $this->lsAreasSelect([$this->companiesId])
            // ...catálogos que necesitan los <select> del front
        ];
    }

    // Productos

    function lsProducts() {
        $rows = $this->listProducts([
            'companies_id' => $this->companiesId,
            'active'       => $_POST['active'],
            'category_id'  => $_POST['category_id']
        ]);

        $__row = [];
        foreach ($rows as $item) {
            $__row[] = [
                'id'        => $item['id'],
                'SKU'       => skuPill($item['sku']),
                'Producto'  => ['class' => 'justify-start px-2 py-2', 'html' => productImageCell($item['image'], $item['name'], $item['id'])],
                'Categoria' => $item['category_name'] ?: '-',
                'Costo'     => ['html' => evaluar((float) $item['cost_unit']), 'class' => 'text-end'],
                'a'         => actionButtons('productos', $item['id'], $item['active'])
            ];
        }
        return ['row' => $__row, 'thead' => ''];
    }

    function getProduct() {
        $data = $this->getProductById([(int) $_POST['id']]);
        return [
            'status'  => $data ? 200 : 404,
            'message' => $data ? 'Producto encontrado' : 'Producto no encontrado',
            'data'    => $data
        ];
    }

    function addProduct() {
        if ($this->existsProductByName([$_POST['name'], $this->companiesId])) {
            return ['status' => 409, 'message' => 'Ya existe un producto con ese nombre'];
        }
        $create = $this->createProductMaster([
            $_POST['name'], (float) $_POST['price'], (int) $_POST['category_id'],
            $_POST['description'], $this->companiesId
        ]);
        return [
            'status'  => $create ? 200 : 500,
            'message' => $create ? 'Producto agregado correctamente' : 'No se pudo agregar el producto'
        ];
    }

    function editProduct() {
        $values = $this->util->sql([
            'name'        => $_POST['name'],
            'price'       => (float) $_POST['price'],
            'category_id' => (int) $_POST['category_id'],
            'id'          => (int) $_POST['id']
        ], 1);
        $edit = $this->updateProductMaster($values);
        return [
            'status'  => $edit !== false ? 200 : 500,
            'message' => $edit !== false ? 'Producto actualizado correctamente' : 'No se pudo editar el producto'
        ];
    }

    function statusProduct() {
        $update = $this->updateProductStatus([(int) $_POST['active'], (int) $_POST['id']]);
        return [
            'status'  => $update ? 200 : 500,
            'message' => $update ? 'Estado actualizado correctamente' : 'No se pudo cambiar el estado'
        ];
    }

    // ...repetir bloque ls/get/add/edit/status por entidad
}

// Complements.  (render de celdas — devuelven HTML/estructura para createTable)

function actionButtons($entidad, $id, $active) {
    $isActive = ((int) $active === 1) || ($active === '1');
    $next     = $isActive ? 0 : 1;
    return [
        ['class' => 'inline-flex items-center px-2 py-1 text-sm rounded bg-blue-500/15 text-blue-400 border border-blue-500/30 me-1',
         'html'  => '<i class="icon-pencil"></i>', 'onclick' => "{$entidad}.edit({$id})"],
        ['class' => 'inline-flex items-center px-2 py-1 text-sm rounded bg-gray-500/15 border border-gray-500/30',
         'html'  => '<i class="' . ($isActive ? 'icon-toggle-on' : 'icon-toggle-off') . '"></i>',
         'onclick' => "{$entidad}.status({$id}, {$next})"]
    ];
}

function skuPill($code) {
    if (empty($code)) return '<span class="font-mono text-[10px] text-gray-500 border border-dashed border-gray-600 rounded px-2 py-0.5 uppercase">SIN SKU</span>';
    return '<span class="font-mono text-xs text-gray-300 bg-[#1a2332] border border-gray-700 rounded px-2 py-0.5">' . $code . '</span>';
}

function boolBadge($value, $trueLabel, $falseLabel) {
    if ((int) $value === 1) return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-[rgba(63,193,137,0.15)] text-[#3FC189]">' . $trueLabel . '</span>';
    return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-[rgba(234,2,52,0.15)] text-[#EA0234]">' . $falseLabel . '</span>';
}

$obj = new ctrl();
echo json_encode($obj->{$_POST['opc']}());
```

### Reglas CTRL

- `class ctrl extends mdl`, instancia al pie: `$obj = new ctrl(); echo json_encode($obj->{$_POST['opc']}());`.
- `init()` devuelve los catálogos (`*Select()`) que alimentan los `<select>` del front.
- Cada `ls[Entidad]()` arma `$__row[]` y devuelve `['row' => $__row, 'thead' => '']`.
- `get/add/edit/status` devuelven siempre `['status' => , 'message' => (, 'data' => )]`.
- Validaciones de negocio antes de insertar (duplicados, SKU en uso) → devolver `409` con mensaje claro.
- **Las funciones complemento** (`actionButtons`, `skuPill`, `colorSwatch`, `boolBadge`, `productImageCell`…) generan el HTML de celda. Sus clases de color son **tokens de theme** (dark en el ejemplo → adaptar a light).
- Edición parcial vía `util->sql([...], 1)` para construir `values/where/data`.

---

## Capa 3 — MDL (modelo)

`class mdl extends CRUD`. Define prefijos de BD en el constructor y agrupa por entidad: `*Select()` (catálogos), `list[Entidad]()` (con WHERE dinámico), `get[Entidad]ById()`, `create[Entidad]()`, `update[Entidad]()`, `update[Entidad]Status()`.

```php
<?php
require_once '../../conf/_CRUD.php';
require_once '../../conf/_Utileria.php';

class mdl extends CRUD {

    public $util;
    public $bd;
    public $bdAlpha;

    public function __construct() {
        $this->util    = new Utileria;
        $this->bd      = 'fayxzvov_reginas.';
        $this->bdAlpha = 'fayxzvov_alpha.';
    }

    // Selects (catalogos para formularios y filtros)

    function lsCategoriesSelect() {
        $query = "SELECT id, classification AS valor
                  FROM {$this->bd}order_category
                  WHERE active = '1'
                  ORDER BY classification ASC";
        $r = $this->_Read($query);
        return is_array($r) ? $r : [];
    }

    // Productos

    function listProducts($array) {
        $where = 'p.companies_id = ?';
        $data  = [$array['companies_id']];

        if ($array['active'] !== '') { $where .= ' AND p.active = ?'; $data[] = $array['active']; }
        if (!empty($array['category_id'])) { $where .= ' AND p.category_id = ?'; $data[] = $array['category_id']; }

        $query = "SELECT p.id, p.name, p.price, p.image, p.active, p.category_id,
                         oc.classification AS category_name, pa.sku, pa.cost_unit
                  FROM {$this->bd}order_products p
                  LEFT JOIN {$this->bd}order_category    oc ON oc.id = p.category_id
                  LEFT JOIN {$this->bd}product_attribute pa ON pa.product_id = p.id AND pa.active = 1
                  WHERE {$where}
                  ORDER BY p.id DESC";
        $r = $this->_Read($query, $data);
        return is_array($r) ? $r : [];
    }

    function getProductById($array) {
        $query = "SELECT id, name, price, description, image, category_id, active
                  FROM {$this->bd}order_products WHERE id = ? LIMIT 1";
        $r = $this->_Read($query, $array);
        return is_array($r) && !empty($r) ? $r[0] : null;
    }

    function existsProductByName($array) {
        $query = "SELECT id FROM {$this->bd}order_products
                  WHERE LOWER(name) = LOWER(?) AND companies_id = ? AND active = 1";
        $r = $this->_Read($query, $array);
        return is_array($r) && count($r) > 0;
    }

    function createProductMaster($array) {
        $query = "INSERT INTO {$this->bd}order_products
                    (name, price, category_id, description, active, date_creation, companies_id)
                  VALUES (?,?,?,?,1,NOW(),?)";
        return $this->_CUD($query, $array);
    }

    function updateProductMaster($array) {
        return $this->_Update([
            'table'  => "{$this->bd}order_products",
            'values' => $array['values'],
            'where'  => $array['where'],
            'data'   => $array['data']
        ]);
    }

    function updateProductStatus($array) {
        $query = "UPDATE {$this->bd}order_products SET active = ? WHERE id = ?";
        return $this->_CUD($query, $array);
    }

    // ...repetir grupo list/getById/create/update/updateStatus por entidad
}
```

### Reglas MDL

- `class mdl extends CRUD`; prefijos de esquema (`$this->bd`, `$this->bdAlpha`…) en el constructor.
- Lecturas con `$this->_Read($query, $data)`; siempre `return is_array($r) ? $r : []` (o `$r[0] : null` para singular).
- Escrituras: `_CUD()` para INSERT/UPDATE directos; `_Update([...])` para updates parciales construidos con `util->sql`.
- WHERE dinámico: filtro de `active` solo si viene (`!== ''`).
- Conteos relacionados (p.ej. `product_count`) vía subquery correlacionada.
- `*Select()` devuelven `id` + alias `valor` (lo que esperan los `<select>` del front).
- Convención de columnas/montos según [[feedback_db_money_double]] y [[feedback_db_column_order]].

---

## Checklist de implementación

- [ ] `index.php` resuelto con PIVOTE-INDEX (NO en este pivote)
- [ ] Theme correcto: `light` por defecto, `dark` solo Huubie
- [ ] JS: `App` orquesta (createLayout sin filterBar) + N clases CRUD `extends Templates`
- [ ] JS: variable global por entidad == `PROJECT_NAME` en minúsculas
- [ ] JS: `renderActiveTab()` pinta SOLO el tab activo (lazy)
- [ ] JS: helpers globales `statusFilter()` + `afterSave(response, reload)` (sin duplicar por clase)
- [ ] JS: `SAMPLE_CATALOGOS` en `sample_*.js`
- [ ] CTRL: `class ctrl extends mdl` + `init()` con catálogos + ls/get/add/edit/status por entidad
- [ ] CTRL: celdas con funciones complemento al pie (tokens de color = theme)
- [ ] CTRL: respuestas `['status','message'(,'data')]`; validaciones devuelven 409
- [ ] MDL: `class mdl extends CRUD` + `*Select()` + list/getById/create/update/updateStatus por entidad
- [ ] Nomenclatura encadenada `ls→list`, `get→getById`, `add→create`, `edit→update`, `status→updateStatus`

---

## Variante — Tabs de 2 niveles (agrupados)

### Cuándo usar esta variante

Cuando el módulo tiene **demasiados tabs planos** (6+ entidades) y se quiere agruparlos en categorías visuales. Ejemplo: 12 entidades CRUD agrupadas en Facturación / Promociones / Accesos.

Esta variante **no reemplaza** el patrón base — lo extiende agregando un nivel de navegación entre `App` y las clases CRUD.

### Arquitectura de 2 niveles

```
App (nivel 1 — tabs de grupos)
  └── FacturacionGroup extends Templates   (nivel 2 — tabs de entidades del grupo)
        └── onClick de cada sub-tab → entidad.render()
  └── PromocionesGroup extends Templates
  └── AccesosGroup extends Templates
  └── [N clases CRUD individuales, igual que el patrón base]
```

**Reglas de arquitectura:**

- `App` solo orquesta el nivel 1: un `tabLayout` con un tab por grupo.
- Cada grupo es una **clase concreta** que `extends Templates` directamente. **NO** crear una clase base abstracta `TabGroup` o `GroupBase` — violaría la regla "no fuerces `extends` para heredar la nada" (FRONT-JS.md).
- Las clases CRUD individuales no cambian — siguen extendiendo `Templates` y tienen su propio `PROJECT_NAME`.
- El grupo **no tiene estado propio** más allá de su `PROJECT_NAME`. Solo implementa `render()`, que contiene el `tabLayout` de nivel 2 y el lazy render de la primera entidad del grupo.

### Patrón de IDs — clave para que funcione el doble nivel

`tabLayout` genera automáticamente `#container-<tab.id>` por cada tab. Esto crea la cadena de IDs:

```
App.renderTabs() genera:
  #container-grp-facturacion   ← nivel 1, aloja el tabLayout del grupo
  #container-grp-promociones
  #container-grp-accesos

FacturacionGroup.render() genera (dentro de #container-grp-facturacion):
  #container-planes            ← nivel 2, aloja el render() de Planes
  #container-cupones
  #container-descuentos

Planes.render() usa parent: "container-planes"
```

**Regla crítica:** Los IDs de sub-tab del nivel 2 deben coincidir exactamente con los `parent` que esperan los métodos `render()` / `filterBar()` / `ls()` de cada clase CRUD. Definirlos de una vez al diseñar el módulo y no cambiarlos.

### Capa JS — código canónico

```js
let api = '/modulo/ctrl/ctrl-admin-modulo.php';
let app, facturacion, promociones, accesos;
let planes, cupones, descuentos, recompensas, usuarios, roles;

$(async () => {
    const data = await useFetch({ url: api, data: { opc: "init" } });

    app          = new App(api, "root");
    facturacion  = new FacturacionGroup(api, "root");
    promociones  = new PromocionesGroup(api, "root");
    accesos      = new AccesosGroup(api, "root");

    planes       = new Planes(api, "root");
    cupones      = new Cupones(api, "root");
    descuentos   = new Descuentos(api, "root");
    recompensas  = new Recompensas(api, "root");
    usuarios     = new Usuarios(api, "root");
    roles        = new Roles(api, "root");

    app.render();
});

// -- App --

class App extends Templates {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "AdminTenant";
    }

    render() {
        this.layout();
        this.renderTabs();
        this.renderActiveTab();
    }

    layout() {
        this.createLayout({
            parent: "root",
            design: false,
            data: {
                id: this.PROJECT_NAME,
                class: "flex flex-col w-full p-3 flex-1",
                container: [
                    {
                        type: "div",
                        id: `container${this.PROJECT_NAME}`,
                        class: "w-full flex-1 bg-white border border-gray-200 rounded-lg p-3 overflow-auto",  // light token
                        children: [
                            { id: `tabs${this.PROJECT_NAME}`, class: "w-full" }
                        ]
                    }
                ]
            }
        });
    }

    renderTabs() {
        this.tabLayout({
            parent: `tabs${this.PROJECT_NAME}`,
            id: `tabs${this.PROJECT_NAME}`,
            theme: "light",         // light token
            type: "short",
            showBorder: false,
            json: [
                {
                    id: "grp-facturacion",
                    tab: "Facturación",
                    lucideIcon: "receipt",
                    active: true,
                    onClick: () => facturacion.render()
                },
                {
                    id: "grp-promociones",
                    tab: "Promociones",
                    lucideIcon: "tag",
                    onClick: () => promociones.render()
                },
                {
                    id: "grp-accesos",
                    tab: "Accesos",
                    lucideIcon: "shield-check",
                    onClick: () => accesos.render()
                }
            ]
        });

        if (window.lucide) lucide.createIcons();
    }

    renderActiveTab() {
        facturacion.render();   // SOLO el primer grupo activo (lazy render)
    }
}

// -- FacturacionGroup --

class FacturacionGroup extends Templates {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Facturacion";
    }

    render() {
        // Guard lazy: si el nivel-2 ya existe, no volver a crear el tabLayout
        if ($('#tabsFacturacion').length) {
            planes.render();
            return;
        }

        this.tabLayout({
            parent: "container-grp-facturacion",
            id: "tabsFacturacion",
            theme: "light",
            type: "short",
            showBorder: true,
            json: [
                {
                    id: "planes",
                    tab: "Planes",
                    lucideIcon: "layout-dashboard",
                    active: true,
                    onClick: () => planes.render()
                },
                {
                    id: "cupones",
                    tab: "Cupones",
                    lucideIcon: "ticket",
                    onClick: () => cupones.render()
                },
                {
                    id: "descuentos",
                    tab: "Descuentos",
                    lucideIcon: "percent",
                    onClick: () => descuentos.render()
                }
            ]
        });

        if (window.lucide) lucide.createIcons();

        planes.render();    // primera entidad activa del grupo (lazy)
    }
}

// -- Planes (clase CRUD — idéntica al patrón base) --

class Planes extends Templates {

    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "Planes";
    }

    render() {
        this.filterBar();
        this.ls();
    }

    filterBar() {
        // parent = "container-planes"  (generado por tabLayout del grupo)
        $("#container-planes").html(`
            <div id="filterbarPlanes" class="mb-2"></div>
            <div id="tablaPlanes" class="w-full"></div>
        `);

        this.createfilterBar({
            parent: "filterbarPlanes",
            data: [
                {
                    opc: "select",
                    id: "estadoPlanes",
                    class: "col-12 col-md-2",
                    data: statusFilter(),
                    onchange: "planes.ls()"
                },
                {
                    opc: "button",
                    id: "btnNuevoPlan",
                    class: "col-12 col-md-3",
                    text: "Nuevo Plan",
                    onClick: () => this.add()
                }
            ]
        });
    }

    ls() {
        this.createTable({
            parent: "tablaPlanes",
            idFilterBar: "filterbarPlanes",
            data: {
                opc: "lsPlanes",
                active: $("#estadoPlanes").val()
            },
            coffeesoft: true,
            conf: { datatable: true, pag: 10 },
            attr: {
                id: "tbPlanes",
                theme: "corporativo",   // light token
                striped: true,
                center: [1, 4, 5]
            }
        });
    }

    add() {
        this.createModalForm({
            id: "formPlanAdd",
            data: { opc: "addPlan" },
            theme: "light",             // light token
            bootbox: { title: "Nuevo Plan", size: "default" },
            json: this.json(),
            success: (response) => afterSave(response, () => this.ls())
        });
    }

    async edit(id) {
        const request = await useFetch({ url: this._link, data: { opc: "getPlan", id } });
        this.createModalForm({
            id: "formPlanEdit",
            data: { opc: "editPlan", id },
            theme: "light",
            bootbox: { title: "Editar Plan", size: "default" },
            autofill: request.data,
            json: this.json(),
            success: (response) => afterSave(response, () => this.ls())
        });
    }

    status(id, active) {
        this.swalQuestion({
            opts: { title: "Cambiar estado del plan", icon: "warning" },
            data: { opc: "statusPlan", active, id },
            methods: { send: () => this.ls() }
        });
    }

    json() {
        return [
            {
                opc: "input",
                id: "name",
                lbl: "Nombre del plan",
                class: "col-12 mb-3"
            }
        ];
    }
}
```

### Reglas de la variante 2 niveles

1. **Una clase concreta por grupo, NO clase base abstracta.** `FacturacionGroup extends Templates`, `PromocionesGroup extends Templates`, `AccesosGroup extends Templates` — sin `GroupBase` ni `TabGroup` intermedio.
2. **Guard lazy en `render()` de cada grupo:** `if ($('#tabsFacturacion').length) { primeraEntidad.render(); return; }` — evita recrear el `tabLayout` de nivel 2 cada vez que el usuario regresa al grupo.
3. **IDs de nivel-1 llevan prefijo `grp-`** para distinguirlos de los IDs de entidad: `id: "grp-facturacion"` → genera `#container-grp-facturacion`.
4. **IDs de nivel-2 coinciden con los `parent` de las clases CRUD** (sin prefijo `grp-`): `id: "planes"` → genera `#container-planes` → `Planes.filterBar()` usa `parent: "container-planes"`.
5. **Render perezoso en dos capas:** App pinta solo el primer grupo activo; el grupo pinta solo su primera entidad activa. El resto se carga al navegar.
6. **Las clases CRUD son idénticas al patrón base** — no saben que viven dentro de un grupo. Su `parent` siempre es `container-[id-de-su-tab-de-nivel-2]`.
7. **Helpers globales se mantienen en `// -- Helpers --`** al pie del archivo, igual que en el patrón base.
8. **Theme aplicado uniformemente en los dos niveles:** si el módulo es light, tanto el `tabLayout` de nivel 1 (App) como los de nivel 2 (grupos) usan `theme: "light"`.

### Checklist adicional para la variante 2 niveles

- [ ] Una clase concreta por grupo (`extends Templates`), sin clase base abstracta
- [ ] Guard lazy en cada `render()` de grupo (`if ($('#tabsX').length)`)
- [ ] IDs de tabs nivel-1 con prefijo `grp-` (evita colisión con IDs de entidad)
- [ ] IDs de tabs nivel-2 coinciden con los `parent` esperados por las clases CRUD
- [ ] Render perezoso en ambos niveles: App → solo primer grupo; grupo → solo primera entidad
- [ ] Theme idéntico en nivel-1 y nivel-2 (no mezclar `"dark"` en App y `"light"` en grupo)
- [ ] Variables globales instanciadas para grupos Y para todas las clases CRUD individuales

---

**Versión:** 1.1
**Última actualización:** 2026-06-13
**Origen:** `app/inventarios/admin-productos.*` (Huubie) + `inventory/tenant/` (módulo light 2 niveles)
**Autor:** CoffeeIA ☕
**Estado:** Aprobado para producción