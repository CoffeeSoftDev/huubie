---
inclusion: always
---
# 📐 PIVOTES — Catálogo de referencia de CoffeeIA

Los **Pivotes** son el equivalente para CoffeeIA de los **grimorios** de CoffeeMagic: implementaciones de referencia, ya probadas en producción, que CoffeeIA consulta **bajo demanda** antes de generar un módulo nuevo. Cada pivote documenta un patrón completo (una o varias capas: `ctrl` / `mdl` / `js` / `index`) con su código canónico, sus reglas y su checklist.

> **Cómo se usan:** este índice se carga siempre (es pequeño). Los pivotes individuales tienen `inclusion: manual` — CoffeeIA los abre y los lee cuando el módulo a generar coincide con el patrón. NO copiar a ciegas: adaptar nombres de entidad, esquema de BD y **theme** (ver regla de cada pivote).

## Regla global de THEME (aplica a todos los pivotes con capa JS/UI)

- **Por defecto: `light`.** Si el usuario NO indica el theme, se genera en **light**.
- **`dark` solo para Huubie** (o cuando el usuario lo pida explícitamente). Huubie usa su paleta dark institucional (`bg-[#1F2A37]`, `theme: "dark"`, sistema `.cs-*`).
- Los pivotes documentan el código en su theme original pero marcan los **tokens dependientes de theme** para que CoffeeIA los intercambie según destino.

## Pivotes disponibles

| Pivote | Capas | Patrón | Estado |
|---|---|---|---|
| [PIVOTE-INDEX](../PIVOTE-INDEX.md) | `index` | Punto de entrada `index.php` (sesión, layouts, framework) | ✅ Producción |
| [CRUD Catálogo Multi-Entidad](pivote-crud-catalogo-multientidad.md) | `ctrl` + `mdl` + `js` | App-orquestador con tabs + N entidades CRUD homogéneas (sin index). Incluye variante **tabs de 2 niveles / agrupados** (v1.1). | ✅ Producción |

### Cuándo usar la variante de 2 niveles

Dentro del mismo pivote CRUD Multi-Entidad, leer la sección **"Variante — Tabs de 2 niveles (agrupados)"** cuando:
- El módulo tiene 6+ entidades CRUD y se quieren agrupar en categorías visuales.
- El usuario pide "tabs agrupados", "grupos de tabs" o "tabs de dos niveles".
- Hay una jerarquía natural: p.ej. Facturación / Promociones / Accesos, cada uno con sus propias sub-entidades.

La variante usa el mismo ctrl y mdl del patrón base — solo cambia la capa JS.

## Convención para agregar un pivote nuevo

1. Crear `pivotes/pivote-[nombre].md` con frontmatter `inclusion: manual`.
2. Encabezar con: **Qué es**, **Cuándo usar**, **Regla de theme**, **Capas incluidas** (declarar explícitamente cuáles NO incluye).
3. Incluir código canónico por capa + reglas + checklist.
4. Registrar la fila en la tabla "Pivotes disponibles" de este índice.
5. El pivote es **inmutable** salvo discusión; documentar versión y fecha al pie.
