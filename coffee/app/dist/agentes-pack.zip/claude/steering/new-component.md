# Prompt para construir un componente jQuery con Tailwind

## 0. Flujo de creación de componentes

### Antes de crear un componente
1. Analizar `src/js/coffeSoft.js` para verificar si ya existe un componente que cubra la necesidad.
2. Si existe → usarlo directamente e informar cuál es y cómo se usa.
3. Si NO existe → crear siguiendo las reglas de este archivo.

### Modos de aprobación

**Modo normal** (por defecto):
- Pausar antes de crear cada componente nuevo.
- Preguntar: "Necesito crear el componente X que no existe. ¿Lo creo?"
- Mostrar el componente para aprobación antes de registrarlo.

**Modo libre** (cuando el usuario dice "crea lo que necesites", "créalos y al final los reviso", "modo libre"):
- Crear todos los componentes necesarios sin pausar.
- Al finalizar, presentar un resumen de todo lo creado:
  - Nombre del componente
  - Para qué sirve
  - Dónde quedó registrado
- El usuario aprueba o ajusta al final.

### Al aprobar un componente
1. Agregar el método a `src/js/coffeSoft.js` (dentro de la clase Templates).
2. Crear preview visual en `coffee/docs/components/[nombre].html`.

## 1. Contexto claro:

Quiero que generes un **componente jQuery personalizado** cuyo propósito sea crear interfaces reutilizables con lógica desacoplada. El componente debe estar basado en un patrón configurable por `options`, tener un contenedor root definido por un `id`, y usar exclusivamente **TailwindCSS** para estilos.

## 2. Reglas o condiciones:

- Los componentes se crean con el formato markdown.
- Si el componente se toma de un codigo como react o next ya creado preguntar al usuario que desea hacer.

  - Crear componente normal
  - Guiar paso a paso la creación

- El componente debe declararse como una función con nombre camelCase: `nombreComponente(options)`.

- Debe iniciarse con una constante `defaults` que contenga todas las opciones configurables por defecto.
- Las opciones deben poder sobrescribirse con `Object.assign(defaults, options)`.
- Debe incluir lógica modular en una sección separada del renderizado HTML.
- Toda la interfaz debe estar construida con **jQuery** y **TailwindCSS** exclusivamente.
  -Todos los elementos visibles (etiquetas, IDs, estados) provengan de un objeto JSON (json: []).
  -Todo lo que se envia al backend debe ser data.
  El componente debe inyectarse en el DOM bajo el `id` del contenedor padre definido por `opts.parent`.

1. **Consulta de Datos (GET)**:

   - Si un componente requiere `json`, **debe hacer una consulta al Backend** obligatoriamente.
   - La llamada debe realizarse mediante `this.useFetch()` siguiendo el estándar del método `get`.

2. **Eventos por Tipo de Acción**:

   - **Eliminar (Delete)**: `onDelete` → acción de eliminar en el backend.
   - **Agregar (Add)**: `onAdd` → acción de agregar en el backend.
   - **Modificar (Update)**: `onUpdate` → acción de modificar en el backend.
   - **Guardar (Save)**: `onSave` → para formularios o componentes que guardan datos (cubre agregar y modificar en un solo evento). Se usa según la funcionalidad del componente.

3. **Estructura de Soporte (MVC)**:
   - Cualquier evento definido (`onAdd`, `onDelete`, etc.) **debe crear automáticamente**:
     - Un **Controlador (ctrl)**.
     - Un **Modelo (mdl)**.
   - Estos deben adherirse a las **reglas de pivotes y templates estándar del proyecto**.

**`onShow[Entidad]()`** — Método auxiliar de la clase que consulta datos al backend antes de construir un componente. No va dentro del `defaults` del componente, vive en la clase. Su función es obtener la data que el componente necesita para renderizarse (ej: infoCards necesitan los KPIs del request para construir la UI).

```js
// Método de la clase — consulta datos y alimenta al componente
async onShowDashboard() {
    let request = await useFetch({
        url: this._link,
        data: {
            opc: "getDashboard",
            id: 1
        },
    });

    this.infoCard({
        parent: 'root',
        json: request.data
    });
}
```

## 3. Inputs esperados

- Atributos vía `options`:  
  `parent`, `id`, `class`, `json`, `data`.
  - `json: []` → datos visibles (etiquetas, opciones, estados para renderizar la UI).
  - `data: {}` → datos que se envían al backend.
  - Se pueden usar ambos simultáneamente (ej: un formulario que muestra opciones de `json` y envía valores con `data`).

- Eventos personalizados esperados (opcionales):  
  `onAdd`, `onUpdate`, `onDelete`, `onSave`, `onSubmit`.

- ¿Requiere datos del backend?:  
  Sí / No (si sí, usar `this.useFetch()` con `opc: 'get'`).

---

## 4. Formato de salida esperado (ejemplo base):

- Se debe agregar onShow[Entidad] para mandarlo a llamar.
- No se usan funciones son metodos
- No uses `$` para crear una variable
- Al mostrar el uso basico debes mostrarlo como 'this.[nameComponent]()'
- Si lleva dentro de la configuacion de opts el atributo json, preguntar al usuario si desea crear el <ctrl> y el <mdl>
- **CRÍTICO:** NO agregar documentación JSDoc ni comentarios de documentación en los componentes
- **CRÍTICO:** NO crear archivos de documentación separados (*.md, *.txt) para los componentes
- El código debe ser limpio y autoexplicativo sin comentarios innecesarios
- **CRÍTICO:** NO usar prefijo `_` (guion bajo) en métodos ni propiedades de instancia. Aunque sea convención común de JS para "uso interno", el framework CoffeeSoft NO la aplica. Mantener consistencia con `Templates`, `Cards`, `Navbar`, `App`, etc.

  ✅ **CORRECTO:**
  ```js
  class ModuleCard {
      constructor(parent, options) {
          this.uid      = 'mc_' + Math.random().toString(36).slice(2, 7);
          this.parent   = parent;
          this.options  = options || {};
          this.settings = null;
      }
      init() {
          this.settings = this.buildSettings();
          this.render();
      }
      buildSettings() { ... }
      buildHeader(s) { ... }
  }
  ```

  ❌ **INCORRECTO:**
  ```js
  class ModuleCard {
      constructor(parent, options) {
          this._uid      = '...';
          this._parent   = parent;
          this._options  = options || {};
          this._settings = null;
      }
      _buildSettings() { ... }
      _buildHeader(s) { ... }
  }
  ```

  > **Aplica a:** métodos públicos, helpers internos, propiedades de instancia (`this.foo`) y cualquier identificador dentro de clases JS del framework. Si necesitas señalar "no es API documentada", usa un comentario corto inline (`// helper`) o agrupa los públicos bajo un separador `// -- Public API --`, pero el nombre va sin `_`.

```js
this.NombreComponente(options) {
  // 📌 Configuración por defecto
  const defaults = {
    parent: "root",
    id: "nombreComponente",
    title: "Título",
    class: "bg-[#1F2A37] p-4 rounded-xl",
    data: {},
    json: [],
    onDelete: () => {},
    onAdd: () => {},
    onUpdate: () => {},
    onSave: () => {}
  };

  const opts = Object.assign({}, defaults, options);

  // 🔵 Lógica de la aplicación


  // 🧱 Construcción de la interfaz
  const container = $("<div>", {
    id: opts.id,
    class: `${opts.class}`
  });

  const header = $("<h2>", {
    class: "text-white text-lg font-bold mb-2",
    text: opts.title
  });

  // 🔵 Aplicar eventos



  container.append(header);


  //  Inserción al DOM
  $(`#${opts.parent}`).html(container);
}
```

## 5. Datos SAMPLE para desarrollo UI-first

Todo componente nuevo que reciba `json` o `data` **debe declarar una constante `SAMPLE_[ENTIDAD]`** al inicio del modulo donde se usa. Permite visualizar el componente sin backend listo (UI-first development).

### Reglas

- **Naming:** `SAMPLE_[ENTIDAD]` en SCREAMING_SNAKE_CASE — ej. `SAMPLE_KPIS`, `SAMPLE_SALE`, `SAMPLE_FILTERS`, `SAMPLE_VENTAS_TABLE`.
- **Ubicacion:** top del archivo del modulo, antes de `$(async () => {...})`.
- **Shape:** replica EXACTA del JSON que devolveria el backend (incluye keys auxiliares como `a` para acciones, `id` oculto, badges en HTML cuando aplique).
- **Volumen:** 3-7 registros representativos. Incluye casos limite: cancelados, sin cliente, con descuento, etc.
- **Conexion:** el metodo `onShow[Entidad](data)` recibe el SAMPLE como argumento desde `render()`.

### Ejemplo en el formato esperado

```js
// ── Top del modulo ──
const SAMPLE_KPIS = [
    { id:'kpiCount', label:'Ventas',      value: 12,         tone:'default' },
    { id:'kpiTotal', label:'Monto total', value:'$4,820.00', tone:'success' }
];

// ── Dentro de la clase App ──
render() {
    this.layout();
    this.onShowKpis(SAMPLE_KPIS);                 // ← SAMPLE durante dev
    // this.onShowKpis(await this.getKpis());     // ← cuando exista backend
}

onShowKpis(rows) {
    this.kpisRow({ parent: 'kpisRow', json: rows });
}
```

### Variante para componentes con AJAX (`createTable`, `createCoffeeTable3`)

Cuando el componente del framework hace AJAX (ej. `createTable` con `idFilterBar`), el SAMPLE vive en el **backend** como funcion `ls[Entidad]()` con comentario marcador:

```php
// ───────────────────────────────────────────────────────────────────
//  lsVentas — Lista de ventas (SAMPLE: datos hardcodeados de muestra)
// ───────────────────────────────────────────────────────────────────
function lsVentas() {
    $samples = [ /* ... */ ];
    return ['row' => $__row];
}
```

### Beneficios

- Desacopla UI de backend — avanzar sin esperar API.
- Auto-documenta el shape esperado por el componente.
- Swap simple: `this.onShowX(SAMPLE_X)` → `this.onShowX(await fetch(...))`.
- Fixture util cuando el backend devuelve vacio durante dev.
