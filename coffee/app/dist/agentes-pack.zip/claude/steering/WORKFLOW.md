---
inclusion: always
---
# WORKFLOW — Flujo de Trabajo Obligatorio de CoffeeIA

> **Este archivo es LECTURA OBLIGATORIA antes de iniciar cualquier proyecto o módulo nuevo en el ERP-GV. Saltarse este flujo es la causa #1 de código que no funciona en runtime o que tiene que reescribirse.**

## Principio rector

CoffeeIA trabaja por **fases con checkpoint**. No avanza a la siguiente fase sin aprobación explícita del usuario. La velocidad no justifica saltar pasos — cada fase saltada es deuda técnica inmediata.

---

## Fase 0 — Comprensión (bloqueante, antes de tocar código)

Objetivo: entender QUÉ se va a construir y con QUÉ piezas.

### 0.1 Leer steering files obligatorios

Dependiendo del tipo de archivo a crear, leer SIEMPRE:

| Si vas a crear... | Lee obligatoriamente |
|---|---|
| `ctrl/*.php` | `CTRL.md` |
| `mdl/*.php` | `MDL.md` |
| `js/*.js` del módulo | `FRONT-JS.md` |
| `index.php`, `layout/head.php`, `layout/core-libraries.php` | `PIVOTE-INDEX.md` |
| Componentes de UI reusables | `new-component.md` |
| Cualquier archivo | `CoffeeIA.md` (general) |

**Regla de oro:** si hay contradicción entre steering files, `PIVOTE-INDEX.md` y `MDL.md` / `CTRL.md` / `FRONT-JS.md` tienen prioridad sobre `CoffeeIA.md`. Reportar la contradicción al usuario.

### 0.2 Inspeccionar `coffeeSoft.js`

```bash
grep -n "^\s\+[a-zA-Z]\+\s*(\s*options\s*)\s*{" src/js/coffeeSoft.js
```

Listar los componentes existentes. Esto se hace para:
- No reinventar componentes que ya existen
- Identificar componentes similares como referencia de estilo

### 0.3 Validar BD con MCP (si aplica)

Si el proyecto usa BD:

```sql
SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = '[bd]';

SELECT COLUMN_NAME, DATA_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = '[bd]'
  AND TABLE_NAME = '[tabla]'
ORDER BY ORDINAL_POSITION;
```

**PROHIBIDO** hardcodear nombres de columna desde documentación descriptiva (`README.md`, diseño, etc.). Solo se confía en lo que devuelve MCP.

### 0.4 Inventariar candidatos a componente

Para cada pieza de UI identificada, preguntar:

- ¿Es reusable en otro módulo?
- ¿Tiene estado interno?
- ¿Tiene eventos propios (`onAdd`, `onDelete`, `onUpdate`)?
- ¿Es una composición de varias sub-piezas?

Si responde **sí a 2 o más**, es candidato a componente en `coffeeSoft.js`, no método de módulo.

### 0.5 Analizar templates/mockups existentes (si existen)

Si el módulo ya tiene archivos en `templates/`, `images-templates/`, o mockups aprobados:

1. **Leer CADA template HTML** completo — no resumir, no saltear
2. **Identificar los componentes CoffeeSoft equivalentes** para cada sección del template:
   - Tablas → `createTable` / `createCoffeTable3`
   - Formularios → `createForm` / `createModalForm`
   - KPIs/stats → `infoCard` con `style: "file"`
   - Filtros → `createfilterBar`
   - Tabs → `tabLayout`
   - Layouts → `primaryLayout` / `createLayout`
3. **Mapear cada sección del template a un método del JS** — crear tabla de correspondencia
4. **Los templates son la FUENTE DE VERDAD del diseño** — el JS debe replicar ese diseño usando componentes CoffeeSoft, NO inventar un diseño diferente

**PROHIBIDO:**
- Usar `$('#container').html('<div>...')` para recrear lo que ya está diseñado en un template
- Ignorar los templates y generar UI genérica
- Cambiar el diseño aprobado sin autorización del usuario

**Resultado esperado:** Tabla de mapeo `Template → Método JS → Componentes CoffeeSoft` que se presenta en Fase 1.

---

## Fase 1 — Diseño con aprobación (bloqueante)

Objetivo: alinear con el usuario ANTES de escribir código.

### 1.1 Presentar árbol de archivos

```
modulo-nuevo/
├── index.php                 # pivote de PIVOTE-INDEX.md
├── layout/
│   ├── head.php              # pivote
│   └── core-libraries.php    # pivote
├── mdl/
│   ├── mdl-x.php             # modelo (list/create/update/delete)
│   └── mdl-y.php
├── ctrl/
│   ├── ctrl-x.php            # controlador (init/ls/add/edit/delete)
│   └── ctrl-y.php
└── js/
    └── modulo.js             # glue code que usa componentes
```

### 1.2 Clasificar cada archivo

Para cada archivo, decir explícitamente:

- **(P)** Pivote — se copia tal cual, no se modifica
- **(M)** Método de clase del módulo — CRUD simple, no reusable
- **(C)** Componente nuevo en `coffeeSoft.js` — UI compleja/reusable

### 1.3 Lista de componentes a crear

Por cada componente nuevo:

- Nombre (`recetaCard`, `subrecetaCard`, etc.)
- Propósito en 1 línea
- Eventos que dispara
- Aprobación individual del usuario

### 1.4 Orden de implementación

Siempre: `estructura → modelos → controladores → componentes → módulo JS`

### 1.5 🛑 CHECKPOINT obligatorio — Formato de presentación

Antes de avanzar a Fase 2, presentar al usuario **EN ESTE FORMATO EXACTO:**

```
## Diseño propuesto — [Nombre del módulo]

### Árbol de archivos:
[árbol completo con todos los archivos a crear]

### Clasificación P/M/C:
| Archivo | Tipo | Notas |
|---|---|---|
| index.php | (P) Pivote | Copia de PIVOTE-INDEX.md |
| mdl/mdl-x.php | (M) Método | CRUD de [entidad] |
| js/modulo.js | (M) Método | Glue code del módulo |

### Componentes de CoffeeSoft a usar:
- tabLayout → navegación principal entre secciones
- createTable (theme: corporativo) → listados
- createfilterBar → filtros por sucursal/estado/fecha
- createModalForm → formularios de alta/edición
- infoCard (style: file) → KPIs del dashboard
- swalQuestion → confirmaciones de eliminación/baja

### Componentes NUEVOS a crear (si aplica):
- [nombre] → [propósito en 1 línea] → [eventos: onAdd, onDelete, etc.]

### Templates existentes mapeados (si aplica):
| Template HTML | Método JS | Componentes CoffeeSoft |
|---|---|---|
| rrhh-resumen.html | renderResumen() | infoCard + createTable |
| rrhh-personal.html | lsPersonal() | createfilterBar + createTable |
```

Terminar con:

> **"¿Apruebas este diseño? ¿Procedo con Fase 2 (construcción)?"**

**No continuar sin respuesta explícita del usuario.** Si el usuario dice "sí" o "adelante" → proceder. Si modifica algo → actualizar diseño y volver a preguntar.

---

## Fase 2 — Construcción con checkpoints

### 2.1 Estructura base

Crear `index.php`, `layout/head.php`, `layout/core-libraries.php` siguiendo **exactamente** `PIVOTE-INDEX.md`. No improvisar rutas ni orden de carga.

**Validación:** abrir en navegador y verificar que carga sin errores de consola.

🛑 **CHECKPOINT:** "Estructura base lista, ¿continúo con modelos?"

### 2.2 Modelos

Por cada modelo:

1. Ejecutar query MCP `SHOW COLUMNS FROM [tabla]` (via `information_schema.COLUMNS`) y guardar resultado
2. Escribir el modelo usando los nombres exactos de columna
3. Ejecutar query de prueba para cada método `list*` / `get*`
4. Confirmar que devuelve datos reales

🛑 **CHECKPOINT:** "Modelos listos y validados contra BD, ¿continúo con controladores?"

### 2.3 Controladores

Por cada controlador:

1. Leer el modelo correspondiente y listar sus métodos
2. Escribir el controlador llamando solo a métodos que existen
3. Verificar nomenclatura CTRL vs MDL (no pueden coincidir)

🛑 **CHECKPOINT:** "Controladores listos, ¿continúo con componentes?"

### 2.4 Componentes nuevos (uno por uno)

Por cada componente en la lista aprobada en Fase 1:

1. Escribir el componente siguiendo `new-component.md`
2. Agregar el método a `coffeeSoft.js` dentro de la clase `Templates`
3. Crear preview visual en `coffee/docs/components/[nombre].html`
4. **Mostrar al usuario** el código y el preview
5. 🛑 **CHECKPOINT:** "¿Apruebas este componente? ¿Paso al siguiente?"

No lotes — cada componente se aprueba individualmente (modo normal de `new-component.md`).

### 2.5 Módulo JS (glue code)

El archivo `js/[modulo].js` debe ser **solo código pegamento**:

- Instanciar las clases del módulo
- Llamar componentes con `this.[componente]({ json, data, onAdd, onDelete, ... })`
- NO contener lógica de UI propia (ya está en los componentes)
- NO armar HTML manualmente (ya lo hacen los componentes)

🛑 **CHECKPOINT:** "Módulo JS listo, ¿corremos validación final?"

---

## Fase 3 — Validación final (bloqueante)

### 3.1 TESTER agent

Correr el agente `TESTER` contra las 47 reglas de convenciones CoffeeSoft. Reportar PASS/FAIL.

### 3.2 MCP queries en vivo

Ejecutar las queries clave del módulo contra BD real y confirmar que devuelven datos.

### 3.3 Navegador real

Abrir el módulo en el navegador. Verificar:

- ❌ No hay errores de consola (`is not a function`, `undefined`, etc.)
- ✅ Se renderiza el layout completo
- ✅ Los filtros cargan datos
- ✅ Las tablas muestran registros
- ✅ Los modales abren correctamente

### 3.4 Resumen final

Presentar:

- Archivos creados (count + paths)
- Componentes agregados a `coffeeSoft.js`
- Correcciones aplicadas durante validación
- Errores pendientes (si los hay)

---

## ❌ Anti-patrones prohibidos

| Anti-patrón | Por qué está mal |
|---|---|
| Delegar a 3+ subagentes en paralelo sin diseñar primero | Pierdes coherencia; cada agente toma decisiones distintas |
| Improvisar desde `README.md` o `ui.md` | Son docs descriptivos, no autoritativos; solo los steering mandan |
| Hardcodear columnas desde documentación | La BD real manda — siempre MCP primero |
| Saltar componentes y meter UI en el módulo JS | Se vuelve imposible reusar; cada módulo reinventa |
| Ir a "modo libre" sin que el usuario lo pida | Rompe el checkpoint de `new-component.md` |
| "Después lo validamos" | El después nunca llega; se valida EN el paso, no después |
| Copiar de un módulo legacy sin contrastar con el pivote | Los legacy pueden estar desactualizados |
| Lanzar 3+ agentes Explore/General en paralelo para "leer todo" | Consume contexto masivo, pierde foco; el agente principal termina con info superficial de todo en vez de comprensión profunda de cada archivo |
| Tratar un ERS/spec como orden de "ejecuta todo" | El ERS define el QUÉ, no el CÓMO; el CÓMO siempre viene de los steering files y WORKFLOW.md |
| Generar HTML crudo con `$('#x').html('<div>...')` en métodos JS | Rompe la arquitectura de componentes; se vuelve imposible mantener y reusar |

## 🚨 Señales de que estás saltando el flujo

Si escuchas estas frases en tu propia cabeza, PARA:

- "Déjame empezar rápido con los modelos, después veo la estructura..."
- "Basándome en el README voy a asumir que..."
- "Voy a delegar todo en paralelo para ganar tiempo..."
- "Después lo validamos contra la BD..."
- "Esto es simple, no necesita componente..."
- "El usuario ya sabe lo que quiere, no necesito preguntar..."
- "El ERS ya tiene todo especificado, puedo ir directo a construir..."
- "Voy a lanzar 3 agentes en paralelo para leer todo más rápido..."
- "Pongo un `$('#container').html(...)` rápido y después lo mejoro..."
- "Los templates HTML son solo referencia, puedo hacer algo diferente..."

Cada una de estas es un anti-patrón. Vuelve a Fase 0.

## Excepciones legítimas (cuándo SÍ puedes saltar fases)

Solo en estos casos puedes saltar directamente a la fase relevante:

- **Fix de 1-3 líneas** en un archivo existente → ir directo al fix, sin diseño
- **Renombrar una variable/método** → Edit directo
- **Typo en un string** → Edit directo
- **Rollback de un cambio reciente** → git revert
- **Instrucción explícita del usuario** "modo libre" o "créalo todo sin pausas"

Para TODO lo demás, seguir el flujo completo.

---

**Versión:** 1.0
**Última actualización:** 2026-04-06
**Autor:** CoffeeIA ☕ + Somx
**Estado:** Obligatorio
