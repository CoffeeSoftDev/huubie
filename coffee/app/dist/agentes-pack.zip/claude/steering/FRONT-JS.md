## Objetivo General
Desarrollar un archivo JavaScript estructurado y modular, siguiendo estrictamente las convenciones del sistema y buenas prácticas de ingeniería.

### Regla de Componentes

Antes de crear cualquier componente o layout, consulta `DOC-COFFEESOFT.md` para verificar si ya existe un componente que resuelva la necesidad. Si existe, úsalo según la documentación. Si no existe, consulta `new-component.md` para crearlo correctamente como plugin jQuery.

**NO** inventes componentes ni reimplementes funcionalidad que ya existe en el framework.

### 1.Estructura Base del FRONT-JS
Debe respetarse el formato de CoffeeSoft
- Nombre del archivo bajo la convención:
  `[nombre].js`

- Construir una clase `App` que herede de `Templates`.

#### Inicialización estándar (sin datos previos)
 ```JS
    let api = '';
    let ventas;
    $(function () {
        ventas = new Ventas(api,'root');
        ventas.init();
    });
  ```

#### Inicialización async (cuando se necesitan datos antes del render)
 ```JS
    let api = '';
    let ventas;
    $(async () => {
        const data = await useFetch({ url: api, data: { opc: "init" } });
        // Asignar datos globales necesarios
        ventas = new Ventas(api, 'root');
        ventas.init();
    });
  ```

> **Regla:** Usar `$(async () => {})` cuando el módulo necesita cargar datos globales (catálogos, UDNs, configuraciones) antes de instanciar las clases. Nunca usar IIFE `(async () => {})()` — siempre usar el wrapper de jQuery.

#### Estructura de clases
 ```JS
    class App extends Templates{
        constructor(link, div_modulo) {
            super(link, div_modulo);
            this.PROJECT_NAME = "App";
        }
        // init(), render(), layout(), filterBar()
    }

    class Ventas extends App{
        constructor(link, div_modulo) {
            super(link, div_modulo);
            this.PROJECT_NAME = "Ventas";
        }
        // ls(), add(), edit(), json(), cancel()
    }
  ```

- La variable global debe coincidir con el `PROJECT_NAME` del submódulo en minúsculas (ej: `PROJECT_NAME = "Ventas"` → variable `ventas`).
- Esto permite que el `fn` del filterBar funcione correctamente: `fn: "ventas.ls()"`.
- El constructor debe recibir dos parámetros: el enlace del controlador (`link`) y el identificador de contenedor principal (`div_modulo`).
- **App** contiene los métodos de estructura: `init()`, `render()`, `layout()`, `filterBar()`.
- **Submódulo** hereda de App, define su propio `PROJECT_NAME` y contiene los métodos de negocio: `ls()`, `add()`, `edit()`, `json()`, `cancel()`.
- Solo genera un submódulo si se necesita.
- Si se genera un submódulo, debe crear una class aparte, no juntar todo en la misma.

> **Excepción — herencia de `App`:** El submódulo hereda de `App` **solo cuando hay estructura/estado compartido que reutilizar** (layout común, helpers, props de instancia). Si `App` es un mero orquestador (solo `layout()` + `renderTabs()` + `renderActiveTab()`) y no aporta nada que el submódulo reutilice, el submódulo **puede extender `Templates` directamente**. No fuerces `extends App` para heredar la nada. Esto es típico del patrón "catálogo admin multi-entidad" (un `App` con `tabLayout` + N clases CRUD independientes de esqueleto idéntico).

- Los componentes `filterBar`, `container` y `tb` deben incluir `PROJECT_NAME` en el parent:
````   parent: `[filterBar|container|tb]${this.PROJECT_NAME}`, ```
- Los demás componentes pueden usar un parent libre sin `PROJECT_NAME`.


## Rules
- Se pueden usar pivotes para referencia o templates
- No agreges comentarios a las funciones
- Los nombres de las funciones deben:
  - Estar en inglés.
  - Usar notación `camelCase`.
  - Agrega comentario para separar modulos.
- **NO usar prefijo `_`** (guion bajo) en métodos ni propiedades de instancia de clases JS. Aunque sea convención común de JS para "uso interno", el framework CoffeeSoft no la aplica. Todos los identificadores van con nombre normal (`this.uid`, `this.parent`, `buildCards()`, `renderHeader()`), igual que en `Templates`, `Cards`, `Navbar`, `App`.

  ✅ **CORRECTO:**
  ```js
  class Ventas extends Templates {
      constructor(link, divModule) {
          super(link, divModule);
          this.PROJECT_NAME = 'Ventas';
      }
      render(data) {
          const cards = this.buildCards(data);
          new ModuleCard('#mainContainer', { cards }).init();
      }
      buildCards(data) { ... }
  }
  ```

  ❌ **INCORRECTO:**
  ```js
  class Ventas extends Templates {
      render(data) {
          const cards = this._buildCards(data);
          new ModuleCard('#mainContainer', { cards }).init();
      }
      _buildCards(data) { ... }
  }
  ```

  > **Aplica a:** métodos públicos, helpers internos y propiedades de instancia. Para señalar "no es API documentada", usar comentario inline corto o agrupar bajo separador `// -- Public API --`, pero el nombre va sin `_`.

### PROHIBIDO: HTML crudo en métodos JS

- **NUNCA** usar `$('#x').html('<div class="grid">...')` con HTML extenso (más de 1 línea) para construir UI
- **NUNCA** usar template literals con bloques HTML dentro de métodos del módulo
- **SIEMPRE** usar componentes CoffeeSoft para construir la interfaz:
  - Tablas → `createTable` / `createCoffeTable3`
  - Formularios → `createForm` / `createModalForm`
  - KPIs/stats → `infoCard` con `style: "file"`
  - Filtros → `createfilterBar`
  - Layouts → `primaryLayout` / `createLayout` / `splitLayout`
- Si el diseño requiere UI que NO existe como componente → crear componente nuevo siguiendo `new-component.md`

#### Excepción: wrappers simples (máximo 2 elementos)

Se permite `.html()` con HTML inline cuando se cumplen **TODAS** estas condiciones:

1. El propósito del método es **únicamente** crear contenedores vacíos / placeholders para que otros componentes CoffeeSoft los pueblen.
2. El HTML contiene **máximo 2 elementos hermanos** de primer nivel.
3. Cada elemento es un wrapper sin contenido real (sin texto largo, sin atributos de estilo extensos, sin lógica anidada).
4. El método cabe en **una sola línea legible** o en un literal corto.

✅ **Permitido:**
```javascript
renderHeader() {
    $(`#header${this.PROJECT_NAME}`).html('<div id="title"></div><div id="actions"></div>');
}

renderLayout() {
    $('#root').html('<div id="filters"></div><div id="table"></div>');
}
```

❌ **No permitido (excede el límite):**
```javascript
// Más de 2 elementos
$('#x').html('<div id="a"></div><div id="b"></div><div id="c"></div>');

// Contenido real, no es wrapper
$('#x').html('<div class="grid grid-cols-3 gap-4"><h2>Título</h2><p>Texto</p></div>');

// Lógica anidada / atributos extensos
$('#x').html(`<div class="flex p-4 bg-white rounded-lg shadow"><span>${data.name}</span></div>`);
```

> **Regla:** Si necesitas más de 2 wrappers, o cualquier tipo de contenido/estilo dentro, usa `primaryLayout` / `createLayout` o crea un componente nuevo. Esta excepción existe SOLO para evitar verbosidad en wrappers triviales de organización (tipo `renderHeader`, `renderLayout` de placeholders).

### Formato de object literals (JSON)

**CRÍTICO:** Todos los object literals (json de formularios, configuraciones de componentes, arrays de objetos) DEBEN escribirse en **formato expandido vertical**: una propiedad por línea. NUNCA contraídos en una sola línea.

✅ **CORRECTO:**
```javascript
{
    opc: 'input',
    lbl: 'Nombre completo',
    id: 'name',
    tipo: 'texto',
    class: 'col-12 col-sm-6'
},
```

❌ **INCORRECTO:**
```javascript
{ opc: 'input', lbl: 'Nombre completo', id: 'name', tipo: 'texto', class: 'col-12 col-sm-6' },
```

**Aplica a:** `json: [...]` de `createForm`, `coffeeForm`, `createTable`, `createCoffeTable3`, `tabLayout`, `createfilterBar`, `infoCard`, y cualquier otro componente CoffeeSoft que reciba arrays de configuración.

> **Regla:** Esta convención es OBLIGATORIA. Aplica tanto a código nuevo como a refactors/edits sobre archivos existentes. NO mezclar estilos dentro del mismo archivo.

### Nomenclatura de Métodos Frontend (JS)

**CRÍTICO:** Los métodos que muestran tablas DEBEN seguir la nomenclatura `ls[Entidad]()`:

✅ **CORRECTO:**
- `ls()` - Para tabla principal del módulo
- `lsPedidos()` - Para tabla de pedidos
- `lsVentas()` - Para tabla de ventas
- `lsClientes()` - Para tabla de clientes
- `lsReportes()` - Para tabla de reportes

❌ **INCORRECTO:**
- `renderPedidos()` - NO usar "render" para tablas
- `showVentas()` - NO usar "show" para tablas
- `displayClientes()` - NO usar "display" para tablas

**Excepción:** Métodos complejos como dashboards pueden usar `render[Nombre]()` si no son tablas simples.

**IMPORTANTE:** Asegúrate de que las funciones del backend sigan la nomenclatura correcta:
- **Frontend (JS):** `ls[Entidad]()` para métodos que muestran tablas
- **Controlador (ctrl):** `ls[Entidad]()`, `add[Entidad]()`, `edit[Entidad]()`, `get[Entidad]()`
- **Modelo (mdl):** `list[Entidad]()`, `create[Entidad]()`, `update[Entidad]()`, `get[Entidad]ById()`


## Análisis previo de layout (OBLIGATORIO)

Antes de escribir `layout()`, analizar la estructura del módulo para elegir el método correcto:

### Paso 1 — ¿El módulo principal necesita su propio filterBar?

| Pregunta | SÍ | NO |
|---|---|---|
| ¿El módulo principal muestra directamente una tabla con filtros? | `primaryLayout` (filterBar + container) | Ir a Paso 2 |
| ¿Hay un solo nivel sin tabs ni sub-módulos? | `primaryLayout` | Ir a Paso 2 |

### Paso 2 — ¿Tiene tabs con sub-módulos independientes?

| Pregunta | SÍ | NO |
|---|---|---|
| ¿Cada tab maneja su propio filterBar? | `createLayout` (solo container, sin filterBar) | `primaryLayout` |
| ¿Los sub-módulos crean su propio layout dentro del tab? | `createLayout` | `primaryLayout` |

### Paso 3 — ¿Necesita layout no estándar?

| Pregunta | SÍ |
|---|---|
| ¿Sidebar + contenido, multi-panel, split-view? | `createLayout` con estructura personalizada |

### Resumen de decisión

| Estructura del módulo | Método | filterBar en layout |
|---|---|---|
| Módulo simple: 1 tabla + filtros | `primaryLayout` | SÍ |
| Módulo con tabs: sub-módulos con sus propios filtros | `createLayout` | NO — cada sub-módulo lo crea |
| Layout personalizado (sidebar, multi-panel) | `createLayout` | Según necesidad |

> **Regla:** NUNCA crear un filterBar vacío. Si el módulo principal no usa filterBar directamente, no lo incluyas en el layout.

---

## La clase debe implementar los siguientes métodos:

- init()
  - Ejecuta el método render().
- render()
  - Ejecuta los métodos layout() y filterBar() (si aplica según el análisis de layout).
  - En módulos con tabs: ejecuta layout(), renderTabs() y renderActiveTab(). NO llama a filterBar().
- layout()
  - Se elige según el análisis previo de layout.

#### `primaryLayout` — Módulo estándar con filterBar propio

**OBLIGATORIO:** Esta es la configuración estándar al crear un `primaryLayout`. Usar exactamente este formato (multiline + clases sin border) salvo que el módulo requiera explícitamente otro estilo.

```JS
layout() {
    this.primaryLayout({
        parent: 'root',
        id: this.PROJECT_NAME,
        class: 'p-2',
        card: {
            filterBar: {
                class: 'w-full mb-3',
                id: `filterBar${this.PROJECT_NAME}`
            },
            container: {
                class: 'w-full my-3 h-full',
                id: `container${this.PROJECT_NAME}`
            }
        }
    });
}
```

**Reglas:**
- `parent`: el contenedor donde se monta (`'root'` para módulo simple, o `container-[tab]` cuando el primaryLayout vive dentro de un tab).
- `id`: siempre `this.PROJECT_NAME`.
- `class: 'p-2'` para el wrapper exterior.
- `filterBar.class: 'w-full mb-3'` — sin border ni padding extra.
- `container.class: 'w-full my-3 h-full'`.
- IDs siempre derivados de `PROJECT_NAME`: `` `filterBar${this.PROJECT_NAME}` `` y `` `container${this.PROJECT_NAME}` ``.
- Formato vertical (una propiedad por línea), nunca contraído.

#### `createLayout` — Módulo con tabs (sin filterBar principal)
```javascript
layout() {
    this.createLayout({
        parent: 'root',
        design: false,
        data: {
            id: this.PROJECT_NAME,
            class: 'w-full min-h-screen p-2',
            container: [
                { type: 'div', id: `container${this.PROJECT_NAME}`, class: 'w-full my-3 h-full' }
            ]
        }
    });
}
```

#### `createLayout` — Layout personalizado (sidebar, multi-panel)
```javascript
layout() {
    this.createLayout({
        parent: 'root',
        design: false,
        data: {
            id: this.PROJECT_NAME,
            class: "flex gap-5 px-2 py-2",
            container: [
                { type: 'div', id: 'sidebar', class: 'w-64 flex-shrink-0' },
                { type: 'div', id: `main${this.PROJECT_NAME}`, class: 'flex-1 min-w-0',
                    children: [
                        { id: 'tabContent', class: 'bg-white border rounded-lg p-5' }
                    ]
                }
            ]
        }
    });
}
```

- filterBar()
  - Implementa el filtro principal utilizando createfilterBar() y configura el componente dataPicker() para capturar rangos de fechas.
```JS
     filterBar() {
        this.createfilterBar({
            parent: `filterBar${this.PROJECT_NAME}`,
            data: [
                {
                    opc: "input-calendar",
                    class: "col-sm-4",
                    id: "calendar"+this.PROJECT_NAME,
                    lbl: "Consultar fecha: ",
                },
                {
                    opc: "btn",
                    class: "col-sm-2",
                    color_btn: "primary",
                    id: "btn",
                    text: "Buscar",
                    fn: `${this.PROJECT_NAME.toLowerCase()}.ls()`,
                },
            ],
        });

        dataPicker({
            parent: "calendar"+this.PROJECT_NAME,
            onSelect: () => this.ls(),
        });
    }

```

### Modos de dataPicker

El componente `dataPicker()` tiene 3 modos de uso. Elegir según el contexto del módulo:

| Modo | Cuándo usarlo | `getDataRangePicker()` retorna |
|---|---|---|
| Básico (sin type) | Módulos simples, una tabla, rango default | `{ fi, ff }` |
| `all` | Reportes, consolidados, presets de rango | `{ fi, ff }` ambas fechas |
| `simple` | Captura diaria, operación de un solo día | `{ fi }` solo fecha inicio |

> **Regla de decisión:** ¿El usuario necesita comparar o acumular datos entre fechas?
> - Sí → `all`
> - No, trabaja día por día → `simple`
> - Módulo básico sin complejidad → Básico

#### Básico — Sin type
```javascript
dataPicker({
    parent: "calendar" + this.PROJECT_NAME,
    onSelect: () => this.ls(),
});
```

#### Modo `all` — Rango de fechas con presets
```javascript
setDatePickerAll() {
    dataPicker({
        parent: `calendar${this.PROJECT_NAME}`,
        type: 'all',
        rangepicker: {
            startDate: moment().subtract(7, 'days'),
            endDate: moment(),
            showDropdowns: true,
            autoApply: true,
            locale: { format: "DD-MM-YYYY" },
            ranges: {
                Ayer: [moment().subtract(1, "days"), moment().subtract(1, "days")],
                Antier: [moment().subtract(2, "days"), moment().subtract(2, "days")],
                "Últimos 7 días": [moment().subtract(8, "days"), moment().subtract(1, "days")],
                "Mes actual": [moment().startOf("month"), moment().subtract(1, "days")],
                "Mes anterior": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")],
                "Año actual": [moment().startOf("year"), moment().subtract(1, "days")],
                "Año anterior": [moment().subtract(1, "year").startOf("year"), moment().subtract(1, "year").endOf("year")],
            },
        },
        onSelect: () => {
            this.ls();
        }
    });
}
```

#### Modo `simple` — Fecha única
```javascript
setDatePickerSimple() {
    dataPicker({
        parent: `calendar${this.PROJECT_NAME}`,
        type: 'simple',
        rangeDefault: {
            startDate: moment().subtract(7, 'days'),
            singleDatePicker: true,
            showDropdowns: true,
            autoApply: true,
            maxDate: moment(),
            locale: { format: "DD-MM-YYYY" }
        },
        onSelect: () => {
            this.ls();
        }
    });
}
```

### tabLayout Avanzado

Cuando un módulo maneja múltiples secciones con navegación por tabs, se usa `tabLayout` con propiedades avanzadas.

#### Propiedades extendidas del componente

| Propiedad | Tipo | Descripción |
|---|---|---|
| `showBorder` | `boolean` | Oculta/muestra borde inferior del tab |
| `lucideIcon` | `string` | Icono de Lucide (reemplaza `icon` de icon-font) |
| `iconColor` | `string` | Clase CSS para color del icono (ej: `"text-blue-600"`) |
| `active` | `boolean/expression` | Puede ser dinámico: `activeModule === 'ventas'` |

#### Lucide Icons — Selección obligatoria para tabs

Cada tab DEBE incluir `lucideIcon` con un icono semántico que represente el contenido. Elegir el más apropiado según el contexto:

| Contexto del tab | Iconos recomendados |
|---|---|
| Listados / registros | `list`, `table`, `clipboard-list` |
| Ventas / dinero | `dollar-sign`, `credit-card`, `wallet`, `receipt` |
| Reportes / concentrados | `bar-chart-2`, `pie-chart`, `trending-up`, `file-bar-chart` |
| Configuración / admin | `settings`, `sliders-horizontal`, `wrench` |
| Usuarios / personas | `user`, `users`, `user-check`, `contact` |
| Calendario / tiempo | `clock`, `calendar`, `calendar-days`, `timer` |
| Archivos / documentos | `folder-open`, `file-text`, `files`, `archive` |
| Búsqueda / filtros | `search`, `filter`, `scan` |
| Inventario / almacén | `package`, `boxes`, `warehouse`, `truck` |
| Compras / proveedores | `shopping-cart`, `store`, `building-2` |
| Calidad / evaluación | `check-circle`, `shield-check`, `award`, `star` |
| Dashboard / resumen | `layout-dashboard`, `gauge`, `activity` |
| Comunicación | `mail`, `message-square`, `bell` |

> **Regla:** NO repetir el mismo icono en tabs del mismo módulo. Cada tab debe tener un icono distinto que lo diferencie visualmente. Elegir el icono que mejor represente la función específica del tab, no uno genérico.

#### Estructura — `renderTabs()` como método separado

El método `renderTabs()` se llama desde `render()`, no inline en `layout()`:

```javascript
render() {
    this.layout();
    this.renderTabs();
    this.renderActiveTab();
}
```

#### Ejemplo — Tab con Lucide, persistencia y routing por rol

```javascript
renderTabs() {
    const activeModule = localStorage.getItem('module') || 'archivos';
    const isContador = getCookies().ROLE === 'contador';

    this.tabLayout({
        parent: `container${this.PROJECT_NAME}`,
        id: `tabs${this.PROJECT_NAME}`,
        theme: "light",
        type: "short",
        showBorder: false,
        json: [
            {
                id: "archivos",
                tab: "Archivos",
                lucideIcon: 'folder-open',
                iconColor: "text-blue-600",
                active: activeModule === 'archivos',
                onClick: () => {
                    localStorage.setItem('module', 'archivos');
                    files.render();
                }
            },
            {
                id: "ventas",
                tab: "Ventas",
                lucideIcon: 'dollar-sign',
                iconColor: "text-blue-600",
                active: activeModule === 'ventas',
                onClick: () => {
                    localStorage.setItem('module', 'ventas');
                    if (isContador) {
                        sales.render();
                    } else {
                        detailsSale.render();
                    }
                }
            }
        ]
    });
}
```

#### Dispatcher — `renderActiveTab()`

Complementa a `renderTabs()`. Ejecuta el módulo correcto según el tab activo (desde `localStorage`). Permite routing por rol.

> **CRÍTICO — render perezoso (lazy):** `renderActiveTab()` pinta **únicamente el tab activo** en el arranque. **NUNCA** llamar a todos los submódulos de golpe (`productos.render(); categorias.render(); almacenes.render(); ...`), porque cada `render()` dispara su propio `createTable`/`useFetch` y se hacen N peticiones innecesarias al cargar. El resto de los tabs se renderiza **bajo demanda** desde el `onClick` de su tab (o vía el dispatcher), conforme el usuario navega. Patrón: en el arranque solo el primer tab (`active: true`); los demás se crean al hacer click.

```javascript
renderActiveTab(module) {
    const activeModule = module || localStorage.getItem('module') || 'archivos';

    const tabActions = {
        'archivos': () => files.render(),
        'ventas': () => isContador ? sales.render() : detailsSale.render(),
        'compras': () => isContador ? consolidated.render() : purchases.render(),
    };

    if (tabActions[activeModule]) {
        tabActions[activeModule]();
    }
}
```

#### Cuándo usar tab avanzado vs básico

| Caso | Usar |
|---|---|
| 2-3 tabs simples, mismo módulo | `tabLayout` básico inline en `layout()` |
| Múltiples tabs, módulos externos, roles | `renderTabs()` + `renderActiveTab()` separados |

### 🚨 Regla de theme en módulos con tabLayout (BLOQUEANTE)

**ANTES de escribir `layout()` o `renderTabs()`** en cualquier módulo con `tabLayout`, determinar el theme:

| Situación | Theme correcto |
|---|---|
| Módulo nuevo sin indicación del usuario | `light` (default) |
| Módulo dentro del producto Huubie dark | `dark` solo si el usuario lo confirma |
| La ruta contiene `huubie/` pero el módulo es administrativo/tenant | **`light`** — el path NO determina el theme |
| El usuario dice "igual que el módulo anterior" | Verificar el theme de ese módulo antes de copiar clases |

**Tokens a intercambiar dark → light (ver tabla completa en el pivote correspondiente):**

| Token | `light` | `dark` (Huubie) |
|---|---|---|
| `tabLayout` → `theme` | `"light"` | `"dark"` |
| `createTable` → `attr.theme` | `"corporativo"` | `"dark"` |
| `createModalForm` → `theme` | `"light"` | `"dark"` |
| Contenedor principal | `bg-white border` o sin fondo | `bg-[#1F2A37]` |
| Botón primary | `color_btn: "primary"` (azul framework) | `#003360` hardcodeado |
| Badges de estado | paleta `bg-green-100 text-green-800` | `bg-[#014737] text-[#3FC189]` |

> **CRÍTICO:** `h-screen` en el contenedor rompe el auto-crecimiento en módulos light. Solo usar `h-screen` junto con `overflow-auto` en contenedores dark Huubie que lo requieran explícitamente.

---

### Patrón "Catálogo admin multi-entidad"

Cuando un módulo administra varias entidades CRUD homogéneas bajo una misma pantalla (p.ej. admin de inventario: productos, categorías, almacenes, áreas, unidades, proveedores, motivos, estados…), usar este patrón:

- Una clase `App extends Templates` que **solo orquesta**: `layout()` (con `createLayout`, sin filterBar principal), `renderTabs()` (`tabLayout` con un tab por entidad, cada uno con `lucideIcon` distinto) y `renderActiveTab()`.
- Una clase CRUD por entidad. Como `App` solo orquesta, estas clases **extienden `Templates` directamente** (ver excepción de herencia arriba).
- Cada clase CRUD comparte el mismo esqueleto: `render() → filterBar() + ls()`, más `add()`, `edit(id)`, `status(id, active)`, `json()`.
- Variable global por entidad en minúsculas == `PROJECT_NAME` (`productos`, `categorias`, …) para que los `onchange`/`fn` del filterBar resuelvan.
- IDs de parents derivados de `PROJECT_NAME`: `` `filterBar${PROJECT_NAME}` ``, `` `container${PROJECT_NAME}` ``, `` `tb${PROJECT_NAME}` ``.
- **Render perezoso**: en el arranque solo el tab activo (`active: true`); el resto se renderiza bajo demanda desde el `onClick` de su tab.

#### Helpers globales compartidos (anti-duplicación)

En un módulo con N entidades CRUD, **NO** repetir el bloque éxito/error ni la lista de estados en cada clase. Declarar helpers globales al final del archivo (sección `// -- Helpers --`) y reutilizarlos en todas:

```js
// -- Helpers --

function statusFilter() {
    return [
        { id: "1", valor: "Activos" },
        { id: "0", valor: "Inactivos" },
        { id: "",  valor: "Todos" }
    ];
}

function afterSave(response, reload) {
    if (response.status == 200) {
        alert({ icon: "success", text: response.message });
        if (typeof reload === "function") reload();
    } else {
        alert({ icon: "info", title: "Oops!...", text: response.message, btn1: true, btn1Text: "Ok" });
    }
}
```

Uso en cada clase CRUD:
```js
success: (response) => afterSave(response, () => this.ls())
```

> **Regla:** `afterSave(response, reload)` y `statusFilter()` son el estándar para catálogos multi-entidad. NO definir variantes por clase (`statusOptions()`, `afterSave()` propio) que dupliquen la misma lógica. Mantener una sola fuente de verdad en `// -- Helpers --`.

### renderInfoCards() — Tarjetas KPI con `infoCard()`

Para mostrar indicadores/resumen (KPIs) se usa `this.infoCard()` con `style: "file"`. **NO** armar HTML manual con divs y grid-cols.

```javascript
renderInfoCards(counts) {
    this.infoCard({
        parent: `cards${this.PROJECT_NAME}`,
        theme: "light",
        style: "file",
        class: "pt-2 pb-3",
        json: [
            {
                id: "kpiTotal",
                title: "Total",
                bgColor: "bg-yellow-100",
                borderColor: "border-yellow-300",
                data: { value: formatPrice(counts.total || 0), color: "text-yellow-700" }
            },
            {
                id: "kpiCredito",
                title: "Credito",
                bgColor: "bg-red-100",
                borderColor: "border-red-300",
                data: { value: formatPrice(counts.credito || 0), color: "text-red-700" }
            }
        ]
    });
}
```

**Colores condicionales** — para variaciones positivas/negativas:
```javascript
{
    id: "kpiDiff",
    title: "Diferencia",
    bgColor: isPositive ? "bg-emerald-100" : "bg-red-100",
    borderColor: isPositive ? "border-emerald-300" : "border-red-300",
    data: { value: `${diff} kg`, color: isPositive ? "text-green-700" : "text-red-700" }
}
```

> **Nomenclatura:** El metodo se llama `renderInfoCards()` (excepcion a la regla `ls[]`) porque no es una tabla, es un componente de dashboard/KPI.

- ls() / ls[Entidad]()
  - **OBLIGATORIO:** Métodos que muestran tablas DEBEN usar nomenclatura `ls[Entidad]()`
  - Carga datos de la tabla utilizando createTable(), incluyendo paginación y configuración responsiva.
  - Ejemplos: `ls()`, `lsPedidos()`, `lsVentas()`, `lsClientes()`
  - **CRÍTICO - Theme por defecto:** Toda tabla creada con `createTable()` o `createCoffeTable3()` DEBE usar `theme: 'corporativo'`. NO usar `'shadcdn'`, `'light'`, `'dark'` ni ningún otro theme a menos que el usuario lo solicite explícitamente.
    > **Excepción ya decidida:** en módulos del producto **Huubie dark** la tabla va con `theme: 'dark'` — ver "🚨 Regla de theme en módulos con tabLayout (BLOQUEANTE)", que es la que manda cuando el theme del módulo ya está definido. `'corporativo'` es el default de un módulo nuevo sin indicación, no una obligación por encima de esa tabla.
```javascript
  // Método principal del módulo
  ls() {
        let rangePicker = getDataRangePicker("calendar");

        this.createTable({
            parent     : `container${this.PROJECT_NAME}`,
            idFilterBar: `filterBar${this.PROJECT_NAME}`,// importante siempre incluirla
            data: { opc: "ls", fi: rangePicker.fi, ff: rangePicker.ff },
            conf       : { datatable: true, pag: 10 },
            coffeesoft : true,
            attr: {
                id      : `tb${this.PROJECT_NAME}`,
                theme   : 'corporativo',
                title   : 'Lista de registros',
                subtitle: '',
                center  : [1, 2,  7, 8,9,10,11],
                right   : [4,5,6],
                extends : true,
            },
        });
    }

  // Ejemplo de método específico para entidad
  lsPedidos() {
        this.createTable({
            parent     : `container-pedidos`,
            idFilterBar: `filterBar${this.PROJECT_NAME}`,
            data: { opc: "lsPedidos" },
            conf       : { datatable: true, pag: 15 },
            coffeesoft : true,
            attr: {
                id      : `tbPedidos`,
                theme   : 'corporativo',
                title   : '📊 Lista de Pedidos',
                subtitle: 'Pedidos registrados en el sistema',
                center  : [1, 2, 3, 4],
                right   : [5],
            },
        });
    }
```

#### `conf` de createTable — usar los defaults, NO envolverlos

`createTable` ya trae estos valores por defecto; en `conf` se declara **solo lo que cambia** (normalmente `pag`):

| Clave | Default | Cuándo declararla |
|---|---|---|
| `datatable` | `true` | Solo para apagarla (`false`) en tablas que no paginan |
| `fn_datatable` | `'simple_data_table'` | Solo si la tabla necesita otra config de DataTables **que ya exista en `plugins.js`** (ej. `simple_data_table_filter`, con buscador y `lengthMenu`) |
| `beforeSend` | `true` | Solo para apagar el Loading |
| `pag` | `15` | Cuando el módulo quiere otro tamaño de página |

**PROHIBIDO: funciones wrapper que solo reenvían al framework.** No crear helpers locales tipo:

```javascript
// ❌ NO: wrapper que solo reenvía, y un fn_datatable que apunta a él
function dataTableCatalogos(id, pag) {
    if (!$(id).length) return;

    if (typeof simple_data_table === 'function') simple_data_table(id, pag);
}
```

```javascript
// ✅ SÍ: dejar el default de createTable
conf: {
    pag: 12
}
```

El guard `if (!$(id).length) return` no hace falta: cuando el listado sale vacío, `createCoffeTable3`
escribe el aviso de vacío en lugar de un `<table>`, y `simple_data_table` sobre un id inexistente **no
lanza error ni deja paginación colgando** — tampoco con una página guardada en `sessionStorage` (el caso
en que `getPageDataTable` llama a `table.page(n).draw(false)`). Verificado en navegador.

> **Regla general:** antes de escribir un helper que envuelva una función o componente del framework,
> comprobar que el default no hace ya el trabajo. Si de verdad falta comportamiento, va **dentro** del
> componente en `coffeeSoft.js` (ver `new-component.md`), no como wrapper suelto en el módulo.

- add[Entidad]()
  - `createModalForm()`: abre un modal con bootbox y renderiza el formulario dentro (bootbox + createForm)
  - `createForm()`: renderiza el formulario en cualquier contenedor del DOM
  - Ambos son válidos según el contexto de uso.
  - **CRÍTICO:** `createModalForm` ya incluye botones de aceptar/cancelar en el modal. **NUNCA** agregar `opc: "btn-submit"` en el `json[Entidad]()` cuando se use con `createModalForm`. Solo agregar `opc: "btn-submit"` cuando se use `createForm`.
  ```javascript
      add[Entidad]() {
        this.createForm({
            parent: "addForm",
            id: "formEntidad",
            data: { opc: "add" },
            json: this.json[Entidad](),

            success: (response) => {
                if (response.status == 200) {

                alert({
                      icon: "success",
                      title: "Pedido creado con éxito",
                      text: response.message,
                      btn1: true,
                      btn1Text: "Aceptar"
                  });

              } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });

        // extras.
        $("#lblCliente").addClass("border-b p-1");
      }
  ```


- edit(id)
  - usa async en las funciones
  - Realiza una consulta asincrónica useFetch({ opc: 'get', id: id }).
  - Posteriormente despliega un formulario modal de edición, usando autofill para precargar los datos obtenidos.
  - El formulario, al ser enviado, debe ejecutar el flujo opc: 'edit'.

    ```javascript
      async edit[Entidad](id) {
            
        const request = await useFetch({ url: this._link, data: { opc: "get", id } });
        this.createForm({
            parent: "formEditPedido",
            id: "formPedido",
            data: { opc: "edit", id },
            autofill: request,
            json: this.json(),
            success: (response) => {

              if (response.status == 200) {
                    alert({
                        icon: "success",
                        title: "Pedido actualizado",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Aceptar"
                    });
              } else {
                    alert({
                        icon: "error",
                        text: response.message,
                        btn1: true,
                        btn1Text: "Ok"
                    });
                }
            }
        });

      }
  ```
-json[Entidad]
  - Genera un objeto JSON con los datos del formulario, y los devuelve.
  - `tipo`: usa el plugin `validation_form` para validar el campo (ej: `"texto"`, `"tel"`, `"email"`)
  - `type`: usa el atributo nativo HTML del input (ej: `"date"`, `"time"`)
  - Ambos pueden coexistir en el mismo objeto según la necesidad.
  - El objeto JSON debe tener el siguiente formato:
  ```javascript
   jsonOrder() {
        return [
            {
                opc: "label",
                id: "lblCliente",
                text: "Información del cliente",
                class: "col-12 fw-bold text-lg mb-2  p-1"
            },
            {
                opc: "input",
                lbl: "Nombre del cliente",
                id: "name",
                tipo: "texto",
                class: "col-12 col-sm-6 col-lg-4 mb-3"
            },
            {
                opc: "input",
                lbl: "Teléfono",
                id: "phone",
                tipo: "tel",
                class: "col-12 col-sm-6 col-lg-4 mb-3"
            },
            {
                opc: "input",
                lbl: "Correo electrónico",
                id: "email",
                tipo: "email",
                class: "col-12 col-sm-6 col-lg-4 mb-3",
                required: false
            },

            {
                opc: "input",
                lbl: "Fecha de cumpleaños",
                id: "date_birthday",
                type: "date",
                class: "col-12 col-sm-6 col-lg-4 mb-3"
            },

            {
                opc: "label",
                id: "lblPedido",
                text: "Datos del pedido",
                class: "col-12 fw-bold text-lg  mb-2 p-1"
            },


            {
                opc: "input",
                lbl: "Fecha de entrega",
                id: "date_order",
                type: "date",
                class: "col-12 col-lg-3 mb-3"
            },

            {
                opc: "input",
                lbl: "Hora de entrega",
                id: "time_order",
                type: "time",
                class: "col-12  col-lg-3 mb-3"
            },



            {
                opc: "textarea",
                id: "note",
                lbl: "Notas adicionales",
                rows: 3,
                class: "col-12 mb-3"
            },



            {
                opc: "btn-submit",
                id: "btnGuardarPedido",
                text: "Guardar Pedido",
                class: "col-12  offset-md-8 offset-lg-6 col-md-2 col-lg-3 "
            },
            {
                opc: "button",
                id: "btnRegresar",
                text: "Salir",
                class: "col-12 col-lg-3 col-md-2 ",
                className: 'w-full',
                icono: "fas fa-arrow-left",
                color_btn: "danger",
                onClick: () => order.init()
            },
        ];

    }
  ```

- cancel(id)
  - Utiliza swalQuestion() para confirmar la cancelación de un registro, y luego envía la acción opc: 'cancel'.

  ``` javascript
    cancelOrder(id) {
        const row = event.target.closest('tr');
        const folio = row.querySelectorAll('td')[0]?.innerText || '';

        this.swalQuestion({
            opts: {
                title: `¿Esta seguro?`,
                html: `¿Deseas cancelar la reservación con folio <strong>${folio}</strong>?
                Esta acción actualizará el estado a "Cancelado" en la tabla [reservaciones].`,
            },
            data: { opc: "cancelOrder", status: 4, id: id },
            methods: {
                request: (data) => {
                    alert({
                        icon: "success",
                        title: "Cancelado",
                        text: "El pedido fue cancelado exitosamente.",
                        btn1: true
                    });

                    this.ls();
                },
            },
        });
    }
  ```


**Consideraciones Finales**
- Usa los pivotes y templates para generar las funciones
- **CRÍTICO:** Siempre usar `ls[Entidad]()` para métodos que muestran tablas
- Mantener consistencia entre Frontend (JS), Controlador (CTRL) y Modelo (MDL)
- Los métodos `render[Nombre]()` solo para componentes complejos (dashboards, gráficas, etc.)
- Esta nomenclatura es OBLIGATORIA para mantener la consistencia del framework CoffeeSoft

### Comentarios separadores de módulos

**OBLIGATORIO:** Para separar clases o secciones lógicas dentro del archivo, usar comentarios cortos de **una sola línea** con el formato:

```javascript
// -- Nombre --
```

- Colocar antes de cada clase principal (`App`, submódulos) y antes de bloques de funciones auxiliares globales si los hay.
- Mantenerlos breves: 1–3 palabras descriptivas entre los guiones.
- NO usar bloques con `===`, banners de varias líneas, ni `/* ... */` extensos.
- NO añadir descripciones extra como `— Estructura con tabs` después del nombre.

✅ **CORRECTO:**
```javascript
// -- Clase principal --
class App extends Templates { ... }

// -- Usuarios --
class Usuarios extends Templates { ... }

// -- Roles --
class Roles extends Templates { ... }
```

❌ **INCORRECTO:**
```javascript
// ============================================================
// CLASE PRINCIPAL — Estructura con tabs
// ============================================================
class App extends Templates { ... }

/* ===== USUARIOS ===== */
class Usuarios extends Templates { ... }

//////////////// ROLES ////////////////
class Roles extends Templates { ... }
```

> **Regla:** Esta es la **única** forma permitida de comentarios separadores de módulo dentro de archivos JS del framework CoffeeSoft. Aplica tanto a archivos nuevos como a refactors.