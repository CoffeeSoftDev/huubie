# COFFEE-MAGIC — Router de Steering para el agente CoffeeMagic

> Este archivo es la **carta de invocacion** de CoffeeMagic dentro del sistema Kiro Steering.
> No contiene los grimorios completos — describe **cuando** llamarlo, **donde** viven sus grimorios y **que spells** ofrece, para que cualquier asistente (CoffeeIA, KIRBY, etc.) sepa delegar UIs visuales a CoffeeMagic.

---

## 1. Cuando invocar a CoffeeMagic

Delegar a CoffeeMagic (`Agent(subagent_type=CoffeeMagic, ...)`) cuando la peticion del usuario sea **Fase 1 visual** (mockup HTML estatico para aprobacion antes de integrar con backend).

### Triggers semanticos
Palabras clave o intenciones que activan la delegacion:

- **Verbos magicos:** "conjurar", "conjura", "invocar", "hechizo", "spell"
- **Sustantivos UI:** "template", "templates", "mockup", "demo HTML", "UI estatica", "interfaz visual"
- **Componentes:** "modal", "hub de navegacion", "sidebar", "cards", "dashboard KPI", "vista detalle", "formulario centrado", "grid calendario", "recibo"
- **Sistemas de diseno:** "Huubie UI", "huubie-ui", "ui-kit huubie", "tema huubie", "coffee-varoch", "tema varoch", "tema coffee clasico"
- **Referencias a rutas:** `coffee/ui/index.html`, `coffee/ui/css/ui-kit.css`, `coffee/ui/templates/`, `coffee/ui/modals/`

### NO invocar a CoffeeMagic cuando:
- La peticion es backend (PHP, CTRL, MDL, SQL) → usar CoffeeIA
- La peticion es JS frontend con clases CoffeeSoft (no HTML estatico) → usar FRONT-JS
- La peticion es validacion/QA → usar TESTING + agente CoffeeArcher
- Ya hay HTML existente y solo se debe modificar 1-2 lineas → editar directo, no delegar

### Forma de invocacion
```
Agent(
  subagent_type: "CoffeeMagic",
  description: "Conjurar <spell> para <modulo>",
  prompt: "<peticion del usuario, incluyendo dominio/grimorio si aplica>"
)
```

---

## 2. Mapeo dominio → grimorio

| Dominio detectado en la peticion | Grimorio a cargar |
|---|---|
| Ingresos, egresos, compras, bancos, CxC, CxP, presupuestos, finanzas | `grimorio-finanzas.md` |
| Empleados, nomina, asistencia, permisos, vacaciones, RRHH, recursos humanos | `grimorio-rrhh.md` |
| Huubie UI, huubie-ui, ui-kit huubie, tema huubie, clases `.cs-*` | `grimorio-huubie-ui.md` |
| Dominio nuevo no listado | Usar `grimorio-finanzas.md` como base, NO mezclar con huubie-ui salvo peticion explicita |

---

## 3. Rutas de resolucion de grimorios (orden)

CoffeeMagic busca cada grimorio en este orden — el **primer match gana**:

1. **Proyecto (versionado):** `<proyecto>/.kiro/steering/grimorios/grimorio-X.md`
2. **Kiro steering global:** `~/.kiro/steering/grimorios/grimorio-X.md`
3. **Claude steering global:** `~/.claude/steering/grimorios/grimorio-X.md`
4. **Agente global (legacy):** `~/.claude/agents/grimorios/grimorio-X.md`
5. **Local agente:** `.claude/agents/grimorios/grimorio-X.md`
6. **Fallback Glob:** `**/grimorio-X.md`

> Las copias en steering (kiro o claude) son la **fuente canonica**. Las copias en `agents/grimorios/` se conservan como fallback de compatibilidad.

---

## 4. Catalogo de spells

Los 10 spells de CoffeeMagic (referencia rapida — ver el agente para detalle):

| # | Spell | Que genera | Referencia tipica |
|---|---|---|---|
| 1 | `conjure table` | Tabla con filtros + paginacion + sidebar + header | `finanzas-ingresos.html`, `rrhh-personal.html` |
| 2 | `conjure detail` | Vista split: tabla resumen + panel lateral 420px | `finanzas-compras-detalle.html` |
| 3 | `conjure cards` | Dashboard con KPI cards (grid 3x2, 2x2) | `finanzas-ingresos-detalle.html`, `rrhh-resumen.html` |
| 4 | `conjure form` | Formulario centrado o modal con `.input-modal` | `finanzas-ingresos-efectivo.html` |
| 5 | `conjure modal` | Overlay + card centrada (400/520/600/720px) | `templates/modals/*` |
| 6 | `conjure selector` | Modal con grid de opciones (2 columnas) | `modal-seleccionar-ingreso.html` |
| 7 | `conjure hub` | Landing con grid de cards navegables + toggle tema | `finanzas-index-navegacion.html` |
| 8 | `conjure recibo` | Card recibo + panel lateral de items | `rrhh-nomina-recibo.html` |
| 9 | `conjure grid` | Grid tipo calendario con celdas clickeables | `rrhh-incidencia-personalizado.html` |
| 10 | `conjure sidebar` | Sidebar w-56 con logo + menu + submenu + footer | Sidebar comun |

---

## 5. Reglas de tema (resumen)

| Peticion | Comportamiento |
|---|---|
| Sin mencion de tema | Genera AMBOS (light + dark) con toggle + localStorage |
| "tema light" / "modo claro" | SOLO light (sin toggle) — usa **coffee-varoch** por defecto |
| "tema dark" / "modo oscuro" | SOLO dark (sin toggle) |
| "tema varoch" / "coffee-varoch" | Paleta Varoch en ambos modos |
| "tema coffee clasico" / "paleta clasica" | Paleta light original (no varoch) |
| "Huubie UI" / "huubie-ui" | Sistema `.cs-*` dark unico (NO toggle, NO light) |

---

## 6. Estructura de salida estandar

```
[nombre-modulo]/
├── templates/
│   ├── [modulo]-index-navegacion.html    # Hub de demos (SIEMPRE)
│   ├── [modulo]-[seccion].html           # Templates principales
│   ├── [modulo]-[seccion]-detalle.html   # Vistas detalle
│   └── modals/
│       ├── modal-[accion].html
│       ├── modal-confirmacion.html
│       └── modal-[selector].html
```

---

## 7. Integracion con CoffeeIA

Cuando CoffeeIA esta en Fase 1 del WORKFLOW (Diseno con aprobacion) y la salida esperada incluye HTML/UI, delegar a CoffeeMagic en vez de generar HTML directamente. CoffeeIA conserva el control de:

- Comprension del problema (Fase 0)
- Backend (CTRL + MDL + SQL)
- JS frontend con clases CoffeeSoft (Fase 2/3)

CoffeeMagic devuelve los HTML; CoffeeIA los integra con el flujo MVC.

---

## 8. Mantenimiento

- Si agregas un grimorio nuevo, copialo a `~/.kiro/steering/grimorios/` y `~/.claude/steering/grimorios/`, y actualiza la tabla en **Seccion 2** de este archivo.
- Tras editar grimorios, ejecuta `/actualiza` para que `INDICE-STEERING.md` los re-indexe.
- Si cambias un trigger semantico, actualiza tambien el agente `CoffeeMagic.md` para mantener coherencia.
