# TESTING - Reglas de Validacion CoffeeSoft

## Objetivo General
Referencia completa de las validaciones que debe cumplir cualquier modulo del ERP-GV: las 47
de convenciones base (CTRL/MDL/JS/IDX) mas las 17 de transmutacion (TRM), que solo aplican a
modulos nacidos de un template HTML. Este archivo es consultado por el agente TESTER /
CoffeeArcher para verificar cumplimiento de convenciones.

## Severidades
| Nivel | Icono | Significado |
|-------|-------|-------------|
| ERROR | ❌ | Viola una regla critica, DEBE corregirse |
| WARNING | ⚠️ | No cumple convencion, DEBERIA corregirse |
| PASS | ✅ | Cumple la regla correctamente |
| SKIP | ⏭️ | No aplica para este archivo |

## Tipos de Verificacion
| Tipo | Descripcion |
|------|-------------|
| EXISTE | El patron DEBE encontrarse en el archivo |
| AUSENCIA | El patron NO DEBE encontrarse en el archivo |
| PATRON | Debe coincidir con un formato/regex especifico |
| CRUCE | Comparacion entre archivos (ctrl vs mdl) |

---

## 1. Validaciones de Controlador (CTRL) - 14 puntos

Archivo objetivo: `ctrl/ctrl-[nombre].php`

| # | ID | Regla | Tipo | Severidad | Patron |
|---|-----|-------|------|-----------|--------|
| 1 | CTRL-001 | session_start() presente | EXISTE | ⚠️ | `session_start();` |
| 2 | CTRL-002 | Guarda de POST opc | EXISTE | ❌ | `if (empty($_POST['opc'])) exit(0);` |
| 3 | CTRL-003 | Require del modelo | PATRON | ❌ | `require_once '../mdl/mdl-[nombre].php';` (profundidad variable) |
| 4 | CTRL-004 | Require de coffeSoft | PATRON | ❌ | `require_once '../../conf/coffeSoft.php';` (profundidad variable) |
| 5 | CTRL-005 | Clase ctrl extends mdl | EXISTE | ❌ | `class ctrl extends mdl` |
| 6 | CTRL-006 | NO usar ?? con $_POST | AUSENCIA | ❌ | `$_POST[` seguido de `??` |
| 7 | CTRL-007 | NO usar isset() con $_POST | AUSENCIA | ❌ | `isset($_POST[` |
| 8 | CTRL-008 | Metodos no usan nombres reservados de MDL | CRUCE | ❌ | No deben existir: `function list`, `function create`, `function update`, `function get...ById` |
| 9 | CTRL-009 | Variables en foreach no abreviadas | PATRON | ⚠️ | `foreach (... as $[1-letra])` (excepto $key) |
| 10 | CTRL-010 | NO usar _Select() | AUSENCIA | ❌ | `_Select(` o `$this->_Select(` |
| 11 | CTRL-011 | NO usar try-catch | AUSENCIA | ❌ | `try {` o `catch (` |
| 12 | CTRL-012 | Helpers con comentario Complements | PATRON | ⚠️ | `// Complements` antes de funciones fuera de la clase |
| 13 | CTRL-013 | Ultima linea correcta | EXISTE | ❌ | `$obj = new ctrl();` y `echo json_encode($obj->{$_POST['opc']}());` |
| 14 | CTRL-014 | NO PHPDoc | AUSENCIA | ⚠️ | `/**`, `@param`, `@return` |

### Detalle CTRL-001: session_start()
**✅ Correcto:**
```php
<?php
session_start();
```
**❌ Incorrecto:** Archivo sin session_start()

### Detalle CTRL-002: Guarda de POST
**✅ Correcto:**
```php
if (empty($_POST['opc'])) exit(0);
```
**❌ Incorrecto:**
```php
// Sin validacion de opc
// O usar: if (!isset($_POST['opc']))
```

### Detalle CTRL-005: Clase ctrl
**✅ Correcto:**
```php
class ctrl extends mdl {
```
**❌ Incorrecto:**
```php
class Controller extends Model {
class Ctrl extends Mdl {
```

### Detalle CTRL-006: No usar ?? con $_POST
**✅ Correcto:**
```php
$udn = $_POST['udn'];
```
**❌ Incorrecto:**
```php
$udn = $_POST['udn'] ?? 'all';
$udn = $_POST['udn'] ?? '';
```

### Detalle CTRL-007: No usar isset con $_POST
**✅ Correcto:**
```php
$udn = $_POST['udn'];
```
**❌ Incorrecto:**
```php
$udn = isset($_POST['udn']) ? $_POST['udn'] : 'all';
if (isset($_POST['udn'])) $udn = $_POST['udn'];
```

### Detalle CTRL-008: Nombres reservados de MDL
Estos nombres estan RESERVADOS para modelos y NO deben usarse en controladores:
- `list[Entidad]()` → usar `ls[Entidad]()` en su lugar
- `create[Entidad]()` → usar `add[Entidad]()` en su lugar
- `update[Entidad]()` → usar `edit[Entidad]()` en su lugar
- `get[Entidad]ById()` → usar `get[Entidad]()` en su lugar

### Detalle CTRL-009: Variables en foreach
**✅ Correcto:**
```php
foreach ($cuentas as $cuenta) {
foreach ($items as $key => $item) {
```
**❌ Incorrecto:**
```php
foreach ($cuentas as $c) {
foreach ($items as $k => $v) {
```
**Excepcion:** `$key` es aceptable.

### Detalle CTRL-010: No usar _Select()
**✅ Correcto:** `$this->_Read($sql, $data);`
**❌ Incorrecto:** `$this->_Select($sql);`

### Detalle CTRL-011: No usar try-catch
**✅ Correcto:**
```php
$result = $this->createEntidad($data);
if ($result) { return ['status' => 200]; }
return ['status' => 500];
```
**❌ Incorrecto:**
```php
try {
    $result = $this->createEntidad($data);
} catch (Exception $e) {
    return ['status' => 500];
}
```

### Detalle CTRL-013: Ultima linea
**✅ Correcto:**
```php
$obj = new ctrl();
echo json_encode($obj->{$_POST['opc']}());
```
**❌ Incorrecto:**
```php
$obj = new ctrl();
echo $obj->init(); // No usa json_encode
// O cualquier otra variante
```

---

## 2. Validaciones de Modelo (MDL) - 12 puntos

Archivo objetivo: `mdl/mdl-[nombre].php`

| # | ID | Regla | Tipo | Severidad | Patron |
|---|-----|-------|------|-----------|--------|
| 15 | MDL-001 | Requires _CRUD.php y _Utileria.php | EXISTE | ❌ | `require_once '../../conf/_CRUD.php';` y `require_once '../../conf/_Utileria.php';` |
| 16 | MDL-002 | Clase mdl extends CRUD | EXISTE | ❌ | `class mdl extends CRUD` |
| 17 | MDL-003 | Propiedad public $util | EXISTE | ❌ | `public $util;` o `public $util =` |
| 18 | MDL-004 | Propiedad $bd con prefijo correcto | PATRON | ❌ | `$this->bd = "rfwsmqex_` con `.";` al final |
| 19 | MDL-005 | Constructor inicializa $util | EXISTE | ❌ | `$this->util = new Utileria` |
| 20 | MDL-006 | Metodos no usan nombres reservados de CTRL | CRUCE | ❌ | No deben existir: `function init`, `function ls(`, `function add`, `function edit`, `function status`, `function show` |
| 21 | MDL-007 | NO usar _Select() | AUSENCIA | ❌ | `_Select(` |
| 22 | MDL-008 | NO usar try-catch | AUSENCIA | ❌ | `try {` o `catch (` |
| 23 | MDL-009 | NO PHPDoc | AUSENCIA | ⚠️ | `/**`, `@param`, `@return` |
| 24 | MDL-010 | Consultas usan {$this->bd} | PATRON | ❌ | Tablas en queries deben usar `{$this->bd}tabla` |
| 25 | MDL-011 | Placeholders ? en queries | PATRON | ❌ | Valores en WHERE deben usar `?` no variables directas |
| 26 | MDL-012 | Consultas complejas separadas | PATRON | ⚠️ | Una consulta por entidad/concepto |

### Detalle MDL-004: Prefijo de BD
**✅ Correcto:**
```php
$this->bd = "rfwsmqex_contabilidad.";
$this->bd = "rfwsmqex_ventas.";
```
**❌ Incorrecto:**
```php
$this->bd = "contabilidad.";  // Sin prefijo
$this->bd = "rfwsmqex_ventas"; // Sin punto final
```

### Detalle MDL-006: Nombres reservados de CTRL
Estos nombres estan RESERVADOS para controladores y NO deben usarse en modelos:
- `init()` → reservado para ctrl
- `ls()` (sin entidad) → reservado para ctrl
- `add[Entidad]()` → usar `create[Entidad]()` en su lugar
- `edit[Entidad]()` → usar `update[Entidad]()` en su lugar
- `status[Entidad]()` → reservado para ctrl
- `show[Entidad]()` → reservado para ctrl

### Detalle MDL-010: Uso de {$this->bd}
**✅ Correcto:**
```php
$sql = "SELECT * FROM {$this->bd}ventas WHERE id = ?";
```
**❌ Incorrecto:**
```php
$sql = "SELECT * FROM ventas WHERE id = ?";     // Sin prefijo BD
$sql = "SELECT * FROM rfwsmqex_ventas.ventas";  // Hardcodeado
```

### Detalle MDL-011: Placeholders
**✅ Correcto:**
```php
$sql = "SELECT * FROM {$this->bd}ventas WHERE udn = ? AND fecha BETWEEN ? AND ?";
$this->_Read($sql, [$udn, $fi, $ff]);
```
**❌ Incorrecto:**
```php
$sql = "SELECT * FROM {$this->bd}ventas WHERE udn = '$udn'"; // Inyeccion SQL
$sql = "SELECT * FROM {$this->bd}ventas WHERE udn = {$udn}"; // Variable directa
```

---

## 3. Validaciones de Frontend JavaScript (JS) - 13 puntos

Archivo objetivo: `js/[nombre].js`

| # | ID | Regla | Tipo | Severidad | Patron |
|---|-----|-------|------|-----------|--------|
| 27 | JS-001 | Clase App extends Templates | EXISTE | ❌ | `class App extends Templates` |
| 28 | JS-002 | Constructor con PROJECT_NAME | EXISTE | ❌ | `this.PROJECT_NAME =` |
| 29 | JS-003 | Metodo render() presente | EXISTE | ❌ | `render()` o `render ()` como metodo de clase |
| 30 | JS-004 | Metodo layout() presente | EXISTE | ❌ | `layout()` o `layout ()` como metodo de clase |
| 31 | JS-005 | Metodo filterBar() presente | EXISTE | ⚠️ | `filterBar()` como metodo de clase |
| 32 | JS-006 | Tablas usan ls[Entidad]() | PATRON | ❌ | Metodos de tabla deben ser `ls` o `ls[Entidad]`, NO `render[X]`, `show[X]`, `display[X]` |
| 33 | JS-007 | createTable incluye idFilterBar | PATRON | ⚠️ | `idFilterBar:` dentro de llamadas a `createTable` |
| 34 | JS-008 | edit es async con useFetch | PATRON | ⚠️ | Metodos `edit` deben usar `async` y `useFetch` |
| 35 | JS-009 | cancel usa swalQuestion | PATRON | ⚠️ | Metodos `cancel` deben llamar `swalQuestion` |
| 36 | JS-010 | NO usar IIFE | AUSENCIA | ❌ | `(async () =>` como wrapper principal |
| 37 | JS-011 | Wrapper jQuery | EXISTE | ❌ | `$(async () =>` o `$(function` |
| 38 | JS-012 | Variables globales let api, let app | EXISTE | ❌ | `let api =` y `let app` |
| 39 | JS-013 | NO JSDoc excesivo | AUSENCIA | ⚠️ | Bloques `/** ... */` con `@param` o `@returns` |

### Detalle JS-001: Clase principal
**✅ Correcto:**
```javascript
class App extends Templates {
    constructor(link, div_modulo) {
        super(link, div_modulo);
        this.PROJECT_NAME = "NombreModulo";
    }
}
```
**❌ Incorrecto:**
```javascript
class App { // Sin extends Templates
class NombreApp extends Templates { // Debe ser "App"
```

### Detalle JS-006: Metodos de tabla
**✅ Correcto:**
```javascript
ls() { }
lsPedidos() { }
lsVentas() { }
```
**❌ Incorrecto:**
```javascript
renderPedidos() { }  // NO "render" para tablas
showVentas() { }     // NO "show" para tablas
displayClientes() { } // NO "display" para tablas
```

### Detalle JS-010/JS-011: Wrapper
**✅ Correcto:**
```javascript
$(async () => {
    app = new App(api, "root");
    app.render();
});
```
**❌ Incorrecto:**
```javascript
(async () => {
    app = new App(api, "root");
    app.render();
})();
```

### Detalle JS-012: Variables globales
**✅ Correcto:**
```javascript
let api = 'ctrl/ctrl-nombre.php';
let app;
```
**❌ Incorrecto:**
```javascript
const api = 'ctrl/ctrl-nombre.php'; // Debe ser let
var app; // Debe ser let
```

---

## 4. Validaciones de Index.php (IDX) - 8 puntos

Archivo objetivo: `index.php` (raiz del modulo)

| # | ID | Regla | Tipo | Severidad | Patron |
|---|-----|-------|------|-----------|--------|
| 40 | IDX-001 | session_start() al inicio | EXISTE | ❌ | `session_start();` |
| 41 | IDX-002 | Validacion cookie IDU | EXISTE | ❌ | `$_COOKIE["IDU"]` con redirect a logout |
| 42 | IDX-003 | Orden head.php antes de core-libraries | PATRON | ❌ | `head.php` aparece ANTES que `core-libraries.php` |
| 43 | IDX-004 | coffeeSoft.js nombre exacto | PATRON | ❌ | `coffeeSoft.js` (c minuscula, S mayuscula) |
| 44 | IDX-005 | plugins.js no plugin-forms.js | PATRON | ❌ | Usar `plugins.js`, NO `plugin-forms.js` ni `plugin-table.js` |
| 45 | IDX-006 | CDN complementos.js | EXISTE | ⚠️ | `plugins.erp-varoch.com/ERP/JS/complementos.js` |
| 46 | IDX-007 | Estructura HTML correcta | PATRON | ❌ | `<main>` → `<section id="sidebar">` → `<div id="main__content">` → `id="root"` |
| 47 | IDX-008 | Cache busting en scripts | PATRON | ⚠️ | `?t=<?php echo time(); ?>` en scripts del modulo |

### Detalle IDX-002: Validacion de sesion
**✅ Correcto:**
```php
if (empty($_COOKIE["IDU"])) {
    require_once('../acceso/ctrl/ctrl-logout.php');
    exit();
}
```
**❌ Incorrecto:**
```php
// Sin validacion de cookie
// O usar $_SESSION en lugar de $_COOKIE["IDU"]
```

### Detalle IDX-003: Orden de carga
**✅ Correcto:**
```php
<?php require_once('layout/head.php'); ?>
<?php require_once('layout/core-libraries.php'); ?>
<script src="../src/js/coffeeSoft.js"></script>
```
**❌ Incorrecto:**
```php
<?php require_once('layout/core-libraries.php'); ?>
<?php require_once('layout/head.php'); ?>  <!-- Orden invertido -->
```

### Detalle IDX-004: Nombre exacto de coffeeSoft.js
**✅ Correcto:** `coffeeSoft.js`
**❌ Incorrecto:** `coffeSoft.js`, `CoffeeSoft.js`, `coffesoft.js`

### Detalle IDX-007: Estructura HTML
**✅ Correcto:**
```html
<main>
    <section id="sidebar"></section>
    <div id="main__content">
        <div class="main-container" id="root"></div>
    </div>
</main>
```

---

## 5. Validaciones de Transmutacion (TRM) - 17 puntos

Aplica cuando el modulo nace de una **transmutacion** (template HTML de CoffeeMagic o boceto
aprobado -> modulo coffeeSoft). Estas reglas salieron del analisis de las correcciones reales
del usuario sobre modulos transmutados (facture, facturador, control-fogaza, anuncios).
No sustituyen a CTRL/MDL/JS/IDX: se validan **ademas**.

Archivos objetivo: `src/js/*.js`, `ctrl/*.php`, `mdl/*.php` del modulo transmutado.

| # | ID | Regla | Tipo | Severidad | Patron |
|---|-----|-------|------|-----------|--------|
| 48 | TRM-001 | Tablas con componente, no HTML a mano | AUSENCIA | ❌ | `<table`, `<thead`, `<tbody` dentro de un JS de modulo. Debe usarse `createTable` (o `coffeeTable3`) |
| 49 | TRM-002 | Layout canonico con primaryLayout | EXISTE | ❌ | `primaryLayout(` en `layout()` de la clase orquestadora, con `heightPreset: 'full'` y `card.filterBar.id = 'filterBar'` |
| 50 | TRM-003 | Metodos que pintan listas se llaman ls[Entidad] | PATRON | ❌ | Refuerzo de JS-006: `renderTabla`, `renderLista`, `paint*`, `pintar*` que inyectan filas |
| 51 | TRM-004 | Formularios con createModalForm | EXISTE | ⚠️ | Modal con `<form>`/inputs armados a mano en template string |
| 52 | TRM-005 | filterBar minima | AUSENCIA | ⚠️ | Input de "buscar" (lo da createTable), boton "limpiar filtros", borde/`border` en el contenedor de la filterBar |
| 53 | TRM-006 | Filtros de fecha con rangePicker | PATRON | ⚠️ | `<input type="date">` suelto o selects mes/anio a mano donde toca `rangePicker` |
| 54 | TRM-007 | Sin colores hex hardcodeados en JS | AUSENCIA | ❌ | `#RRGGBB` en JS del modulo. Van en el CSS del modulo o en tokens del tema |
| 55 | TRM-008 | Tema coherente container/componentes | CRUCE | ❌ | Fondo del container vs `theme` de tabLayout/createTable/createModalForm (ver CLAUDE.md del proyecto). Nunca container `#1F2A37` con contenido light ni al reves |
| 56 | TRM-009 | Cards/KPI sin borde y compactas | PATRON | ⚠️ | `border` en cards de KPI; padding/tipografia por encima de la escala del modulo de referencia |
| 57 | TRM-010 | Estados de vista completos | EXISTE | ⚠️ | Cada vista con datos remotos necesita loading, empty-state y notas/leyendas que solo aparecen si hay registros |
| 58 | TRM-011 | Cobertura del template fuente | CRUCE | ❌ | Cada tab/seccion del HTML de origen existe en el modulo. Sin secciones perdidas en la transmutacion |
| 59 | TRM-012 | SAMPLE completo o ausente | PATRON | ⚠️ | `SAMPLE_[ENTIDAD]` debe traer TODOS los campos y el volumen del template. Si el modulo ya consulta BD, los samples se eliminan |
| 60 | TRM-013 | Backend real conectado | CRUCE | ❌ | Cada vista tiene su accion en ctrl y su consulta en mdl. Sin datos inventados dentro del JS |
| 61 | TRM-014 | Columnas fieles al documento fuente | CRUCE | ⚠️ | Columnas y orden segun ERS/Excel/boceto, no una version reducida |
| 62 | TRM-015 | Botones vivos y con icono en tablas | PATRON | ⚠️ | Boton renderizado sin handler; boton de accion en tabla con texto en vez de solo icono |
| 63 | TRM-016 | lucide.createIcons() tras cada render | PATRON | ❌ | Bloque que inyecta `data-lucide` sin llamada posterior a `lucide.createIcons()` |
| 64 | TRM-017 | Comentarios segun FRONT-JS | AUSENCIA | ⚠️ | Solo separadores `// -- Nombre --`. Prohibido `// ====`, descriptor sobre `class X`, JSDoc y comentarios que narran cambios |

### Detalle TRM-001: Tablas con componente
**✅ Correcto:**
```javascript
lsBitacora() {
    this.createTable({ parent: 'containerBitacora', id: 'tblBitacora', idFilterBar: 'filterBarCargas', json: data, columns: [...] });
}
```
**❌ Incorrecto:**
```javascript
renderBitacora() {
    $('#containerBitacora').html(`<table class="w-full"><thead>...</thead><tbody>${rows}</tbody></table>`);
}
```

### Detalle TRM-007: Colores hardcodeados
**❌ Incorrecto:** `<div style="background:#1C64F2">` dentro del JS.
**✅ Correcto:** clase del CSS del modulo (`.facture-group-head`) o token del tema.
El azul por defecto de Tailwind/Flowbite (`#1C64F2`, `blue-600`) es la fuga mas comun al
transmutar: no pertenece a ninguna paleta del ecosistema.

### Detalle TRM-011: Cobertura del template
Antes de dar por buena la transmutacion, listar los tabs/secciones del HTML fuente y
cruzarlos uno a uno con los del modulo. Una transmutacion parcial es un fallo critico,
no un pendiente.

### Detalle TRM-013: Backend real
**❌ Incorrecto:** la vista pinta `SAMPLE_VENTAS` y no existe `ctrl-[modulo]-ventas.php`.
**✅ Correcto:** `useFetch` -> accion del ctrl -> metodo del mdl con `{$this->bd}` y placeholders.
Un modulo "transmutado" que solo pinta samples esta en fase maqueta, y debe reportarse asi.

---

## Formato de Reporte

El agente TESTER genera reportes con este formato:

```
# Reporte de Validacion - [nombre-modulo]
Fecha: [fecha]

## Resumen
| Categoria | Total | ✅ | ❌ | ⚠️ | ⏭️ |
|-----------|-------|----|----|----|-----|

## Resultado: XX/47 validaciones base (+ XX/17 TRM si es transmutacion)

## Fallos Detectados
### [ID] - [Regla]
- **Linea:** X
- **Actual:** `codigo encontrado`
- **Esperado:** `codigo correcto`
- **Referencia:** [steering file], seccion [nombre]
```

---

## Reglas CRITICAS

**CRITICO:** Estas son las reglas mas importantes que NUNCA deben violarse:
1. CTRL-006/007: Asignacion directa de $_POST, sin ?? ni isset()
2. CTRL-010/MDL-007: Solo _Read() para SELECT, NUNCA _Select()
3. CTRL-008/MDL-006: Separacion estricta de nombres entre ctrl y mdl
4. CTRL-011/MDL-008: Sin try-catch, usar condicionales
5. JS-006: Tablas SIEMPRE con ls[Entidad](), nunca render/show/display
6. IDX-004: coffeeSoft.js con c minuscula y S mayuscula

**CRITICO en transmutaciones** (las que mas se corrigen a mano despues):
7. TRM-001: tabla armada con `<table>` en el JS en vez de createTable/coffeeTable3
8. TRM-002: sin primaryLayout (el modulo no hereda el shell del proyecto)
9. TRM-011: secciones del template que se perdieron en la transmutacion
10. TRM-013: vista que sigue pintando samples sin ctrl/mdl detras
11. TRM-007: hex hardcodeados en el JS (tipico `#1C64F2` azul Flowbite)
