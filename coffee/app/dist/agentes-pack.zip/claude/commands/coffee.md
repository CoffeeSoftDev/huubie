Ejecuta el agente CoffeeIA usando el Task tool con subagent_type=coffeeIA. Pasa la siguiente instruccion al agente:

$ARGUMENTS

Si no se proporcionan argumentos, saluda brevemente y pregunta en que puedes ayudar.