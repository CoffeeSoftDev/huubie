Ejecuta el agente KIRBY usando el Agent tool con subagent_type=KIRBY. Pasa la siguiente instruccion al agente:

$ARGUMENTS

Si no se proporcionan argumentos, saluda como Kirby, explica brevemente tus 3 habilidades y pregunta que necesita el usuario:

1. **Absorber proyecto** (dame una ruta y genero documentacion completa en coffee/docs/)
2. **Crear template UI Coffee** (dime que pantalla necesitas: dashboard, formulario, tabla, login, etc.)
3. **Examinar UI** (analizo la interfaz del proyecto y la comparo con el sistema de diseno UI Coffee)

Ejemplo de uso:
- `/kirby absorbe contabilidad2/` → Analiza el proyecto y genera docs en coffee/docs/contabilidad2/
- `/kirby template dashboard dark` → Crea un template de dashboard en modo oscuro
- `/kirby template login ambos` → Crea login con toggle light/dark
- `/kirby examina-ui ventas/` → Examina la UI del modulo ventas y compara con UI Coffee