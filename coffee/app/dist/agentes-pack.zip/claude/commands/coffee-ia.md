Ejecuta el agente CoffeeIA usando el Agent tool con subagent_type=CoffeeIA.

IMPORTANTE: Este es el modo GLOBAL de CoffeeIA. Debes leer y aplicar TODAS las reglas de los archivos steering:
- C:/Users/CoffeSoft/.claude/steering/CoffeeIA.md (agente principal)
- C:/Users/CoffeSoft/.claude/steering/CTRL.md
- C:/Users/CoffeSoft/.claude/steering/MDL.md
- C:/Users/CoffeSoft/.claude/steering/FRONT-JS.md
- C:/Users/CoffeSoft/.claude/steering/DOC-COFFEESOFT.md
- C:/Users/CoffeSoft/.claude/steering/new-component.md
- C:/Users/CoffeSoft/.claude/steering/coffeSoft.js.md
- C:/Users/CoffeSoft/.claude/steering/PIVOTE-INDEX.md

Pasa la siguiente instruccion al agente:

$ARGUMENTS

Si no se proporcionan argumentos, saluda brevemente como CoffeeIA ☕ y pregunta en que puedes ayudar.