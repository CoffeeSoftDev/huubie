Ejecuta el script de regeneracion del indice de steering files de CoffeeSoft.

Argumentos del usuario: $ARGUMENTS

Pasos a seguir:

1. Usa la herramienta Bash para correr exactamente este comando:
   `python C:/Users/CoffeSoft/.claude/scripts/regenerar_indice.py $ARGUMENTS`

2. Captura el output completo del script.

3. Resume al usuario con formato claro:
   - Modo ejecutado (global / local / local huubie / local erp / custom)
   - Carpetas procesadas (con su ruta)
   - Archivos renombrados (si los hubo)
   - Duplicados archivados (si los hubo)
   - Total de secciones indexadas por carpeta
   - Si fue modo `global`, confirma que CoffeeIA.md fue actualizado entre los marcadores INDEX:START/END

4. Si hay errores en el output, mostrarlos al usuario destacados.

Modos disponibles:
- `/actualiza global` - Solo ~/.claude/steering/ + embebe el indice en CoffeeIA.md
- `/actualiza local` - Todos los proyectos (Huubie raiz + Huubie inventory + ERP-GV)
- `/actualiza local huubie` - Solo Huubie (raiz + inventory)
- `/actualiza local erp` - Solo ERP-GV
- `/actualiza local <ruta>` - Carpeta personalizada

Si no se proporciona argumento, ejecuta el script sin args (mostrara la ayuda con todas las opciones).
