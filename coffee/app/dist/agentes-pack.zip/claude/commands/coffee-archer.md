Ejecuta el agente CoffeeArcher usando el Agent tool con subagent_type=CoffeeArcher. Pasa la siguiente instruccion al agente:

IMPORTANTE: Antes de validar, DEBES leer estos archivos en orden:
1. C:/Users/CoffeSoft/.claude/steering/TESTING.md (las 47 reglas)
2. C:/Users/CoffeSoft/.claude/steering/CTRL.md
3. C:/Users/CoffeSoft/.claude/steering/MDL.md
4. C:/Users/CoffeSoft/.claude/steering/FRONT-JS.md
5. C:/Users/CoffeSoft/.claude/steering/PIVOTE-INDEX.md

Luego ejecuta las 6 fases de validacion sobre el modulo indicado, generando el reporte completo con el formato definido en el agente CoffeeArcher.

Modulo a validar: $ARGUMENTS

Si no se proporcionan argumentos, saluda como Coffee Archer, presenta las 6 fases de validacion y pide la ruta del modulo a validar.

Ejemplo de uso:
- `/coffee-archer nomina/` -> Valida el modulo nomina completo
- `/coffee-archer contabilidad2/` -> Valida contabilidad2
- `/coffee-archer coffee/calidad/` -> Valida el modulo calidad